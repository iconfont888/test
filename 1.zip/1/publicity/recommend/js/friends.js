$(document).ready(function () {
    $(document).ready(function () {
        $(".select-btn").on("click", function () {
            $(this).parent().toggleClass('toggle-box');
        });

        var rangeSlider = function () {
            var slider = $('.range-slider'),
                range = $('.range-slider__range'),
                value = $('.range-slider__value');

            var valueA;

            slider.each(function () {

                value.each(function () {
                    var value = $(this).prev().attr('value');
                    //$(this).html(value);
                });
                //value.html('<em class="emdig">' + 0 + '</em>（好友本周投注额）');

                range.on('input', function () {
                    valueA = dealNumber(this.value);

                    $(this).next(value).find('.emdig').html(valueA);
                    $(this).css('background', 'linear-gradient(to right, #f65a38, #ff2b39, white ' + this.value * 0.0000001 + '%, #f7ede6)');
                    var tdes = this.value * 0.000000092;
                    if(tdes <= 58) {
                        $(this).next(value).css('left', tdes + '%');
                    } else {
                        $(this).next(value).find('.arrow').css('margin-left', (tdes-58)*2.2 + '%');
                    }

                    $(this).parents(".range-slider").siblings("p").find(".num-earnings").html(dealNumber(this.value * 0.001));
                });
            });
        };

        rangeSlider();

        //数字格式化
        var dealNumber = function (money) {
            if (money && money != null) {
                money = String(money);
                var left = money.split('.')[0], right = money.split('.')[1];
                right = right ? (right.length >= 2 ? '.' + right.substr(0, 2) : '.' + right + '0') : '.00';

                var temp = left.split('').reverse().join('').match(/(\d{1,3})/g);
                return (Number(money) < 0 ? "-" : "") + temp.join(',').split('').reverse().join('') + right;
            } else if (money === 0) {
                return '0.00';
            } else {
                return "";
            }
        };
    });

	// 已送出金额等三个
    number();
    
    $(".friend-btn").on('click',function(e){//试玩登录情况下  点击邀请好友弹出登录框
        if(AG_INIT.isLogin() && pn.userType == 1){
            window.open(window.location.origin + '/ucenter/recommend/statis');
        }else{
            $('#regModal').modal('hide');
            $('#loginModal').modal({
                "backdrop": true,
                "show": true
            });
            $('#loginModal').find('.modal-content').hide();
            $('.sign-in-wrap').fadeIn('fast').find('.nav-tabs li').removeClass('active');
            $('a[href="#quick-login"]').tab("show");
        }
    });

});

// 已送出金额等三个
function number() {
	$.ajax({
		url: "/api/friends/number",
		type: "get",
		dataType: "json",
        headers: {
            "X-Website-Code":"MAIN_PC"
        },
		success: function (res) {
		    if(res.successful){
                $("#tSendMon").text(res.data.sendMoney);
                $("#joinFriend").text(res.data.joinFriend);
                $("#successFriend").text(res.data.successFriend);
            }else{
		        logConsole(res.message);
            }
		},
        error: function(xhr,textStatus,err){
            console.log("error: " + err);
        }
	});
}

