var gulp = require('gulp');
var argv = require('yargs').argv;
var inject = require('gulp-inject');
var uglify = require('gulp-uglify');
var minifyCss = require('gulp-minify-css');

var isDev = (argv.dev === undefined) ? false : true;
var outPath = __dirname + '/_dist';

console.log(isDev)

var headCSS = [
    "./assets/css/bootstrap.min.css",
    "./assets/css/font-awesome.min.css",
    "./assets/css/main.css",
    "./assets/css/animate.css",
    "./assets/css/custom/custom_main.css",
    "./assets/js/plugins/loading/jquery.loading.css",
    "./assets/js/kapcha/kaptcha.css",
];

var footJS = [
    "./assets/libs/html5shiv.min.js",
    "./assets/libs/respond.min.js",
    "./assets/libs/jquery/jquery-1.11.3.min.js",
    "./assets/libs/layer/layer.js",
    "./assets/js/kapcha/jquery.base64.js",
    "./assets/js/utils.js",
    "./assets/js/base.js",
    "./assets/js/login/login.js",
    "./assets/js/register.js",
    "./assets/libs/es6-sham.min.js",
    "./assets/libs/wow.min.js",
    "./assets/libs/bootstrap/bootstrap.min.js",
    "./assets/js/plugins/countdown/jquery.countdown.js",
    "./assets/js/plugins/loading/jquery.loading.js",
    "./assets/libs/carousel.js",
    "./assets/libs/jquery/jquery.easing.js",
    "./assets/libs/jquery/jquery.marquee.min.js",
    "./assets/js/plugins/validate/jquery.validate.min.js",
    "./assets/js/plugins/cookie/jquery.cookie.js",
    "./assets/js/plugins/safety/jquery.md5.js",
    "./assets/js/constants/constants.js",
    "./assets/js/validatorFrom.js",
    "./assets/js/includes/sticky.js",
    "./assets/js/lib/lib.js",
    "./assets/js/jquery.mission.helper.js",
    "./assets/js/crypto-js.min.js",
    "./assets/libs/jquery/jquery.placeholder.min.js",
    "./assets/js/qr/jquery.qrcode.js",
    "./assets/js/qr/qrcode.js",
    "./assets/js/qr/utf.js",
    "./assets/js/ds/fingerprint.js",
    "./assets/js/ds/config-ds-resource.js",
    "./assets/js/ds/ds.js",
    "./assets/js/main.js",
    "./assets/js/custom/associated/associated.login.helper.js",
    "./assets/js/plugins/cookie/cookie.helper.js",
    "./assets/js/custom/helper/jquery.cms.helper.js",
    "./assets/js/ucenter/ucenterCommon.js",
    "./assets/js/home/headImage.js",
    "./assets/js/base/agcs.js",
    "./assets/js/kapcha/kaptcha.js",
    "./assets/js/webSocket/stomp.min.js",
    "./assets/js/webSocket/sockjs.min.js",
    "./assets/js/webSocket/webMessage.js",
    "./assets/js/webSocket/tipMessage.js",
    "./assets/js/publicity/sticky.js",
]

// css
gulp.task('css', function() {
    return gulp.src('./**/*.css')
        .pipe(minifyCss())
        .pipe(gulp.dest(outPath));
});

// js
gulp.task('js', function() {
    return gulp.src(['./**/*.js', '!./node_modules/**/*.js'])
        .pipe(uglify())
        .pipe(gulp.dest(outPath));
});

// images
gulp.task('img', function() {
    return gulp.src(['./**/*.jpg', './**/*.png', './**/*.gif'])
        .pipe(gulp.dest(outPath));
});

// html
gulp.task('html', function() {
    return gulp.src(['./**/*.html', './**/*.htm'])
        .pipe(gulp.dest(outPath));
});

// html
gulp.task('index', function() {
    return gulp.src('./index.html')
        .pipe(inject(gulp.src(headCSS, {read: false})))
        .pipe(inject(gulp.src(footJS, {read: false})))
        .pipe(gulp.dest(outPath));
});


gulp.task('default', function() {
    console.log('first gulp');
});