$(document).ready(function() {

    hideTryGameBtn();
});

/**
 * 隐藏试玩按钮
 */
function hideTryGameBtn() {

    if(pn.userName && pn.userType == "1") {
        $("a:contains('免费试玩')").addClass("hide");
    }
}