window.onload = function(){
    if(pn.customerType === "1"){
        $.request({
            url:"/api/getXtoken",
            type: "get",
            accept: "application/json",
            dataType: "json",
            success:function (response) {
                if(response.successful){
                    startWebSocket(response.data);
                }
            },
            error: function(xhr,textStatus,err){
                console.log("error: " + err);
            }
        });
    }
};

function startWebSocket(data){
    if(!_VALID.isNormal(data)){
        return;
    }
    var tigerMessageUrl = data.url;
    var xToken = data.token;
    var stompClient = null;
    var socket = new SockJS(tigerMessageUrl+'/web/message');
    stompClient = Stomp.over(socket);
    stompClient.debug = null;
    stompClient.connect({'x-auth-token': xToken}, function () {
        stompClient.subscribe('/user/msg/receive/pc_egame',function(greeting){
            showLetter(JSON.parse(greeting.body));
        });
        stompClient.subscribe('/user/msg/receive/pc_egame/red_packet_rain', function (greeting) {
            showRedPacketRainWin(JSON.parse(greeting.body));
        });
        depositFailureMsg(stompClient);
        
        if(location.pathname=="/game/dygame/"){
            promotedMsg(stompClient);
        }
    });
}

var redPacketRainMessage = {};
function showRedPacketRainWin(message) {
    redPacketRainMessage = message;
    $.ajax({
        dataType: 'json',
        url: "/api/getTime",
        headers: {
            "X-Website-Code":"MAIN_PC"
        },
        success: function (data) {
            _now = data && data.data && data.data.serverTime;
            hongbao_rain_min();
        },
        error: function(xhr,textStatus,err){
			console.log("error: " + err);
		}
    });
}