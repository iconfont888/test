/* 红包弹窗数据 */
var _red_envelope = {};
var setRedEnvelope = function (data) {
    var remark = data.remarks || "";
    var remarks = remark.split("|");
    var option = {
        title: remarks.length > 1 ? remarks[1] : "",
        text: remarks.length > 2 ? remarks[2] : "",
        href: remarks.length > 3 ? remarks[3] : "",
        sec_content: remarks.length > 4 ? remarks[4] : "",
        sec_text: remarks.length > 5 ? remarks[5] : "",
        sec_platform: remarks.length > 6 ? remarks[6] : "",
        sec_href: remarks.length > 7 ? remarks[7] : ""
    };
    var title = option.title || '您有一个红包可领取！';
    var text, href;
    if (option.text && option.href) {
        text = option.text;
        href = option.href;
    } else {
        text = "下载亚游加速登录器，体验流畅游戏！";
        href = "/website/redirect?url=/tools/accelerator";
    }
    /* 推荐好友礼金特殊处理 */
    if (data.type === 'TJHYLJ') {
        title = '您的推荐好友奖金已发放，请及时领取！';
        text = '如有疑问请联系客服, 谢谢合作!';
        href = 'cs';
    }
    var tips;
    if (/cs/i.test(href)) {
        tips = text.replace("联系客服", "<a href='#' class='as-cs'>联系客服</a>");
    } else {
        tips = '<a target="_blank" href="' + href + '">' + text + '</a>';
    }
    var amount = data.amount;
    var content = option.sec_content || "所需有效投注: " + data.betAmount + "元";
    var button;
    if (option.sec_text && option.sec_platform && option.sec_href) {
        var hrefA = option.sec_platform !== 'EG' ? '/website/redirect?url=' + option.sec_href : option.sec_href;
        button = '<a href="' + hrefA + '" class="btn-link btn-link2">' + option.sec_text + '</a>';
    } else {
        var hrefB = data.type !== 'EGAMEHB' ? '/' : '/game/play/ag?gameCode=500&trial=true';
        button = '<a href="' + hrefB + '" class="btn-link btn-link2">立即投注</a>';
    }

    _red_envelope = {
        tips: tips,
        first: {
            title: title
        },
        second: {
            amount: amount,
            content: content,
            button: button
        }
    };
};

$.ajaxSetup({cache: false});
var _updateBalance = function () {
    return $.request({url:"/personal/balance/totalBalance?" + (new Date() - 1)}).done(function (response) {
        var $node = $(".personal-total-balance");
        var $balance = $(".overall-balance");
        if (response.successful) {
            var formatBalance = parseFormatNum(response.data[2],2);
            $node.html("¥" + formatBalance);
            $balance.html("¥" + formatBalance);
        } else {
            $node.html("<h5>系统繁忙,请稍后再试!</h5>");
            $balance.html("<h5>系统繁忙,请稍后再试!</h5>")
        }
    }).fail(function (error) {
        $(".personal-total-balance").html("<h5>系统繁忙,请稍后再试!</h5>");
        $(".overall-balance").html("<h5>系统繁忙,请稍后再试!</h5>");
    });
};

//数字加逗号
function parseFormatNum(number,n){
    if(n != 0 ){
        n = (n > 0 && n <= 20) ? n : 2;
    }
    number = parseFloat((number + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var sub_val = number.split(".")[0].split("").reverse();
    var sub_xs = number.split(".")[1];

    var show_html = "";
    for (i = 0; i < sub_val.length; i++){
        show_html += sub_val[i] + ((i + 1) % 3 == 0 && (i + 1) != sub_val.length ? "," : "");
    }
    if(n == 0 ){
        return show_html.split("").reverse().join("");
    }else{
        return show_html.split("").reverse().join("") + "." + sub_xs;
    }

}

var _modalMiddle = function ($modal) {
    var $modal_dialog = $modal.find(".modal-dialog");
    $modal_dialog.addClass("modal-dialog-js");
    $modal.find(".modal-content").addClass("modal-dialog-js");
    var m_top = ( $(window).height() - $modal_dialog.height() ) / 2;
    $modal_dialog.css({'margin': m_top + 'px auto'});
};

if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (elt /*, from*/) {
        var len = this.length >>> 0;
        var from = Number(arguments[1]) || 0;
        from = (from < 0)
            ? Math.ceil(from)
            : Math.floor(from);
        if (from < 0)
            from += len;
        for (; from < len; from++) {
            if (from in this &&
                this[from] === elt)
                return from;
        }
        return -1;
    };
}


if (!Function.prototype.bind) {
    Function.prototype.bind = function (oThis) {
        if (typeof this !== 'function') {
            // closest thing possible to the ECMAScript 5
            // internal IsCallable function
            throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
        }

        var aArgs = Array.prototype.slice.call(arguments, 1),
            fToBind = this,
            fNOP = function () {
            },
            fBound = function () {
                return fToBind.apply(this instanceof fNOP && oThis
                    ? this
                    : oThis,
                    aArgs.concat(Array.prototype.slice.call(arguments)));
            };

        fNOP.prototype = this.prototype;
        fBound.prototype = new fNOP();

        return fBound;
    };
}

function partition(array, n) {
    return array.length ? [array.splice(0, n)].concat(partition(array, n)) : [];
}


var changeCaptcha = function (e) {
    var captcha;
    if (e && e.target && e.target.nodeName === "IMG" && $(e.target).hasClass("captcha")) {
        captcha = $(e.target);
    } else if (e && e instanceof jQuery) {
        captcha = $("img.captcha", e);
    } else {
        captcha = $("img.captcha");
    }
    captcha.each(function (index, item) {
        var $item = $(item);
        var src = $item.data("src");
        var time = new Date().getTime();
        $item.attr("src", src + "?d=" + time);
    });
};

/**
 * set(key, value) 生命周期 session
 * set(key, value, expiredays) expiredays 过期天数
 * set(key, value, Infinity) Infinity 过期时间9999年12月31日  最大值
 *
 * @type {{set: _Cookie_.set, get: _Cookie_.get, del: _Cookie_.del}}
 * @private
 */
var _Cookie_ = {
    set: function (key, value, expiredays) {
        var expire = new Date();
        expire.setTime(expire.getTime() + (expiredays || 0) * 24 * 60 * 60 * 1000);
        var expires = expire.toUTCString();
        if (expiredays === Infinity) {
            expires = "Fri, 31 Dec 9999 23:59:59 GMT";
        }
        document.cookie =
            key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; expires=" + expires)
            + "; domain=" + window.location.hostname + "; path=/;";
    },
    get: function (key) {
        var arr, reg = new RegExp("(^|\\s+)" + key + "=(.*?)(;|$)");
        if (arr = document.cookie.match(reg))
            return (arr[0]);
        else
            return null;
    },
    del: function (key) {
        if (_Cookie_.get(key)) {
            var date = new Date();
            date.setTime(date.getTime() - 10000);
            document.cookie = key + "=v; expires =" + date.toUTCString()
                + "; domain=" + window.location.hostname + "; path=/;";
        }
    }
};

$(document).ajaxError(function (event, response, settings, thrownError) {
    if (response.status == "401") {
        var message = "您已登出或者由于长时间未操作,当前登陆已失效,请重新登录!";
        if (response.responseJSON) {
            message = response.responseJSON.data;
        }
        if(message) {
            layer.open({
                title: ' ',
                btn: ['确定'],
                closeBtn: 0,
                yes: function (index) {
                    location.href = location.pathname === '' ? "/login" : "/login?redirect=" + location.pathname;
                    layer.close(index);
                },
                content: '<li class="list-group-item list-group-item-warning">' + message + '</li>'
            });
        }
    }
});

function updateRedirectUrl() {
    var protocol = location.protocol.replace(/:$/, "");
    $("a[href^='/website/redirect']").each(function (i, n) {
        var $this = $(n), href = $(n).attr("href");
        if (!/\?scheme=/.test(href)) {
            var newValue = href.replace(/\?/, "?scheme=" + protocol + "&");
            $this.attr("href", newValue);
        }
    });
}

$(function () {
    /**
     * 百度统计公共代码
     * data-tongji-attr="_trackEvent,AG8,主站,首页,首页"
     */
    $("body").on("click", '*[data-tongji-attr]', function (e) {

        var $this = $(this);
        var selectStr = $this.data("select"), matchStr = $this.data("match"), parentStr = $this.data("parent");
        if (!selectStr && !matchStr) {
            _hmt.push($this.data('tongji-attr').split(","));
            return;
        }
        var $select;
        if (!selectStr && parentStr) {
            $select = $this.parent();
        } else if (!selectStr && !parentStr) {
            $select = $this;
        } else if (selectStr && parentStr) {
            $select = $this.parents(selectStr);
        } else {
            $select = $this.find(selectStr);
        }
        if ($select.is(matchStr)) {
            _hmt.push($this.data('tongji-attr').split(","));
        }
    });

    updateRedirectUrl();

    if (typeof __message !== 'undefined' && __message) {
        layer.alert(__message, {title: ' '});
    }
    //加入收藏夹
    $('#bookmarkme').click(function (e) {
        addFavorite(location.href, $("title").text());
        e.preventDefault();
    });

    function addFavorite(url, title) {
        if (window.external && 'addFavorite' in window.external) { // IE
            window.external.addFavorite(url, title);
        } else if (window.sidebar && window.sidebar.addPanel) { // Firefox23后被弃用
            window.sidebar.addPanel(url, title);
        } else if (window.opera && window.print) { // rel=sidebar，读取a链接的href，title 注：opera也转战webkit内核了
            this.title = title;
            return true;
        } else { // webkit - safari/chrome
            layer.alert('请使用快捷键 ' + (navigator.userAgent.toLowerCase().indexOf('mac') !== -1 ? 'Command/Cmd' : 'CTRL') + ' + D 将本网站加入收藏夹.', {title: ' '});
        }
    }

    //单击更换验证码
    $("img.captcha").on("click", changeCaptcha);

//更新头部余额信息的方法
    var $accInfo = $("#btn-acc-name-setting");
    var updateTopBalance = function () {
        var $this = $accInfo, src = $this.data("load");
        $(".personal-total-balance").html('<img src="' + src + '">');
        _updateBalance().always(function () {
            setTimeout(function () {
                $accInfo.parent().one("show.bs.dropdown", updateTopBalance);
            }, 3000);
        });
    };
    //鼠标单击头部账号,显示余额
    $accInfo.parent().one("show.bs.dropdown", updateTopBalance);

    $("#logintool").on("click", function () {
        layer.alert("暂未开放,敬请期待", {title: ' '});
    });
    $(".promotion-wait").on("click", function () {
        layer.alert("活动暂未开启,敬请期待", {title: ' '});
    });


});
$(function () {

    function playGame(node) {
        var url = node.data("url"); // isTrial = !!node.data("trial");
        window.open(url, "_game");
    }

    $("body").on("click", ".play-game-js", function (t) {
        var node = $(this);
        if (node.is(".play-game-js")) {
            playGame(node);
        } else {
        }
    });
    var $callPhone = $("#callBack");

    //回拨电话
    function call() {
        var input = $callPhone.find(".call-phone-number"),
            $captcha = $callPhone.find(".input-captcha"),
            captchaValue = $.trim($captcha.val()),
            value = $.trim(input.val());
        if (value.length == 0) {
            layer.alert("请输入您的联系电话", {title: ' '});
            $callPhone.find(".call-back-btn").one("click", call);
            return;
        }

        if (!/^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$/.test(value)) {
            layer.alert("请输入11位有效手机号码", {title: ' '});
            $callPhone.find(".call-back-btn").one("click", call);
            changeCaptcha();
            return;
        }
        if (captchaValue.length == 0) {
            layer.alert("请输入验证码", {title: ' '});
            $callPhone.find(".call-back-btn").one("click", call);
            return;
        }
        if (!/^\d{4}$/.test(captchaValue)) {
            layer.alert("您输入的验证码不正确", {title: ' '});
            $callPhone.find(".call-back-btn").one("click", call);
            return;
        }
        $.request({url:"/call/callBack?phone=" + encryptByDES(value) + "&captcha=" + captchaValue + "&_d=" + (new Date() - 1)}).done(function (response) {
            // if (response.successful) {
            //     //清空验证码和电话
            //     $("#phoneCallBackForm").get(0).reset();
            // }
            layer.alert(response.data, {title: ' '});
        }).fail(function () {
            layer.alert("回拨电话时出现故障,请联系<a class='as-cs'>在线客服</a>", {title: ' '});
        }).always(function () {
            $callPhone.find(".call-back-btn").one("click", call);
        });
    }

    //  生成电话回拨
    function createSticky(data){
        // var html = '';
        // var gender = data.gender;
        // html += '<div class="left">';
        // if(data["receptionistStatus"] == 1){
        //     if(gender == 1) {
        //         html += '<img src="'+__static_url+'/static/images/others/sidebar/online-m.png" />';//男头像-在线
        //     }else {
        //         html += '<img src="'+__static_url+'/static/images/others/sidebar/online.png" />';//女头像-在线
        //     }
        // }else{
        //     if(gender == 1) {
        //         html += '<img src="'+__static_url+'/static/images/others/sidebar/offline-m.png" />';//男头像-不在线
        //     }else {
        //         html += '<img src="'+__static_url+'/static/images/others/sidebar/offline.png" />';//女头像-不在线
        //     }
        // }
        // html += '<dl>';
        // if(data["receptionistStatus"] == 1){
        //     html += '<dt>'+data["receptionistNickname"]+'<span class="online">[在线]</span></dt>';
        // }else{
        //     html += '<dt>'+data["receptionistNickname"]+'<span class="offline">[离线]</span></dt>';
        // }
        // html += '<dd>VIP客户经理</dd>';
        // html += '</dl>';
        // html += '</div>';
        // html += '<form id="phoneCallBackForm" class="form-inline">';
        // if(data["receptionistStatus"] == 1){
        //     html += '<p class="title">专属客户经理为您致电服务</p>';
        // }else{
        //     html += '<p class="title">24小时电话客服为您致电服务</p>';
        // }
        // html += '<div class="form-group">';
        // html += '<input name="phone" type="text" class="form-control call-phone-number" maxlength="11" placeholder="请输入您的手机号码">';
        // html += '</div>';
        // html += '<div class="form-group form-group-2">';
        // html += '<div class="input-group">';
        // html += '<input name="captcha" type="text" class="form-control vali-code input-captcha" maxlength="4" placeholder="请输入验证码">';
        // html += '<span class="input-group-addon captcha"><img class="captcha" data-src="/captcha" alt="captcha"></span>';
        // html += '</div>';
        // html += '</div>';
        // if (data["receptionistStatus"] == 1) {
        //     html += '<a class="btn btn-add-contact-tab1 btn-add-contact-tab2 call-back-btn"><i class="i-call"></i>经理回拨</a>';
        // } else {
        //     html += '<a class="btn btn-add-contact-tab1 call-back-btn">客服回拨</a>';
        // }
        // html += '</form>';
        // return html;
    }
    //  生成default电话回拨
    function creatDefaultSticky() {
        // var html = '';
        // html += '<div class="left"><img src="'+__static_url+'/static/images/others/sidebar/3mins_add_1.png" class="three-mins" /></div>';
        // html += '<form  id="phoneCallBackForm" class="form-inline">';
        // html += '<p class="title">24小时电话客服为您致电服务</p>';
        // html += '<div id="phoneCallBackForm" class="form-group">';
        // html += '<input name="phone" type="text" class="form-control call-phone-number" maxlength="11" placeholder="请输入您的手机号码">';
        // html += '</div>';
        // html += '<div class="form-group form-group-2">';
        // html += '<div class="input-group">';
        // html += '<input name="captcha" type="text" class="form-control vali-code input-captcha" maxlength="4" placeholder="请输入验证码">';
        // html += '<span class="input-group-addon captcha"><img class="captcha" data-src="/captcha" alt="captcha"></span>';
        // html += '</div>';
        // html += '</div>';
        // html += '<a class="btn btn-add-contact-tab1 call-back-btn">客服回拨</a>';
        // html += '</form>';
        // return html;
    }
/** end candice **/
    $callPhone.find(".call-back-btn").one("click", call);

    // getCustomerReceptionist();
    /**
     * 查询客户对应的客服经理
     */
    function getCustomerReceptionist(){
        $.ajax({
            type:"get",
            url:"/call/callBack/getCustomerReceptionist",
            headers: {
                "X-Website-Code":"MAIN_PC"
            },
            success:function (response) {
                if(response.successful){
                    var data = response.data;
                    $("#callBack").html(createSticky(data));
                    $("#callBack").find(".call-back-btn").one("click", call);
                    //  单击更换验证码
                    $("#callBack").find("img.captcha").on("click", changeCaptcha);
                }else{
                    $("#callBack").html(creatDefaultSticky());
                    $("#callBack").find(".call-back-btn").one("click", call);
                    //  单击更换验证码
                    $("#callBack").find("img.captcha").on("click", changeCaptcha);
                }
            },
            error:function () {
                $("#callBack").html(creatDefaultSticky());
                $("#callBack").find(".call-back-btn").one("click", call);
                //  单击更换验证码
                $("#callBack").find("img.captcha").on("click", changeCaptcha);
            }
        });
    }

    if (pn.customerType === "1") {
        $.request({url:"/personal/letter/new/total?" + (new Date() - 1)}).done(function (res) {
            var data = res.data;
            var noticeCount = data.notice;
            var perferentialCount = data.perferential;
            var count = noticeCount + perferentialCount;
            if (count > 0) {
                $(".badge.letter").text(count);
            } else {
                $(".badge.letter").hide();
            }
            var $yhTabs = $(".yh-tabs");
            if ($yhTabs.length) {
                setUnRead($yhTabs,perferentialCount,noticeCount);
            }
        });
    }
    //  设置未读
    function setUnRead($yhTabs,perferential,notice){
        var perferentialTag = $yhTabs.find("li[data-value=0]");
        var noticeTag = $yhTabs.find("li[data-value=1]");
        if(perferential){
            perferentialTag.append('<em class="badge">' + perferential + '</em>');
        }else{
            perferentialTag.find("em").remove();
        }
        if (notice) {
            noticeTag.append('<em class="badge">' + notice + '</em>');
        }else {
            noticeTag.find("em").remove();
        }
    }
});

/**
 * 时间对象的格式化
 * @param format yyyy-MM-dd HH:mm:ss
 */
Date.prototype.format = function (format) {

    if (this == 'Invalid Date') {
        return '';
    }
    var o = {
        "M+": this.getMonth() + 1,      // month
        "d+": this.getDate(),           // day
        "h+": this.getHours(),          // hour
        "m+": this.getMinutes(),        // minute
        "s+": this.getSeconds(),        // second
        "q+": Math.floor((this.getMonth() + 3) / 3),    // quarter
        "S": this.getMilliseconds()     // millisecond
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "")
            .substr(4 - RegExp.$1.length));
    }

    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
};

/**
 * 对Date的扩展，将 Date 转化为指定格式的String
 * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
 * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 * eg:
 * (new Date()).pattern("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
 * (new Date()).pattern("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04
 * (new Date()).pattern("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04
 * (new Date()).pattern("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04
 * (new Date()).pattern("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
 */
Date.prototype.pattern = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, //小时
        "H+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    var week = {
        "0": "/u65e5",
        "1": "/u4e00",
        "2": "/u4e8c",
        "3": "/u4e09",
        "4": "/u56db",
        "5": "/u4e94",
        "6": "/u516d"
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    if (/(E+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[this.getDay() + ""]);
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
};

Date.prototype.addDays = function (days) {
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
};


var Common = {
    /**
     * 格式化成金额形式
     *
     * @param num 数值(Number或者String)
     * @return 金额格式的字符串,如'1,234,567.45'
     * @type String
     */
    AmountFormatter: function (num) {
        if (num == undefined || num == null || num == '') {
            return 0;
        }
        var num_top = "";
        var num_tail = "";
        var result = '';
        var re = new RegExp("^(-?\\d+)(\\.\\d+)$"); // 判断是否是浮点数
        if (re.test(num)) {
            strSum = new String(num);
            if (strSum.indexOf(".") > -1) {
                num_tail = strSum.split(".")[1];
                num_top = strSum.split(".")[0];
            }
            while (num_top.length > 3) {
                result = ',' + num_top.slice(-3) + result;
                num_top = num_top.slice(0, num_top.length - 3);
            }
            if (num_top) {
                result = num_top + result + '.' + num_tail;
            }
        } else {
            num_top = new String(num);
            while (num_top.length > 3) {
                result = ',' + num_top.slice(-3) + result;
                num_top = num_top.slice(0, num_top.length - 3);
            }
            if (num_top) {
                result = num_top + result;
            }
        }
        return result;
    },
    /*
     单位
     */
    units: '个十百千万@#%亿^&~',
    /*
     字符
     */
    chars: '零一二三四五六七八九',
    /*
     数字转中文
     @number {Integer} 形如123的数字
     @return {String} 返回转换成的形如 一百二十三 的字符串
     */
    numberToChinese: function (number) {
        var a = (number + '').split(''), s = [], t = this;
        if (a.length > 12) {
            throw new Error('too big');
        } else {
            for (var i = 0, j = a.length - 1; i <= j; i++) {
                if (j === 1 || j === 5 || j === 9) {//两位数 处理特殊的 1*
                    if (i === 0) {
                        if (a[i] !== '1') s.push(t.chars.charAt(a[i]));
                    } else {
                        s.push(t.chars.charAt(a[i]));
                    }
                } else {
                    s.push(t.chars.charAt(a[i]));
                }
                if (i !== j) {
                    s.push(t.units.charAt(j - i));
                }
            }
        }
        return s.join('').replace(/零([十百千万亿@#%^&~])/g, function (m, d, b) {//优先处理 零百 零千 等
            b = t.units.indexOf(d);
            if (b !== -1) {
                if (d === '亿') return d;
                if (d === '万') return d;
                if (a[j - b] === '0') return '零'
            }
            return '';
        }).replace(/零+/g, '零').replace(/零([万亿])/g, function (m, b) {// 零百 零千处理后 可能出现 零零相连的 再处理结尾为零的
            return b;
        }).replace(/亿[万千百]/g, '亿').replace(/[零]$/, '').replace(/[@#%^&~]/g, function (m) {
            return {'@': '十', '#': '百', '%': '千', '^': '十', '&': '百', '~': '千'}[m];
        }).replace(/([亿万])([一-九])/g, function (m, d, b, c) {
            c = t.units.indexOf(d);
            if (c !== -1) {
                if (a[j - c] === '0') return d + '零' + b
            }
            return m;
        });
    }
};

//  顺序排列
var resort = function (banners, property) {
    banners = banners.sort(function (a, b) {
        return a[property] - b[property];
    });
    return banners;
};

var isBeforeToNow = function (date) {
    return compareToNowDate(date) <= 0;
};

var compareToNowDate = function (date) {
    return getTime(date) - __now;
};

var getTime = function (value) {
    return new Date(value.replace(/-/g, "/")).getTime();
};

//底部游戏搜索,展示等
$(function () {
    (function () {
        try {
            if (_wms_js && _wms_js.length) {
                var jsFile = _wms_js[0],
                    name = jsFile[_wms_key.image1];
                var url = _static_url + "static/__static/electronicgames/" + name + "?" + jsFile[_wms_key.popular];
                var hm = document.createElement("script");
                hm.src = url;
                var s = document.getElementsByTagName("script")[0];
                s.parentNode.insertBefore(hm, s);
            }

        } catch (Error) {
        }
    })();

});

(function ($, window, document, undefined) {
    var countdown = 0;
    $.fn.agcountdown = function (userOptions) {
        var $ele = this;
        /**
         * 倒计时方法
         * @param stepTime      倒计时秒
         * @param before        前置方法：执行倒计时之前执行
         * @param after         后置方法：执行倒计时之后执行
         * @param buttonText    按钮文字
         * @param defaultMsg    倒计时结束后对象的默认值
         * @param start         是否启动
         * @param reset         终止倒计时，重置到默认状态
         * @param clear         启动时先终止在运行的倒计时
         */
        var options = {
            stepTime: 60,
            before: function () {
            },
            after: function () {
            },
            buttonText: "",
            defaultMsg: "点击",
            start: true,
            reset: false,
            clear: true
        };
        $.extend(options, userOptions);
        var start = function (element, options) {
            var timer = options.stepTime;
            options.before();
            var func = function () {
                if (options.buttonText) {
                    var text = options.buttonText;
                    text = text.replace(/{}/, timer + "");
                    element.html(text);
                } else {
                    element.html(timer);
                }
                timer = timer - 1;
                if (timer < -1) {
                    if (options.defaultMsg) {
                        element.html(options.defaultMsg);
                    }
                    window.clearInterval(countdown);
                    options.after();
                }
            };
            if (countdown && options.clear) {
                window.clearInterval(countdown);
            }
            countdown = window.setInterval(function () {
                func()
            }, 1000);
            func();
        };
        var reset = function (element, options) {
            if (options.defaultMsg) {
                element.html(options.defaultMsg);
            }
            window.clearInterval(countdown);
            options.after();
        };
        if (options.start === true) {
            start(this, options)
        }
        if (options.reset === true) {
            reset(this, options);
        }
        return $ele;
    };


    //动态控制光标位置
    $.fn.selectRange = function (start, end) {
        return this.each(function () {
            if (this.setSelectionRange) {
                this.focus();
                this.setSelectionRange(start, end);
            } else if (this.createTextRange) {
                var range = this.createTextRange();
                range.collapse(true);
                range.moveEnd('character', end);
                range.moveStart('character', start);
                range.select();
            }
        });
    };
})(jQuery, window, document);


$("#copyloginName").on("click", function () {
    $('#loginName').removeAttr("disabled");
    document.getElementById('copySucces').style.visibility = 'visible';
    document.getElementById("loginName").select();
    document.execCommand('copy');
    $('#loginName').attr("disabled", "disabled");
});

function getBillTime(date) {
    var time = date.split(" ");
    var dayArray = time[0].split("-");
    return dayArray[1] + "/" + dayArray[2] + " " + time[1];
}

(function () {
    /**
     * 活动头部倒计时 - 春节活动
     */
    function activityHeaderTimer() {
        var beginTimeStr = "2018/02/15 00:00:00";
        var endTimeStr = "2018/02/19 23:59:59";
        var startTime = new Date(beginTimeStr).getTime(),
            endTime = new Date(endTimeStr).getTime(),
            s_v = startTime - new Date(_now).getTime(),
            e_v = endTime - new Date(_now).getTime();
        if (s_v > 0) {//未开始
            $(".activity-header-countdown").attr('style', 'display:block');
            var dd = parseInt(s_v / 1000 / 60 / 60 / 24);//计算剩余的天数
            var hh = parseInt(s_v / 1000 / 60 / 60 % 24);//计算剩余的小时数
            var mm = parseInt(s_v / 1000 / 60 % 60);//计算剩余的分钟数
            var ss = parseInt(s_v / 1000 % 60);//计算剩余的秒数
            dd = checkTime(dd);
            hh = checkTime(hh);
            mm = checkTime(mm);
            ss = checkTime(ss);
            var _time = (dd + hh + mm + ss).split("");
            $(".activity-header-countdown>ul>li.countdown-time").each(function (index, item) {
                $(item).text(_time[index]);
            });
        } else {
            if (e_v >= 0) {//进行中
                $(".activity-header-countdown").remove();
                $(".activity-header-ongoing").attr('style', 'display:block');
            } else {//已结束
                $(".activity-header-countdown").remove();
                $(".activity-header-ongoing").attr('style', 'display:none');
                $(".default-ad").attr('style', 'display:block');
            }
        }
    }

    /**
     * 活动倒计时
     */
    function timer() {
        var countdownStartTimeStr = "2018/02/09 00:00:00";
        var countdownStartTime = new Date(countdownStartTimeStr).getTime(),
            countdownShow_v = countdownStartTime - _now;

        if (countdownShow_v > 0) {//倒计时未开始
            $(".default-ad").attr('style', 'display:block');
        } else {
            activityHeaderTimer();
        }

        _now = _now + 1000;
    }

    function checkTime(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i + "";
    }

    setInterval(timer, 1000);
})();


/*根据注册星级展示充值按钮icon*/
$(function () {
    try {
        if (pn.customerType === "1") {
            $.ajax({
                url: "/personal/check/newly/register",
                type: "post",
                headers: {
                    "X-Website-Code":"MAIN_PC"
                },
                success: function (res) {
                    var _data = res.data, userLevel = parseInt(pn.userLevel);
                    if (userLevel > 0 || !res.successful) {
                        $('.btn.btn-default.btn-deposit').attr('class', 'btn btn-default recharge btn-deposit');
                    } else if (!res.successful) {
                        return;
                    } else if (!_data.firstDeposit && pn.userLevel === "0") {
                        $('.icon-dollar-circle').attr('class', 'gift-icon');
                    } else if (localStorage.getItem("key") === "MODAL-NEW-MAMBER") {
                        return;
                    } else if (_data.firstDeposit && !_data.promotionRecord) {
                        $(".modal-new-mamber").show();
                        $('.modal-new-mamber .btn-close').on('click', function () {
                            $('.modal-new-mamber').fadeOut();
                        });
                        localStorage.setItem("key", "MODAL-NEW-MAMBER");
                    }
                },
                error: function(xhr,textStatus,err){
                    logConsole("error: " + err);
                }
            });
        }

    } catch (Ex) {

    }
});

/*/**
 * 判断是否已经在这几款游戏页面,就无需弹窗
 * @param href
 */
XINSlotUtil = {
    testGameUrl: function (href) {
        return /play\/ag\?gameCode=158/.test(href)
            || /play\/ag\?gameCode=WH01/.test(href)
            || /play\/ag\?gameCode=162/.test(href);
    },
    getGameUrl: function (gameType) {
        if (gameType === '158' || gameType === 158) {//AG神奇宝贝
            return "/game/play/ag?gameCode=158&gameName=Mystic%20Gems&platForm=AG&language=zh&trial=false";
        } else if (gameType === 'WH01' || gameType === 'WHGWH01') {
            return "/game/play/ag?gameCode=WH01&gameName=alibaba&platForm=AG&language=zh&trial=false";
        //XIN哥王者传说
        }else if(gameType === '166' || gameType === 166) {
            return "/game/play/ag?gameCode=166&gameName=Lucky%20Combo&platForm=AG&language=zh&trial=false";
        }
    },
};
/**
 * 厅方弹窗推广活动
 */
(function (_now, staticUrl, _gameUrl) {
    try {
        if (typeof _now === 'undefined' || !_now) {
            var date = new Date();
            _now = date.getTime();
        }
        /*
         *  时间范围
         *  new Date('2018-11-28 15:00:00').getTime();  1543388400000
         *  new Date('2018-11-28 22:00:00').getTime();  1543413600000
         *  new Date('2018-11-29 15:00:00').getTime();  1543474800000
         *  new Date('2018-11-29 22:00:00').getTime();  1543500000000
         *  new Date('2018-11-30 15:00:00').getTime();  1543561200000
         *  new Date('2018-11-30 22:00:00').getTime();  1543586400000
         *
         */
        if ((_now < 1543413600000 && _now > 1543388400000) ||
            (_now < 1543500000000 && _now > 1543474800000) ||
            (_now < 1543586400000 && _now > 1543561200000)) {
            var day = new Date(_now).getDate();
            var expirationtime = parseInt(localStorage.getItem('WINDOW_XINGE'));
            var nowTime = new Date(_now).getTime();
            if (nowTime < expirationtime) {
                return;
            }
            var href = location.href;
            if (XINSlotUtil.testGameUrl(href)) {
                return;
            }
            $("head").append('<link type="text/css" rel="stylesheet" href="https://xingaming.com/API/css/XINSlotEvent.css"/>');
            $("head").append("<style>.eventLayerXINSlotEvent.large{z-index: 9999 !important;}" +
                "        .eventPopupXINSlotEvent.large,.closeBtnXINSlotEvent.large{z-index: 99999 !important;}" +
                "    </style>");
            $.getScript("https://xingaming.com/API/XINSlotEvent-v2.0.min.js", function (e) {
                var xINSlotEvent = new XINSlotEvent();
                xINSlotEvent.API({
                    action: "init",
                    style: "large",
                    showButton: true,
                    lang: "ZH",
                    pid: "B79",
                    afterClose: "neverShow",
                    // imgPath : _static_url + "/static/promotion/jinlaba/images/",
                    mode: localStorage.getItem('WINDOW_XINGE_ENV') || constants.environment,
                    goGameCallback: function (gameType) {
                       var date = new Date(_now);
                       localStorage.setItem('WINDOW_XINGE', date.setHours(date.getHours() + 8));
                       window.open(XINSlotUtil.getGameUrl(gameType), "_blank");
                    }
                });
                xINSlotEvent.API({action:"show"});
            });
        }
    } catch (E) {

    }
})(typeof _now === 'undefined' ? 0 : _now,  "/asset/",  "/game/play/ag?gameCode=166&gameName=Lucky%20Combo&platForm=AG&language=zh&trial=false");



//注册成功点击成功弹窗关闭按钮流量统计
$('.modal-content.sign-up-wrap .modal-header .close').click(function () {
    $('#registration-succ-modal').parent().parent().find('.close').attr("onclick", "_hmt.push(['_trackEvent','AG86','注册成功','关闭','关闭'])");
});

/**
 * 判断是否展示香港的电话号码
 */
$(function() {
    // if(pn.hongKong1 != "true" && pn.hongKong2 != "true") {
    //     $(".hongKongParent").hide();
    // }else if(pn.hongKong1 != "true"){
    //     $(".hongKong1").hide();
    // }else if(pn.hongKong2 != "true") {
    //     $(".hongKong2").hide();
    // }
    if(_now < 1545753600000) {
        $('.icon-dollar-circle').attr('class', 'gift-icon').removeClass("icon-dollar-circle");
        $("#homeWrapId,#headerMastHeadWrapId").addClass("christmas-theme");
        $(".gift-icon").parent().attr("style", "padding-left:0px !important");
    }
});