//  生成背景图
$(function () {
    var $back = $(".wrapper .dy-home-wrap");

    var createBackground = function(data){
        var backList = resort(grepGame(data, [function (n) {
            if (n.endTime) {
                return (n.beginTime - _now) <= 0 && (n.endTime - _now) >= 0;
            } else {
                return (n.beginTime - _now) <= 0;
            }
        }]), "index");
        if(backList.length){
            var backInfo = backList[0];
            $back.attr("style","background:url(" + backInfo.maxImageHttpUrl + ") center 308px");
        }
    };

    dy_cmsHelper.getScriptResult(DY_CMS_MODEL.bgPicture).done(createBackground).fail(dy_cms_failure);
});

//  生成轮播图
$(function () {
    var $carouselWrap = $(".carousel-home-wrap");
    var $indicators = $carouselWrap.find(".carousel-indicators");
    var $banner = $carouselWrap.find(".carousel-inner");

    var indicatorsHtml = function (index) {
        var classA = index === 0 ? 'active' : '';
        return '<li data-target="#carousel-home" data-slide-to="' + index + '" class="' + classA + '" style="margin-left: 5px;"></li>';
    };
    //  生成 banner 大图
    var innerHtml = function (index, item) {
        var classA = index === 0 ? 'active' : '';
        var href = item.maxUrl === '' ? '' : ('href="' + item.maxUrl + '"');
        var target = item.target ? " target='_blank'" : '';
        var imageUrl = item.maxImageHttpUrl;
        var html = '';
        if (item.buttons.length) {
            var buttons = [];
            $.each(item.buttons, function (index, item) {
                var buttonHtml ='<a href="'+item.buttonAction+'" target="_blank" class="btn btn-link">'
                    +item.buttonName+'</a> ';
                buttons.push(buttonHtml);
            });
            html += '<div class="item game ' + classA + '">';
            html += '   <a class="item-img" ' + href + target + ' style="background-image: url(' + imageUrl + ')"></a> ';
            html += '   <div class="carousel-caption">' + buttons.join("") + '</div>';
            html += '</div>';
        } else {
            html += '<div class="item '+classA+'">';
            html += '   <a class="item-img" ' + href + ' target="_blank" style="background-image: url(' + imageUrl + ')"></a>';
            html += '</div>';
        }
        return html;
    };
    //  生成 Banner 对象集合
    var grepBanners = function (data) {
        var banners = [];
        $.each(data, function (index, item) {
            var $banner =
                {
                    "index": item.rank,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime,
                    "minUrl": item.defaultAction || item.maxImageAction,
                    "maxUrl": item.defaultAction || item.maxImageAction,
                    "minImageHttpUrl": item.minImageHttpUrl,
                    "maxImageHttpUrl": item.maxImageHttpUrl,
                    "target": item.targetType === "target" ? "target" : "",
                    "buttons": item.templateButtons,
                    "templateType": item.templateType
                };
            banners.push($banner);
        });
        return resort(grepGame(banners, [function (n) {
            if (n.endTime) {
                return (n.beginTime - _now) <= 0 && (n.endTime - _now) >= 0;
            } else {
                return (n.beginTime - _now) <= 0;
            }
        }]), "index");
    };
    //  生成的轮播图
    var generate = function (data) {
        var banners = grepBanners(data);
        if (!banners) {
            return false;
        }
        var indicators = [], inners = [];
        $.each(banners, function (index, item) {
            indicators.push(indicatorsHtml(index));
            inners.push(innerHtml(index, item));
        });
        if (indicators.length && inners.length) {
            $indicators.empty();
            $banner.empty();
            $indicators.append(indicators.join(""));
            $banner.append(inners.join(""));
        }
    };
    //  首页轮播图
    dy_cmsHelper.getScriptResult(DY_CMS_MODEL.banner)
        .done(generate)
        .done(updateRedirectUrl)
        .fail(dy_cms_failure);
});

//  生成左下角热门优惠
$(function () {
    var $hdList = $(".hot-deals").find(".hd-list");
    // dy_cmsHelper.getScriptResult(DY_CMS_MODEL.hotPreferential)
    //     .done(createHotPreferential)
    //     .done(tonji)
    //     .fail(cms_failure);
    function createHotPreferential(data) {
        var PreferentialList = sortPreferentialData(data);
        if(PreferentialList.length){
            var htmlList = createPreferentialHtml(PreferentialList);
            $hdList.find("ul").html(htmlList.join(""));
        }
    }
    function sortPreferentialData(data){
        return resort(grepGame(data, [function (n) {
            if (n.endTime) {
                return (n.beginTime - _now) <= 0 && (n.endTime - _now) >= 0;
            } else {
                return (n.beginTime - _now) <= 0;
            }
        }]), "rank");
    }

    function createPreferentialHtml(preferentialList){
        var htmlList = [];
        $.each(preferentialList,function (index,item) {
            var target = item.targetType == "a" ? "" : "_blank";
            var title = item.title;
            var text = item.promotionDescription;
            var textList = text.split("#");
            var description = textList[0];
            var imageDescription = textList[1];
            var imgUrl = item.maxImageHttpUrl;
            var preferentialUrl = item.defaultAction;
            var html = '<li><span class="img-wrap">';
            html += '<a href="' + preferentialUrl + '" target="' + target + '">';
            html += '<img class="lazy-js" data-original="' + imgUrl + '" alt="" src="' + imgUrl + '" style="display: inline;"> ';
            html += '</a>' + imageDescription;
            html += '</span> ';
            html += '<span class="title"> ';
            html += '<a href="' + preferentialUrl + '" target="' + target + '">' + title;
            html += '<em>【进行中】</em> ';
            html += '</a> ';
            html += '</span> ';
            html += '<p>' + description + '</p> ';
            html += '</li>';
            htmlList.push(html);
        });
        return htmlList;
    }

    function tonji(){
        //首页-热门优惠-百度统计
        var li = $(".hot-deals .hd-list ul a");
        li.on('click', function () {
            var t = $(this), num;
            var $li = t.parents("li");
            var _len = $li.find("~li").length;
            var len = $li.parents("ul").find("li").length;
            _hmt.push(['_trackEvent', 'AG86', '电游', (len - _len) + '优惠位置', (len - _len) + '优惠位置']);
        });
    }
});

//  生成滚动广告
$(function () {

    dy_cmsHelper.getScriptResult(DY_CMS_MODEL.bingoData)
        .done(createBingo)
        .fail(dy_cms_failure);

    function createBingo(data){
        var $bingo = $(".list-container-3");
        var joinHtml = "";
        var bingoList = sortBingoList(data);
        if(bingoList.length){
            var htmlList = createHtml(bingoList);
            $bingo.html(htmlList.join(joinHtml));
        }
    }

    function createHtml(bingoList){
        var htmlList = [];
        if(bingoList.length>10){
            bingoList.splice(10)
        }
        $.each(bingoList,function (index,item) {
            var text = item.textDescription;
            var url = changeNewGameUrl(item.defaultAction);
            var maxurl = item.minImageAction
            var target = item.targetType == "a" ? "" : "_blank";
            text = text.split("#");
            var gameUrl="";
            if(pn.userName && pn.userType == "1"){
                gameUrl='<a href="'+url+'" target="_blank"><span class="proname">'+(text[2].length>5?text[2].substring(0,5)+'..':text[2])+'</span></a>';
            }else{
                gameUrl='<a data-href="'+url+'" onclick="doLogin(this)" style="cursor: pointer" target="_blank"><span class="proname">'+(text[2].length>5?text[2].substring(0,5)+'..':text[2])+'</span></a>';
            }
            var html = '<div class="list-row">'
                    +'     <ul class="list-inline">'
                    +'        <li class="list-data" ><a href="'+maxurl+'" target="_blank"><span>'+text[3]+'</span></a></li>'
                    +'        <li class="list-data"><a href="'+maxurl+'" style="color: #4d423c;" target="_blank">'+text[1]+'</a></li>'
                    +'        <li class="list-data">'
                    + gameUrl
                    +'        </li>'
                    +'        <li class="list-data"><a href="'+maxurl+'" target="_blank"><span class="date">'+text[0]+'</span></a></li>'
                    +'     </ul>'
                    +'</div>';
            htmlList.push(html);
        });
        return htmlList;
    }

    /**
     * 兼容电游历史记录的URL配置
     * @param gameUrl
     */
    function changeNewGameUrl(gameUrl) {
        if(gameUrl && gameUrl.trim().length > 0 && gameUrl.indexOf("egames=1") < 0) {
            var urlArr = gameUrl.split("?");
            if(urlArr[0].endsWith("/")) {
                urlArr[0] = urlArr[0].substr(0, urlArr[0].length - 1);
            }
            var plotType = urlArr[0].substr(urlArr[0].lastIndexOf("/") + 1);
            gameUrl = "/game/iframe/index.html?egames=1&g=" + plotType + "&" + urlArr[1];
        }
        return gameUrl;
    }

    function sortBingoList(data){
        return resort(grepGame(data, [function (n) {
            if (n.endTime) {
                return (n.beginTime - _now) <= 0 && (n.endTime - _now) >= 0;
            } else {
                return (n.beginTime - _now) <= 0;
            }
        }]), "rank");
    }
});
/**
 * set(key, value) 生命周期 session
 * set(key, value, expiredays) expiredays 过期天数
 * set(key, value, Infinity) Infinity 过期时间9999年12月31日  最大值
 *
 * @type {{set: _Cookie_.set, get: _Cookie_.get, del: _Cookie_.del}}
 * @private
 */
var _Cookie_ = {
    set: function (key, value, expiredays) {
        var expire = new Date();
        expire.setTime(expire.getTime() + (expiredays || 0) * 24 * 60 * 60 * 1000);
        var expires = expire.toUTCString();
        if (expiredays === Infinity) {
            expires = "Fri, 31 Dec 9999 23:59:59 GMT";
        }
        document.cookie =
            key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; expires=" + expires)
            + "; domain=" + window.location.hostname + "; path=/;";
    },
    get: function (key) {
        var arr, reg = new RegExp("(^|\\s+)" + key + "=(.*?)(;|$)");
        if (arr = document.cookie.match(reg))
            return (arr[0]);
        else
            return null;
    },
    del: function (key) {
        if (_Cookie_.get(key)) {
            var date = new Date();
            date.setTime(date.getTime() - 10000);
            document.cookie = key + "=v; expires =" + date.toUTCString()
                + "; domain=" + window.location.hostname + "; path=/;";
        }
    }
};
