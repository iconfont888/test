$(document).ready(function () {
	$('body').on('click', '.coming-soon', function (e) {
		e.preventDefault();
		alert('即将推出，敬请关注！');
	});
	includeComponents();

	function includeComponents() {

		navbarFixedScroll();
		disableDropdownClosing();

		$('.search-engine').focus(function () {
			$(this).siblings('.list').toggleClass('active');
		});
		$('.search-engine').focusout(function () {
			$(this).siblings('.list').toggleClass('active');
		});
		$("input[name=inlineRadioOptions]").on('change', function () {
			$(this).parents('.form-group').next().toggleClass('hide', parseInt($(this).val(), 10));
		});

		$(function () {
			$("[data-hide]").on("click", function () {
				$("." + $(this).attr("data-hide")).hide();
			});
		});

	}

	function navbarFixedScroll() {
		var a = $(".masthead-wrap");
		$(window).on("load resize scroll", function (f) {
			a.css("left", -$(window).scrollLeft() + "px")
		});
	}

	function disableDropdownClosing() {
		$(document).on('click', '.mid-navbar .dropdown-menu', function (e) {
			e.stopPropagation();
		});
	}

	// 修复bootstrapde的tab切换页面跳顶bug
	$('.nav-tabs a').on('shown.bs.tab', function (e) {
		// 更新地址栏
		var sTop = document.body.scrollTop || document.documentElement.scrollTop;
		window.location.hash = e.target.hash;
		$('html, body').scrollTop(sTop);
	});
});

/*end*/

function listScroll(x, y) {
//	var $listContainer = $('.list-containe-stop'),
	var $listContainer = $('.list-container-1, .list-container'),
		$animate;

	// CONFIG

	var animationSpeed = x,
		pause = y;

	$listContainer.hover(function () {
			clearInterval($animate);
		},
		function () {
			$animate = setInterval(function () {
				var $firstRow = $listContainer.find('.list-row:first');
				var $rows = $listContainer.find('.list-row');
				var $heightRow = $firstRow.height();
				$rows.animate({'top': -$heightRow + 'px'}, animationSpeed, function () {
					$rows.css('top', 0);
					$firstRow.appendTo($listContainer);
				})
			}, pause);
		}).trigger('mouseleave');
}



$.loading = function () {
	if (arguments.length > 0 && arguments[0] === false) {
		$('.loading-mask').remove();
		return false;
	}
	$('body').loading();
};
// $('.u-main').loading();
// $.loading();
// $.loading(false);  关闭loading


// countDown(10, function() { cosole.log('tick') }, function() { console.log('done') });
window.countDown = function (time, fn1, fn2) {
	var timer = 'timer_' + (new Date()).getTime();
	window[timer] = setInterval(function () {
		time -= 1;
		if (time >= 0) {
			fn1(time);
		} else {
			clearInterval(window[timer]);
			fn2();
		}
	}, 1000);
};
