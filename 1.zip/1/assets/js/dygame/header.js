$('.header').load('/includes/header2.html', function() {

})