var DY_CMS_CONFIG = typeof dy_cms_config !== "undefined" ? dy_cms_config : "";
var DY_CMS_MODEL = {
    banner: "banner",
    bgPicture: "bgPicture",
    bingoData: "bingoData",              // bingo滚动字幕
    promotionSidebar: "promotionSidebar", // 嵌套菜单-热门优惠
};

var DY_CMSHelper = function () {
    var _helper = this;
    var _ID = {
        banner: "020101",
        bgPicture: "020102",
        bingoData: "020106",
        promotionSidebar: "020123",
    };

    this.getScriptResult = function (modal) {
        var _deferred = $.Deferred();
        $.request({
            url: "/api/cms/page/templates",
            data:{moduleCodes:_ID[modal]}
        }).done(function (res) {
            if (res.successful && res.data) {
                var data = res.data;
                if(data && data.length > 0){
                    for (var i =0;i<data.length;i++){
                        if(data[i].beginTime){
                            data[i].beginTime = new Date (data[i].beginTime.replace(/-/g,'/')).getTime();
                        }
                        if(data[i].endTime){
                            data[i].endTime = new Date (data[i].endTime.replace(/-/g,'/')).getTime();
                        }
                    }
                }
                _deferred.resolve(data);
            } else {
                _deferred.reject(_ID[modal]);
            }
        }).fail(function(e){
            logConsole(e);
        });
        return _deferred.promise();
    };
};
window.dy_cmsHelper = new DY_CMSHelper();
function dy_cms_failure(data) {
    logConsole("Get CMS(" + data + ") configuration is abnormal.");
}
