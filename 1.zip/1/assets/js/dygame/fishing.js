/**
 * Created by Davy on 2017/5/11.
 */
$(function () {
    listScroll(1000, 3000);

    var buildHtml = function (loginName, amount, date) {
        return '<div class="list-row">' +
            '<ul class="list-inline">' +
            '<li class="list-data" style="width: 30%;">' + loginName + '</li>' +
            '<li class="list-data">' + amount + '</li>' +
            '<li class="list-data" style="width: 40%;">' + date + '</li>' +
            '</ul>' +
            '</div>';
    };
    var getRanks = function () {
        $('.sidebar-left').loading();
        $.request({
            url:'/api/fish/rank/winners'
        }).done(function (res) {
            var success = res.successful, data = res.data;
            if (success) {
                var htmls = [];
                $.each(data, function (index, item) {
                    var h = buildHtml(item.loginName, item.cusAccount, item.billTime);
                    htmls.push(h);
                });
                $(".list-body>.list-container").html(htmls.join(""));
            }
        }).fail(function(e){
            logConsole(e);
        }).always(function () {
            $('.sidebar-left').loading("close");
        });
    };

    /* 初始化获取中奖数据 */
    getRanks();
    /* 初始化获取中奖数据 */

    var $sidebarLeft = $('.sidebar-left'),
        $btnClose = $sidebarLeft.find('.btn-close');
    $btnClose.on('click', function () {
        // $sidebarLeft.hide();
        $sidebarLeft.find('.list-body').slideToggle();
    });
    $('.hamburger-menu').on('click', function () {
        $('.bar').toggleClass('animate');
    });
    $("#modal-video").on("show.bs.modal", function () {
        var video = document.getElementById("fish_king_video");
         video.play();
    });
    
    setInterval(function(){
		$('.prog').delay(1000).animate({width:'0%'}, 3000, function(){
			if($('.prog').width() == '0'){
				$('.prog').width(100 + '%');
			}
		});
  }, 500);

});

$(function(){
    $.request({
        url:"/api/game/jackpot?platForm=Fish"
    }).done(function(res){
        if(res.successful){
            var data= res.data;
            if(data===0){
                $(".desc .number").last().text("游戏维护中...");
            }else{
                new CountUp($(".desc .number").get(0), data, 99999999, 2, 10000000000, {
                    useEasing: true,
                    useGrouping: true,
                    separator: '	,',
                    decimal: '.',
                }).start();
            }
        }else{
            logConsole(res.message);
        }
	}).fail(function(e){
        logConsole(e);
    });
})