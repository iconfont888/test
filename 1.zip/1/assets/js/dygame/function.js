/**
 * 红包雨下移
 */
function drop() {
    var wHeight = $(window).height();
    $('.hongbao').animate({
        top: wHeight
    }, 5000, function () {
        $(this).remove();
    });
}

var money = 0;
var redPacketTotal = 0;
/**
 * 下红包雨
 */
function rain(time, fn) {
    money = 0;
    redPacketTotal = 0;
    var hongbaoRain = setInterval(function () {
        var elNum = Math.floor(Math.random() * 6);
        var lPos = Math.floor(Math.random() * 100) + 1;
        var el = "<div data-money=" + elNum + " class='hongbao hongbao-" + elNum + "' style='left:" + lPos + "%'>";
        $('.hongbao-rain').append(el);
        drop();
    }, 400);
    /*number of hongbao rain*/


    /*get money on click*/

    setTimeout(function () {
        clearInterval(hongbaoRain);
        fn(money, redPacketTotal)
    }, time * 1000);
    /*clear animation after 1s*/

    return hongbaoRain;
}

/**
 * 启动倒计时
 * @param duration 倒计时秒数
 * @param display 倒计时对象
 */
function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    var tick = setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds;

        if (--timer < 0) {
            // timer = duration;
            clearInterval(tick);
        }
    }, 1000);
}

/**
 * 开始倒计时
 * @param downSeconds 倒计时秒数
 */
function timerStarts(downSeconds) {
    var oneMinute = downSeconds * 1,
        display = document.querySelector('#times');
    startTimer(oneMinute, display);
}
/**
 * 点击红包，提交红包记录
 */
$(document).on('click', '.hongbao-rain .hongbao', function () {
    $this = $(this);
    if ($this.hasClass('click')) {
        return;
    }
    $.ajax({
        dataType: 'json',
        accept: 'application/json',
        type: 'POST',
        url: "/api/promotion/redpacket/rain/request",
        headers: {
            "X-Website-Code":"MAIN_PC"
        },
        data: {
            "actId": redPacketRainMessage.activityId
        }
    }).done(function (response) {
        //noinspection JSUnresolvedVariable
        if (response.successful) {
            $this.addClass('click');
            $this.attr('data-before-1', response.data);
            $this.attr('data-before-2', response.data);
            $this.attr('data-before-3', response.data);
            $this.attr('data-before-4', response.data);
            $this.attr('data-before-5', response.data);
            $this.attr('data-before-6', response.data);
            money += response.data;
            redPacketTotal += 1;
        } else {
            switch (response.code || '') {
                //未中奖
                case 2001:
                case 1021:
                case 1022:
                    $this.addClass('click');
                    $this.attr('data-before-1', 0);
                    $this.attr('data-before-2', 0);
                    $this.attr('data-before-3', 0);
                    $this.attr('data-before-4', 0);
                    $this.attr('data-before-5', 0);
                    $this.attr('data-before-6', 0);
                    break;
                default:
                    failure(response.message);
                    break;
            }
        }
    }).fail(function (e) {
        logConsole(e);
    });
});
$('.hongbao-snippet .btn-trigger').on('click', function () {
    $(this).toggleClass('active');
    $('.hongbao-snippet div.active').removeClass('active');
    $(this).hasClass('active') ?  $('.page-2').addClass('active') :  $('.page-1').addClass('active');
});
$('.hongbao-snippet .page-2 .btn').on('click', function () {
    if ($(this).hasClass('btn-1')) {
        $.request({
            url: "/api/promotion/redpacket/rain/record",
            data: {
                actId: redPacketRainMessage.activityId
            },
        }).done(function (response) {
            // response = JSON.parse(response)
            if (response.successful) {
                var htmlStr = [];
                if (response.data && response.data.length) {
                    $.each(response.data, function (i, item) {
                        var received = item.received;
                        if (received === 1) {
                            received = '已发放';
                        } else {
                            received = '派奖中';
                        }
                        htmlStr.push('+' + item.amount + ' 元 <span>' + new Date(item.createTime).format('yyyy/MM/dd') + '  ' + received + '</span> <br>');
                    });
                    $(".hongbao-snippet .page-3 .record-list").html(htmlStr.join(""));
                } else {
                    $(".hongbao-snippet .page-3 .record-list").html("您暂时没抢到红包，加油吧！");
                }
            } else {
                switch (response.code) {
                    case 5001:
                    case 5002:
                        $('#loginModal').modal({
                            "backdrop": true,
                            "show": true
                        });
                        return;
                    default:
                        $(".hongbao-snippet .page-3 .record-list").html(response.message || "服务器发生错误,请稍后再试!");
                }
            }
        }).fail(function (e) {
            logConsole(e);
        });
        $(this).parents('.page').removeClass('active').siblings('.page-3').addClass('active');
    }
    else {
        $(this).parents('.page').removeClass('active').siblings('.page-4').addClass('active');
    }
});
$('.hongbao-snippet .btn-return').on('click', function () {
    $(this).parents('.page').removeClass('active').siblings('.page-2').addClass('active');
});
$('.hongbao-snippet').show();

$('.hongbao-content-2 .btn-close').on('click', function () {
    $.request({
        dataType: 'json',
        accept: 'application/json',
        type: 'POST',
        url: "/api/promotion/redpacket/rain/apply",
        data: {
            "actId": redPacketRainMessage.activityId,
            "rainId": redPacketRainMessage.timerId
        }
    }).done(function (response) {
        //noinspection JSUnresolvedVariable
        if (!response.successful) {
            if (response.code !== 2002) {
                layer.open({
                    title: ' ',
                    yes: function (index) {
                        layer.close(index);
                    },
                    content: response.data || "服务器发生错误,请稍后再试!"
                });
            }
        }
    }).fail(function () {
        layer.open({
            title: ' ',
            yes: function (index) {
                layer.close(index);
            },
            content: "服务器遇到错误,请联系客服或稍后再试!"
        });
    }).always(function () {
    });
    $('.hongbao-prize').fadeOut('slow');
    $('.hongbao-content-1').addClass("active");
    $('.hongbao-content-2').removeClass("active");
    $('.hongbao-prize .btn-start span').hide();
    $('.hongbao-rain').hide();
    $('.timer-wrap').show();
    $('.hongbao-content').fadeIn('fast');
});
var hongbaoRain;
/**
 * 点击红包雨关闭按钮
 * 右上角： “X” 关闭页面
 * 如果没有抢到红包，点击“X”直接关闭红包雨
 * 如果抢到红包，点击”X“中奖信息弹框
 */
$('.hongbao-rain .btn-close').on('click', function () {
    if (money > 0) {
        clearInterval(hongbaoRain);
        $('.hongbao-content-2 .money').html(money);
        $('.hongbao-content-2 .red-packet-total').html(redPacketTotal);
        $('.hongbao-content').removeClass('active').siblings('.hongbao-content-2').addClass('active');
        $('.timer-wrap').hide();
        $(".hongbao-snippet .page-1 span").text("已结束，红包抢完啦！");
        $(".hongbao-snippet .page-2 span").text("已结束，红包抢完啦！");
    } else {
        clearInterval(hongbaoRain);
        $('.hongbao-prize').hide();
        $('.hongbao-content-1').addClass("active");
        $('.hongbao-content-2').removeClass("active");
        $('.hongbao-prize .btn-start span').hide();
        $('.hongbao-rain').hide();
        $('.timer-wrap').show();
        $('.hongbao-content').fadeIn('fast');
        $(".hongbao-snippet .page-1 span").text("已结束，红包抢完啦！");
        $(".hongbao-snippet .page-2 span").text("已结束，红包抢完啦！");
    }
});
$('.hongbao-content-1 .btn-close').on('click', function () {
    $('.hongbao-prize').fadeOut('slow');
});

function finish(money, redPacketTotal) {
    $('.hongbao-content-2 .money').html(money);
    $('.hongbao-content-2 .red-packet-total').html(redPacketTotal);
    $('.hongbao-content').removeClass('active').siblings('.hongbao-content-2').addClass('active');
    $('.timer-wrap').hide();
    $(".hongbao-snippet .page-1 span").text("已结束，红包抢完啦！");
    $(".hongbao-snippet .page-2 span").text("已结束，红包抢完啦！");
}
$('.btn-start').on('click', function () {
    $(this).parents('.hongbao-content').fadeOut('fast');
    if (_now > redPacketRainMessage.beginTime && _now < redPacketRainMessage.endTime) {
        $('.hongbao-rain').fadeIn("slow");
        timerStarts(parseInt((redPacketRainMessage.endTime - _now) / 1000));
        hongbaoRain = rain(parseInt((redPacketRainMessage.endTime - _now) / 1000), function (money, redPacketTotal) {
            $('.hongbao-content-2 .money').html(money);
            $('.hongbao-content-2 .red-packet-total').html(redPacketTotal);
            $('.hongbao-content').removeClass('active').siblings('.hongbao-content-2').addClass('active');
            $('.timer-wrap').hide();
            $(".hongbao-snippet .page-1 span").text("已结束，红包抢完啦！");
            $(".hongbao-snippet .page-2 span").text("已结束，红包抢完啦！");
        });
    } else {
        $('.hongbao-prize').fadeOut('slow');
    }

    /*rain after btn start click*/
});
/*$('.hongbao-prize .btn-close').on('click', function () {
    $(this).parents('.hongbao-prize').fadeOut('slow');
 });*/
// 红包雨弹窗
function hongbao_rain() {
    console.log(_now, 66666)
    if (_now < redPacketRainMessage.beginTime) {
        console.log('push one');
        console.log('====================================')
        countDown(parseInt((redPacketRainMessage.beginTime - _now) / 1000), function (t) {
            $('.hongbao-prize .btn-start span').html('（' + t + '秒）');
        }, function () {
            $('.hongbao-prize .btn-start span').hide();
            $('.hongbao-prize .btn-start').removeAttr('disabled').removeClass('disabled');
            countDown(parseInt((redPacketRainMessage.endTime - _now) / 1000), function (t) {
            }, function () {
                if ($('.hongbao-prize').css('display') !== 'none' && $('.hongbao-prize .hongbao-content-1').hasClass('active')) {
                    $('.hongbao-prize').fadeOut();
                    $('.hongbao-prize .btn-start span').show();
                    $('.hongbao-prize .btn-start').attr('disabled', 'disabled').addClass('disabled');
                    $(".hongbao-snippet .page-1 span").text("已结束，红包抢完啦！");
                    $(".hongbao-snippet .page-2 span").text("已结束，红包抢完啦！");
                }
            });
        });
        $(".hongbao-prize").removeClass("hide");
        $('.hongbao-prize').fadeIn();
    } else if (_now > redPacketRainMessage.beginTime && _now < redPacketRainMessage.endTime) {
        console.log('push two');
        console.log('====================================')
        $('.hongbao-prize').fadeIn();
        $(".hongbao-prize").removeClass("hide");
        $('.hongbao-prize .btn-start span').remove();
        $('.hongbao-prize .btn-start').removeAttr('disabled').removeClass('disabled');
    }

}

function hongbaoRainMiddle() {
    $('.hongbao-snippet').removeClass('hide');
    var _timerMiddle = parseInt(redPacketRainMessage.beginTime);
    var countdownMiddle = window.setInterval(function () {
        if (parseInt((_timerMiddle - _now) / 1000) <= 10) {
            hongbao_rain();
            window.clearInterval(countdownMiddle);
        }
    }, 1000);
    $(".hongbao-snippet .page-2 span,.hongbao-snippet .page-1 span").agcountdown({
        stepTime: parseInt((redPacketRainMessage.beginTime - _now) / 1000),
        buttonText: "距离红包雨还有 ({}) 秒",
        defaultMsg: "疯狂抢红包中",
        start: true
    });

}

/**
 * 红包雨小浮动弹窗
 */
function hongbao_rain_min() {
    $('.hongbao-snippet .page-2 strong').text(Common.AmountFormatter(redPacketRainMessage.maxBonus) + "元");
    $('.subtitle').text(redPacketRainMessage.actName);
    $('.hongbao-snippet .page-4 .list-wrap').html(redPacketRainMessage.ruleDetail);
    if (_now < redPacketRainMessage.beginTime) {
        if (parseInt((redPacketRainMessage.beginTime - _now) / 1000) > 120) {
            $('.hongbao-snippet').removeClass('hide');
            $(".hongbao-snippet .page-1 span").text("下一场活动时间为" + new Date(redPacketRainMessage.beginTime).format("hh:mm"));
            $(".hongbao-snippet .page-2 span").text("下一场活动时间为" + new Date(redPacketRainMessage.beginTime).format("hh:mm"));
            var _timerBig = parseInt(redPacketRainMessage.beginTime);
            var countdownBig = window.setInterval(function () {
                if (parseInt((_timerBig - _now) / 1000) <= 120) {
                    hongbaoRainMiddle();
                    window.clearInterval(countdownBig);
                }
            }, 1000);
        } else if (parseInt((redPacketRainMessage.beginTime - _now) / 1000) <= 120) {
            hongbaoRainMiddle();
        }
    } else if (_now > redPacketRainMessage.beginTime && _now < redPacketRainMessage.endTime) {
        hongbaoRainMiddle();
        $('.hongbao-prize').fadeIn();
        $('.hongbao-prize .btn-start span').hide();
        $('.hongbao-prize .btn-start').removeAttr('disabled').removeClass('disabled');
    }

}
$(document).ready(function () {

    includeComponents();

    function includeComponents() {
        navbarFixedScroll();
        disableDropdownClosing();
        var $btnForgetPass = $('.btn-forget-password');
        $btnForgetPass.click(function () {
            $(this).parents('.dropdown-content').hide().next().fadeIn('fast');
        });

        sidebarLinkHover();
        backTopBtn();
        $('.modal-toggle').click(function (e) {
            var tab = e.target.hash;
            $('li > a[href="' + tab + '"]').tab("show");
        });
    }
    function navbarFixedScroll() {
        var a = $(".top-navbar");
        $(window).on("load resize scroll", function (f) {
            a.css("left", -$(window).scrollLeft() + "px")
        });
    }

    function disableDropdownClosing() {
        $(document).on('click', '.mid-navbar .dropdown-menu', function (e) {
            e.stopPropagation();
        });
    }



    function sidebarLinkHover() {
        var $sidebarUnit = $('.sidebar-unit');
        $sidebarUnit.hover(function () {
            var contentWidth = $(this).find('.sidebar-content, .login-pop-up4').width();
            $(this).find('.sidebar-content, .login-pop-up4').stop(true, true).animate({'left': -contentWidth}, 100);
            if ($(this).hasClass('online-service')) {
                contentWidth = 155;
                $(this).find('.sidebar-content, .login-pop-up4').stop(true, true).animate({'left': -contentWidth}, 100);
            }
            if ($(this).hasClass('free-hotline')) {
                var $this = $(this).parent();
                var $captcha = $this.find("span.captcha>.captcha");
                $captcha.attr("src", "/captcha?d" + _now);
            }
        }, function () {
            if ($(this).hasClass('free-hotline')) {
                $(this).find('.sidebar-content, .login-pop-up4').stop(true, true).animate({'left': 40}, 10);
            } else {
                $(this).find('.sidebar-content, .login-pop-up4').stop(true, true).animate({'left': 40}, 100);
            }
        });
    }

    function backTopBtn() {
        // show button on scroll
        $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('.back-top').css({'opacity': 1});
            } else {
                $('.back-top').css({'opacity': 0});
            }
        });

        // scroll body to 0px on click
        $('.back-top').click(function () {
            $('.back-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 700);
            return false;
        });
    }


    (function () {
        var pathname = location.pathname;
        var $li = $('.header .main-navbar .navbar-nav > li').removeClass('active');
        $li.find("a").each(function (i, e) {
            var path = e.pathname;
            pathname = pathname === "/" ? "/index" : pathname;
            path = path === "/" ? "/index" : path;
            if (path == pathname) {
                $(e).parents("li").addClass('active');
            }
        });
    })();


});
/*end*/

function listScroll(x, y) {
    var $listContainer = $('.list-container'),
        $animate;

    // CONFIG

    var animationSpeed = x,
        pause = y;

    $listContainer.hover(function () {
            clearInterval($animate);
        },
        function () {
            $animate = setInterval(function () {
                var $firstRow = $listContainer.find('.list-row:first');
                var $rows = $listContainer.find('.list-row');
                var $heightRow = $firstRow.height();
                $rows.animate({'top': -$heightRow + 'px'}, animationSpeed, function () {
                    $rows.css('top', 0);
                    $firstRow.appendTo($listContainer);
                })
            }, pause);
        }).trigger('mouseleave');
}



$('.fixed-sidebar').load('/promotion/fixed_sidebar', function(){
	$('.fixed-sidebar-wrap > ul > li').each(function (i, el) {
        var $el = $(el);
        if (location.href.indexOf($el.children('a').attr('href')) !== -1) {
            $el.addClass('active');
            $el.siblings('li').removeClass('active');
        } 
        else {
        }
    });

    $('.fixed-sidebar-wrap .dropdown li').each(function (i, el) {
        var $el = $(el);
        if (location.href.indexOf($el.children('a').attr('href')) !== -1) {
            $el.parents('.dropdown-wrap').addClass('active');
            $el.addClass('active');
            $el.siblings('li').removeClass('active');
        } 
        else {
        }
    });
    if ($('.fixed-sidebar-wrap > ul > li').length > 4) {
        $('.list-trigger').addClass('active');
    }
    else {
        $('.list-trigger').removeClass('active');
    }
    $('.list-trigger').click(function () {
        $('.fixed-sidebar-wrap > ul > li').css({'animation': 'none', 'opacity': '1'});
        var $listContainer = $('.fixed-sidebar-wrap > ul');
        var $rows = $listContainer.find('> li');
        var $firstRow = $listContainer.find('> li:first');
        var $heightRow = $firstRow.height();
        $rows.animate({'top': -$heightRow + 'px'}, 600, function () {
            $rows.css('top', 0);
            $firstRow.appendTo($listContainer);
        })
    });
});


//新年气氛元素
$(function(){
	try{
	if(_now < 1520006400000){
		$("#mid-navbar").attr('class','mid-navbar newyear');
		$("#header-login-dropdown").attr('class','btn btn-login login dropdown-toggle');
		$("#icon-user-circle-o").attr('class','icon-user-circle-ooo');
	}
	}catch (e) {
		
	}
});
// countDown(10, function() { cosole.log('tick') }, function() { console.log('done') });
window.countDown = function (time, fn1, fn2) {
    var timer = 'timer_' + (new Date()).getTime();
    window[timer] = setInterval(function () {
        time -= 1;
        if (time >= 0) {
            fn1(time);
        } else {
            clearInterval(window[timer]);
            fn2();
        }
    }, 1000);
};