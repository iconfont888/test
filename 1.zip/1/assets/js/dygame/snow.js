(function() {
	function ready(fn) {
		if (document.readyState != 'loading'){
			fn();
		} else {
			document.addEventListener('DOMContentLoaded', fn);
		}
	}
	
	function makeSnow(el) {
		var ctx = el.getContext('2d');
		var width = 0;
		var height = 0;
		var particles = [];
		
		var Particle = function() {
			this.x = this.y = this.dx = this.dy = 0;
			this.reset();
		}
		
		Particle.prototype.reset = function() {
			this.y = Math.random() * height;
			this.x = Math.random() * width;
			// wind strength from left
			this.dx = (Math.random() * 1) - 0.5;
			// snow drop speed
			this.dy = (Math.random() * 1) + 0.5;
		}
		
		function createParticles(count) {
			if (count != particles.length) {
				particles = [];
				for (var i = 0; i < count; i++) {
					particles.push(new Particle());
				}
			}
		}
				
		function onResize() {
			width = window.innerWidth;
			height = window.innerHeight;
			el.width = width;
			el.height = height;

			// number of snow
			createParticles((width * height) / 100000);
		}
		
		function updateParticles() {
			ctx.clearRect(0, 0, width, height);
			ctx.fillStyle = '#f6f9fa';
			
			particles.forEach(function(particle) {
				particle.y += particle.dy;
				particle.x += particle.dx;
				
				if (particle.y > height) {
					particle.y = 0;
				}
				
				if (particle.x > width) {
					particle.reset();
					particle.y = 0;
				}
				
				ctx.beginPath();

				// snow size
				ctx.arc(particle.x, particle.y, 2, 0, Math.PI * 2, false);
				
				ctx.fill();
			});
			
			window.requestAnimationFrame(updateParticles);
		}
		
		onResize();
		updateParticles();
		
		window.addEventListener('resize', onResize);
	}
	
	ready(function() {
		var canvas = document.getElementById('snow');
		makeSnow(canvas);
	});

	// snow flakes js
    var wHeight = $('.home-wrap').outerHeight() + 100;
	
    var hongbaoRain = setInterval(function(){
      var elNum = Math.floor(Math.random() * 4);
      var lPos = Math.floor(Math.random() * 100) + 1
      var el = "<div class='snow-flakes snow-flakes-"+elNum+"' style='left:"+lPos+"%'>";
      $('.snow-flakes-wrap').append(el);
      drop();
    }, 5000); /*number of snow-flakes rain*/	

    function drop(){
      $('.snow-flakes').animate({
          top: wHeight,                
      }, 50000, function(){
          $(this).remove();
      });
    } 	
})();