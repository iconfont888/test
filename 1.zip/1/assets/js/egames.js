//變數宣告
var total_items = 0; //遊戲總數
var page_items = [0,20,30]; //每頁顯示遊戲量
var row_items = 4;//每行游戲量
var visible_pages = 5; //分頁顯示量
var provider = 'home';//遊戲平台
var column=[];
var condition=[];
var page_type = 1;//頁面型態1圖表2列表
var favgame_cookiename = "favorite_game"; //for favorite_list
var favorite = [];//for favorite_list


$(document).ready(function(){
	if($.cookie(favgame_cookiename)){
		favorite = $.cookie(favgame_cookiename).split(",");
	}
	getXMLGame(null,null,'HOME');
});


// fixed IE8 string .trim() bug
if(typeof String.prototype.trim !== 'function') {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, '');
  }
}
// fixed IE before IE9 don't have an .indexOf() function for Array
if (!Array.prototype.indexOf) {
  Array.prototype.indexOf = function(elt /*, from*/ ) {
    var len = this.length >>> 0;

    var from = Number(arguments[1]) || 0;
    from = (from < 0) ? Math.ceil(from) : Math.floor(from);
    if (from < 0)
      from += len;

    for (; from < len; from++) {
      if (from in this &&
        this[from] === elt)
        return from;
    }
    return -1;
  };
}
// fixed IE8 don't hava an .isArray function for Array
if(!Array.isArray) {
	Array.isArray = function(obj) {
		return Object.prototype.toString.call(obj) === '[object Array]';
	}
}
// fixed IE8 Array forEach()
if (!Array.prototype.forEach) {
  Array.prototype.forEach = function(callback /*, thisArg*/ ) {
    var T, k;
    if (this == null) {
      throw new TypeError('this is null or not defined');
    }

    var O = Object(this);
    var len = O.length >>> 0;

    if (typeof callback !== 'function') {
      throw new TypeError(callback + ' is not a function');
    }

    if (arguments.length > 1) {
      T = arguments[1];
    }
    k = 0;
    while (k < len) {
      var kValue;
      if (k in O) {
        kValue = O[k];
        callback.call(T, kValue, k, O);
      }
      k++;
    }
  };
}




function changeGamePage(pt){
	//param setting
	page_type = pt;
	if(pt==1){
		$('.egame-lists').removeClass('is-click');
		$('.egame-content').addClass('is-click');
	}else if (pt==2){
		$('.egame-content').removeClass('is-click');
		$('.egame-lists').addClass('is-click');
	}
	getXMLGame(column,condition);
	//window.location.href=location.pathname+'?pt='+pt+pro;
}

function getXMLGame(title,value,tag_id) {
	if(title!=null && value!=null){
		if(Array.isArray(title) && Array.isArray(value)){
			column = title;
			condition = value;
		}else{
			column = title.split(",");
			condition = value.split(",");
		}
	} else {
		column = title;
		condition = value;
	}
	// console.log(column+' - '+condition);
	$("#egame_HOME").removeClass("active");//全部平台
	$("#egame_AG").removeClass("active");//AG
	$("#egame_TGP").removeClass("active");//申博
	$("#egame_PT").removeClass("active");//PT
	$("#egame_MG").removeClass("active");//MG
	$("#egame_TTG").removeClass("active");//TTG
	$("#egame_HOT").removeClass("active");//熱門遊戲
	$("#egame_NEW").removeClass("active");//最新遊戲
	$("#egame_POOL").removeClass("active");//獎金池遊戲
	$("#egame_POP").removeClass("active");//人氣值
	$("#egame_ALL").removeClass("active");//全部遊戲
	$("#egame_LIKE").removeClass("active");//我的收藏
	$("#egame_"+tag_id).addClass("active");

	$.ajax({
		type : "GET",
		url : "assets/xml/e-game/game_list_home.xml",
		dataType : "xml",
        headers: {
            "X-Website-Code":"MAIN_PC"
        },
		success : gamelist,
		error:function(xhr,textStatus,err){
            logConsole("error: " + err);
			$(".egame-list").remove();
		}
	});
}



function gamelist(xml) {
	//var total_items = $(xml).find('game').size();
	//if($_GET('pt')){ page_type = $_GET('pt');}

	if(column == 'LIKE') {//favorite 收藏搜尋
		egames = getSectionXML(xml,column,condition,favorite);
	} else {
		egames = getSectionXML(xml,column,condition);
	}
	total_items = egames.length;

	// clean view
	$(".egame-list").remove();

	if(total_items>0){
		// 分頁處理Single Page
		$.jqPaginator('#pagination1',
		{
			totalCounts : total_items,
			pageSize : page_items[page_type],
			visiblePages : visible_pages,
			currentPage : 1,
			first : '<li class="margin">共有{{totalCounts}}个游戏, 共{{totalPages}}页, 每页'+ page_items[page_type] + '条</li>',
			prev : '<li class="prev"><button class="btn btn-modify" onClick="javascript:void(0);">上一页</button></li>',
			last : '<li class="last"><button class="btn btn-modify" onClick="javascript:void(0);">最后</button></li>',
			next : '<li class="next"><button class="btn btn-modify" onClick="javascript:void(0);">下一页</button></li>',
			page : '<li class="page"><button class="btn btn-modify" onClick="javascript:void(0);">{{page}}</button></li>',
			onPageChange : showGames
		});
	}else{
		// 分頁處理Single Page
		$.jqPaginator('#pagination1',
		{
			totalPages: 1,
			visiblePages : visible_pages,
			currentPage : 1,
			first : '<li class="margin">共有{{totalCounts}}个游戏, 共{{totalPages}}页, 每页'+ page_items[page_type] + '条</li>',
			prev : '<li class="prev"><button class="btn btn-modify" onClick="javascript:void(0);">上一页</button></li>',
			last : '<li class="last"><button class="btn btn-modify" onClick="javascript:void(0);">最后</button></li>',
			next : '<li class="next"><button class="btn btn-modify" onClick="javascript:void(0);">下一页</button></li>',
			page : '<li class="page"><button class="btn btn-modify" onClick="javascript:void(0);">{{page}}</button></li>',
			onPageChange : showGames
		});
	}




	// 遊戲顯示Show Games in this page
	function showGames(num, type) {
		var showid = (num - 1) * page_items[page_type];
		var itemid = '',egame = '', first = '';
		var x = 0, i = 0;
		var game = {
				gameid: ''
				,display:''
				,provider:''
				,type:''
				,name_en:''
				,name_cn:''
				,pic1:''
				,pic2:''
				,pic3:''
				,playline:0
				,popular_value:0
				,jackpot:''
				,trial:''};
		var div1 = '';
		var div2 = '';
		var div3 = '';
		var golink = '';
		// clean view
		$(".egame-list").remove();


		for (var i; i < page_items[page_type]; i++) {
			itemid = showid + i;
			if(egames.length > 0){
				egame = egames[itemid];
			} else {
				egame = $(xml).find('game')[itemid];
			}

			game.gameid = $(egame).find('gameid').text().trim();
			game.display = $(egame).find('display').text();
			game.provider = $(egame).find('provider').text().trim();
			game.type = $(egame).find('type').text().trim();
			game.name_en = $(egame).find('name_en').text().trim();
			game.name_cn = $(egame).find('name_cn').text().trim();
			game.pic1 = $(egame).find('pic1').text();
			game.pic2 = $(egame).find('pic2').text();
			game.pic3 = $(egame).find('pic3').text();
			game.playline = $(egame).find('playline').text();
			game.popular_value = $(egame).find('popular_value').text();
			game.jackpot = $(egame).find('jackpot').text();
			game.trial = $(egame).find('trial').text();

			golink = 'e-games.html?gameid='+game.gameid+'&name='+game.name_en+'&pro='+game.provider;
			var ishidden ='';
			if(game.gameid==''){
				islike = 'unlike'; game.popular_value=0;
			} else {
				islike = 'like';
				var isfavorite = getFavoriteGame(game.gameid,game.provider);
				/****  Picture List 圖列表*/
				 if (page_type == 1) {
						if (i % row_items == 0) {
							if (x > 0) {first = '';} else {first = 'first';	}
							x++;
							div1 =  '<div class="list egame-list '+first+'">';
							div1 +=	'  <ul class="egame-list-row'+x+'"></ul>';
							div1 +=	'</div>';
							$("#egame-content").append(div1);
						}
						if (i % row_items > 0) {first = '';} else {first = 'first';}

						div2  = '<li class="box item_g'+i+' '+first+'"></li>';
						div3  = '';
							div3 += '<div class="imgbox">';
								div3 += '<span class="over"><a href="'+golink+'"><img src="'+game.pic2+'" alt="'+game.gameid+'"></a>';
								div3 += '<a href="'+golink+'"><img src="assets/images/e-games/imgbox-hover1.png" alt="'+game.gameid+'"></a></span>';
								div3 += '<img class="img-border" src="'+game.pic1+'" alt="'+game.gameid+'">';
							div3 += '</div><h5><a href="'+golink+'">'+ game.name_cn+'</a></h5>';
						div3 += '<div class="under">';
							div3 += '<img src="assets/images/e-games/play-icon.png" alt="">';
							div3 += '<span class="margin"><span class="light-yellow">'+game.popular_value+'</span>人玩过</span>';
							div3 += '<div class="'+islike+' '+isfavorite+'" name="provider_'+game.provider+':gameid_'+game.gameid+'"><span class="like-icon"></span><span class="margin">收藏</span></div>';
						div3 += '</div>';
						$(".egame-list-row"+x).append(div2);
						$(".item_g"+i).append(div3);


					/****  Picture List 圖列表*/
				} else if (page_type == 2){

						if(i==0){//div1
							div1  = '<div id="egame-list" class="egame-list egame-view is-active">';
								div1 += '<div class="table-responsive">';
									div1 += '<table class="table table-bordered tab_game"><thead>';
										div1 += '<tr><th>游戏名称</th><th>游戏平台</th><th>游戏种类</th><th>人气值</th><th>奖金池</th><th>试玩</th><th>操作</th>';
							div1 += '</tr></thead><table></div></div>';
							div2  = '<tbody class="tbody_game"></tbody>';
							$("#egame-content").append(div1);
							$(".tab_game").append(div2);
						}
						 div3  = '<tr><td><a href="'+golink+'">'+game.name_cn+'</a></td>';
						 div3 += '<td>'+game.provider+'</td>';
						 div3 += '<td>'+game.type+'</td>';
						 //div3 += '<td>'+game.playline+'</td>';
						 div3 += '<td>'+game.popular_value+'</td>';
						 div3 += '<td>'+game.jackpot+'</td>';
						 div3 += '<td>'+game.trial+'</td>';
						 div3 += '<td class="'+islike+' '+isfavorite+'" name="provider_'+game.provider+':gameid_'+game.gameid+'">';
						 div3 += '<span class="like-icon" ></span> <span class="margin">收藏</span></td></tr>';
						 $(".tbody_game").append(div3);
				}
			}
		}//for
		$('.like').click(function(){
			$(this).toggleClass('is-click');
			setFavoriteGame($(this).attr('name'));
		 });
	}//showGames End
}

//User's like 收藏功能
function setFavoriteGame(gid){
	var fid = favorite.indexOf(gid);
	if(fid!=null && fid>=0){//cancel
		favorite.splice(fid,1);
	} else {//add
		favorite.push(gid);
	}
	$.cookie(favgame_cookiename,favorite,{expires:14,path:location.pathname});
}
function getFavoriteGame(gameid,provider){
	var gid = 'provider_'+provider+':gameid_'+gameid;
	var fid = favorite.indexOf(gid);
	if(fid!=null && fid>=0){
		return 'is-click';
	}else {
		return '';
	}
}


//column = array, condition = array
function getSectionXML(xml,column,condition,matchlist){
	var item_name = 'game';
	var egames = new Array(), game = '';
	var col='',val='',idx=0,conform=0;

	if(column==null && condition==null){ //Return All
		egames = $(xml).find(item_name);
	} else {
		if(matchlist!=null){//Return List Array
			$(xml).find(item_name).each(function(){
				game = $(this);
				matchlist.forEach(function(m){
					var ms = m.split(":");
					conform = 0;
					ms.forEach(function(_ms){
						var cv = _ms.split("_");
						if(game.find(cv[0]).text() == cv[1]){
							conform++;
						}
					});
					if(ms.length == conform){
						egames.push(game);
						// console.log(ms.length+' , '+conform);
					}
				});
			});

		}else{ //Return Condition's item
			$(xml).find(item_name).each(function(){
				game = $(this);
				conform = 0;
				if(Array.isArray(column)){
					column.forEach(function(col,idx){
						val = condition[idx];
						if(game.find(col).text()==val){
							conform++;
						}
					});
					if(column.length == conform){
						egames.push(game);
					}
				}else{
					if(game.find(column).text() == condition){
						egames.push(game);
					}
				}
			});
		}
	}
	return egames;
}

//抓網頁參數 get the param from url.(ex index.html?x=10  --->$_GET(x))
function $_GET(param) {
	var vars = {};
	window.location.href.replace( location.hash, '' ).replace(
		/[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
		function( m, key, value ) { // callback
			vars[key] = value !== undefined ? value : '';
		}
	);

	if ( param ) {
		return vars[param] ? vars[param] : null;
	}
	return vars;
}
