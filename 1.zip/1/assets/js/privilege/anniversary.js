$(function () {
	$.request({
		url: "/api/anniversary/countDownInfo"
	}).done(function (r) {
		if (r.successful && r.data !== 'N') {
			$(".count-time").html(dealWithCountTime2(r.data));
		}else{
			failure(r.message);
		}
	}).fail(function(e){
        logConsole(e);
    });

	function dealWithCountTime2(endTime2) {
		var formatTime = function (i) {
			return (i < 10 ? "0" + i : (i + ""));
		};

		var endTime = new Date(endTime2.replace(/-/g, '/'));
		var now = new Date();

		if (endTime.getTime() < now.getTime()) {
			return;
		}
		var monthX = getIntervalMonth(now, endTime);
		var month = 0;
		var day = 0;
		//var hour = 0;
		//计算月

		for (var i = 0; i < monthX; i++) {
			endTime.setUTCMonth(endTime.getUTCMonth() - 1);
			if (endTime.getTime() > now.getTime()) {
				month = month + 1;
			} else {
				endTime.setUTCMonth(endTime.getUTCMonth() + 1);
				break;
			}
		}
		var space = endTime.getTime() - now.getTime();
		//计算天
		day = space / (1000 * 60 * 60 * 24);
		//计算时
		// hour = space / 1000 / 60 / 60 % 24;

		month = formatTime(Math.floor(month));
		day = formatTime(Math.ceil(day));

		// hour = formatTime(Math.floor(hour));
		var result = "";
		result = result + (month.length == 2 ? "<span>" + month + "</span><em>月</em>" : "<span>0" + month + "</span><em>月</em>");
		result = result + (day.length == 2 ? "<span>" + day + "</span><em>日</em>" : "<span>0" + day + "</span></em>日</em>");
		// result = result + (hour.length == 2 ? "<span>" + hour + "</span>时" : "<span>0" + hour + "</span>时");
		return result;
	}

	function formatDate(date) {
		var y = date.getFullYear();
		var M = date.getMonth() + 1;
		var d = date.getDate();
		var h = date.getHours();
		var m = date.getMinutes();
		var s = date.getSeconds();
		console.log(y + "-" + M + "-" + d + " " + h + ":" + m + ":" + s);
	}

	function getIntervalMonth(date1, date2) {
		var month1 = date1.getMonth();
		var month2 = date2.getMonth();
		return (date2.getFullYear() * 12 + month2) - (date1.getFullYear() * 12 + month1);
	}
});

var success = false;
$("#getMoney").on('click', function () {

	$(".v-year-wrap").loading();
	setTimeout(function () {
		var content = '';
		$.request({
			url: "/api/anniversary/privilege"
		}).done(function (response) {
			var maturities, data = response.data;
			if (response.successful && data) {
				// data.privilegeValue='1000';
				if(data.privilegeValue===''||data.privilegeValue===null||data.privilegeValue ===undefined){
					maturities = data.maturity.split("-");
					content += '<p class="msg">'
						+ '亲 慢慢来! 还有<span class="orange">' + data.nextReceiveTime + '天</span>才可领取周年礼金<br/>AG亚游 会一直在这里等您！'
						// + '</p>'
						// + '<p>'
						// + '<span class="orange" style="font-size: 16px;">温馨提醒：最后相见日为'
						// + maturities[0] + '年'
						// + maturities[1] + '月'
						// + maturities[2] + '日</span>'
						+ '</p>';
				}else{
					success = true;
					content = '<p class="msg"><span class="gold-tit">我们的纪念日&nbsp;有你在&nbsp;真好~</span><br/>周年礼金<span class="orange">'+data.privilegeValue+'元</span>，已添加到账<br/>AG亚游永远在这里等您哟！</p>';
				}
				$(".v-year-wrap").loading(false);
				layer.open({
					title: false,
					skin: 'vip-pop',
					area: ['660px', '378px'],
					content: content,
					end: function () {
						if (success) {
							window.location.href="/ucenter/transaction/view?_tab=tab-4";
						}
					}
				});
			}else{
				$(".v-year-wrap").loading(false);
				maturities = data.maturity.split("-");
				content += '<p class="msg">'
					+ '亲 慢慢来! 还有<span class="orange">' + data.nextReceiveTime + '天</span>才可领取周年礼金<br/>AG亚游 会一直在这里等您！'
					// + '</p>'
					// + '<p>'
					// + '<span class="orange" style="font-size: 16px;">温馨提醒：最后相见日为'
					// + maturities[0] + '年'
					// + maturities[1] + '月'
					// + maturities[2] + '日</span>'
					+ '</p>';
				layer.open({
					title: false,
					skin: 'vip-pop',
					area: ['660px', '378px'],
					content: content
				});
			}
		});
	}, 1500);
});
