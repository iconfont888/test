$(document).ready(function () {
	// 几月几日（统计周期）
	var now = new Date(pn.sys_now);
	var historyDate=new Date(now.getFullYear(),now.getMonth(),0);
	var historyDay = historyDate.getDate() < 10 ? "0" + historyDate.getDate() : historyDate.getDate();
	var currentDate=new Date(now.getFullYear(),now.getMonth()+1,0);
	var currentDay = currentDate.getDate() < 10 ? "0" + currentDate.getDate() : currentDate.getDate();
	var histMonth = (now.getMonth()<=0)? 12 : (now.getMonth()<10 ? "0"+now.getMonth():now.getMonth());
	var month = (now.getMonth()+1)<10 ? "0"+(now.getMonth()+1):(now.getMonth()+1);
	$('#date-1').text("统计周期：北京时间"+histMonth+"月01日-"+histMonth+"月"+historyDay+"日");
	$('#date-2').text("统计周期：北京时间"+month+"月01日-"+month+"月"+currentDay+"日");
	$('#month-1').text(histMonth + '月');
	$('#month-2').text(month + '月');

	$.request({
		url : "/api/travel/bet-amount",
		data: {limit: 10}
	}).done(function (response) {
		if(response.data === "没有数据."){
			return;
		}
		if (response.successful && response.data.length > 0) {
			var content = "";
			var span = "";
			var data = response.data;
			for(var i = 0 ; i < data.length ; i++){
				if(data[i].loginName == pn.userName){
					content += '<li class="activity">';
					span = "<span>";
				}else{
					content += '<li>';
					span = '<span class="highlight">';
				}
				if(i+1 === 1){
					content += span + '<i class="num-1"></i></span>' + span + data[i].loginName + '</span>' + span + data[i].totalBetAmount.toLocaleString('en-US') + '</span></li>';
				}else if(i+1 === 2){
					content += span + '<i class="num-2"></i></span>' + span + data[i].loginName + '</span>' + span + data[i].totalBetAmount.toLocaleString('en-US') + '</span></li>';
				}else if(i+1 === 3){
					content += span + '<i class="num-3"></i></span>' + span + data[i].loginName + '</span>' + span + data[i].totalBetAmount.toLocaleString('en-US') + '</span></li>';
				}else{
					content += '<span><i class="num">' + (i + 1) + '</i></span><span>' + data[i].loginName + '</span><span>' + data[i].totalBetAmount.toLocaleString('en-US') + '</span></li>';
				}
			}
			$("#betAmountTop10").html(content);
		}else{
			failure(response.message);
		}
	}).fail(function(e){
		logConsole(e);
	});
	$.request({
		url : "/api/travel/bet-amount",
		data: {limit: 3}
	}).done(function (response) {
		if(response.data === "没有数据."){
			return;
		}
		if (response.successful && response.data.length > 0) {
			var data = response.data;
			for(var i = 0 ; i < data.length ; i++){
				if(data[i].loginName == pn.userName){
					$(".trophies").addClass("top-" + (i+1));
					$("#applyTravelBtn").show();
				}
				$("#top3_loginName_" + (i + 1)).text(data[i].loginName);
				$("#top3_betAmount_" + (i + 1)).text(data[i].totalBetAmount.toLocaleString('en-US'));
			}
		}else{
            failure(response.message);
		}
	}).fail(function(e){
        logConsole(e);
    });
});

var vipPrivilegeId;
var type = false;
// 点击 立即预约 按钮
$(".travelApplyNow").on('click', function() {
	$('.v-main').loading();
	setTimeout(function() {
		$('.v-main').loading(false);
		var content = [];
        $.request({
			url : "/api/travel/privilege"
		}).done(function (response) {
			if (response.successful) {
				vipPrivilegeId=response.data.id;
				if(response.data.subscribeStatus==='alreadySubscribe'){
					type=false;
					content.push('<p class="msg msg-ticket">您本月已经预约过海外旅游特权，请下个月再来哦！</p>');
					layer.open({
						title: false,
						skin: type ? 'vip-pop vip-pop-medium' : 'vip-pop vip-pop-small',
						area: type ? ['660px', '510px'] : ['660px', '378px'],
						btn: type ? ['确定'] : ['客户经理', '确定'],
						content: content.join(''),
						yes: function(index) {
							if(!type) {
								openWindow(window.cs_target, 850, 550);
							}
							layer.close(index);
						}
					})
				}
				if(response.data.subscribeStatus==='noSubscribe'){
					type=true;
					content.push('<p class="msg"><span class="gold-tit">顶级旅游体验&nbsp;五星级的享受</span><br/>请选择您想要的预约方式</p>');
					content.push('<div class="radio-box"><label><input type="radio" name="apply_type" value="online" checked/>');
					content.push('<span><i class="fa fa-globe icon-left"></i>在线预约</span><i class="fa fa-check" aria-hidden="true"></i></label>');
					content.push('<label><input type="radio" name="apply_type" value="phone" />');
					content.push('<span><i class="fa fa-phone icon-left"></i>电话预约</span><i class="fa fa-check" aria-hidden="true"></i></label></div>');
					layer.open({
						title: false,
						skin: type ? 'vip-pop vip-pop-medium' : 'vip-pop vip-pop-small',
						area: type ? ['660px', '510px'] : ['660px', '378px'],
						btn: type ? ['确定'] : ['客户经理', '确定'],
						content: content.join(''),
						yes: function(index) {
							if(!type) {
								openWindow(window.cs_target, 850, 550);
							} else {
								var apply_type = $('input[name="apply_type"]:checked').val();
								if(apply_type === 'online') {
									layer.open({
										title: false,
										skin: 'vip-pop vip-pop-small',
										area: ['660px', '378px'],
										btn: false,
										content: ['<p class="msg"><span class="gold-tit" style="margin-bottom: 35px;">顶级旅游体验&nbsp;五星级的享受</span><br/>',
											'您已成功预约【海外旅游】特权！<br/>正在为您接入客户经理<span class="dotting"></span></p>',
											'<div class="pop-loading"></div>'].join(''),
										success: function() {
											$.request({
												type: 'PUT',
												url: "/api/travel/subscribe/"+vipPrivilegeId,
												async: false
											}).done(function (response) {
												var data = response.data;
												if (response.successful) {
													layer.closeAll();
													openWindow(window.cs_target, 850, 550);
												}else{
													layer.open({
														title : '' ,
														yes : function (index) {
															layer.close(index);
														} ,
														content : "海外旅游特权预约失败,请联系客服或稍后再试!"
													});
												}
											});
										}
									});
									type = !type;
								} else if(apply_type === 'phone') {
									layer.open({
										title: false,
										skin: 'vip-pop vip-pop-small',
										area: ['660px', '378px'],
										btn: false,
										content: '<p class="msg"><span class="gold-tit" style="margin-bottom: 35px;">顶级旅游体验&nbsp;五星级的享受</span><br/>您已成功预约【海外旅游】特权！<br/>客户经理将在30分钟内为您致电，请您留意接听。</p>',
										success: function() {
											$.request({
                                                type: 'PUT',
                                                url: "/api/travel/subscribe/"+vipPrivilegeId,
											}).done(function (response) {
												var data = response.data;
												if (response.successful) {
													setTimeout(function() {
														layer.closeAll()
													}, 3000);
												}else{
													layer.open({
														title : '' ,
														yes : function (index) {
															layer.close(index);
														} ,
														content : "海外旅游特权预约失败,请联系客服或稍后再试!"
													});
												}
											});
										}
									});
								} else {
									layer.tips('请您先选择预约方式！', '.layui-layer-btn0', {
										tips: [1, '#695331']
									});
									return false;
								}
							}
							layer.close(index);
						}
					})
				}
			}else{
				failure(response.message);
			}
		}).fail(function(e){
            logConsole(e);
        });
	},600);
});

// 轮播右下角 数字
$('.carousel').on('slid.bs.carousel', function(ev) {
	var $this = $(this);
	var currentIndex = $this.find('.item.active').index() + 1;
	var totalNum = $this.find('.item').length;
	$this.find('.numbers').html(currentIndex + ' / ' + totalNum);

	var activeImg = $this.find('.item.active img');
	if(activeImg.attr('data-src')) {
		$this.carousel('pause');
		//$(this).loading();
		activeImg.attr('src', activeImg.attr('data-src')).load(function() {
			activeImg.removeAttr('data-src');
			$.loading(false);
			$this.carousel('cycle');
		});
	}
});

$('body').on('click', '.arrow-down', function(){
	$('body, html').animate({
		scrollTop: 882
	}, 500);
});
$('.v-menu dd').each(function (i, el) {
	var $el = $(el);
	if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
		$el.addClass('active');
		$el.siblings('dt').addClass('active');
	}
});