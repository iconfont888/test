var _now = pn.sys_now;
var _img_url = "";

var commonData = {
    module_theme:null,
    module_title:null,
    betAmount:0,
    festivalId:0
};
//  生成轮播图
$(function () {
    var $indicators = $(".carousel-indicators"), $inner = $(".carousel-inner"), $control = $(".carousel-control"), $picList = $(".picList");
    //  生成 banner 小图

    var indicatorsHtml = function (index, item) {
        var classA = index === 0 ? 'active' : '';
        
        var image = item.minImage;
        return '<li data-target="#carousel-gift" data-slide-to="' + index + '" class="' + classA + '">'
            + '</li>';
    };
    //  生成 banner 大图
    var innerHtml = function (index, item) {
        var itemObj = utils.parseJSONObj(item.jsonObj);
        if(!commonData.module_title&&itemObj&&itemObj["title"]){
            commonData.module_title = itemObj["title"];
        }
        if(!commonData.module_theme&&itemObj&&itemObj["theme"]){
            commonData.module_theme = itemObj["theme"];
        }
        var classA = index === 0 ? 'active' : '';
        var href = item.maxUrl === '' ? 'javaScript:void(0);' : item.maxUrl ;
        var target = item.target == "" ? "" : "_blank";
        var imageUrl = _img_url + item.maxImage;
        return '<div class="item ' + classA + '">'
            + '    <a class="item-img" href="' + href + '" target="'+ target +'">'
            + '     <img src="'+ imageUrl +'">'
            + '    </a></div>';
    };
    // 生成节日列表
    var picsHtml = function(index, item){
        var href = item.minUrl === '' ? 'javaScript:void(0);' : item.minUrl ;
        var target = item.target == "" ? "" : "_blank";
        var imageUrl = _img_url + item.minImage;
        var text = item.description;
        return '<li class="fl">'
            + '<a href="' + href + '" target="' + target + '">'
            + '<img src="' + imageUrl + '" />'
            + '<span>'+ text + '</span>'
            + '</a></li>';
    };
    //  生成 Banner 对象集合
    var grepBanners = function (data) {
        var banners = [];
        $.each(data, function (index, item) {
            var $banner =
                {
                    "index": item.rank,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime,
                    "minUrl": item.defaultAction || item.minImageAction,
                    "maxUrl": item.defaultAction || item.maxImageAction,
                    "minImage": item.minImageHttpUrl,
                    "maxImage": item.maxImageHttpUrl,
                    "target": item.targetType == " " ? "" : "_blank",
                    "buttons": item.templateButtons,
                    "description":item.textDescription,
                    "templateType": item.templateType,
                    "jsonObj":item.jsonObj
                };
            banners.push($banner);
        });
        return resort(grepGame(banners, [function (n) {
            if(n.endTime){
                if(n.beginTime < _now && n.endTime > _now){
                    return true;
                }
                return false;
            }else {
                return n.beginTime < _now;
            }
        }]), "index");
    };
    //  生成的轮播图
    var generate = function (data) {
        if(data === undefined) {
            return false;
        }
        var banners = grepBanners(data);
        if (!banners) {
            return false;
        }
        var indicators = [], inners = [];
        $.each(banners, function (index, item) {
            indicators.push(indicatorsHtml(index, item));
            inners.push(innerHtml(index, item));
        });
        if (indicators.length && inners.length) {
            $indicators.empty();
            $inner.empty();
            indicators.length > 1? $indicators.append(indicators.join("")): null;
            $inner.append(inners.join(""));
            if(commonData.module_theme){
                $(".duanwu h1").html(commonData.module_theme);
                if(commonData.module_theme.length>4){
                    $(".duanwu h1").addClass("longTitle");
                }
            }else{
                $(".duanwu h1").html("佳节礼品");
            }
            if(commonData.module_title){
                $(".more h1").html(commonData.module_title);
                if(commonData.module_title.length>4){
                    $(".more h1").addClass("longTitle");
                }
            }else{
                $(".more h1").html("更多礼品，敬请期待").addClass("longTitle");
            }
        }
        if(indicators.length==1){
            $control.hide();
        }else{
            $control.show();
        }
    };

    // 生成图片列表
    var packagePicList = function(data){
        if(data === undefined) {
            return false;
        }
        var banners = grepBanners(data);
        if (!banners) {
            return false;
        };
        var picArr = [];
        $.each(banners, function (index, item) {
            picArr.push(picsHtml(index, item));
        });

        if (picArr.length) {
            $picList.empty();
            $picList.append(picArr.join(""));
        }
    };
    //  佳节礼品轮播图
    cmsHelper.getScriptResult(CMS_MODEL.giftBanner)
        .done(generate)
        .done(updateRedirectUrl)
        .done(function(){
            $("#carousel-gift").on("slide.bs.carousel", function (e) {
                var target = e.relatedTarget, imgNode = $("img", target), src = imgNode.src;
                imgNode.each(function (index, item) {
                    if (!item.src) {
                        $(item).attr("src", $(item).data("src"));
                    }
                });
            });
        })
        .fail(cms_failure);

    //  佳节礼品节日图片列表
    cmsHelper.getScriptResult(CMS_MODEL.giftPicList)
        .done(packagePicList)
        .fail(cms_failure);

    initData();
});

function initData(){
    $.when(
        $.request({
            url: "/api/festivalgift/privilege",
        }),
        $.request({
            url:"/api/draw/privilege",
        })
    ).done(function(res1,res2){
        if(res1[0].successful&&res1[0].code==0){
            var data = res1[0].data;
            commonData.betAmount = data.betAmount;
            commonData.festivalId = data.id;
            displayPrizeView(data.prizeNum, data.cashBeginDate, data.cashEndDate, data.current);
        }else if(res1[0].code==5207){  // 查不到数据
            $(".clothes em").html("敬请期待");
            $(".clothes .cashOpenDate").html("暂未开放");
        }
        if(pn.userLevel<5){
            registerEvent(2);
            return;
        }
        if(res2[0].successful&&res2[0].code==200){ // 可领取
            registerEvent(6);
        }else if(res2[0].code == 5201||res2[0].code == 5207){ // 非领取时间 或没有后续活动
            registerEvent(1);
        }else if(res2[0].code==5202){  // 未达到有效投注额
            registerEvent(3);
        }else if(res2[0].code==5203){  // 礼品已领完
            registerEvent(4);
        }else if(res2[0].code==5204){ // 已经领取
            registerEvent(5);
        }else if(res2[0].code==5205){ //  同IP或者同电话
            registerEvent(8);
        }else if(res2[0].code==5206){ //  活动未开始
            registerEvent(9);
        }else if(res2[0].code==5200){
            registerEvent(res2[0].message);
        }
    }).fail(function(e){
        logConsole(e);
    });
}

function registerEvent(type){
    var type = type;
    $("#getGift").click(function () { //  同IP或者同电话
        if(typeof type=="number"){
            alertPop(type);
        }else{
            failure(type);
        }
    });
}

function alertPop(type){
    var cont = "<h3>小秘书温馨提示：</h3>";
    switch (type) {
        case 1:
            var currentMonth = new Date(_now).getMonth()+1;
            var months = "";
            if(currentMonth<=2){
                months = "2月、5月、7月、9月、12月";
            }else if(2<currentMonth&&currentMonth<=5){
                months = "5月、7月、9月、12月";
            }else if(5<currentMonth&&currentMonth<=7){
                months = "7月、9月、12月";
            }else if(7<currentMonth&&currentMonth<=9){
                months = "9月、12月";
            }else if(9<currentMonth&&currentMonth<=12){
                months = "12月";
            }
            cont += '<p class="p-2">不好意思，当月无可领取的礼品，请耐心等待！<br />活动指定月份：'+ months +'</p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                content: cont,
                scrollbar: false,
                end: function(){
                    $(".clothes em").html("敬请期待");
                }
            });
            break;
        case 2:
            cont += '<p class="p-3">只要在领取时间结束前晋级5星级及以上会员即可领取，<br />累计300万有效投注额即可晋级5星级！</p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: ['点我投注'],
                scrollbar: false,
                content: cont,
                yes: function(){
                    location.href = "/game/show/lobby/";
                }
            });
            break;
        case 3:
            var amount = commonData.betAmount==0?"5万":_AG_AMOUNT_.conversion(commonData.betAmount);
            cont += '<p class="p-3">只要在领取时间结束前完成' + amount + '有效投注额即可领取！</p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: ['点我投注'],
                scrollbar: false,
                content: cont,
                yes: function(){
                    location.href = "/game/show/lobby/";
                }
            });
            break;
        case 4:
            cont += '<p class="p-2">不好意思，礼品已领取完毕，敬请期待下一轮活动！ </p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                scrollbar: false,
                content: cont,
                end: function(){
                    $(".clothes em").html("礼品已领完");
                }
            });
            break;
        case 5:
            cont += '<p class="p-1">您已成功领取本期礼品！精致礼品会在领取成功后<br/ >7天内送到，请您耐心等待！ </p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                scrollbar: false,
                content: cont
            });
            break;
        case 6:
            cont += '<p>请输入送货所需资料即可领取成功！<br />精致礼品会在领取成功后7天内送到！</p>';
            cont += '<form id="giftGetInfoForm" class="giftGet">' +
                '                <div class="form-group">' +
                '                    <div class="input-group">' +
                '                        <label for="consignee">收货人：</label>' +
                '                        <input name="consignee" type="text" maxlength="20" placeholder="请输入收货人姓名" required/>' +
                '                    </div>' +
                '                </div>' +
                '                <div class="form-group">' +
                '                    <div class="input-group">' +
                '                        <label for="phone">手机号码：</label>' +
                '                        <input name="phone" type="text" maxlength="11" placeholder="请输入有效手机号码" required/>' +
                '                    </div>' +
                '                </div>' +
                '                <div class="form-group addr-group">' +
                '                    <div class="input-group">' +
                '                        <label for="province">送货地址：</label>' +
                '                        <div class="row">' +
                '                           <div class="fake-select">' +
                '                               <select id="province" name="province" onchange="doProvAndCityRelation()">' +
                '                                   <option id="choosePro" value="-1">省份</option>' +
                '                               </select>\n' +
                '                               <div class="select-show-text" id="provinceName">请选择省份</div>'+
                '                           </div>'+
                '                           <div class="fake-select middle-select">' +
                '                               <select id="citys" name="city" onchange="doCityAndCountyRelation()">' +
                '                                   <option id="chooseCity" value="-1">城市</option>' +
                '                               </select>\n' +
                '                               <div class="select-show-text" id="cityName">请选择城市</div>'+
                '                           </div>'+
                '                           <div class="fake-select">' +
                '                               <select id="county" name="county" onchange="doCountyRelation()">' +
                '                                   <option id="chooseCounty" value="-1">区/县</option>' +
                '                               </select>' +
                '                               <div class="select-show-text" id="countyName">请选择区/县</div>'+
                '                           </div>'+
                '                         </div>' +
                '                         <input name="site" type="text" maxlength="40" placeholder="详细地址：如街道、门牌号、小区、楼栋号" required>' +
                '                    </div>' +
                '                </div>' +
                '            </from>';

            var pop = layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small vip-pop-addition',
                area: ['660px', '510px'],
                btn: ['提交并领取','取消'],
                scrollbar: false,
                content: cont,
                success: function(){
                    var $giftGetInfoForm = $("#giftGetInfoForm");
                    var sb = new StringBuffer();
                    $.each(cityJson, function(i, val) {
                        if (val.item_code.substr(2, 4) == '0000') {
                            sb.append("<option value='" + val.item_code + "'>" + val.item_name + "</option>");
                        }
                    });
                    $("#choosePro").after(sb.toString());
                    var giftVidator = new ValidatorFrom($giftGetInfoForm, {
                        validationFunction: {
                            "consignee": function($this){
                                var value = $this.val().toLowerCase();
                                if (!value) {
                                    return {successful: false, message: "收货人姓名不能为空"};
                                }
                                if (!constants.realNameRegular.test(value)) {
                                    return {successful: false, message: "必须为汉字或者英文,最少2位"};
                                }
                                return {successful: true};
                            },
                            "phone": function ($this) {
                                var value = $this.val().toLowerCase();
                                if (!value) {
                                    return {successful: false, message: "手机号码不能为空"};
                                }
                                if (constants.INTERNET_PHONE_REGEX.test(value)) {
                                    return {successful: false, message: "无效号码，属于网络运营商"};
                                }
                                if (!constants.phoneRegular.test(value)) {
                                    return {successful: false, message: "请输入正确手机号码"};
                                }
                                return {successful: true};
                            },
                            "site": function ($this) {
                                var value = $this.val();
                                if (!value) {
                                    return {successful: false, message: "详细地址不能为空"};
                                }
                                var reg = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？ ]");
                                if(reg.test(value)){
                                    return {successful: false, message: "详细地址不能输入句号逗号分号引号等特殊字符"};
                                }
                                if (!constants.addressRuguler.test(value)) {
                                    return {successful: false, message: "详细地址必须为不少于2位，且为汉字开头的字母数字汉字组合"};
                                }
                                if (value.length > 40) {
                                    return {successful: false, message: "详细地址最多输入40位"};
                                }
                                return {successful: true};
                            }
                        },
                        validationCallBack: showError,
                        submit: function () {
                            var $submit = $giftGetInfoForm.find(".btn-submit");
                            if ($submit.hasClass("progressing-js")) {
                                return;
                            }
                            $submit.addClass("progressing-js");
                            var consignee = $giftGetInfoForm.find("input[name='consignee']").val();
                            var phone = $giftGetInfoForm.find("input[name='phone']").val();
                            var district = "";
                            if($("#provinceName").html()!="请选择省份"){
                                district += $("#provinceName").html();
                            }
                            if($("#cityName").html()!="请选择城市"){
                                district += ("," + $("#cityName").html());
                            }
                            if($("#countyName").html()!="请选择区/县"){
                                district += (","+ $("#countyName").html());
                            }
                            var site = $giftGetInfoForm.find("input[name='site']").val();

                            var formData = {"name":consignee,"phone":phone,"district":district,"site":site,"festivalId":commonData.festivalId};
                            $.request({
                                type: "POST",
                                url: "/api/downdraw/privilege",
                                data: formData
                            }).done(function (response) {
                                layer.close(pop);
                                if (response.successful&&response.code==0) { // 成功领取
                                    alertPop(7);
                                    registerEvent(5);
                                } else if(response.code==1002||response.code==1003){ //已经领取过礼品
                                    alertPop(5);
                                    registerEvent(5);
                                }else if(response.code==1004){ //活动不存在
                                    alertPop(1);
                                    registerEvent(1);
                                }else if(response.code==1005){ //不在礼品领取时间内
                                    alertPop(9);
                                    registerEvent(9);
                                }else if(response.code==1006){  //礼品已领完
                                    alertPop(4);
                                    registerEvent(4);
                                }else if(response.code==1008){  //星级未达到
                                    alertPop(2);
                                    registerEvent(2);
                                }else if(response.code==1009){  //同ip或电话
                                    alertPop(8);
                                    registerEvent(8);
                                }else{
                                    location.reload();
                                }
                            }).fail(function(e){
                                logConsole(e);
                            }).always(function () {
                                $submit.removeClass("progressing-js");
                            });
                        }
                    });
                    $giftGetInfoForm.find('input[name="phone"]').on('blur',function(e){
                        giftVidator.validation("phone").done(function (res) {
                            if (!res || res.successful === false) {
                                return;
                            }
                            $.request({
                                url: "/api/phone/right",
                                data: {
                                    phone: $(e.currentTarget).val()
                                }
                            }).done(function (rs) {
                                if(!rs.successful){
                                    showError({successful:true, message:"与绑定手机号码不一致，继续提交吗？"},"extra",$(e.currentTarget));
                                }
                            })
                        })
                    });
                    $giftGetInfoForm.find('input[name="consignee"]').on('blur',function(e){
                        giftVidator.validation("consignee").done(function (res) {
                            if (!res || res.successful === false) {
                                return;
                            }
                            $.request({
                                url: "/api/name/right",
                                data: {
                                    name: $(e.currentTarget).val()
                                }
                            }).done(function (rs) {
                                if(!rs.successful){
                                    showError({successful:true, message:"收货人与绑定姓名不一致，继续提交吗？"},"extra",$(e.currentTarget));
                                }
                            })
                        })
                    })
                },
                yes:function(){
                    $("#giftGetInfoForm").submit();
                },
                no:function(layero,index){
                    layer.close(index);
                }
            });
            break;
        case 7:
            cont += '<p class="p-2">您已经成功领取礼品，感谢您的参与！ </p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                scrollbar: false,
                content: cont
            });
            break;
        case 8:
            cont += '<p class="p-2">为保证活动回馈广大会员，本活动每位会员限同一账户及同一IP地址参加。  </p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                scrollbar: false,
                content: cont
            });
            break;
        case 9:
            cont += '<p class="p-2">不好意思，活动尚未开始领取，请耐心等待！<br /> 礼品领取时间为: ' + $(".clothes .cashOpenDate").html() + '</p>';
            layer.open({
                title: false,
                skin: 'vip-pop vip-pop-small',
                area: ['660px', '378px'],
                btn: "",
                scrollbar: false,
                content: cont
            });
            break;
    }
}

function showError(data, key, $node) {
    var $wrapper = $node.parents('.form-group');
    $wrapper.find("p").remove();
    if (!data.successful) {
        $("<p class='error help-block has-error'></p>").html(data.message || data.data).appendTo($wrapper);
    }
    if(key==="extra"&&data.successful){
        $("<p class='error help-block has-error'></p>").html(data.message).appendTo($wrapper);
    }
}

function displayPrizeView(prizeNum, cashBeginDate, cashEndDate, isCurrent){
    if((cashBeginDate&&cashEndDate&&new Date(cashBeginDate).getTime()<=_now&&_now<new Date(cashEndDate).getTime())|| isCurrent){
        $(".clothes em").html(prizeNum>0?"剩余数量：" + prizeNum + "份":"礼品已领完");
    }else{
        $(".clothes em").html("敬请期待");
    }
    var time = switchTimeToDetailDay(cashBeginDate)+' — '+switchTimeToDetailDay(cashEndDate);
    $(".clothes .cashOpenDate").html(time);
}

function switchTimeToDetailDay(date){
    if(date==undefined||date.length==0){
        return;
    }
    var month = new Date(date.replace(/-/g,"/")).getMonth()+1;
    month = month<10?"0"+month:month;
    var day = new Date(date.replace(/-/g,"/")).getDate();
    day = day<10? "0"+day:day;
    return month+"/"+day;
}

