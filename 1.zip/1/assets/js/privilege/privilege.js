$(function () {
	$('.v-menu dd').each(function (i, el) {
		var $el = $(el);
		if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
			$el.addClass('active');
			$el.siblings('dt').addClass('active');
		}
	});
    $('.header .nav a, .sidebar a, .v-menu a, .btn').easyAudioEffects({
        ogg: "/assets/audio/pi.ogg",
        mp3: "/assets/audio/pi.mp3",
        eventType: "hover"
    });
});

$(function () {
	var privilegeType = "";
	var pathname = location.pathname;
    if (pathname.indexOf("concert") != -1) {
        privilegeType = "concert";
    }
    if (pathname.indexOf("business") != -1) {
        privilegeType = "business";
    }
    if (pathname.indexOf("travel") != -1) {
        privilegeType = "travel";
    }

	var honorable = [
		{
			name: "concert",
			level: 1,
			amount: "2000万"
		}, {
			name: "business",
			level: 2,
			amount: "5000万"
		}, {
			name: "travel",
			level: 3,
			amount: "1亿"
		}
	];
	var _honorable = grepGame(honorable, [function (c) {
		return c.name === privilegeType;
	}]);
	if (_honorable.length) {
		new HonorableHelper().setLayer(_honorable);

		function HonorableHelper() {
			this.setLayer = function (_h) {
				$.request({
					url: '/api/concert/privilege'
				}).done(function (response) {
					var data = response.data;
					var $applyNow = $(".applyNow");
					$applyNow.removeClass("as-cs");
					if (response.successful) {
						var level = data.level;
						if (level >= _h[0].level) {
							$applyNow.on("click", function () {
								openWindow(window.cs_target, 850, 550);
							});
							return false;
						}
					}
					$applyNow.on("click", function () {
						layer.open({
							title: false,
							skin: 'vip-pop vip-pop-small',
							area: ['660px', '378px'],
							content: '<p class="msg">尊敬的会员，本月总有效投注达<i>' + _h[0].amount + '</i>即可解锁该特权，<br>请您继续多多投注。</p>'
						});
					});
				}).fail(function(e){
                    logConsole(e);
                });
			};
		}
	}
});

// 我的特权票务演出对接cms
function moviecms(movie){
	var html ='<li>'
		+'    <a class="pointer-link">'
		+'       <img src="'+movie.minImageUrl+'" alt=""><span>'+movie.information+'</span>'
		+'    </a>'
		+'</li>';
	return html;
}
function movieTime(beginTime,endTime){
	if(endTime){
		if(beginTime < pn.sys_now && endTime > pn.sys_now){
			return true;
		}
		return false;
	}else {
		return beginTime < pn.sys_now;
	}
}
function new_movieList(data) {
	var movieList= [];
	$.each(data,function (index,item) {
		var headline = {
			"index":item.rank,
			"pageHref": item.defaultAction,
			"activityBeginTime": item.beginTime,
			"activityEndTime": item.endTime,
			"activeprocess":movieTime(item.beginTime,item.endTime),
			"target": item.targetType == "target" ? "_blank" : "",
			"information":item.textDescription.replace(/\n/g,"<br/>"),
			"minImageUrl": item.maxImageHttpUrl,
			"templateType":item.templateType,
			"tip":item.tip,
		};
		if(movieTime(item.beginTime,item.endTime)){
			movieList.push(headline);
		}
	});
	movieList = movieList.sort(function(a,b){
		return a.index - b.index;
	});
	return movieList;
}
$(document).ready(function() {
	cmsHelper.getScriptResult(CMS_MODEL.cinematicket)
		.done(moviepage)
		.fail(cms_failure);
	function moviepage(data){
		if(data === undefined) {
            return false;
        }
		var htmlStrYch = [],htmlStrYyh=[],htmlStrHj=[],htmlStrZl=[],htmlStrWd=[],htmlStrQyzt=[],htmlStrTy=[];
		var html = new_movieList(data);
		$.each(html,function(index,item){
			if(/one/.test(item.tip)){
				htmlStrYch.push(moviecms(item));
			}else if(/two/.test(item.tip)){
				htmlStrYyh.push(moviecms(item));
			}else if(/three/.test(item.tip)){
				htmlStrHj.push(moviecms(item));
			}else if(/four/.test(item.tip)){
				htmlStrZl.push(moviecms(item));
			}else if(/five/.test(item.tip)){
				htmlStrWd.push(moviecms(item));
			}else if(/six/.test(item.tip)){
				htmlStrQyzt.push(moviecms(item));
			}else if(/seven/.test(item.tip)){
				htmlStrTy.push(moviecms(item));
			}
		});
		$("#boxYch").find(".clearfix").html(htmlStrYch.join(""));
		$("#boxYyh").find(".clearfix").html(htmlStrYyh.join(""));
		$("#boxHj").find(".clearfix").html(htmlStrHj.join(""));
		$("#boxZl").find(".clearfix").html(htmlStrZl.join(""));
		$("#boxWd").find(".clearfix").html(htmlStrWd.join(""));
		$("#boxQyzt").find(".clearfix").html(htmlStrQyzt.join(""));
		$("#boxTy").find(".clearfix").html(htmlStrTy.join(""));
	}
});

var type = "";
$("#businessApplyNow").on('click', function () {
	$('.v-content').loading();
	setTimeout(function() {
		$('.v-content').loading(false);
		var content = [];
		$.request({
			url: '/api/business/privilege'
		}).done(function (response) {
			var data = response.data;
			if (response.successful||response.code=="5930") {
                var subscribeStatus= "";
				if(data){
                    var subscribeStatus=data.subscribeStatus? data.subscribeStatus:"";
				}

				if(!subscribeStatus){
					type=1;
					content = ['<p class="msg">本月投注游戏达到有效投注额<span class="orange">5000万</span>，即可预约<br />商务秘书，请您继续加油哦！</p>'];
				}
				if(subscribeStatus==='noSubscribe'){
					type=2;
					content = ['<p class="msg"><span class="gold-tit">千挑万选 只为给您最佳人选</span>',
						'您已成功预约【商务秘书】特权！<br />正在为您接入客户经理</p>',
						'<div class="pop-loading"></div>'];
				}
				if(subscribeStatus==='alreadySubscribe'){
					type=3;
					content = ['<p class="msg">您本月已经预约过商务秘书特权，请下个月再来哦！</p>'];
				}
				layer.open({
					title: false,
					skin: 'vip-pop vip-pop-small',
					area: ['660px', '378px'],
					btn: type === 1 ? ['游戏大厅', '确定'] : type === 3 ? ['客户经理', '确定'] : false,
					content: content.join(''),
					success: function(layero, index) {
						if(type === 2) {
							layer.close(index);
							// 打开在线客服弹框
							openWindow(window.cs_target, 850, 550);
						}
					},
					yes: function(index) {
						if(type === 1) {
							window.location.href = "/game/show/lobby";
						} else if(type === 3 || type === 2) {
							layer.close(index);
							// 打开在线客服弹框
							openWindow(window.cs_target, 850, 550);
						}
					},
				});
			}else{
				failure(response.message);
			}
		}).fail(function(e){
            logConsole(e);
        });
	},600);
});
