function canvasRound() {
// 顶部数字动画
	var canvas = document.getElementById('canvas');
	var spanProcent = document.getElementById('procent');
	var ctx = canvas.getContext('2d');
	var posX = canvas.width / 2,
		posY = canvas.height / 2,
		fps = 1000 / 200,
		procent = 0,
		oneProcent = 360 / 100,
		result = oneProcent * (parseInt($('#procent').text(), 10) || 0);
	ctx.lineCap = 'square';
	(function arcMove() {
		var deegres = 0;
		var acrInterval = setInterval(function () {
			deegres += 1;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			procent = deegres / oneProcent;
			spanProcent.innerHTML = procent.toFixed();
			$('.stats > span').html(procent.toFixed());
			ctx.beginPath();
			ctx.arc(posX, posY, 42, (Math.PI / 180) * 270, (Math.PI / 180) * (270 + 360));
			ctx.strokeStyle = '#e5e5e5';
			ctx.lineWidth = '1';
			ctx.stroke();

			ctx.beginPath();
			ctx.strokeStyle = '#FF6A09';
			ctx.lineWidth = '4';
			ctx.arc(posX, posY, 42, (Math.PI / 180) * 270, (Math.PI / 180) * (270 + deegres));
			ctx.stroke();
			if (deegres >= result) {
				clearInterval(acrInterval);
			}
		}, fps);
	})();
}

var PERCENTAGE_VALUE = [0, 2, 5, 10, 20, 30, 35, 45, 50, 55, 60, 70, 72, 76, 78, 80, 88, 90, 95, 98, 99];
var PERCENTAGE_AMOUNT = [0, 1, 100, 1000, 10000, 30000, 50000, 80000, 100000, 300000, 500000, 800000, 1000000, 2000000, 3000000, 6000000, 10000000, 50000000, 100000000, 300000000, 500000000];

$(document).ready(function () {
	$.datetimepicker.setLocale('ch');
	$('#agDate').datetimepicker({
		timepicker: false,
		formatDate: 'Y/m/d',
		inline: true,
		onGenerate: function (ct) {
            var date = new Date(), currentDay = date.getDate();
            $(this).find('td[data-date=8]').addClass('highlight');
            $(this).find('td[data-date=18]').addClass('highlight');
            $(this).find('td[data-date=28]').addClass('highlight');
            $(this).find('td[data-date='+currentDay+']').removeClass('highlight');
		}
	});
	$('.xdsoft_today_button').trigger('mousedown');

	//刷新余额
	function showBalanceHandle() {
		var $balanceText = $(".total-balance-js");
		if ($balanceText.find("img").length) {
			return;
		}
		$balanceText.html('<img src="' + $balanceText.data("src") + '">');
		uCenterHelper.getBalance().done(function (response) {
			if (response.successful) {
				var data = response.data;
				$balanceText.html("¥"+ utils.amountFormatter(data.totalBalance));
			}
		});
	}

	$("#refresh_total_credit").on("click", showBalanceHandle).trigger("click");

	function updateNextVipLevel(monthBetAmount) {
		var vipName = ["商务秘书", "海外旅游"];
		var level = uCenterHelper.vipLevelAmount();
		var valueBet = level.concat(monthBetAmount);
		//直接取当前投注额所能达到的星级
		var _sort = valueBet.sort(function (a, b) {
			return a - b
		});
		var indexOf = _sort.indexOf(monthBetAmount);
		var _nextAmount = level[indexOf];
		if (_nextAmount === undefined) {
			// $(".next-vip-bet").html("恭喜您！已成功解锁所有VIP特权！");
            $(".next-vip-bet").html("本月有效投注额达到<font color='red'>前3名</font>可解锁海外旅游特权。");
			$('#procent').text(100);
		} else {
			$(".next-privilege-name").html(vipName[indexOf]);
			var nextAmount = monthBetAmount / _nextAmount;
			$('#procent').text(utils.amountFormatter(nextAmount * 100));
			if (indexOf === 1) {//海外旅游
				$(".next-vip-bet").html("本月有效投注额达到<font color='red'>前3名</font>可解锁海外旅游特权。");
			} else {
				$(".next-vip-bet-amount").html(window.utils.amountFormatter((_nextAmount / 10000)));
			}
		}
		canvasRound();
	}

	$.request({
		url: "/api/bet-amount/month"
	}).done(function (response) {
		var data = response.data;
		if (response.successful) {
			$(".month-bet-js").html(window.utils.amountFormatter(data));
			updateNextVipLevel(data);
		}
	}).fail(function(e){
        logConsole(e);
    });

	$.request({  //vip特权接口
		url: constants.vipPrefix + "/api/privilege/countInfo",
	}).done(function (response) {
		if(response.successful) {
			for(var o in response.data){    //循环json对象
				if(response.data[o] > 0){   
					$('.' + o).removeClass('disabled').find("i").removeAttr("title");  //有值则显示
				}
			}
		}
	}).done(function () {
		var $privilege = $(".supreme");
		var count = $privilege.find("dd").length;
		var unit = $(".v-account .slider .range-wrap").width() / count;
		var length = count - $privilege.find("dd.disabled").length;
		$('.v-account .slider .range').animate({
			'width': length * unit
		}, 2000, function() {
			// $(this).find('.handle').removeClass('scaleRoate');
		});
	}).fail(function(e){
        logConsole(e);
    });
});