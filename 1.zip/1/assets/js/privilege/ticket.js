$(document).ready(function () {
	// Get Started
	var faqTits = [
		'1、进入东方福利网微信公众号，绑定手机号码后进入【我的东福卡】。',
		'2、将菜单拉到最下方，选择【东福卡福利券】。',
		'3、点击绑新卡。',
		'4、输入16位卡密以及验证码。',
		'5、绑定成功后即可查看到尚未使用的卡券信息。',
		'6、在公众号菜单选择【东福文娱】--【电影】。',
		'7、选择所在城市以及想要观看的电影。',
		'8、选择适合的影院。',
		'9、选择观影时间。',
		'10、选择座位后，即可使用绑定的卡券进行支付购买。'
	]
	$('#faqCarousel').on('slide.bs.carousel', function (e) {
		var idx = $(e.relatedTarget).index();
		$(this).parent().prev().html(faqTits[idx]);
	});

	// 在线影视  立即申请
	$("#applyNow").on('click', function () {
		var elem = ['<h4>客户经理温馨提示：</h4>',
			'<p class="form-line">网站名称：<select><option value="">优酷</option><option value="">爱奇艺</option><option value="">腾讯视频</option><option value="">乐视视频</option></select></p>'
		];
		layer.open({
			title: false,
			skin: 'vip-pop',
			area: ['520px', '314px'],
			btn: ['申请'],
			content: elem.join(''),
			yes: function (index) {
				layer.close(index);
				var result = ['<h4>恭喜您获得优酷的一个月VIP使用权。</h4>',
					'<p class="form-line">账号：freestyle<br />密码：freestyle123</p>'
				];
				layer.open({
					title: false,
					skin: 'vip-pop',
					area: ['520px', '314px'],
					btn: ['发送到手机'],
					content: result.join('')
				});
			}
		});
	});

	// 领取记录 发送短信
	$(".btn-send").on('click', function () {
		layer.open({
			title: false,
			skin: 'vip-pop',
			area: ['520px', '314px'],
			content: '<p class="msg">短信已成功发送，请注意查看您的手机信息。</p>'
		});
	});
	function unknownException() {
		var content = ["<h4>服务器发生未知错误 , 请联系客服 ...</h4>"];
		layer.open({
			title: false,
			skin: 'vip-pop vip-pop-small',
			area: ['660px', '378px'],
			btn: ['确定'],
			content: content.join('')
		});
	}

	function depositNotEnough() {
		var content = ['<p class="msg">本月充值达到<span class="orange">1000元</span>即可领取观影券，<br />请您继续加油哦！</p>'];
		layer.open({
			title: false,
			skin: 'vip-pop vip-pop-small',
			area: ['660px', '378px'],
			btn: ['立即充值', '确定'],
			content: content.join(''),
			yes: function () {
				window.location.href = "/ucenter/pay/payIndex";
			}
		});
	}
	function userLevelNotEnough() {
		var content = [
			'<p class="msg">只要会员星级达到<span class="orange">VIP5</span>及以上 , 即可解锁<br/>【电影门票】特权 , 请您继续加油哦 !</p>',
			'<p></p>',
			'<a href="/activity/promote" class="howto howto2" style="padding-bottom:2px;border-bottom:1px solid #c7603f;font-size:16px;color:#c7603f;">如何晋升星级 ?</a>',
			'<br/><br/><br/>',
			'<div class="layui-layer-btn layui-layer-btn-"><a class="layui-layer-btn1" style="top:40px;">确定</a></div>'
		];

		layer.open({
			title: false,
			skin: 'vip-pop vip-pop-small',
			area: ['660px', '378px'],
			content: content.join(''),
			success: function (layer1) {
				layer1.find('.layui-layer-btn0').hide();
				var btn = layer1.find('.btn-determine');
				btn.on('click', function () {
					layer.closeAll();
				});
			}
		});
	}
	//领取影券
	$("#getTicket").on("click", function () {
		$(".loadingBox").loading();
		$.request({
			url: "/api/movie/privilege",
            async:false
		}).done(function (response) {
			if (response.successful) {
				openWindow(window.cs_target, 850, 550);
			} else {
				if (response.code === 5701) {
					userLevelNotEnough();
				} else if (response.code === 5940) {
					depositNotEnough();
				}else {
                    unknownException();
				}
			}
		}).fail(function(e){
            logConsole(e);
        }).always(function () {
			$(".loadingBox").loading("close");
		});
	});
});

// 我的特权电影门票对接cms
function moviecms(movie){
	var html ='<li>'
		+'    <a class="pointer-link">'
		+'       <img src="'+movie.minImageUrl+'" alt=""><span>'+movie.information+'</span>'
		+'    </a>'
		+'</li>';
	return html;
}
function movieTime(beginTime,endTime){
	if(endTime){
		if(beginTime < pn.sys_now && endTime > pn.sys_now){
			return true;
		}
		return false;
	}else {
		return beginTime < pn.sys_now;
	}
}
function new_movieList(data) {
	var movieList= [];
	$.each(data,function (index,item) {
		var headline = {
			"index":item.rank,
			"pageHref": item.defaultAction,
			"activityBeginTime": item.beginTime,
			"activityEndTime": item.endTime,
			"activeprocess":movieTime(item.beginTime,item.endTime),
			"target": item.targetType == "target" ? "_blank" : "",
			"information":item.textDescription,
			"minImageUrl":  item.maxImageHttpUrl,
			"templateType":item.templateType
		};
		if(movieTime(item.beginTime,item.endTime)){
			movieList.push(headline);
		}
	});
	movieList = movieList.sort(function(a,b){
		return a.index - b.index;
	});
	return movieList;
}
$(document).ready(function() {
	cmsHelper.getScriptResult(CMS_MODEL.movie)
		.done(moviepage)
		.fail(cms_failure);
	function moviepage(data){
		if(data === undefined) {
            return false;
        }
		var htmlStr = [];
		var htmlStro=[];
		var html = new_movieList(data);
		$.each(html,function(index,item){
			if(item.templateType=="AD"){
				htmlStr.push(moviecms(item));
			}else{
				htmlStro.push(moviecms(item));
			}
		});
		$("#inTheater").find(".clearfix").html(htmlStr.join(""));
		$("#comingSoon").find(".clearfix").html(htmlStro.join(""));
	}
});
$('.v-menu dd').each(function (i, el) {
	var $el = $(el);
	if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
		$el.addClass('active');
		$el.siblings('dt').addClass('active');
	}
});