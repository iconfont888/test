/**
 * Created by Davy on 2016/9/13.
 */
(function ($, window, document, undefined) {
    var $window = $(window);
    $.fn.agmodal = function (options) {
        var elements = this;
        var htmlTemplate = function (options) {
            var footer = "";
            if (options.confirm || options.cancel) {
                footer = '<div class="modal-footer as-text-align-center">' +
                    (options.confirm ? '<button type="button" class="btn btn-primary confirm">' + options.confirmText + '</button>' : "") +
                    (options.cancel ? '<button type="button" class="btn btn-default cancel" data-dismiss="modal">' + options.cancelText + '</button>' : "") +
                    '</div>';
            }
            return '<div data-backdrop="' + options.backdrop + '" class="modal fade ag-modal-as' + (settings.blur ? ' ag-modal-blur' : '') + ' ' + options.modalClass + '" id="' + options.id + '" tabindex="-1" role="dialog">' +
                '    <div class="modal-dialog modal-sm custom" role="document">' +
                '        <div class="modal-content">' +
                '            <div class="modal-header gradient-bg">' +
                '                <button type="button" class="close" data-dismiss="modal" aria-label="Close">' +
                '                            <span aria-hidden="true">' +
                '                               X' +
                '                            </span>' +
                '                </button>' +
                '                <p class="modal-title">' + options.title + '</p>' +
                '            </div>' +
                '            <div class="modal-body text-center ' + options.bodyClass + '">' +
                '            </div>'.concat(footer) + '        </div>' +
                '    </div>' +
                '</div>';
        };
        var settings = {
            backdrop: true,
            allowClose: true,
            closeEvent: null,
            modalClass: "",
            titleClass: "",
            bodyClass: "",
            showEvent: null,
            title: "提示",
            context: "",
            confirm: false,
            confirmEvent: null,
            confirmText: "保存",
            cancel: true,
            cancelText: "确定",
            cancelEvent: null,
            id: null,
            load: null,
            blur: false
        };
        if (options) {
            $.extend(settings, options);
        }
        if (!settings.id) {
            settings.id = "as" + (new Date() - 1);
        }
        var closeOtherModal = function () {
            var d = $.Deferred();
            var _other = $("div.modal:visible");
            $('body>.modal-backdrop.fade.in').remove();
            if (_other.length > 0 && _other.modal && typeof _other.modal === 'function') {
                try {
                    _other.one("hidden.bs.modal", function () {
                        d.resolve();
                    });
                    _other.modal('hide');
                } catch (Error) {
                    if (console) {
                        console.log(Error);
                    }
                    d.resolve();
                }
            } else {
                d.resolve();
            }
            return d.promise();
        };
        $(".ag-modal-as").remove();
        closeOtherModal().done(function () {
            $(htmlTemplate(settings)).find(".modal-body").append(settings.context).end().appendTo(elements);
            var modal = $("#" + settings.id);
            if (settings.closeEvent && typeof settings.closeEvent === "function") {
                modal.on("hide.bs.modal", settings.closeEvent);
            }
            if (settings.showEvent && typeof settings.showEvent === "function") {
                modal.on("show.bs.modal", settings.showEvent);
            }
            if (settings.confirmEvent) {
                modal.find(".confirm").on("click", {modal: modal}, settings.confirmEvent.bind(modal));
            }
            if (settings.cancelEvent) {
                modal.find(".cancel").on("click", {modal: modal}, settings.cancelEvent);
            }
            modal.modal("show");
            return modal;
        });

    }
})(jQuery, window, document);