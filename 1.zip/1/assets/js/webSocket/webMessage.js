var href = window.location.pathname;
var withdraw = /\/withdrawIndex/g.test(href);

$(document).ready(function(){
    if(pn.userType == "1"){
        $.request({
            url:"/api/message/token",
            success:function (response) {
                if(response.successful){
                    startWebSocket(response.data);
                }
            },
            error: function(xhr,textStatus,err){
                logConsole("error: " + err);
            }
        });
    }
    if(withdraw){
        $('.tab li:eq(0)').trigger('click');
    }
});

function formLetter(message){
    var total = getUnReadTotal(),
        content = message["content"],
        msgType = message["msgType"],
        id = message["id"],
        title = message["title"],
        showType = message["showType"];
    content.replace("<p>","").replace("</p>","");
    content = (content.length>60)?content.substring(0,60)+"...":content;

    var windowHtml = '<div class="fix-letter">' +
        '<h4>您共有<span>'+total+'</span>条未读消息<i class="gift-close"></i></h4>' +
        '<div class="msg-tip">';
    if(showType == "2"){
        windowHtml += '<a href="/ucenter/letter/details/index.html?id='+id+'&msgType='+msgType+'">' +
            '<h3>' + title + '</h3>' + content + '</a>';
    }else{
        windowHtml += '<a><h3>' + title + '</h3>' + content +'</a></div></div>';
    }
    return windowHtml;
}

function getUnReadTotal(){
    var total = 1;
    $.ajax({
        type: 'GET',
        url:"/api/letters/unread",
        async:false,
        dataType: 'JSON',
        headers: {
            "X-Website-Code":"MAIN_PC"
        },
        success:function(response){
            if(response.successful){
                var data = response.data;
                var noticeCount = data.notice;
                var perferentialCount = data.perferential;
                total = noticeCount + perferentialCount;
                if(total == 0){
                    total = 1;
                }
            }else{
                logConsole(response.message);
            }
        },
        error: function(xhr,textStatus,err){
            logConsole("error: " + err);
        }
    });
    return total;
}
var data_map = {};
var active_table = {};
var time_status_B;
//初始化需要显示的桌台
active_table['qj'] = 'B001';
var vipPrivilegeLoginName = sessionStorage.getItem("vipPrivilege")
if(vipPrivilegeLoginName && vipPrivilegeLoginName == pn.userName) {
    $('#vipkehu').addClass('on');
    $('#vipkehu').on("click", function(){
        $(this).removeClass("on");
        sessionStorage.removeItem("vipPrivilege");
    })
}

function startWebSocket(data){
    if(!_VALID.isNormal(data)){
        return;
    }
    var tigerMessageUrl = data.url;
    var xtoken = data.token;
    var stompClient = null;
    var socket = new SockJS(tigerMessageUrl+'/web/message');
    stompClient = Stomp.over(socket);
    stompClient.debug = null;
    stompClient.connect({'x-auth-token': xtoken}, function () {
        stompClient.subscribe('/user/msg/receive/pc',function(greeting){
            showLetter(JSON.parse(greeting.body));
        });
        stompClient.subscribe('/user/msg/receive/commonMessage/B79',function(greeting){
            //header我的特权btn 新升级用户就给一个提示，清除便不会显示（vip4以上）
            sessionStorage.setItem("vipPrivilege", (greeting.body && JSON.parse(greeting.body).loginName) || "");
            $('#vipkehu').addClass('on');
            $('#vipkehu').on("click", function(){
                $(this).removeClass("on");
                sessionStorage.removeItem("vipPrivilege");
            })
        });
        // if(withdraw){
        //     /*旗舰厅*/
        //     stompClient.subscribe('/lobby/agin/result_list', function (greeting) {
        //         var jsonStr = greeting.body;
        //         if(jsonStr.indexOf("[")==0){
        //             tableFilter(jsonStr.substring(1,jsonStr.length-1));
        //         }else{
        //             var historyList = JSON.parse(jsonStr);
        //             $.each(historyList, function (index, item) {
        //                 var table = JSON.parse(item);
        //                 var tableStr;
        //                 for (var key in table) {
        //                     tableStr = table[key];
        //                 }
        //                 tableFilter(tableStr);
        //             });
        //         }
        //     });

        //     //newRound
        //     stompClient.subscribe('/lobby/agin/new_round', function (greeting) {
        //         //缓存数据
        //         var body = greeting.body;
        //         var newRound = body.substring(1, body.length - 1);
        //         if (newRound == "" || newRound.length == 0) {
        //             return;
        //         }
        //         var new_round = JSON.parse(newRound);
        //         var new_round_vid = new_round.vid;
        //         resetDate(new_round_vid, "new_round", new_round);
        //         //根据展示桌台决定是否展示数据
        //         if (new_round_vid == active_table['qj']) {
        //             var b_left = $('#' + new_round_vid).find('.b-left').find('h3')[0];
        //             $(b_left).html('发牌倒计时<span>' + new_round.seconds + '</span>秒');
        //         }
        //     });
        // }
        depositFailureMsg(stompClient);
        depositOriginMsg(stompClient);

        if(location.pathname!="/game/dygame/"){
            promotedMsg(stompClient);
        }
    });
}

/**
 *   用户星级晋级弹窗提醒
 **/
function promotedMsg(stompClient){
    stompClient.subscribe('/user/msg/receive/window_user_promotion', function (msg) {
        if(utils.getCookie("promote_pop")){
            return;
        }
        if(msg) {
            var msgObj = JSON.parse(msg.body);
            var tips = {
                loginName: msgObj.loginName,
                productId: msgObj.productId,
                customerLevel: msgObj.customerLevel,
                statisticValidAccount: msgObj.statisticValidAccount,
            };
            if(tips.customerLevel==5||tips.customerLevel==6){
                var pop = {};
                if(tips.customerLevel==5){
                    pop.left = 'VIP4';
                    pop.totalAmount = utils.amountFormatter(3000000,false);
                    pop.right = 'VIP5';
                    pop.prize = 2000;
                    pop.className = "promote-pop";
                }else if(tips.customerLevel==6){
                    pop.left = 'VIP5';
                    pop.totalAmount = utils.amountFormatter(6000000,false);
                    pop.right = 'VIP6';
                    pop.prize = 4000;
                    pop.className = "promote-pop promote-pop-2";
                }
                var content = '<div class="content">' +
                    '<div class="pbf">' +
                    '<div class="left">'+pop.left+'</div>' +
                    '<div class="progressbarfull">' +
                    '<p class="progress"></p>' +
                    '<p class="horizon-line"></p>' +
                    '<div class="pointer">' +
                    '<span class="weekValidAmount">'+utils.amountFormatter(tips.statisticValidAccount,false)+'</span>/' +
                    '<span class="totalValidAmount">'+pop.totalAmount+'</span>' +
                    '</div>' +
                    '</div>' +
                    '<div class="right">'+pop.right+'</div>' +
                    '</div>' +
                    '<ul class="rights">' +
                    '<li>晋级礼金：<span class="promotePrize">'+pop.prize+'</span>元</li>' +
                    '<li>佳节好礼</li>' +
                    '</ul>' +
                    '<a class="go-invest">马上投注</a>' +
                    '<a class="link-more-right">更多至尊VIP权益</a>' +
                    '</div>';
                layer.open({
                    skin:  pop.className,
                    btn:false ,
                    btnActive: 0,
                    shadeClose: true,
                    content: content,
                    area:['856px','644px'],
                    success: function (layero) {
                        setTimeout(function(){
                            levelAnimation(tips.statisticValidAccount, tips.customerLevel);
                        }, 500);
                        utils.setCookie("promote_pop","1",7);
                        $(layero).find(".go-invest").on("click",function(){
                            layer.closeAll();
                            location.href = "/game/show/lobby/";
                        });
                        $(layero).find(".link-more-right").on("click",function(){
                            layer.closeAll();
                            location.href = "/activity/promote/";
                        });
                    }
                });
            }
        }
    });
}

function levelAnimation(money, current_level){
    var $progress = $('.progress'), $pointer = $('.pointer');
    _width = current_level==5?money/3000000*520:money/6000000*520;
    if(_width<115){
        _left = 0;
    }else if(_width>=115&&_width<405){
        _left = _width - 115;
    }else{
        _left = 290;
    }
    $progress.animate({'width': _width + 'px'}, 500, 'linear');
    $pointer.animate({'left':_left + 'px'}, 500, 'linear');
}

//是否已经初始化了存款失败标识
var depositFailureFlag = false;
var depositOriginFlag = false;
/**
 * 校验存款失败弹窗页面是否符合弹出规则
 */
function depositFailPageRule() {
    var pathName = location.pathname;
    var pathName = (pathName.length > 1 && pathName.lastIndexOf("/") == pathName.length - 1)
        ? pathName.substr(0, pathName.length - 1) : pathName;
    var containsUrl = ["/", "/index.html", "/ucenter/account", "/ucenter/recommend/statis", "/ucenter/transaction/view",
        "/ucenter/pay/payIndex", "/ucenter/withdraw/withdrawIndex", "/ucenter/rebate/view",
        "/ucenter/mission/newcomer", "/ucenter/mission/daily", "/ucenter/mission/achieve",
        "/ucenter/person/pwdIndex", "/ucenter/bank/bankIndex", "/ucenter/security/phone", "/ucenter/subscribe",
        "/ucenter/letters"];
    if(containsUrl.indexOf(pathName) >= 0 || pathName.indexOf("/privilege") >= 0) {
        return true;
    }
    return false;
}

/**
 * 存款失败消息接收
 */
function depositFailureMsg(stompClient) {
    if(depositFailureFlag) {
        return;
    }
    depositFailureFlag = true;

    stompClient.subscribe('/user/msg/receive/depositFail/B79', function (msg) {
        if(msg) {
            var msgObj = JSON.parse(msg.body);
            var tipMessage = {
                type: (msgObj.notifyWay == 1 ? "weixin" : "qq"),
                text: msgObj.account,
                copy: true,
                timeClose: false,
                timeCloseMin: 60000,
                html: msgObj.note,
                loginName: msgObj.loginName
            }
            if(depositFailPageRule()) {
                var $Message = new Message();
                $Message.init(tipMessage);
            }else {
                //由于消息只推送一次，故不是以上界面的线缓存消息到session，如果清除便不会弹出。
                var tipMessageJson = JSON.stringify(tipMessage);
                sessionStorage.setItem("tipMessageJson", tipMessageJson);
            }
        }
    });
}
// 多个域名弹出框
function depositOriginMsg(stompClient) {
    if(depositOriginFlag) {
        return;
    }
    depositOriginFlag = true;
    stompClient.subscribe('/user/msg/receive/send_lottery', function (msg) {
        if(msg) {
            var msgObj = JSON.parse(msg.body);
            if(msgObj.type == '1'){
                moreOriginModal('rechargeModal','/activity/maserati1788')
            } else if(msgObj.type == '-102'){
                layer.open({
                    title:' ',
                    content: '彩券已派完！<br>请关注其余优惠，谢谢！',
                    btn: ['确定'],
                    closeBtn: 1,
                });
            }else if(msgObj.type == '-103'){
                layer.open({
                    title:' ',
                    content: '您的IP或电话不能重复享受该优惠！<br>请关注其余优惠，谢谢！',
                    btn: ['确定'],
                    closeBtn: 1,
                });
            }
            
        }
    });
}   
/**
 * 获取cooKie中的消息进行弹窗显示
 */
$(function() {
    if(depositFailPageRule()) {
        var tipMessageJson = sessionStorage.getItem("tipMessageJson");
        if(tipMessageJson) {
            var tipMessage = JSON.parse(tipMessageJson);
            if(pn.userName == tipMessage.loginName) {
                var $Message = new Message();
                $Message.init(tipMessage);
                sessionStorage.removeItem("tipMessageJson");
            }
        }
    }
});


function showLetter(message){
    var letterHtml = formLetter(message);
    $("body").append($(letterHtml));
    var $modal = $('.fix-letter');
    $modal.fadeIn(2000);
    var timer = setTimeout(function() {
        $modal.fadeOut(function() {
        	$modal.remove();
        });
    }, 4000);
    $modal.mouseenter(function() {
        clearTimeout(timer);
    }).on('mouseleave', function() {
        $modal.fadeOut(2000, function() {
        	$modal.remove();
        });
    });
    $('.gift-close').click(function() {
        $('.fix-letter').fadeOut(function() {
        	$modal.remove();
        });
    });
}

function tableFilter(tableStr){
    var luzituHelper = new LuzituHelper(tableStr, showInfo, maxLength);
    var data = {
        data: [luzituHelper.daluDate, luzituHelper.dayanluDate, luzituHelper.xiaoluDate, luzituHelper.xiaoqiangluDate],
        roundCount: luzituHelper.roundCount,
        seconds: luzituHelper.seconds,
        status: luzituHelper.status,
        vid: luzituHelper.vid
    };
    resetDate(luzituHelper.vid, "data", data);
    if (data.vid == active_table['qj'] ) {
        //清除左面板
        //left_handler_clear(b_left);
        //展示左面板
        var b_left = $('#' + data.vid).prev().find('.active');
        left_handler(b_left);
        //路子图
        var $chart = $('#' + data.vid).find('.chart');
        $chart.removeClass('loading');
        draw($chart, data.data);
    }
}
/**
 * 渲染左面板
 */
function left_handler(object) {
    var tab_name = $(object).attr("data-value");
    var b_left = $(object).parent().parent().next().find('.b-left');
    //设置属性
    $(b_left).parent().attr("id", tab_name);
    var round = b_left.find('h3');
    var tableDate = data_map[tab_name].data;
    for (var i = 0; i < round.length; i++) {
        if (i == 0) {
            time_status_B = time_handler(time_status_B, round[i], tab_name);
        } else {
            $(round[i]).find('span').html(tableDate.roundCount);
        }
    }
    var dl = b_left.find('dl');
    if (tableDate == null) {
        return;
    }
    dl.find('.red').html('庄<span>' + tableDate.status.banker + '</span>');
    dl.find('.blue').html('闲<span>' + tableDate.status.player + '</span>');
    dl.find('.green').html('和<span>' + tableDate.status.equal + '</span>');
}

function time_handler(status, round, tab_name) {
    clearInterval(status);
    status = setInterval(function () {
        if ('seconds' in data_map[tab_name] && data_map[tab_name].seconds > 0) {
            data_map[tab_name].seconds--;
            $(round).html('本局剩余<span>' + data_map[tab_name].seconds + '</span>秒结束');
        } else if (data_map[tab_name].new_round != undefined && data_map[tab_name].new_round.seconds > 0) {
            data_map[tab_name].new_round.seconds--;
            $(round).html('发牌倒计时<span>' + data_map[tab_name].new_round.seconds + '</span>秒');
        }
    }, 1000);
    return status;
}

/**
 * 清除左面板
 */
function left_handler_clear(object) {
    var b_left = $(object).parent().parent().next().find('.b-left');
    //清除属性
    //$(b_left).parent().removeAttr("id");
    var round = b_left.find('h3');
    for (var i = 0; i < round.length; i++) {
        if (i == 0) {
            $(round[i]).html('本局剩余<span>0</span>秒结束');
        } else {
            $(round[i]).find('span').html(0);
        }
    }
    var dl = b_left.find('dl');
    dl.find('.red').html('庄<span>0</span>');
    dl.find('.blue').html('闲<span>0</span>');
    dl.find('.green').html('和<span>0</span>');
}
//重新设置data
function resetDate(vid, key, date) {
    var tabbleDate = data_map[vid];
    if (tabbleDate == null) {
        tabbleDate = {};
    }
    var newRoundDate = tabbleDate.new_round;
    var tableDate = tabbleDate.data;
    data_map[vid] = {};
    if (key == "new_round") {
        data_map[vid] = {
            new_round: date,
            data: tableDate
        }
    } else if (key == "data") {
        data_map[vid] = {
            new_round: newRoundDate,
            data: date
        }
    }
}

function draw(el, d) {
    var $wrap = el;
    var width = $wrap.parent().width();
    // 计算每行格子数量nums  每个格子固定宽12px
    var nums = parseInt(width / 12, 10);

    // getRowDom 获取每行dom
    var getRowDom = function (id, row, col) {
        var el = ['<div class="line">'];
        for (var i = 0; i < col; i++) {
            // 最终每个格子的class为 s_0_1_2 代表第1组 第2行 第3列 的格子
            el.push('<span class="s_' + id + '_' + row + '_' + i + '"></span>');
        }
        el.push('</div>');
        return el.join('');
    }
    var getGroupDom = function (id, row, col) {
        var el = ['<div class="group">'];
        for (var i = 0; i < row; i++) {
            el.push(getRowDom(id, i, col));
        }
        el.push('</div>');
        return el.join('');
    }

    var getChart = function () {
        return getGroupDom(0, 6, nums) + getGroupDom(1, 3, nums) + getGroupDom(2, 3, nums)
    };

    $wrap.html(getChart());
    renderData($wrap, d);
};

// 根据返回结果渲染对应box的走势结果
var renderData = function (el, d) {
    var getIconDom = function (cls) {
        return '<i class="i-' + cls + '"></i>';
    }

    var setIcon = function (group, col, colData) {
        for (var i = 0; i < colData.length; i++) {
            el.find('.s_' + group + '_' + i + '_' + col).html(getIconDom(colData[i]));
        }
    }

    var setIconFour = function (group, col, colData) {
        for (var i = 0; i < colData.length; i++) {
            var d = colData[i].split('');
            var dom = [];
            for (var j = 0; j < d.length; j++) {
                dom.push(getIconDom(d[j]));
            }
            el.find('.s_' + group + '_' + i + '_' + col).html(dom.join(''));
        }
    }

    for (var i = 0; i < d.length; i++) {
        var row = d[i];
        for (var j = 0; j < row.length; j++) {
            var colData = row[j].split('|');
            // i = 0 第一组
            if (i === 0) {
                setIcon(0, j, colData);
            } else if (i === 1) {
                setIconFour(1, j, colData);
            } else if (i === 2) {
                setIconFour(2, j, colData);
            } else if (i === 3) {
                setIconFour(2, j + 18, colData);
            }
        }
    }
}

$("ul.tab").find("li").on("click",function(e){
    var $chart = $('.chart');
    $(this).addClass('active').siblings().removeClass('active');
    $chart.addClass('loading');
    left_handler_clear(this);
    //缓存展示的桌台
    var tab_name = $(this).attr("data-value");
    active_table['qj'] = tab_name;
    if (tab_name in data_map) {
        if ("data" in data_map[tab_name]) {
            if (data_map[tab_name].data && "data" in data_map[tab_name].data) {
                var datemap = data_map[tab_name].data.data;
                if (datemap == null || datemap == undefined) {
                    return;
                }
                left_handler(this);
                $chart.removeClass('loading');
                draw($chart, datemap);
            }
        }
    }
})
