function Message(){
    /**
     *  @author candice
     *  @params : {  }
     *
     *
     **/
    var self = this;
    self.id = 'message-' + parseInt(Math.random(1) * 10000);
    self.div = document.createElement('div');
    self.div.id = self.id;
    self.div.className = 'candice-message';
    self.html = null;
    self.param = {
        type: 'weixin', //string
        text: '123456789123', // string
        copy: true, //bool
        html: "请联系客服",
        timeClose: true, // bool
        timeCloseMin: 60000, // number
        callback:function(){} // function 复制成功之后的函数
    }

    this.addCss = function () {
        var linkLabel = document.createElement("link");
        linkLabel.rel = "stylesheet";
        linkLabel.href = location.origin + '/assets/css/tipMessage.css';
        document.head.appendChild(linkLabel);
    }

    this.init = function(par){
        this.addCss();
        for(var key in par){
            if(self.param[key]){
                self.param[key] = par[key]
            }
        }
        self.getHtml();
    }
    this.getHtml = function(){
        self.div.innerHTML = self.getContentHtml();
        self.show();
        if(self.param.timeClose){
            self.timeAn = setTimeout(function(){
                self.hide();
                self.clear()
            }, self.param.timeCloseMin)
        } else {
            self.clear('timeAn')
        }
        document.querySelector('#' + self.id +' .close').onclick = function(){
            self.hide()
        }
        document.querySelector('#' + self.id +' .copy').onclick = function(){
            self.copy(self.param.text);
            document.querySelector('#' + self.id +' .copy').textContent = '复制成功';
            self.param.callback(true);
            self.copyAn = setTimeout(function(){
                document.querySelector('#' + self.id +' .copy').textContent = '复制';
                self.clear('copyAn')
            }, 2000)
        }
    }
    this.getContentHtml = function(){
        var html = '<div class="'+ self.param.type +'">';
        var leftHtml = '', rightHtml = '', rightFooterHtml = '', copyHtml = '';
        if(self.param.type == 'qq'){
            leftHtml = '<span class="qq-icon"></span><p>搜索QQ号</p>';
            rightHtml = '充值遇到问题？ QQ客服帮帮我！';
            rightFooterHtml = self.param.html;//'首次存款联系qq客服拿好礼';
        } else {
            leftHtml = '<span class="weixin-icon"></span><p>搜索微信号</p>';
            rightHtml = '充值遇到问题？ 微信客服帮帮我！';
            rightFooterHtml = self.param.html;//'首次存款联系微信客服拿好礼';
        }
        if(self.param.copy){
            copyHtml = '<span class="copy float-left" style="width: 61px;">复制</span>'
        }
        html += '<div class="left">' + leftHtml + '</div>';
        html += '<div class="right">'+
            '<p class="title" style="width:247px;">'+ rightHtml +'</p>' +
            '<p class="text clear-float"><span class="content-text float-left">'+ self.param.text + '</span>' + copyHtml +'</p>' +
            '<p class="footer-title">'+ rightFooterHtml +'</p>' +
            '</div>'
        html += '</div><div class="close" ></div>';
        return html;
    }
    this.getWeiXinHtml = function(){
        var html = '';
        return html;
    }
    this.show = function(){
        document.body.appendChild(self.div)
        self.showAn = setTimeout(function() {
            document.getElementById(self.id).style.bottom = '0px';
            self.clear(self.showAn)
        },300)

    }
    this.hide = function(){
        document.getElementById(self.id).style.bottom = '-300px';
        self.hideAn = setTimeout(function() {
            document.getElementById(self.id).parentNode.removeChild(document.getElementById(self.id))
            self.clear(self.hideAn)
        },3000)

    }
    this.copy = (function (window, document, navigator) {
        var textArea;

        function isOS() {
            return navigator.userAgent.match(/ipad|iphone/i);
        }

        function createTextArea(text) {
            textArea = document.createElement('textArea');
            textArea.value = text;
            document.body.appendChild(textArea);
        }

        function selectText() {
            var range,
                selection;

            if (isOS()) {
                range = document.createRange();
                range.selectNodeContents(textArea);
                selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
                textArea.setSelectionRange(0, 999999);
            } else {
                textArea.select();
            }
        }

        function copyToClipboard() {
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }

        return function (text) {
            createTextArea(text);
            selectText();
            copyToClipboard();
        };
    })(window, document, navigator);
    this.clear = function(objName){
        // 清除无用的内存
        self[objName] = null;

    }
}
