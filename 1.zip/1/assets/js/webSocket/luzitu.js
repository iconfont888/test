var showInfo = {
    daluInfo:{"bankerWin":"a","bankerEqual":"b","playerWin":"c","playerEqual":"d","placeHolder":"0"},
    dayanluInfo:{"red":"e","blue":"f","placeHolder":"0"},
    xiaoluInfo:{"red":"g","blue":"h","placeHolder":"0"},
    xiaoqiangluInfo:{"red":"i","blue":"j","placeHolder":"0"}
};
var maxLength = {
    dalu:6,
    dayanlu:6,
    xiaolu:6,
    xiaoqianglu:6
};
//路子图结果整理
function LuzituHelper(msg,showInfo,maxLength){
    var A = "A";//庄
    var B = "B";//庄和
    var C = "C";//闲
    var D = "D";//闲和
    var AB = ['A','B'];
    var message = JSON.parse(msg)
    var roundRes = message.roundRes;
    this.seconds = message.seconds;
    this.vid = message.vid;
    var initDate = initMsg(roundRes);
    this.status = initDate.status;
    //总局数
    this.roundCount = message.roundCount;
    //大路原始数据
    var daluInitDate = initDate.daluInitDate;

    //路子图原始数据
    this.daluList = getDaluList(daluInitDate);
    this.dayanluList = sort(this.daluList,1);
    this.xiaoluList = sort(this.daluList,2);
    this.xiaoqiangluList = sort(this.daluList,3);

    var daluListHandler = handler(this.daluList,maxLength.dalu);
    var dayanluListHandler = handler(this.dayanluList,maxLength.dayanlu);
    var xiaoluListHandler = handler(this.xiaoluList,maxLength.xiaolu);
    var xiaoqiangluListHandler = handler(this.xiaoqiangluList,maxLength.xiaoqianglu);

    //大路绘制结果
    var daluInfo = showInfo.daluInfo;
    this.daluDate = daluHandler(daluListHandler,daluInfo);

    //大眼路绘制结果
    var dayanluInfo = showInfo.dayanluInfo;
    this.dayanluDate = otherHandler(dayanluListHandler,dayanluInfo);

    //小路绘制结果
    var xiaoluInfo = showInfo.xiaoluInfo;
    this.xiaoluDate = otherHandler(xiaoluListHandler,xiaoluInfo);

    //小强路绘制结果
    var xiaoqiangluInfo = showInfo.xiaoqiangluInfo;
    this.xiaoqiangluDate = otherHandler(xiaoqiangluListHandler,xiaoqiangluInfo);

    //初始化数据
    function initMsg(date){
        var result = {};
        var daluInitDate = [];
        var banker = 0,
            player = 0,
            equal = 0;
        for (var gameId in date){
            var banker_val = date[gameId].banker_val;
            var player_val = date[gameId].player_val;
            if(banker_val > player_val){
                daluInitDate.push(A);
                banker++;
            }else if(banker_val < player_val){
                daluInitDate.push(C);
                player++;
            }else if(banker_val == player_val){
                var daluListBefor = daluInitDate[daluInitDate.length-1];
                if(daluListBefor == A){
                    daluInitDate[daluInitDate.length-1] = B;
                }else if(daluListBefor == C){
                    daluInitDate[daluInitDate.length-1] = D;
                }
                equal++;
            }
        }
        result = {
            daluInitDate:daluInitDate,
            status:{
                banker:banker,
                player:player,
                equal:equal
            }
        }
        return result;
    }

    //获取大路list
    function getDaluList(date){
        var daluList = [];
        for(var i = 0;i<date.length;i++){
            var list = new Array();
            if(i == 0){
                list.push(date[0]);
                daluList.push(list);
            }else{
                var daluListItemLast = daluList[daluList.length-1];
                var daluListItemLastValue = daluListItemLast[daluListItemLast.length-1];
                var valueJudge = AB.indexOf(daluListItemLastValue)>=0;
                var resultJudge = AB.indexOf(date[i])>=0;
                if((valueJudge && resultJudge)){
                    daluListItemLast.push(date[i]);
                }else if(valueJudge || resultJudge){
                    list.push(date[i]);
                    daluList.push(list);
                }else{
                    daluListItemLast.push(date[i]);
                }
            }
        }
        return daluList;
    }

    //绘制路子图
    function sort(date,index){
        var result = [];
        for(var i=index;i<date.length;i++){
            var dateItemNow = date[i];
            var dateItemBefore = date[i-index];
            if(i==index){
                for(var j=1;j<dateItemNow.length;j++){
                    if(j == 1){//坐标2，2
                        var resultItem = [];
                        //前一列不为空的时候
                        if(dateItemBefore[j] != null){
                            resultItem.push(A);
                        }else{//当第一列为空的时候
                            resultItem.push(B);
                        }
                        result.push(resultItem);
                    }else if(j > 1){//有三个以上的，全写红
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        if(resultItem[0] == A){
                            resultItem.push(A);
                        }else{
                            resultItemNew.push(A)
                        }
                        result[result.length-1] = resultItem;
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }
                }
            }else if(i==index+1){
                for(var j=0;j<dateItemNow.length;j++){
                    if(j==0){
                        var resultItem = [];
                        var resultItemNew = [];
                        if(result.length < 1){
                            resultItemNew.push(A);
                        }else{
                            resultItem = result[result.length-1];
                            if(resultItem[0] == B){
                                resultItem.push(B);
                            }else{
                                resultItemNew.push(B);
                            }
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }else if(j==1){
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        if(dateItemBefore[j] != null){
                            if(resultItem[0] == A){
                                resultItem.push(A)
                            }else{
                                resultItemNew.push(A);
                            }
                        }else{
                            if(resultItem[0] == B){
                                resultItem.push(B)
                            }else{
                                resultItemNew.push(B);
                            }
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }else if(j>1){
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        if(resultItem[0] == A){
                            resultItem.push(A);
                        }else{
                            resultItemNew.push(A);
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }
                }
            }else{
                for(var j=0;j<dateItemNow.length;j++){
                    if(j==0){
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        //dalu前两个为1
                        if(i>index+2 && date[i-1].length == 1 && date[i-2].length == 1){
                            if(resultItem[0] == A){
                                resultItem.push(A);
                            }else{
                                resultItemNew.push(A);
                            }
                        }else{
                            if(resultItem[0] == B){
                                resultItem.push(B)
                            }else{
                                resultItemNew.push(B);
                            }
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }else if(j == 1){
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        if(dateItemBefore[j] != null){
                            if(resultItem[0] == A){
                                resultItem.push(A)
                            }else{
                                resultItemNew.push(A);
                            }
                        }else{
                            if(resultItem[0] == B){
                                resultItem.push(B)
                            }else{
                                resultItemNew.push(B);
                            }
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }else if(j > 1){
                        var resultItem = result[result.length-1];
                        var resultItemNew = [];
                        if(resultItem[0] == A){
                            resultItem.push(A);
                        }else{
                            resultItemNew.push(A);
                        }
                        if(resultItemNew.length>0){
                            result.push(resultItemNew);
                        }
                    }
                }
            }
        }
        return result;
    }

    //整理list
    function handler(date,max){
        var newArray = new Array();
        for(var i = 0;i<date.length;i++){
            var dateItem = date[i];
            if(dateItem.length>max){
                //先把前6个取出来,newArray中
                var firstLine = dateItem.slice(0,6);
                newArray.push(firstLine);
                for(var j=max;j<dateItem.length;j++){
                    var newArrayItem = new Array();
                    for (var k = 0;k<max-1 ;k++){
                        newArrayItem.push(0);
                    }
                    newArrayItem.push(dateItem[j]);
                    newArray.push(newArrayItem);
                }
            }else{
                newArray.push(dateItem);
            }
        }
        return newArray;
    }

    //绘制大路路子图
    function daluHandler(daluList,info){
        var bankerWin = info.bankerWin,
            bankerEqual = info.bankerEqual,
            playerWin = info.playerWin,
            playerEqual = info.playerEqual,
            placeHolder = info.placeHolder;
        var daluDate = new Array();;
        for(var i = 0;i<daluList.length;i++){
            var daluItem = daluList[i];
            var daluDateItem = "";
            for (var j = 0;j<daluItem.length;j++){
                if(daluDateItem != ""){
                    daluDateItem += "|";
                }
                if(daluItem[j] == A){
                    daluDateItem += bankerWin;
                }else if(daluItem[j] == B){
                    daluDateItem += bankerEqual;
                }else if(daluItem[j] == C){
                    daluDateItem += playerWin;
                }else if(daluItem[j] == D){
                    daluDateItem += playerEqual;
                }else if(daluItem[j] == 0){
                    daluDateItem += placeHolder;
                }
            }
            daluDate.push(daluDateItem);
        }
        return daluDate;
    }

    //绘制其他路子图
    function otherHandler(date,info){
        var red = info.red;
        var blue = info.blue;
        var placeHolder = info.placeHolder;
        var length = date.length;
        var data = new Array();
        for(var i=0;i<length/2;i++){
            var dateItemFirst = date[2*i];
            var dateItemFirstLength = dateItemFirst.length;
            var dateItemSecond = new Array();
            var dateItemSecondLength;
            if(date[2*i+1] != null){
                dateItemSecond = date[2*i+1];
                dateItemSecondLength = dateItemSecond.length;
            }
            var maxItemLength;
            if(date[2*i+1] != null){
                maxItemLength = Math.max(dateItemFirstLength,dateItemSecondLength);
            }else{
                maxItemLength = dateItemFirstLength;
            }
            var itemDate = "";
            for(var j = 0;j<maxItemLength/2;j++){
                if(dateItemFirst[j*2] != null){
                    var value = judgeValue(dateItemFirst[j*2],red,blue);
                    itemDate += value;
                }else{
                    itemDate += placeHolder;
                }
                if(dateItemSecond[j*2] != null){
                    var value = judgeValue(dateItemSecond[j*2],red,blue);
                    itemDate += value;
                }else{
                    itemDate += placeHolder;
                }
                if(dateItemFirst[j*2+1] != null){
                    var value = judgeValue(dateItemFirst[j*2+1],red,blue);
                    itemDate += value;
                }else{
                    itemDate += placeHolder;
                }
                if(dateItemSecond[j*2+1] != null){
                    var value = judgeValue(dateItemSecond[j*2+1],red,blue);
                    itemDate += value;
                }else{
                    itemDate += placeHolder;
                }
                if(j < maxItemLength/2-1){
                    itemDate += "|"
                }
            }
            data.push(itemDate);
        }
        return data;
    }

    function judgeValue(value,red,blue){
        if(value == A){
            return red;
        }else if(value == B){
            return blue;
        }else{
            return 0;
        }
    }

}