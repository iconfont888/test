var Utils = function () {
    if (window.utils) {
        return window.utils;
    }
    this.amountFormatter = function (object, isSuffix, pointLength) {
        if (typeof object === 'undefined' || !object || isNaN(parseFloat(object))) {
            return isSuffix !== false ? '0.00' : "0";
        }
        var _num = parseFloat(object).toString();
        var _numArray = _num.split(".");
        var amount = _numArray[0].split("").reverse().join("").replace(/(\d{3})/ig, "$1,").split("").reverse().join("").replace(/^,/, "");
        var suffix = "";
        if (_numArray.length === 2) {
            suffix = "." + _numArray[1].substr(0, pointLength || 2);
            if (_numArray[1].length === 1) {
                suffix += "0";
            }
        } else if (isSuffix !== false) {
            suffix = ".00";
        }
        return amount + suffix;
    };

    /**
     * 获取Url参数值
     * @param name
     * @returns {*}
     */
    this.getQueryString = function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r !== null) return unescape(r[2]);
        return null;
    };

    /**
     * 复制的方法，传入字符串，添加到剪切板
     * utils.copy("test");
     */
    this.copy = (function (window, document, navigator) {
        var textArea;

        function isOS() {
            return navigator.userAgent.match(/ipad|iphone/i);
        }

        function createTextArea(text) {
            textArea = document.createElement('textArea');
            textArea.value = text;
            document.body.appendChild(textArea);
        }

        function selectText() {
            var range,
                selection;

            if (isOS()) {
                range = document.createRange();
                range.selectNodeContents(textArea);
                selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
                textArea.setSelectionRange(0, 999999);
            } else {
                textArea.select();
            }
        }

        function copyToClipboard() {
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }

        return function (text) {
            createTextArea(text);
            selectText();
            copyToClipboard();
        };
    })(window, document, navigator);
    /**
     * 更新跳转地址,当跳转到其他子网站时添加当前用户的scheme
     */
    // this.updateRedirectUrl = function () {
    //     var protocol = location.protocol.replace(/:$/, "");
    //     $("a[href^='/website/redirect']").each(function (i, n) {
    //         var $this = $(n), href = $(n).attr("href");
    //         if (!/\?scheme=/.test(href)) {
    //             var newValue = href.replace(/\?/, "?scheme=" + protocol + "&");
    //             $this.attr("href", newValue);
    //         }
    //     });
    // };

    /**
     * 封装埋码的Code属性
     */
    this.getDsCodeAttr = function(jsonObj) {
        try {
            var dsObj = this.parseJSONObj(jsonObj);
            var codeDs = "";
            if(dsObj) {
                if(dsObj["code"]) {
                    codeDs += " code-ds='" + (dsObj["code"].trim()) + "' ";
                }
                if(dsObj["label"]) {
                    codeDs += " label-ds='" + (dsObj["label"].trim()) + "' ";
                }
                if(dsObj["locationName"]) {
                    codeDs += " location-name-ds='" + (dsObj["locationName"].trim()) + "' ";
                }
                if(dsObj["location"]) {
                    codeDs += " location-ds='" + (dsObj["location"].trim()) + "' ";
                }
                return codeDs;
            }
        }catch (e) {
            return "";
        }
        return "";
    }

    /**
     * 去掉前后空格和换行符后转换对象
     * @param jsonObj
     * @return {any}
     */
    this.parseJSONObj = function(jsonObj) {
        if(jsonObj) {
            return JSON.parse(jsonObj.trim().replace(/[\n\r]/g,''))
        }
    };

    this.storage = (function () {
        if (window.localStorage) {
            try {
                window.localStorage.setItem("__test__", "1");
                window.localStorage.removeItem("__test__");
                return window.localStorage;
            } catch (e) {
            }
        }
        var key_prefix = "local_";
        return {
            getItem: function (key) {
                key = key_prefix + key;
                var cookie = document.cookie;
                var regex = new RegExp(key + "=(.*?)(;|$)");
                var res = regex.exec(cookie);
                if (res && res.length >= 1) {
                    return regex.exec(cookie)[1] || null;
                } else {
                    return null;
                }
            },
            setItem: function (key, value) {
                key = key_prefix + key;
                document.cookie = key + '='+ value + ';' ;
            },
            clear: function () {
                document.cookie = "logout=right";
            },
            removeItem: function (key) {
                key = key_prefix + key;
                document.cookie = key + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
            }
        }
    })();

    this.setCookie = function(c_name,value,expiredays){
        var exdate=new Date();
        exdate.setDate(exdate.getDate() + expiredays);
        document.cookie=c_name+ "=" + escape(value) + ((expiredays==null) ? "" : ";path=/;expires="+exdate.toGMTString());

    };
    this.getCookie = function(key){
        var arr1 = document.cookie.split("; ");
        for (var i = 0; i < arr1.length; i++) {
            var arr2 = arr1[i].split("=");
            if (arr2[0] == key) {
                return decodeURI(arr2[1]);
            }
        }
        return '';
    };
    this.delCookie = function (key) {
        var cval=this.getCookie(key);
        if(cval!=null)
            this.setCookie(key,"",-1)
    };

    this.sessionStorage = (function () {
        if (window.sessionStorage) {
            try {
                window.sessionStorage.setItem("__test_", "1");
                window.sessionStorage.removeItem("__test_");
                return window.sessionStorage;
            } catch (e) {
            }
        }
        var sessionKey = "session_";
        return {
            getItem: function (key) {
                key = sessionKey + key;
                var cookie = document.cookie;
                var regex = new RegExp(key + "=(.*?)(;|$)");
                var res = regex.exec(cookie);
                if (res && res.length >= 1) {
                    return regex.exec(cookie)[1] || null;
                } else {
                    return null;
                }
            },
            setItem: function (key, value) {
                key = sessionKey + key;
                document.cookie = key + '=' + value + ';';
            },
            clear: function () {
                document.cookie = "logout=right";
            },
            removeItem: function (key) {
                key = sessionKey + key;
                document.cookie = key + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
            }
        }
    })();

    //  loading 效果
    this.loading = function () {
        var cont = '<div>';
        cont += '<h1>VIP</h1>';
        cont += '<span class="font">loading</span>';
        cont += '<span class="dots">';
        cont += '<span class="loading-dot"></span>';
        cont += '<span class="loading-dot"></span>';
        cont += '<span class="loading-dot"></span>';
        cont += '</span>';
        cont += '<span class="line"></span>';
        cont += '</div>';
        return layer.open({
            type: 2,
            className: 'layer-loading',
            content: cont
        });
    };

    //  关闭 Loading 效果
    this.close = function (_index) {
        if (_index >= 0) {
            layer.close(_index);
        } else {
            layer.closeAll();
        }
    };

    // 获取验证码图片地址添加请求头
    this.getImageCode = function(url, obj){
        var oReq = new XMLHttpRequest();
        oReq.open("GET", url, true);
        oReq.setRequestHeader("X-Website-Code","MAIN_PC");
        oReq.responseType = "blob";
        oReq.onreadystatechange = function(){
            if(oReq.readyState == 4 && oReq.status == 200){
                $(obj).attr("src",URL.createObjectURL(oReq.response));
            }
        }
        oReq.send();
    };

    /**
     * 筛选数据
     * @param arr 需要筛选的数据
     * @param funcArr 筛选方法
     * @returns {*}
     */
    this.grep = function grep(arr, funcArr) {
        return $.grep(arr, function (n) {
            for (var _i = 0; _i < funcArr.length; _i++) {
                if (!funcArr[_i](n)) {
                    return false;
                }
            }
            return true;
        });
    };

    /**
     * 按照给定参数排序,倒序
     * @param _obj
     * @param property
     * @param isDesc 是否为倒序, 默认为false
     * @returns {*}
     */
    this.resort = function (_obj, property, isDesc) {
        _obj = _obj.sort(function (a, b) {
            if (isDesc) {
                return b[property] - a[property];
            }
            return a[property] - b[property];
        });
        return _obj;
    };

    /**
     * DES 加密
     * @param value
     * @param key
     * @returns {string}
     */
    this.encrypt = function (value, key) {
        var cryptoKeyVal = pn.cryptoKey ? pn.cryptoKey : JSON.parse(sessionStorage.getItem('ag_init_params')).cryptoKey; //没有全局对象则去session里取cryptoKey
        if(key || cryptoKeyVal){
            var keyHex = CryptoJS.enc.Utf8.parse(key || cryptoKeyVal);
            var encrypted = CryptoJS.DES.encrypt(value, keyHex, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7
            });
            return encodeURIComponent(encrypted.toString());
        }else{
            layer.open({
                title:'',
                content:'系统繁忙，请刷新后再试',
                btn:['确定'],
                yes:function(){
                    window.location.reload();
                }
            })
        }
        
    };

    /**
     * DES 解密
     * @param value
     * @param key
     * @returns {string}
     */
    this.decrypt = function (value, key) {
        var plaintext = CryptoJS.DES.decrypt(value, (key || pn.cryptoKey), {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return plaintext.toString(CryptoJS.enc.Utf8);
    };
};
window.utils = new Utils();

// 查询元素在数组中索引值
Array.prototype.indexValue = function(arr){
    for(var i=0;i<this.length;i++){
        if(this[i]==arr){
            return i;
        }
    }
}

// 数组去重
Array.prototype.getNoRepeats = function(){
    var res = [];
    var json = {};
    for(var i=0;i<this.length;i++){
        if(!json[this[i]]){
            res.push(this[i]);
            json[this[i]] = 1;
        }
    }
    return res;
}

/**
 *  用指定字符替换字符串中的特殊字符
 * */
String.prototype.replaceAll = function(findText, repText){
    regExp = new RegExp(findText, "g");
    return this.replace(regExp, repText);
}

/**
 * 时间对象的格式化
 * @param format yyyy-MM-dd HH:mm:ss
 */
Date.prototype.format = function (format) {
    if (this === 'Invalid Date') {
        return '';
    }
    var o = {
        "M+": this.getMonth() + 1, 		// month
        "d+": this.getDate(), 			// day
        "h+": this.getHours(), 			// hour
        "m+": this.getMinutes(), 		// minute
        "s+": this.getSeconds(), 		// second
        "q+": Math.floor((this.getMonth() + 3) / 3), 	// quarter
        "S": this.getMilliseconds()  	// millisecond
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "")
            .substr(4 - RegExp.$1.length));
    }

    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
};

Date.prototype.addDays = function (days) {
    var dat = new Date(this.valueOf());
    dat.setDate(dat.getDate() + days);
    return dat;
};

/**
 * 比较两个时间, date1 早于 date2 则返回 true, 否则返回 false
 * ##isBefore(var1, var2)
 * ##compare(var1, var2)
 *          1. var1 为{空,'',null,undefined,0}中任意值, 返回 false
 *          2. var2 为{空,'',null,undefined,0}中任意值, 则为 var1 与 当前时间比较
 *
 * ##period(var1, var2, space): 期间内
 *          计算两个时间的时间差, 是否小于间隔值(period)
 *
 * @参数格式: var1, var2
 *           1522141951518, '1522141951518'
 *           '2018/03/27', '2018/03/27 23:59:59'
 *           '2018-03-27', '2018-03-27 23:59:59'
 * @参数格式: space 为毫秒数
 * @其他格式: 按照 JS 基础算法, 返回结果
 *
 * ##format(v) 格式化时间, 将字符中的 "/" 替换成 "-", 以兼容IE浏览器
 * @参数格式: '2018/03/27', '2018/03/27 23:59:59',
 *           '2018-03-27', '2018-03-27 23:59:59'
 * @其他格式: 返回原数据
 * @type {{isBefore: (function(*=, *=): boolean), period: (function(*, *, *): boolean), compare: (function(*=, *=): number), format: (function(*): number)}}
 * @public
 */
var __AG_DATE_ = {
    /**
     * var1 是否在 var2 之前
     * @param var1
     * @param var2
     * @returns {boolean}
     */
    isBefore: function (var1, var2) {
        return var1 ? __AG_DATE_.compare(var1, var2) <= 0 : false;
    },
    /**
     * 两个时间的间隔, 是否在给定值范围内
     * @param var1
     * @param var2
     * @param space
     * @returns {boolean}
     */
    period: function (var1, var2, space) {
        return Math.abs(var1 - var2) <= space;
    },
    /**
     * 计算两个时间的间隔, var2 为空时, 与当前时间比较
     * @description 与服务器返回时间对比, 仅在页面初始化时, 方能使用;
     * @param var1
     * @param var2
     * @returns {number}
     */
    compare: function (var1, var2) {
        var1 = isNaN(var1) ? __AG_DATE_.format(var1) : var1;
        var2 = var2 ? (isNaN(var2) ? __AG_DATE_.format(var2) : var2) : (typeof(_now) === 'undefined' ? new Date().getTime() : _now);
        return var1 - var2;
    },
    /**
     * 格式化时间
     * @param v
     * @returns {number}
     */
    format: function (v) {
        var value = v.replace(/-/g, "/");
        return new Date(value).getTime();
    },
    /**
     * 获取距离当前时间的天数/小时数
     * @param v
     * @returns {string}
     * */
    timeFun:function(v){
        var dateBegin = new Date(v.replace(/-/g, "/")).getTime();
        var dateEnd = typeof _now==='undefined'?new Date().getTime():_now;
        var dateDiff = dateEnd - dateBegin;
        var dayDiff = Math.floor(dateDiff/(24*3600*1000));
        if(dayDiff>0&&dayDiff<7){
            return dayDiff+"天前";
        }else if(dayDiff==0){
            var leave1 = dateDiff%(24*3600*1000);
            var hours = Math.floor(leave1/(3600*1000));
            if(hours>0){
                return  hours+"小时前";
            }else{
                var leave2 = leave1%(3600*1000);
                var minutes = Math.floor(leave2/(60*1000));
                if(minutes>0){
                    return minutes+"分钟前";
                }else{
                    return "刚刚";
                }
            }
        }else if(dayDiff>=7&&dayDiff<30){
            var weeks = Math.floor(dayDiff/7);
            return weeks+"周前";
        }else{
            var months = Math.floor(dayDiff/30);
            return months+"月前";
        }
    }
};

/**
 * 与用户相关固定数据
 * #TYPE 用户类型: 0-试玩, 1-真钱
 * @type {{type: {trial: string, real: string}}}
 * @public
 */
var _USER = {
    type: {
        trial: 0,
        real: 1
    }
};

/**
 * 验证对象: 验证方法集合
 * @type {{isDom: _VALID.isDom, isNormal: _VALID.isNormal}}
 * @public
 */
var _VALID = {
    /**
     * DOM节点在页面上是否存在
     * @param o jQuery 对象
     * @returns {boolean}
     */
    isDom: function (o) {
        return !isJQuery(o) ? false : o && o.length;
    },
    /**
     * 判断字符类型(String)的值是否为正常值: true-正常, false-非正常
     * 1.当 v 为非正常值时, 返回 false
     * 2.当 v0 为正常值时, 再对比 v 与 v0 的值是否相等
     *
     * @非正常值: {空, '', ' ', null, undefined}
     * @param v
     * @param v0
     * @returns {*}
     */
    isNormal: function (v, v0) {
        return !!(v0 ? v && $.trim(v).length && v === v0 : v && $.trim(v).length);
    }
};

/**
 * 格式化金额
 * @type {{conversion: _AG_AMOUNT_.conversion, retain: _AG_AMOUNT_.retain, format: _AG_AMOUNT_.format}}
 * @public
 */
var _AG_AMOUNT_ = {
    /**
     * 格式化金额, 当前金额大于等于10000, 使用'万'做单位
     * @param amount
     * @returns {"2,000", "2,001.00", "5万"}
     */
    conversion: function (amount) {
        amount = typeof amount === "number" ? amount : parseFloat(amount);
        if (amount < 100 * 10 * 10) {
            return _AG_AMOUNT_.retain(amount);
        } else {
            return _AG_AMOUNT_.format(amount / 10000) + "万"
        }
    },
    /**
     * 是否保留小数位 (返回为字符)
     * 当为整数时, 不需要添加小数位, 反之, 将金额格式化为2位(舍掉)
     *
     * @param amount
     * @returns {"2,000", "2,001.00"}
     */
    retain: function (amount) {
        amount = typeof amount === "number" ? amount : parseFloat(amount);
        return Number.isInteger(amount) ? utils.amountFormatter(amount, false) : utils.amountFormatter(amount);
    },
    /**
     * 格式化金额(返回数值)
     *
     * @param amount
     * @returns {number}
     */
    format: function (amount) {
        return parseFloat(utils.amountFormatter(amount).replace(/,/g, ""));
    }
};

/**
 * 验证是否为 jQuery 对象
 * @param o
 * @returns {boolean}
 */
function isJQuery(o) {
    return ((typeof jQuery === "function" || typeof jQuery === "object") && (o instanceof jQuery || $(o).length));
}