function getUserLevel(){
    if(pn.userName){
        if(pn.userName){
            //如果登录,那么从pn读取
            if(pn.userLevel){
                return pn.userLevel + "";
            }
        }
        return "1";
    }else{
        //如果未登录,那么从缓存读取
        // var userLevel = $.cookie("userLevel");
        // if(typeof userLevel === "undefined"){
        //     userLevel = "1";
        // }
        // return userLevel + "";
    }
}