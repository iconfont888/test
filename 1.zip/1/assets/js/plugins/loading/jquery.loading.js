/**
 * Created by Davy on 2017/4/25.
 */
(function ($, window, document, undefined) {
    var $window = $(window);
    $.fn.loading = function (options) {
        var settings = {
            autoClose: false,
            time: 10 * 1000,
            logo: true,
            glass: false,
            glassWrap: "",
            onlyMask: false,
            multiple: false
        };
        if (options && typeof options === 'object') {
            $.extend(settings, options);
        }
        var elements = this,
            logo = settings.logo && !settings.onlyMask ? '<div class="loading-logo"></div>' : '',
            container = !settings.onlyMask ? '<div class="loading-container"></div>' : '',
            $_loading = $('<div class="transparent-base64 loading-js">' + container + logo + '</div>'),
            $loading = $('.loading-js'),
            closeHandle = function (multiple) {
                if (multiple) {
                    elements.find(".loading-js").remove();
                    elements.removeClass("loading-portion");
                    elements.removeClass("glass-back filter");
                    elements.find(".glass-back").removeClass("glass-back filter");
                } else {
                $(".loading-js").remove();
                $(".loading-portion").removeClass("loading-portion");
                $(".glass-back").removeClass("glass-back filter");
                }
            };
        if (typeof options === 'string' && options === 'close') {
            $loading.fadeOut(closeHandle);
            return elements;
        }
        if (typeof options === 'boolean' && !options) {
            closeHandle(true);
            return elements;
        }
        closeHandle.apply($loading, [settings.multiple]);

        if (!elements.is("body")) {
            if (elements.css("position") === "static") {
                elements.addClass("loading-portion");
            }
            $_loading.addClass("loading-portion-content")
        }
        if (!settings.onlyMask) {
            var left = elements.width() / 2, gifHeight = 25, gifLeft = left - 60, _height = elements.height(),
                offset = 18;
            if (settings.logo) {
                var logoHeight = 85;
                var logoLeft = left - 110;
                var top = (_height / 2) - ((gifHeight + logoHeight) / 2),
                    totalHeight = (gifHeight + logoHeight) + offset;
                if (_height <= totalHeight) {
                    top = (elements.height() / 2) - (gifHeight / 2);
                    $_loading.find(".loading-logo").remove();
                } else {
                    $_loading.find(".loading-logo").css({
                        "left": logoLeft + "px",
                        top: (top + gifHeight + offset) + "px"
                    });
                }
                $_loading.find(".loading-container").css({"left": gifLeft + "px", top: top + "px"});
            } else {
                $_loading.find(".loading-container").css({
                    "left": gifLeft + "px",
                    top: ((_height / 2) - (gifHeight / 2)) + "px"
                });
            }
        }
        if (settings.glass && settings.glassWrap) {
            elements.find(settings.glassWrap).addClass("glass-back filter");
        } else if (settings.glass) {
            elements.addClass("glass-back filter");
        }
        $_loading.appendTo(elements).fadeIn('slow');
        if (settings.autoClose) {
            setTimeout(function () {
                $('.loading-js').fadeOut(closeHandle);
            }, settings.time);
        }
        return elements;
    }
})(jQuery, window, document);