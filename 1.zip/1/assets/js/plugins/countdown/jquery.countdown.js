/***
 *
 * 倒计时工具
 *
 * <p>User: Ives
 * <p>Date: 2017/10/27
 * <p>Time: 17:02
 *
 *  @author Best
 */

(function ($, window, document, undefined) {
    var countdown = 0;
    $.fn.agcountdown = function (userOptions) {
        var $ele = this;
        /**
         * 倒计时方法
         * @param stepTime      倒计时秒
         * @param before        前置方法：执行倒计时之前执行
         * @param after         后置方法：执行倒计时之后执行
         * @param buttonText    按钮文字
         * @param defaultMsg    倒计时结束后对象的默认值
         * @param start         是否启动
         * @param reset         终止倒计时，重置到默认状态
         * @param clear         启动时先终止在运行的倒计时
         */
        var options = {
            stepTime: 60,
            before: function () {
            },
            after: function () {
            },
            buttonText: "",
            defaultMsg: "点击",
            start: true,
            reset: false,
            clear: true
        };
        $.extend(options, userOptions);
        var start = function (element, options) {
            var timer = options.stepTime;
            options.before();
            var func = function () {
                if (options.buttonText) {
                    var text = options.buttonText;
                    text = text.replace(/{}/, timer + "");
                    element.html(text);
                } else {
                    element.html(timer);
                }
                timer = timer - 1;
                if (timer < -1) {
                    if (options.defaultMsg) {
                        element.html(options.defaultMsg);
                    }
                    window.clearInterval(countdown);
                    options.after();
                }
            };
            if (countdown && options.clear) {
                window.clearInterval(countdown);
            }
            countdown = window.setInterval(function () {
                func()
            }, 1000);
            func();
        };
        var reset = function (element, options) {
            if (options.defaultMsg) {
                element.html(options.defaultMsg);
            }
            window.clearInterval(countdown);
            options.after();
        };
        if (options.start === true) {
            start(this, options)
        }
        if (options.reset === true) {
            reset(this, options);
        }
        return $ele;
    };
})(jQuery, window, document);