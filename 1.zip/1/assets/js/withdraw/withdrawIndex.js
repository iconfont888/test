var minAmount;
var btcMinAmount;
var ethMinAmount = 1;
function layerNoBank() {
    layer.open({
        skin: 'btn-reverse',
        title: ' ',
        content: '您还没有可用于提现的银行卡，请先添加一张银行卡',
        area: ['400px', '170px'],
        btn: ['暂不添加', '添加银行卡'],
        success: function (layero) {
            var btn = layero.find('.layui-layer-btn');
            btn.find('.layui-layer-btn1').attr({
                href: '/ucenter/bank/bankIndex'
                , target: '_self'
            });
        }
    });
}
var totalBalance = 0;
var $balanceAmount = $("#balanceAmount");
function refreshBalance() {
    if (!$balanceAmount.length) {
        return;
    }
    $balanceAmount.text("刷新中...");
    return window.uCenterHelper.getBalance().done(function (response) {
        if (response.successful) {
            var res = response.data;
            totalBalance = res.totalBalance;
            $balanceAmount.attr("data-amount",totalBalance).text(utils.amountFormatter(res.totalBalance));
            if($(".bitcoin-txt").css("display")!="none"){
                var rate = ($(".selectors").find('ul li[data-currency="BTC"]').attr("data-rate")), currencyObject = getCurrencyObject("BTC") ;
                if (totalBalance === 0) {
                    $('.exchange-' + currencyObject.en).text(utils.amountFormatter(0.00))
                } else {
                    $('.exchange-' + currencyObject.en).text(utils.amountFormatter(totalBalance / rate));
                }
            }
        } else {
            $("#balanceAmount").text("刷新失败,请重试");
        }
    }).fail(function () {
        $("#balanceAmount").text("刷新失败,请重试");
    });
}

var LAST_WITHDRAW_ID = "last_withdraw_id";

function getCurrencyObject(currency) {
    switch (currency) {
        case "BTC":
            return {zh: "比特币", en: "bitcoin"};
        case "ETH":
            return {zh: "以太币", en: "ethcoin"};
    }
}
$(document).ready(function () {
    refreshBalance();
    var $withDrawHasBankForm = $("#withDrawHasBankForm"), $dowithdrawMsg = $("#dowithdrawMsg");
    if (isExistBankCard) {
        $('.u-main').css({
            'min-height': "600px",
            'height': 'auto'
        });
        var $imgBank = $('.img-bank-icons'), $selectBank = $('#selectBank');
        $imgBank.each(function () {
            $(this).attr("src", $(this).attr("data-src"));
        });
        /*$imgBank.error(function () {
         $(this).parent().html($(this).attr("data-name"));
         });*/
        $("#doWithDrawBankBtn").on("click", function () {
            $withDrawHasBankForm.submit();
        });
        var withdrawValidate = $withDrawHasBankForm.validate({
            errorLabelContainer: ".error-wrapper",
            submitHandler: doWithdrawBank,
            rules: {
                withdrawAmount: {
                    required: true,
                    number: true,
                    min: parseInt(minAmount)
                },
                btc: {
                    required: true,
                    number: true,
                    min: parseFloat(btcMinAmount)
                },
                eth: {
                    required: true,
                    number: true,
                    min: parseFloat(ethMinAmount)
                }
            },
            messages: {
                withdrawAmount: {
                    required: "请输入提现金额",
                    number: "请输入正确的提现金额",
                    min: "单笔最低提现金额：" + minAmount + "元"
                },
                btc: {
                    required: "请输入提现金额",
                    number: "请输入正确的提现金额",
                    min: "单笔最低提现金额" + btcMinAmount + "比特币"
                },
                eth: {
                    required: "请输入提现金额",
                    number: "请输入正确的提现金额",
                    min: "最低提现" + ethMinAmount + "以太币，上不封顶"
                }
            },
            errorElement: "div",
            errorClass: "text-orange"
        });

        $('.options').on('click', function () {
            $(this).find('.ddtitle').toggleClass('optionshovered');
            $(this).find('.selectors').toggleClass('open');
            if ($('.selectors').hasClass('open')) {
                $(this).find('.selectors').css('height', 'auto');
            } else {
                $(this).find('.selectors').css('height', 0);
            }
        });
        var $selectors = $('.selectors');
        var $withdrawAmount = $withDrawHasBankForm.find("input[name='withdrawAmount']"),
            $cny = $withDrawHasBankForm.find("input[name='rmb']"),
            $btc = $withDrawHasBankForm.find("input[name='btc']"),
            $eth = $withDrawHasBankForm.find("input[name='eth']");
        $selectors.find('ul li').on('click.select', function () {
            var $this = $(this), selected = $this.html();
            if ($this.data("type") === 'add') {
                window.location.href = "/ucenter/bank/bankIndex";
            }
            var currency = $this.data("currency");
            var id = $this.data("id");
            $selectBank.val(id);
            if (currency === "BTC" || currency === "ETH") {
                var $value = $withDrawHasBankForm.find("input[name='" + currency.toLowerCase() + "']");
                $cny.val('');
                $withdrawAmount.val('');
                if ($value.val()) {
                    $value.trigger("input");
                }
                var currencyObject = getCurrencyObject(currency);
                $(".currency-switch").hide();
                $withDrawHasBankForm.find("." + currencyObject.en + "-input").show();
                $('.' + currencyObject.en + '-txt').show();
            } else {
                $(".currency-switch").hide();
                $withDrawHasBankForm.find(".normal-input").show();
            }

            localStorage.setItem(LAST_WITHDRAW_ID, id);
            $('.ddtitle').html(selected);
            withdrawValidate.element($selectBank);
        });

        $selectors.find('ul li[data-currency="BTC"],ul li[data-currency="ETH"]')
            .on("click.select", function () {
                var $this = $(this), currency = $this.data("currency"), currencyObject = getCurrencyObject(currency);
                $withDrawHasBankForm.loading();
                return $.request({
                    url: '/api/withdraw/rate?currency=' + currency
                }).done(function (response) {
                    var data = response.data;
                    if (response.successful) {
                        $('.' + currencyObject.en + '-exchange-rate').text('当前汇率：1' + currencyObject.zh + ' =' + utils.amountFormatter(data, true, 2) + '人民币');
                        var totalBalance = parseFloat($balanceAmount.attr("data-amount"));
                        if (totalBalance === 0) {
                            $('.exchange-' + currencyObject.en).text(utils.amountFormatter(0.00))
                        } else {
                            if(!lib.hasValue(totalBalance)){
                                refreshBalance().always(function () {
                                    $('.exchange-' + currencyObject.en).text(utils.amountFormatter(totalBalance / data));
                                });
                            }
                            $('.exchange-' + currencyObject.en).text(utils.amountFormatter(totalBalance / data));
                        }
                        $this.attr("data-rate", data);
                        $selectBank.find("option[value='" + $this.data("id") + "']").attr("data-rate", data);
                        var $value = $withDrawHasBankForm.find("input[name='" + currency.toLowerCase() + "']");
                        if ($value.val()) {
                            $value.trigger("input");
                        }
                    } else {
                        layer.alert("获取实时汇率时发生错误,请刷新后再试!", {title: ' '}, function () {
                            location.reload();
                        });
                    }
                }).fail(function () {
                    layer.alert("获取实时汇率时发生错误,请刷新后再试!", {title: ' '}, function () {
                        location.reload();
                    });
                }).always(function () {
                    $withDrawHasBankForm.loading("close");
                });
            });


        function needRate() {
            var $selected = $selectBank.find(":selected");
            return $selected.length && $selected.attr("data-rate");
        }

        $btc.on("input propertychange", function () {
            var rate = needRate();
            if (rate) {
                var value = parseFloat($btc.val());
                var cny = utils.amountFormatter(Number(rate) * value);
                $cny.val(cny);
            }
        });
        $eth.on("input propertychange", function () {
            var rate = needRate();
            if (rate) {
                var value = parseFloat($eth.val());
                var cny = utils.amountFormatter(Number(rate) * value);
                $cny.val(cny);
            }
        });
        (function () {
            /* var _lastId = localStorage.getItem(LAST_WITHDRAW_ID);
             var _lastLi = $selectors.find('ul li[data-id="' + _lastId + '"]');
             if (_lastLi.length) {
             _lastLi.trigger("click.select");
             } else {*/
            $selectors.find('ul li').first().trigger("click.select");
            /* }*/
        })();
        $('.img-bank-icons').error(function () {
            $(this).parent().html($(this).attr("data-name"));
        });
    } else {
        layerNoBank();
        $(".options").on("click", function () {
            window.location.href = "/ucenter/bank/bankIndex";
        });
        $("#doWithDrawBankBtn").on("click", function () {
            layerNoBank();
        });
    }
    if ($dowithdrawMsg.val() === 'success') {
        $("#successModal").modal('show');
    }
    else if ($dowithdrawMsg.val() === 'error') {
        layer.alert('提交提现申请失败!', {title: ' '});
    }
    else if ($dowithdrawMsg.val() === 'index') {

    } else {
        layer.alert($("#dowithdrawMsg").val(), {title: ' '});
    }


    function doWithdrawBank() {
        if (!$("#withDrawHasBankForm").validate().form()) {
            return;
        }

        var bankId = $selectBank.val();
        if (!bankId) {
            layer.alert("请先绑定银行卡", {title: ' '});
            return;
        }
        var withdrawAmount = $("#withdrawAmount").val();
        $("div.u-content.u-withdraw").loading({'glass': false});
        var $selected = $selectBank.find(":selected");
        var $request, currency = $selected.data("currency");
        if (currency === "BTC") {
            $request = $.request({
                type: "POST",
                url: '/api/withdraw/request-virtual',
                data: {
                    "id": bankId,
                    "currency": currency,
                    "rate": $selected.attr("data-rate"),
                    "amount": $("#withDrawHasBankForm").find("input[name='" + currency.toLowerCase() + "']").val()
                }
            });
        } else {
            $request = $.request({
                type: "POST",
                url: '/api/withdraw/request-cny',
                data: {
                    "bankId": bankId,
                    "currency": currency,
                    "withdrawAmount": withdrawAmount
                }
            });
        }
        $request.done(function (data) {
            if (data.successful) {
                if (data.code === 1) {
                    $("#successModal-2").modal("show");
                }
                else {
                    $("#successModal").modal('show');
                }
            } else {
                if (data.code === 8534) {
                    $(".u-content.u-withdraw").append('<div class="proBox step-3 rate-refresh-js">实时汇率已发生变化，请检查最新金额并再次点击“提交”。</div>');
                    $(".rate-refresh-js").show();
                    $selectors.find('ul li[data-id="' + bankId + '"]').trigger("click.select");
                    setTimeout(function () {
                        $(".rate-refresh-js").remove();
                    }, 3000);
                } else {
                    layer.open({
                        title: ' ',
                        content: data.message,
                        btn: ['确定'],
                        yes: function () {
                            location.reload();
                        }
                    });
                }
            }
        }).fail(function () {
            layer.open({
                skin: 'btn-reverse',
                title: ' ',
                content: '提交提现申请失败!请重试或联系客服!',
                area: ['400px', '170px'],
                btn: ['联系客服', '重试'],
                yes: function () {
                    openWindow(window.cs_target, 850, 550);
                },
                btn2: function () {
                    location.reload();
                }
            });
        }).always(function () {
            $("div.u-content.u-withdraw").loading("close");
        })

    }

    //零钱转一转
    eventFramePopFunc();
    // getLotteryList();
});

/**
 * 注册Frame窗口事件
 */
function eventFramePopFunc() {
    /**
     *  添加jq方法，可直接通过动画名引用动画
     */
    $.fn.animateCss = function (animationName, callback) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function () {
            $(this).removeClass('animated ' + animationName);
            if (callback) {
                callback();
            }
        });
        return this;
    };

    // 点击零钱转一转 ，弹出弹层
    $('.change').on('click', function () {
        winnerIndex = 0;
        closeTimer();
        if ($('.mask').is(':hidden')) {
            $('.mask').fadeIn(function () {
                $(".money-info").addClass("flipping");
                toggleBody(1);
                renderWinerData();
                iframeObj = createGameUrl();
                timer4 = setTimeout(function () {
                    $(".prize-info,.loading").hide();
                    $('.content').css({
                        'width': '595px',
                        "height": "700px",
                        "marginTop": '-320px',
                        "marginLeft": "-310px"
                    });
                    $(iframeObj).show();//.animateCss('zoomIn');
                    clearTimeout(timer1);
                    clearTimeout(timer2);
                }, 1000);
            });
        }
    });

    /**
     *  关闭弹层
     */
    $('.close-btn').on('click', function () {
        closeTimer();
        refreshBalance();
        $('.change').attr("disabled", "true").css("point-events", "all");
        $('.mask').fadeOut('fast', function () {
            clearTimeout(timer4);
            toggleBody(0);
            $('.content').css({'width': '650px', "height": "372px", "marginTop": "-170px", "marginLeft": "-306px"});
            $(".prize-info,.loading").show();
            $("#gameIframe").remove();
        });
    });
}
var flag = 0, timer1, timer2, timer3, timer4, winnerIndex = 0, prizeList = [];

/**
 *  处理遮罩穿透背景滚动问题
 */
var toggleBody = function toggleBody(isPin) {
    if (isPin) {
        $('html,body').css({'height': '100Vh', 'overflow-y': 'hidden'});
        $('.mask').on('touchmove', function (e) {
            e.preventDefault();
            e.stopPropagation();
        }, false);
    } else {
        $('html,body').css({'height': 'unset', 'overflow-y': 'auto'});
    }
}

/**
 * 关闭定时器
 */
function closeTimer() {
    clearTimeout(timer1);
    clearTimeout(timer2);
    clearTimeout(timer3);
    clearTimeout(timer4);
}

/**
 * 处理快速点击按钮时出现的定时器累积bug
 */
var changeBtnState = function () {
    if (flag == 2) {
        $('.change').removeAttr("disabled").css("point-events", "none");
        flag = 0;
    }
}

/**
 *  iframe创建游戏加载页面
 **/
var createGameUrl = function () {
    $("iframe[name='gameIframe']").remove();
    iframe = document.createElement("iframe");
    iframe.src = location.origin + "/game/play/scg?isActivity=true";
    iframe.width = "100%";
    iframe.height = "100%";
    iframe.style.frameborder = "no";
    iframe.style.border = "0";
    var iFrameName = "gameIframe";
    iframe.name = iFrameName;
    iframe.id = iFrameName;
    $(iframe).insertBefore(".close-btn").hide();
    return iframe;
};


/**
 * 获取中奖信息列表
 */
var getLotteryList = function () {
    $.ajax({
        url: "/game/show/getBigWinnerRank/day",
        type: "get",
        accept: "application/json",
        dataType: "json",
        headers: {
            "X-Website-Code":"MAIN_PC"
        }
    }).done(function (response) {
        if (response.successful) {
            winnerIndex = 0;
            prizeList = response.data;
        } else {
            logConsole(response.message);
        }
        setTimeout(getLotteryList, 180000);
    }).fail(function(e){
        logConsole(e);
    });
};


/**
 *  刷新弹窗中奖信息数据，循环动画
 */
function updateDataAndStartAnimation() {
    if (!prizeList || prizeList.length == 0) {
        prizeList = [{'loginName': 'agb***1', 'billTime': '2018/08/22 11:33:33', 'cusAccount': '424000'}];
    }
    var length = prizeList && prizeList.length;
    if ($('.mask').is(':hidden')) {
        clearTimeout(timer1);
        clearTimeout(timer2);
        flag += 1;
        changeBtnState();
        return;
    }
    data = [], H1 = $('.userName').height(), H2 = $('.winTime').height();
    data = prizeList[winnerIndex];
    winnerIndex++;
    //winnerIndex从0开始
    if ((winnerIndex + 1) > length) {
        winnerIndex = 0;
    }
    $('.userName').animate({
        height: 0,
        marginTop: H1 / 2,
        marginBottom: H1 / 2
    }, 100, "linear", function () {
        $(this).html(data && data.loginName).animate({
            height: H1,
            marginTop: 0,
            marginBottom: 0
        });
    });
    $('.winTime').animate({
        height: 0,
        marginTop: H2 / 2,
        marginBottom: H2 / 2
    }, 100, "linear", function () {
        $(this).html(data && subWinnerTime(data.billTime)).animate({
            height: H2,
            marginTop: 0,
            marginBottom: 0
        });
    });
    // $('.money-info').delay(1000).animate({
    //     opacity:0
    // },200,"linear",function(){
    //
    // });
    timer1 = setTimeout(function () {
        $('.money-info').find('span').html(data && Common.AmountFormatter(data.cusAccount));
    }, 1200);
    timer2 = setTimeout(function () {
        updateDataAndStartAnimation();
    }, 2400);
}

/**
 *  金额动画
 */
function addAnimation() {
    if ($('.mask').is(':hidden')) {
        clearTimeout(timer3);
        flag += 1;
        changeBtnState();
        return;
    }
    $('.money-info').toggleClass("flipping");
    timer3 = setTimeout(function () {
        addAnimation();
    }, 1200);
};

/**
 * 渲染弹窗广告数据
 * @param prizeList
 */
function renderWinerData() {
    // updateDataAndStartAnimation();
    // addAnimation();
}

/**
 * 截取获奖时间
 * @param timeStr
 * @returns {string}
 */
function subWinnerTime(timeStr) {
    if (timeStr) {
        return timeStr.substr(5, 11).replace("-", "/");
    }
    return "";
}