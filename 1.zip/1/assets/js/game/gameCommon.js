function notAllowTryTips() {
  layer.confirm("抱歉，该游戏不支持试玩，请您注册真钱账号！", {
    btn: ['去注册真钱账号', '取消'], //按钮
    icon: 3,
    title: ' '
  }, function () {
    //登出并弹小窗
    window.location.href = "/logout/to/register"

  }, function () {
    //do nothing

  });
}

var notAllowedForTry = function (msg) {
  if (layer) {
    layer.alert(msg || '很抱歉，本游戏暂不支持试玩！', {title: ' '});
  }
};