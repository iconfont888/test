var _now = pn.sys_now;
//  生成轮播图
$(function () {
    var $indicators = $(".carousel-indicators"), $inner = $(".carousel-inner");
    //  生成 banner 小图
    var indicatorsHtml = function (index, item) {
        var classA = index === 0 ? 'active' : '';
        var image =  item.minImageHttpUrl;
        return '<li data-target="#home-carousel" data-slide-to="' + index + '" class="' + classA + '">'
            + '</li>';
    };
    //  生成 banner 大图
    var innerHtml = function (index, item) {
        var classA = index === 0 ? 'active' : '';
        var dataSrc = index !== 0 ? 'data-' : '';
        var href = item.maxUrl === '' ? '' : ('href="' + item.maxUrl + '"');
        var target = item.target == "" ? "" : "_blank";
        var imageUrl = item.maxImageHttpUrl;
        if (item.buttons) {
            var html = "";
            if((item.buttons).length>1){
                $.each(item.buttons, function (index, item) {
                    var url = "";
                    if (item.buttonAction) {
                        url = "href='" + item.buttonAction + "'";
                    }
                    var text = item.buttonName;
                    if(pn.userName){
                        if(pn.userType==0){  //试玩
                            if(index==0){
                                html += '<a ' + url +  ' class="btn" target="'+target +'">' + text + '<i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                            }
                        }else{  //真钱
                            if(index==1){
                                html += '<a ' + url +  ' class="btn orange" target="'+target +'">' + text + '<i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                            }
                        }
                    }else{
                        if(index===0){
                            html += '<a ' + url + ' class="btn trial-gobut" target="'+target +'">' + text + '<i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                        } else if(index===1){
                            html += '<a ' + url +  ' class="btn orange login-gobut" target="'+target +'">' + text + '<i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                        }
                    }
                });
            }else{
                $.each(item.buttons, function (index, item) {
                    var url = "", s = "";
                    if (item.buttonAction) {
                        url = "href='" + item.buttonAction + "'";
                    }
                    var text = item.buttonName;
                    html = '<a ' + url +  ' class="btn orange " target="'+target +'">' + text + '<i class="fa fa-angle-right" aria-hidden="true"></i></a>';
                });
            }
            return '<div class="item ' + classA + '" style="background: #f6f6f6 url('+ imageUrl + ') center top no-repeat">'
                + '    <div class="caption">' + html + '</div>'
                + ' </div>';
        } else {
            return  '<div class="item ' + classA + '" style="background: #f6f6f6 url('+ imageUrl + ') center top no-repeat"></div>';
        }
    };
    //  生成 Banner 对象集合
    var grepBanners = function (data) {
        var banners = [];
        $.each(data, function (index, item) {
            var $banner =
                {
                    "index": item.rank,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime,
                    "minUrl": item.defaultAction || item.maxImageAction,
                    "maxUrl": item.defaultAction || item.maxImageAction,
                    "minImageHttpUrl": item.minImageHttpUrl,
                    "maxImageHttpUrl": item.maxImageHttpUrl,
                    "target": item.targetType == "a" ? "" : "_blank",
                    "buttons": item.templateButtons,
                    "templateType": item.templateType
                };
            banners.push($banner);
        });
        return resort(grepGame(banners, [function (n) {
            if(n.endTime){
                if(n.beginTime < _now && n.endTime > _now){
                    return true;
                }
                return false;
            }else {
                return n.beginTime < _now;
            }
        }]), "index");
    };
    //  生成的轮播图
    var generate = function (data) {
        if(data === undefined) {
            return false;
        }
        var banners = grepBanners(data);
        if (!banners) {
            return false;
        }
        var indicators = [], inners = [];
        $.each(banners, function (index, item) {
            indicators.push(indicatorsHtml(index, item));
            inners.push(innerHtml(index, item));
        });
        if (indicators.length && inners.length) {
            $indicators.empty();
            $inner.empty();
            $indicators.append(indicators.join(""));
            $inner.append(inners.join(""));
        }
    };
    //  首页轮播图
    cmsHelper.getScriptResult(CMS_MODEL.agq)
        .done(generate)
        .done(updateRedirectUrl)
        .done(function(){
            $("#home-carousel").on("slide.bs.carousel", function (e) {
                var target = e.relatedTarget, imgNode = $("img", target), src = imgNode.src;
                imgNode.each(function (index, item) {
                    if (!item.src) {
                        $(item).attr("src", $(item).data("src"));
                    }
                });
            });
        })
        .fail(cms_failure);
});