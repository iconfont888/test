
$(document).ready(function () {
    //试玩用户不允许进入赌场厅
    if (pn.userName) {
        if (pn.userType == "0") {
            $("#agtel_btn").attr({"href": "#modal-demos", "data-toggle": "modal"});
        } else {
            $("#agtel_btn").attr({"href": "/game/play/agtlb", "data-toggle": "_blank"});
        }
    }else {
        $("#agtel_btn").attr({"href": "/login?redirect=/game/play/agtlb", "data-toggle": "_blank"});
    }
});
$(document).ready(function () {
    // Get Started
    $('.showmap').click(function () {
        $('.map').fadeIn();
    });
    $('.close-map').click(function () {
        $('.map').fadeOut();
    });

    //=========WEB-838 新增AG现场厅和NB体育提示引导弹窗  begin=======
    $('#modal-demos .btn-1').on('click', function(){
        $('#modal-demos').modal('hide');
        $('#loginModal').modal({
            "backdrop": true,
            "show": true
        });
    });
    $('#modal-demos .btn-2').on('click', function(){
        $('#modal-demos').modal('hide');
        $('#regModal').modal({
            "backdrop": true,
            "show": true
        });
    });
    //=========WEB-838 新增AG现场厅和NB体育提示引导弹窗  end =======
});