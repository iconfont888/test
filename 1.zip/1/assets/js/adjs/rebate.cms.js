$(function () {
    cmsHelper.getScriptResult(CMS_MODEL.rebateAdImage, getUserLevel()).done(
        function (data) {
            if(data === undefined) {
                return false;
            }
            var target = data[0].target == "target" ? "_blank" : "";
            var href = data[0].defaultAction;
            var imageURL = data[0].maxImageHttpUrl;
            var str = '<a target="' + target + '" href="' + href + '" class="new-promo" style="background:url(' + imageURL + ') center top;"></a>';
            $("#rebate_ad").html(str);
        }
    ).fail(cms_failure);
});