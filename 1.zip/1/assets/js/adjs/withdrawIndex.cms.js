$(function () {
    cmsHelper.getScriptResult(CMS_MODEL.withdrawAdImage, getUserLevel()).done(
        function (data) {
            if(data === undefined) {
                return false;
            }
            var target = data[0].targetType === "target" ? "_blank" : "";
            var href = data[0].defaultAction;
            var imageURL =  data[0].maxImageHttpUrl;
            var str = '<a target="' + target + '" href="' + href + '" class="hyr-promo top-banner-member-day-js" style="background:url(' + imageURL + ') center top;"></a>';
            $("#withdraw_ad").html(str);
        }
    ).fail(cms_failure);
}); 