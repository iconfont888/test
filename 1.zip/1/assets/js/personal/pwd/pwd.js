var pwdRegex = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,10}$/;
var oldRegex = /^[a-zA-Z0-9]{6,12}$/;

$(document).ready(function(){
    //表单校验
    var validate = $("#changePwdForm").validate({
    	onkeyup: null,
        rules: {
            oldPwd:{
                required: true,
                rangelength: [6, 12],
                maxlength: 12,
                regex: oldRegex,
                checkOldPwd: true
            },
            newPwd:{
                required: true,
                rangelength: [8, 10],
                maxlength: 10,
                notEqualTo: "#oldPwd",
                regex: pwdRegex
            },
            newPwdConfim:{
                required: true,
                rangelength: [8, 10],
                maxlength: 10,
                equalTo: "#newPwd"
            }
        },
        messages: {
            oldPwd: {
                required: "请输入原始密码",
                minlengrh: "您输入的密码格式不正确!",
                maxlength: "密码最多输入12位！",
                rangelength: "您输入的密码格式不正确!",
                regex: "您输入的原始密码格式不正确!",
                checkOldPwd: "您输入的原始密码不正确!"
            },
            newPwd:{
                required: "请输入新密码",
                minlengrh: "您输入的密码格式不正确!",
                maxlength: "密码最多输入10位！",
                rangelength: "您输入的密码格式不正确!",
                notEqualTo: "新密码不能和原始密码相同!",
                regex: "您输入的密码格式不正确!"
            },
            newPwdConfim:{
                required: "请再次输入以确认新密码",
                minlengrh: "您输入的密码格式不正确!",
                maxlength: "密码最多输入10位！",
                rangelength: "您输入的密码格式不正确!",
                equalTo: "两次输入密码不一致!"
            }

        },
        errorClass: "error col-xs-9 text-orange",
        submitHandler: changePwd
    });

    /**
     * 检查原始密码是否正确
     */
    $.validator.addMethod("checkOldPwd", function (v, e, param) {
        var $e = $(e), value = v;
        var method = "checkOldPwd";

        var previous = this.previousValue(e, method),
            validator, data, optionDataString;
        if (!this.settings.messages[e.name]) {
            this.settings.messages[e.name] = {};
        }
        previous.originalMessage = previous.originalMessage || this.settings.messages[e.name][method];
        this.settings.messages[e.name][method] = previous.message;

        param = typeof param === "string" && {url: param} || param;
        optionDataString = $.param($.extend({data: value}, param.data));
        if (previous.old === optionDataString) {
            return previous.valid;
        }
        this.startRequest(e);
        previous.old = optionDataString;
        validator = this;
        data = {};
        data[e.name] = value;
        $.request({
            url: "/api/password/verify/old",
            type: "POST",
            data: {
                'oldPassword': $e.val()
            }
        }).done(function (response) {
            var flag = response.successful, valid;
            if (flag) {
                var submitted = validator.formSubmitted;
                validator.prepareElement(e);
                validator.formSubmitted = submitted;
                validator.successList.push(e);
                validator.showErrors();
                valid = true;
            } else {
                var errors = {};
                errors[e.name] = previous.message;
                validator.invalid[e.name] = true;
                validator.showErrors(errors);
                valid = false;
            }
            previous.valid = valid;
            validator.stopRequest(e, valid);
        }).fail(function(e){
            logConsole(e);
        });
        return "pending";
    }, "您输入的原始密码不正确");
    validatePassword(validate);
});

function validatePassword(validate){
	$("input[name='newPwd'],input[name='newPwdConfim'],input[name='oldPwd']").on("propertychange input",function(event){
	    var $this=$(this);
	    var pwd = $this.val();
	    if(pwd.length>12){
	    	var errors = {};
	    	// errors[$this.attr("name")]="密码最多输入12位！";
	    	 validate.showErrors(errors);
		     $this.val($this.val().substr(0,12));
		}
	});
}

changePwd = function(){
    if($("#changePwdForm").validate().form()){
        $("#changePwdBtn").attr("href", "javascript:;");
        var oldPwd = $("#oldPwd").val();
        var newPwd = $("#newPwd").val();

        $("div.u-content.u-update-pwd").loading({'glass': false});

        $.request({
            type : 'PUT',
            url : '/api/password',
            encrypt:true,
            data : {'oldPassword' : oldPwd, 'password': newPwd},
            success:function (response) {
                //泡吧跳转
                if(utils.getQueryString("min")=="true"){
                    return window.parent.postMessage(response,'*');
                }
                $("div.u-content.u-update-pwd").loading('close');
                $("#changePwdBtn").attr("href", "javascript:changePwd();");
                if(response.successful){
                    //  标记, 不再自动授权登录
                    nonLoginHelper.setLogoutMark();
                    AG_INIT.clear();
                    setTimeout(function () {
                        window.location.href = "/index.html?login";
                    }, 2000);
                    layer.open({
                        title: ' ',
                        content: '恭喜您，密码已修改成功，系统会自动退出，请用新密码重新登录。',
                        btn: ['确定'],
                        closeBtn: 0,
                        yes: function(){
                            window.location.href = "/index.html?login";
                        }
                    });
                }else{
                    failure(response.message);
                }
            },
            error:function () {
                $("div.u-content.u-update-pwd").loading('close');
                $("#changePwdBtn").attr("href", "javascript:changePwd();");
                layer.open({
                    title: ' ',
                    content: '更改密码失败!',
                    btn: ['确定'],
                    closeBtn: 0,
                    yes: function(){
                        window.location.href = "/ucenter/person/pwdIndex";
                    }
                });
            }
        });
    }
};
(function () {
    var min = utils.getQueryString("min");
    if (min){
        $.getScript(webConf.cdn_url + "/assets/js/pay/paymin.js");
    }
})();