/**
 * 定时刷新
 * @param freshId 要刷新显示的id或者直接是jquery的元素
 * @param freshTxt  刷新显示的文本
 * @param endTxt 结束刷新的文本
 * @param freshFunc 开始刷新时执行自定义函数，通常用于执行禁用目标id的某些效果
 * @param endFunc 刷新结束时执行的自定义函数
 * @param time 自定义刷新时间
 */
function countdown(freshId, freshTxt, endTxt, freshFunc, endFunc, time) {
    if("function" == typeof freshFunc){
        freshFunc();
    }

    //计时启动时间
    var currenttime = new Date().getTime();
    var csecond = time || 300;

    var freshElment;
    if(typeof freshId == 'string'){
        freshElment = $('#' + freshId);
    }else{
        freshElment = freshId;
    }

    UpdateTime();
    //每0.5秒刷新一次
    var counter = setInterval(UpdateTime, 500);

    //刷新
    function UpdateTime() {
        var cTime = new Date().getTime();
        var diff = cTime - currenttime;
        var seconds = csecond - Math.floor(diff / 1000);
        //小于10，前补零
        var count = seconds < 10 ? "0" + seconds : seconds;
        if (seconds >= 0) {
            //剩余时间大于0，刷新显示秒数
            freshElment.text(freshTxt + count);

        } else {
            //计时结束，清除定时，刷新显示
            freshElment.text(endTxt);
            if("function" == typeof endFunc){
                endFunc();
            }
            clearInterval(counter);
        }
    }

}

//倒计时回置
function countDownReset(freshId, freshTxt, endTxt, freshFunc, endFunc, key) {
    var codeSendTime = $.cookie(key);
    if(typeof codeSendTime != 'undefined'){
        var remainTime = parseInt((new Date() - new Date().setTime(codeSendTime)) / 1000);
        if(remainTime < 300){
            //如果还需要倒计时
            countdown(freshId, freshTxt, endTxt, freshFunc, endFunc, 300 - remainTime);
        }
    }
}

/**
 * 修改会员日活动倒计时
 * @param start
 * @param finish
 */
function memberDayTimer(start, finish) {
    var ts = finish - start;
    if (ts >= 0) {
        $(".countdown").attr('style', 'display:block');
        var dd = parseInt(ts / 1000 / 60 / 60 / 24);//计算剩余的天数
        var hh = parseInt(ts / 1000 / 60 / 60 % 24);//计算剩余的小时数
        var mm = parseInt(ts / 1000 / 60 % 60);//计算剩余的分钟数
        var ss = parseInt(ts / 1000 % 60);//计算剩余的秒数
        dd = checkTimeHeader(dd);
        hh = checkTimeHeader(hh);
        mm = checkTimeHeader(mm);
        ss = checkTimeHeader(ss);
        var _time = (dd + hh + mm + ss).split("");
        $(".xin-wrap>ul>li[id]").each(function (index, item) {
            $(item).text(_time[index]);
        });
    } else {
        $(".xin-wrap").remove();
    }
}


function checkTimeHeader(i) {
   if (i < 10) {    
       i = "0" + i;    
    }
    return i + "";
}


/*根据注册星级展示充值按钮icon*/
$(function () {
	if(new Date(pn.sys_now).getTime()>1520092799000){
		if(pn.userType=="1"){
			 $.ajax({
		        url: "/personal/check/newly/register",
		        type: "post",
		        dataType: "json",
                 headers: {
                     "X-Website-Code":"MAIN_PC"
                 },
		        success: function (data) {
		          var _data = data.data;
		           if(!data.successful){
		        	   return;
		           }else if(!_data.firstDeposit && pn.userLevel=="0"){
		        	   $('.btn.btn-custom.btn-orange').attr('class','btn btn-custom btn-orange btn-deposit');
		           	   $('.icon-piggy').remove();
		        	}
		        },
                 error: function(xhr,textStatus,err){
					console.log("error: " + err);
				}
		    });
		};
	}
});