$(function () {
    if($('.sidebar').length > 0) {
        renderSidebar();
    }
    
    (function () {
        var href = window.location.href;
        if (href.indexOf('#tryplay') > -1) {
            $('.btn-freeplay').click();
            $('.modal-backdrop').hide();
        } else if (href.indexOf('login') > -1) {
            $('.modal-backdrop').hide();
        } else if (href.indexOf('#fastRegBut') > -1) {
            showReg();
            $('.modal-backdrop').hide();
        } else if (href.indexOf('?login')) {
            // $('#quick-login-btn').click();
            $('.modal-backdrop').hide();
        }
    })();

    $('.navbar-right .dropdown-toggle').click(function () {//为了避免获取不到dom，click事件失效导致偶现验证码无法加载，请勿放置ready后
        showSpeedyActive(this, true);
    });
})
//初始化埋码
try {
    cfgForDS['p_url'] = pn.p_url;
    cfgForDS['l_url'] = pn.l_url;
    cfgForDS['r_url'] = pn.r_url;
    cfgForDS['sysCode'] = pn.sysCode;
    cfgForDS['productId'] = pn.productId;
    cfgForDS['visitSite'] = pn.visitSite;
    cfgForDS['visitTime'] = pn.sys_now;
    cfgForDS['customerId'] = pn.userId;
    cfgForDS['loginName'] = pn.userName;
    cfgForDS['customerType'] = pn.userType;
    cfgForDS['customerLevel'] = pn.userLevel;
    switchForDS = pn.switchForDS;
} catch (e) {

}

var DS_VAR = DS_VAR || [];
DS_VAR.DEVICE_TYPE = DS_VAR.DEVICE_TYPE_PC;
var dsObj = new DSObj();
dsObj.init();

$.ajaxSetup({cache: false});
var Common = {
    /**
     * 格式化成金额形式
     *
     * @param num 数值(Number或者String)
     * @return String
     * 金额格式的字符串,如'1,234,567.45'
     * @type String
     */
    AmountFormatter: function (num) {
        if (num === undefined || num === null || num === '') {
            return '0';
        }
        var num_top = "";
        var num_tail = "";
        var result = '';
        var re = new RegExp("^(-?\\d+)(\\.\\d+)$"); // 判断是否是浮点数
        if (re.test(num)) {
            var strSum = String(num);
            if (strSum.indexOf(".") > -1) {
                num_tail = strSum.split(".")[1];
                num_top = strSum.split(".")[0];
            }
            while (num_top.length > 3) {
                result = ',' + num_top.slice(-3) + result;
                num_top = num_top.slice(0, num_top.length - 3);
            }
            if (num_top) {
                result = num_top + result + '.' + num_tail;
            }
        } else {
            num_top = String(num);
            while (num_top.length > 3) {
                result = ',' + num_top.slice(-3) + result;
                num_top = num_top.slice(0, num_top.length - 3);
            }
            if (num_top) {
                result = num_top + result;
            }
        }
        return result;
    },
    /*
     单位
     */
    units: '个十百千万@#%亿^&~',
    /*
     字符
     */
    chars: '零一二三四五六七八九',
    /*
     数字转中文
     @number {Integer} 形如123的数字
     @return {String} 返回转换成的形如 一百二十三 的字符串
     */
    numberToChinese: function (number) {
        var a = (number + '').split(''), s = [], t = this;
        if (a.length > 12) {
            throw new Error('too big');
        } else {
            for (var i = 0, j = a.length - 1; i <= j; i++) {
                if (j === 1 || j === 5 || j === 9) {//两位数 处理特殊的 1*
                    if (i === 0) {
                        if (a[i] !== '1') s.push(t.chars.charAt(a[i]));
                    } else {
                        s.push(t.chars.charAt(a[i]));
                    }
                } else {
                    s.push(t.chars.charAt(a[i]));
                }
                if (i !== j) {
                    s.push(t.units.charAt(j - i));
                }
            }
        }
        return s.join('').replace(/零([十百千万亿@#%^&~])/g, function (m, d, b) {//优先处理 零百 零千 等
            b = t.units.indexOf(d);
            if (b !== -1) {
                if (d === '亿') return d;
                if (d === '万') return d;
                if (a[j - b] === '0') return '零'
            }
            return '';
        }).replace(/零+/g, '零').replace(/零([万亿])/g, function (m, b) {// 零百 零千处理后 可能出现 零零相连的 再处理结尾为零的
            return b;
        }).replace(/亿[万千百]/g, '亿').replace(/[零]$/, '').replace(/[@#%^&~]/g, function (m) {
            return {'@': '十', '#': '百', '%': '千', '^': '十', '&': '百', '~': '千'}[m];
        }).replace(/([亿万])([一-九])/g, function (m, d, b, c) {
            c = t.units.indexOf(d);
            if (c !== -1) {
                if (a[j - c] === '0') return d + '零' + b
            }
            return m;
        });
    }
};
if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (elt /*, from*/) {
        var len = this.length >>> 0;
        var from = Number(arguments[1]) || 0;
        from = (from < 0)
            ? Math.ceil(from)
            : Math.floor(from);
        if (from < 0)
            from += len;
        for (; from < len; from++) {
            if (from in this &&
                this[from] === elt)
                return from;
        }
        return -1;
    };
}
jQuery.cachedScript = function (url, options) {
    options = $.extend(options || {}, {
        dataType: "script",
        cache: true,
        url: url
    });
    return jQuery.ajax(options);
};

window._wms_key = {
    'id': 0,
    'recommend': 19, //是否推荐游戏
    'platForm': 1, //平台
    'enName': 2,//英文名
    'zhName': 3, //中文名
    'gameType': 4, //游戏类型
    'playerType': 7, //玩家类型
    'line': 6, //线数
    'limit': 14,//最高派奖
    'score': 15, //积分
    'image1': 16, //图片地址
    'bonusUrl': 17, //奖池地址
    'hot': 26, //是否热门
    'new': 18, //是否最新
    'bonus': 8, //是否奖池游戏
    'style': 5, //游戏风格
    "playCount": 12,//游玩次数
    'supportTry': 9, //是否支持试玩
    'promotion': 27, //是否爆奖游戏
    'remark': 23, //备注
    'popular': 10, //人气值
    'lang': 25, //游戏语言
    'characteristic': 20
};

if (typeof games === 'undefined') {
    games = [];
}

//  首页轮播图
var patten = /^(banner|promotion|wms)_/i;
var _games = grepGame(games, [function (n) {
    return !(patten.test(n[_wms_key.id]));
}]);
var _banners = grepGame(games, [function (n) {
    return /^banner_/i.test(n[_wms_key.id]);
}]);
//  优惠内页轮播图
var _promotions = grepGame(games, [function (n) {
    return /^promotion_/i.test(n[_wms_key.id]);
}]);

/* 红包弹窗数据 */
var _red_envelope = {};
var setRedEnvelope = function (data) {
    var remark = data.remarks || "";
    var remarks = remark.split("|");
    var option = {
        title: remarks.length > 1 ? remarks[1] : "",
        text: remarks.length > 2 ? remarks[2] : "",
        href: remarks.length > 3 ? remarks[3] : "",
        sec_content: remarks.length > 4 ? remarks[4] : "",
        sec_text: remarks.length > 5 ? remarks[5] : "",
        sec_platform: remarks.length > 6 ? remarks[6] : "",
        sec_href: remarks.length > 7 ? remarks[7] : ""
    };
    var title = option.title || '您有一个红包可领取！';
    var text, href;
    if (option.text && option.href) {
        text = option.text;
        href = option.href;
    } else {
        text = "下载亚游加速登录器，体验流畅游戏！";
        href = '/tools/accelerator';
    }
    /* 推荐好友礼金特殊处理 */
    if (data.type === 'TJHYLJ') {
        title = '您的推荐好友奖金已发放，请及时领取！';
        text = '如有疑问请联系客服, 谢谢合作!';
        href = 'cs';
    }
    var tips;
    if (/cs/i.test(href)) {
        tips = text.replace("联系客服", "<a href='#' class='as-cs'>联系客服</a>")
    } else {
        tips = '<a target="_blank" href="' + href + '">' + text + '</a>';
    }
    var amount = data.amount;
    var content = option.sec_content || "所需有效投注: " + data.betAmount + "元";
    var button;
    if (option.sec_text && option.sec_platform && option.sec_href) {
        var hrefA = option.sec_platform !== 'AG' ? '/website/redirect?url=' + option.sec_href : option.sec_href;
        button = '<a href="' + hrefA + '" class="btn-link btn-link2">' + option.sec_text + '</a>';
    } else {
        var hrefB = '/game/show/lobby';
        if (data.type === "EGAMEHB") {
            var protocol = location.protocol.replace(/:$/, "");
            hrefB = "/website/redirect?scheme=" + protocol + "&url=/game/play/ag?gameCode=500&trial=true";
        }
        button = '<a href="' + hrefB + '" class="btn-link btn-link2">立即投注</a>';
    }

    _red_envelope = {
        tips: tips,
        first: {
            title: title
        },
        second: {
            amount: amount,
            content: content,
            button: button
        }
    };
};
var getPromotionTypeCN = function (value) {
    switch (value) {
        case 'CLLJ':
            value = '蝉联礼金';
            break;
        case 'JJLJ':
            value = '晋级礼金';
            break;
        case 'MRSC':
            value = '日日首存';
            break;
        case 'SREG':
            value = '注册礼金';
            break;
        case 'SDEP':
            value = '100%存送礼金';
            break;
        case 'P02Lottery01':
            value = '100%百万奖金大放送';
            break;
        case '88LJ':
            value = '88礼金';
            break;
        case 'ZNLJ':
            value = '周年礼金';
            break;
        case 'HBLJ':
            value = '红包礼金';
            break;
        case 'EGAMEHB':
            value = '电游红包';
            break;

        case 'BREAKTHROUGH':
            value = '过关斩将';
            break;
        case 'TJHYLJ':
            value = '推荐好友礼金';
            break;
        case 'OTHER':
            value = '其他优惠';
            break;
        case 'REG18':
            value = '注册礼金';
            break;
        case 'RED_ENVELOPES':
            value = '红包优惠';
            break;
        case 'REDENVELOPES':
            value = '红包优惠';
            break;
        case 'TANABLATA':
        case 'TANABLATAEND':
            value = '七夕活动';
            break;
        case 'MIDAUTUMN':
            value = 'AG亚游金秋博饼';
            break;
        case 'MIDAUTUMNEND':
            value = 'AG亚游金秋博饼-终极奖';
            break;
        case 'REG_GIFT_18':
            value = '18元电游体验金';
            break;
        case 'MEMBERDAY8':
            value = '亚游会员日-AG红包';
            break;
        case 'MEMBERDAY18':
            value = '亚游会员日-充值红包';
            break;
        case 'MEMBERDAY28AGIN':
            value = '亚游会员日-8财红包（国际厅）';
            break;
        case 'MEMBERDAY28AGQ':
            value = '亚游会员日-8财红包（旗舰厅）';
            break;
        case 'FIRSTDEPOSIT':
            value = '新人首存电游红包';
            break;
        case 'SINGLESDAY':
            value = '双11首存';
            break;
        case 'ZXFL':
            value = '在线支付返利';
            break;
        case 'DXLJ':
            value = '电消礼金';
            break;
        case 'BETTERLUCK':
            value = '开运红包';
            break;
    }
    return value;
};

var _Cookie_ = {
    set: function (key, value, expiredays) {
        var exp = expiredays * 24 * 60 * 60;
        var expire = new Date();
        expire.setTime(expire.getTime() + (expiredays || 0) * 24 * 60 * 60 * 1000);
        //  IE 下不支持 max-age
        document.cookie =
            key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; expires=" + expire.toUTCString())
            + "; domain=" + window.location.hostname + "; path=/;";
        //document.cookie = key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; max-age=" + exp) + ";";
    },
    get: function (key) {
        var arr, reg = new RegExp("(^|\\s+)" + key + "=(.*?)(;|$)");
        if (arr = document.cookie.match(reg))
            return (arr[0]);
        else
            return null;
    },
    del: function (key) {
        if (_Cookie_.get(key)) {
            var date = new Date();
            date.setTime(date.getTime() - 10000);
            //  IE 下不支持 max-age
            document.cookie = key + "=v; expires =" + date.toUTCString()
                + "; domain=" + window.location.hostname + "; path=/;";
            //document.cookie = key + "=v; max-age=0";
        }
    }
};

function resort(banners, property) {
    banners = banners.sort(function (a, b) {
        return a[property] - b[property];
    });
    return banners;
}

function isBeforeToNow(date) {
    return compareToNowDate(date) <= 0;
}

function compareToNowDate(date) {
    return getTime(date) - pn.sys_now;
}

function getTime(value) {
    return new Date(value.replace(/-/g, "/")).getTime();
}

function grepGame(gameList, funcArray) {
    return $.grep(gameList, function (n, i) {
        for (var _i = 0; _i < funcArray.length; _i++) {
            if (!funcArray[_i](n)) {
                return false;
            }
        }
        return true;
    });
}

// 判断是否是IE浏览器
function BrowserType() {
    var isIE = window.ActiveXObject || "ActiveXObject" in window;
    if (isIE) {
        return true;
    }
}
function showReg(){
    $("#loginModal").modal('hide');
    var _register_flag = utils.storage.getItem("register_flag");
    if(_register_flag && _register_flag =="true"){
        $("#regModal3").modal('show');
    }else{
        $("#regModal").modal('show');
    }
}
(function () {
    var redirect = utils.getQueryString("redirect");
    if (redirect) {
        $("form input[name='redirect']").val(redirect);
        //登录的情况下直接跳到重定向地址
        if (pn.userType == "0" && redirect.indexOf("egames=1") >= 0 && redirect.indexOf("trial=true") < 0) {
            // location.href = location.origin + '/index.html?login&redirect=' + encodeURIComponent(redirect);
            history.pushState({url: '/index.html?login', title: document.title}, document.title, '/index.html?login')
        } else {
            // 改变url地址，不刷新页面
            var url = location.origin + '/index.html?login';
            //此判断只针对电游的游戏试玩
            if (redirect && redirect.indexOf("egames=1") >= 0 && redirect.indexOf("trial=true") >= 0) {
                url = location.origin + "/index.html?trial"
            }
            history.pushState({url: url, title: document.title}, document.title, url)
        }
    }
    try {
        if (games && $.isArray(games)) {
            var _js = $.grep(games, function (n, i) {
                var _id = n[_wms_key.id];
                return _id === "banner_dev" || /^wms_js_/i.test(_id);
            });
            if (_js) {
                var jsFile = _js[0],
                    name = jsFile[_wms_key.image1];
                var url = pn.gameStaticUrl + "static/__static/electronicgames/" + name + "?" + jsFile[_wms_key.popular];
                var hm = document.createElement("script");
                hm.src = url;
                var s = document.getElementsByTagName("script")[0];
                s.parentNode.insertBefore(hm, s);
            }
        }
    } catch (Error) {
    }
})();

$(document).ready(function () {
    $("#fast-reg-but").on("click", function () {
        $("#loginModal").modal('hide');
        switch (pn.registerVerificationType) {
            case 2 :
                $(".kaptcha").addClass("hide");
                break;
            case 3 :
                $(".kaptcha").removeClass("hide");
                $(".kaptcha").next(".register-captcha").hide();
                break;
            /*default:
                $(".kaptcha").addClass("hide").next(".register-captcha").hide();*/
        }
        setTimeout(function () {
            $('.modal-backdrop').remove();
        }, 200);
    });
    var domainList = {
        A21: "ag13821.com",
        A22:"ag13822.com",
        A23: "ag13823.com",
        A24:"ag13824.com",
        A25: "ag13825.com",
        A26:"ag13826.com",
        A27: "ag13827.com",
        A28:"ag13828.com",
        A29: "ag13829.com",
        A30:"ag13830.com",
        A31: "ag13831.com",
        A32:"ag13832.com",
        A33: "ag13833.com",
        A34:"ag13834.com",
        A35:"ag13835.com"
    };
    var d=utils.getQueryString("d");
    if(d){
        d=d.toUpperCase();
        if(d in domainList){
            $("#quick-login-btn").attr("data-target","#regModal2")
        }
    }

    $("#quick-login-btn, #fast-reg-but, #try-reg-but").on("click", function () {
        setTimeout(function () {
            $('.modal-backdrop').remove();
        }, 200);
    });

    /**
     * 百度统计公共代码
     * data-tongji-attr="_trackEvent,AG8,主站,首页,首页"
     */
    $("body").on("click", '*[data-tongji-attr]', function (e) {
        var $this = $(this);
        var selectStr = $this.data("select"), matchStr = $this.data("match"), parentStr = $this.data("parent");
        if (!selectStr && !matchStr) {
            _hmt.push($this.data('tongji-attr').split(","));
            return;
        }
        var $select;
        if (!selectStr && parentStr) {
            $select = $this.parent();
        } else if (!selectStr && !parentStr) {
            $select = $this;
        } else if (selectStr && parentStr) {
            $select = $this.parents(selectStr);
        } else {
            $select = $this.find(selectStr);
        }
        if ($select.is(matchStr)) {
            _hmt.push($this.data('tongji-attr').split(","));
        }
    });

    //  图片验证码-刷新 verification-group-js
    $(".verification-group-js img").on("click", function () {
        var type = $(this).data("type");
        utils.getImageCode("/api/captcha?site=10&type=" + type + "&_d=" + (1 - new Date()),$(this));
    });

    /**
     * 点击任意位置右上边弹出效果隐藏
     */
    $('.header-overlay').click(function () {
        $('body').toggleClass('is-active');
    });
    /**
     * 点击任意位置右上边弹出效果隐藏
     */
    $(document).on('click', '.header-wrap .dropdown-menu', function (e) {
        e.stopPropagation();
    });


    $("input[name=autoLoginName]").on('change', function () {
        $(this).parents('.form-group').next().toggleClass('hide', parseInt($(this).val(), 10));
    });

    setTimeout(function () {
        var b1 = window.lib && lib.hasParam('trial');
        var b2 = window.lib && !lib.hasParam('/register/trial/basic/success');
        if ((b1 && b2) || window.lib && lib.hasParam('trygame')) {
            $("#try-reg-but").click();
            $("#regModal").modal('hide');
            $("#loginModal").modal('hide');
            $('body').addClass('is-active');
            setTimeout(function () {
                $('.modal-backdrop').remove();
            }, 200);
        }
    }, 400);


    //保存推荐码到cookie缓存
    var _recommend_code = window.lib && lib.getUrlParam('recommendcode');
    if (_recommend_code) {
        var expiresDate = new Date();
        expiresDate.setTime(expiresDate.getTime() + (15 * 60 * 1000));
        $.cookie(constants.recommendcode, _recommend_code, {path: '/', expires: expiresDate});
        showRecommend();
    }

    if (window.lib && lib.hasParam('register') && !lib.hasParam('trial/basic/success') || window.lib && lib.hasParam('bitcoin/preRegister')) {
        $("#fast-reg-but").click();
        setTimeout(function () {
            $('.modal-backdrop').remove();
        }, 200);
        showRecommend();
    }

    $(document).on('click', '.trial-gobut', function (e) {
        $("#trialPayForm input[name='redirect']").val($(e.currentTarget)[0].href);
        $("#try-reg-but").click();
        return false;
    });

    $(document).on('click', '.register-gobut', function () {
        $("#fast-reg-but").click();
        return false;
    });

    $(document).on('click', '.login-gobut', function (e) {
        utils.sessionStorage.setItem("gameUrl", $(e.currentTarget)[0].href);
        $('.modal-backdrop').hide();
        $("#quick-login-btn").click();
        return false;
    });

    // $(".btn-logout").on("click", function () {
    //     nonLoginHelper.setLogoutMark();
    // });

    $('.link-loding-gobut').click(function () {
        $("body").loading({'logo': true});
    });

    //sidebar样式
    var winwidth = $(window).width();
    var winheight = $(window).height();
    $(window).on('scroll', function () {
        // if (winwidth <= 1366 && winheight <= 768) {
        //     var sTop = document.body.scrollTop || document.documentElement.scrollTop;
        //     $('.sidebar').toggleClass('fixed', sTop > 175);
        // }
        // else {
        $('.sidebar').addClass('fixedsm');
        // }
    });

    var $btnSignIn = $('.btn-sign-in'),
        $btnSignUp = $('.btn-sign-up'),
        $signInCont = $('.sign-in-wrap'),
        $loginModal = $('#loginModal'),
        $regModal = $('#regModal'),
        $regModal3 = $('#regModal3');

    // sign-in sign-up modal
    $('#loginModal, #regModal,#regModal3,  #chargeModal, #tryplayModal').on('show.bs.modal', function (e) {
        $('.modal-header .nav-tabs li:eq(0) a', $(e.target)).trigger('click');
    }).on('hidden.bs.modal', function () {

    });

    $(document).on("click", '.header-wrap .modal .close', function () {
        $('body').removeClass('is-active');
    });

    $('.forget-password-wrap3').find('.btn-submit').click(function () {
        $(this).parents('.modal-content').hide();
        $('.sign-in-wrap').fadeIn('fast');
    });
    $('.btn-forget-password').click(function () {
        $(this).parents('.modal-content').hide();
        ($(this).parents('.modal-content').next()).removeClass('hidden').fadeIn('fast');
    });
    $btnSignIn.click(function () {
        $signInCont.show().siblings().hide();
        $signInCont.find('.nav-tabs li').removeClass('active');
        $('a[href="#quick-login"]').tab("show");
    });
    $('.go-sign-in').click(function () {
        $regModal.modal('hide');
        $loginModal.modal({
            "backdrop": true,
            "show": true
        });
        $loginModal.find('.modal-content').hide();
        $('.sign-in-wrap').fadeIn('fast').find('.nav-tabs li').removeClass('active');
        $('a[href="#quick-login"]').tab("show");
    });
    $btnSignUp.click(function () {
        $loginModal.modal('hide');
        var _register_flag = utils.storage.getItem("register_flag");
        if(_register_flag && _register_flag =="true"){
            $regModal3.modal({
                "backdrop": true,
                "show": true
            });
            $regModal3.find('.modal-content').hide().fadeIn('fast');
        }else{
            $regModal.modal({
                "backdrop": true,
                "show": true
            });
            $regModal.find('.modal-content').hide().fadeIn('fast');
        }
        $('a[href="#phone-login"]').parent().addClass('active').siblings().removeClass('active');
    });


    $('[data-toggle="tooltip"]').tooltip();

    if (pn.userType == "1") {
        $.request({
            url: "/api/letters/unread"
        }).done(function (res) {
            if(res.successful){
                var data = res.data;
                var noticeCount = data.notice;
                var perferentialCount = data.perferential;
                var count = noticeCount + perferentialCount;
                count>0?$(".badge.letter").text(count).show():$(".badge.letter").hide();
                var $yhTabs = $(".yh-tabs");
                if ($yhTabs.length) {
                    setUnRead($yhTabs, perferentialCount, noticeCount);
                }
            }else{
                logConsole(res.message);
            }
        }).fail(function(e){
            logConsole(e);
        });
    }

    //  设置未读
    function setUnRead($yhTabs, perferential, notice) {
        if (perferential) {
            var noticeTag = $yhTabs.find("a[data-value=0]");
            noticeTag.parent().append('<em class="badge">' + perferential + '</em>');
        }
        if (notice) {
            var perferentialTag = $yhTabs.find("a[data-value=1]");
            perferentialTag.parent().append('<em class="badge">' + notice + '</em>');
        }
    }

});

/**
 * 更新跳转地址,当跳转到其他子网站时添加当前用户的scheme
 */
function updateRedirectUrl() {
    var protocol = location.protocol.replace(/:$/, "");
    $("a[href^='/website/redirect']").each(function (i, n) {
        var $this = $(n), href = $(n).attr("href");
        if (!/\?scheme=/.test(href)) {
            var newValue = href.replace(/\?/, "?scheme=" + protocol + "&");
            $this.attr("href", newValue);
        }
    });
}

$(function () {
    updateRedirectUrl();
    /** @author candice **/
    var inputs = $('input');
    if (inputs.length) {
        for (var i = 0; i < inputs.length; i++) {
            $(inputs[i]).placeholder()
        }
    }
    inputs = null;
    /** end **/
});

/**
 * 显示右上边弹出效果
 */
function showSpeedyActive(tab, iscaptcha) {
    $('body').toggleClass('is-active');
    if (true === iscaptcha) {
        var $img = $(tab).parent().find('.verification-group-js img');
        var type = $img.data("type");
        utils.getImageCode("/api/captcha?site=10&type=" + type + "&_d=" + (1 - new Date()),$img);
    }

    showRecommend();

    $('.navbar-right .btn-group').removeClass('is-active');
    $(tab).parent().addClass('is-active');
}

function showRecommend() {
    if (lib.hasValue($.cookie(constants.recommendcode))) {
        next();
    }else{
        // 校验是否是VIP专属域名
        var hostDic = JSON.parse(utils.storage.getItem('hostDic'));
        if(hostDic && hostDic.isVipHost===true && hostDic.currentHost === location.host){
            next();
        }else{
            checkDomain();
        }
    }
}

function checkDomain(){
    $.request({
        url : "/api/check/domain" ,
        async : false
    }).done(function (res) {
        if(res && res.successful) {
            utils.storage.setItem('hostDic',JSON.stringify({'isVipHost':true,'currentHost':location.host}));
            next();
        }else{
            utils.storage.setItem('hostDic',JSON.stringify({'isVipHost':false,'currentHost':location.host}));
        }
    }).fail(function(e){
        logConsole(e);
    });
}

function next(){
    $('.recommend-group').each(function () {
        var sidebar = $(this);
        sidebar.hide();
    });
}

var protocol = location.protocol.replace(/:$/, "");


$.loading = function () {
    if (arguments.length > 0 && arguments[0] === false) {
        $('.loading-mask').remove();
        return false;
    }
    $('body').loading();
};


XINSlotUtil = {
    testGameUrl: function (href) {
        return /play\/ag\?gameCode=158/.test(href)
            || /play\/ag\?gameCode=WH01/.test(href)
            || /play\/ag\?gameCode=162/.test(href);
    },
    getGameUrl: function (gameType) {
        if (gameType === '158' || gameType === 158) {//AG神奇宝贝
            return "/game/play/ag?gameCode=158&gameName=Mystic%20Gems&platForm=AG&language=zh&trial=false";
        } else if (gameType === 'WH01' || gameType === 'WHGWH01') {
            return "/game/play/ag?gameCode=WH01&gameName=alibaba&platForm=AG&language=zh&trial=false";
            //XIN哥王者传说
        } else if (gameType === '162' || gameType === 162) {
            return "/game/play/ag?gameCode=162&gameName=King%20of%20Glory&platForm=AG&language=zh&trial=false";
        }
    },
};

var protocol = location.protocol.replace(/:$/, "");
(function (_now, staticUrl, _gameUrl) {
    if (typeof _now === 'undefined' || !_now) {
        var date = new Date();
        _now = date.getTime();
    }
    if ((_now < 1533135600000 && _now > 1533124800000) ||
        (_now < 1533222000000 && _now > 1533211200000) ||
        (_now < 1533308400000 && _now > 1533297600000)) {
        $("head").append('<link type="text/css" rel="stylesheet" href="https://xingaming.com/API/css/XINSlotEvent-v2.0.css"/>');
        $("head").append("<style>.eventLayerXINSlotEvent.large{z-index: 9999 !important;}" +
            "        .eventPopupXINSlotEvent.large,.closeBtnXINSlotEvent.large{z-index: 99999 !important;}" +
            "    </style>");
        $.getScript("https://xingaming.com/API/XINSlotEvent-v2.0.min.js", function (e) {
            var xINSlotEvent = new XINSlotEvent();
            xINSlotEvent.API({
                action: "init",
                style: "large",
                showButton: true,
                lang: "ZH",
                pid: "B79",
                afterClose: "neverShow",
                mode: localStorage.getItem('WINDOW_XINGE_ENV') || "production",
                goGameCallback: function (gameType) {
                    var date = new Date(_now);
                    localStorage.setItem('WINDOW_XINGE_MAIN', date.setHours(date.getHours() + 8))
                    var url = '/website/redirect?scheme=' + protocol + '&url=' + encodeURIComponent(XINSlotUtil.getGameUrl(gameType));
                    window.open(url, "_blank");
                },
            });
        });
    }
})(typeof pn.sys_now === 'undefined' ? 0 : pn.sys_now, "",
    '/website/redirect?scheme=' + protocol +
    '&url=%2Fgame%2Fplay%2Fag%3FgameCode%3D162%26gameName%3DKing%2520of%2520Glory%26platForm%3DAG%26language%3Dzh%26trial%3Dfalse');


/**
 * 判断是否展示香港的电话号码
 */
$(function () {
    var hongkongInterval = setInterval(function(){
        if($(".hongKongParent").length){
            if (pn.hongKong1 != "true" && pn.hongKong2 != "true") {
                $(".hongKongParent").hide();
            } else if (pn.hongKong1 != "true") {
                $(".hongKong1").hide();
                $(".hongKong2").show();
            } else if (pn.hongKong2 != "true") {
                $(".hongKong2").hide();
                $(".hongKong1").show();
            }
            clearInterval(hongkongInterval);
        }
    })
});
