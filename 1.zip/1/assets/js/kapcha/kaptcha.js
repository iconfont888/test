(function ($, window, document, undefined) {
    //定义kaptcha的构造函数
    var Kaptcha = function (ele, opt) {
        this.$element = ele;
        this.defaults = {
            img: '/api/captcha/CLICK_TEXT/img',//获取文字点击验证码图片
            text: '/api/captcha/CLICK_TEXT',//获取数字图片验证码文字
            check: '/api/captcha/CLICK_TEXT/check',//校验文字点击验证码图片
            success_tip: '验证成功',//验证成功提示
            warn_tip: '验证失败，请重试！',//验证失败提示
            normal_tip: '点击图片进行验证',//常规提示
            reload: false,//验证失败重新刷新标志
            temp_tip: '点击图片进行验证',//验证失败过渡文字
            iWidth: 330,//图片宽度
            iHeight: 170,//图片高度
        };
        this.options = $.extend({}, this.defaults, opt);
        this.clickPoint = [];
    };
    function getOffset(event,target){
        var evt =event||window.event;
        var srcObj = evt.target || evt.srcElement;
        if(target && target == "x"){
            if (evt.offsetX){
                return evt.offsetX;
            }else{
                var rect = srcObj.getBoundingClientRect();
                var clientx = evt.clientX;
                return clientx - rect.left;
            }
        }else{
            if (evt.offsetY){
                return evt.offsetY;
            }else{
                var rect = srcObj.getBoundingClientRect();
                var clienty = evt.clientY;
                return clienty - rect.top;
            }
        }

    }
    //定义Kaptcha的方法
    Kaptcha.prototype = {
        imgclick: function (target, e) {
            if(this.$element.hasClass("arrow_box")){
                this.$element.removeClass("arrow_box").find(".tip_icon").removeClass("shake_img");
            }
            if (this.clickPoint.length >= 3) {
                return;
            }
            var offsetX = getOffset(e,"x");
            var offsetY = getOffset(e,"y");
            var imgWidth = $(target).width();
            var imgHeight = $(target).height();
            var iWidth = this.options.iWidth;
            var iHeight = this.options.iHeight;
            var x = offsetX * (iWidth / imgWidth);
            var y = offsetY * (iHeight / imgHeight);
            var point = {};
            point['x'] = x;
            point['y'] = y;
            this.clickPoint.push(point);
            //显示选择点
            var html = '<div class="captchaWrap-point captchaWrap-point' + this.clickPoint.length + '"></div>';
            $(html).appendTo(this.$element.prev().find('.captchaWrap-img-box')).css({
                "left": offsetX - 13,
                "top": offsetY - 25
            });
            if (this.clickPoint.length >= 3) {
                this.checkCaptcha();
            }
        },
        checkCaptcha: function () {
            //base64加密
            var _this = this;
            var encClickPoint = $.base64.encode(JSON.stringify(this.clickPoint));
            $.request({
                url:this.options.check,
                data:{"code": encClickPoint, type: "register"}
            }).then(function(data){
                if (data.successful) {
                    _this.$element.prev().find('[name="kaptcha"]').val(encClickPoint);
                    _this.success();
                } else {
                    _this.showTip("warning");
                    setTimeout(function () {
                        _this.load();
                    }, 800);
                }
            });
        },
        init: function () {
            var _this = this;
            if(this.options.reload){
                this.clear();
            }
            //构建html
            var html = '<div class="captchaWrap">'
                + '<div class="captchaWrap-box">'
                + '<div class="captchaWrap-img-box">'
                + '<span class="imgWapper"></span>'
                + '<div class="captchaWrap-btn-refresh" title="刷新"></div>'
                + '</div>'
                + '<div class="captchaWrap-tip-box normal"><span class="captchaWrap-tip-box tip-text"></span></div>'
                + '<input name="kaptcha"  type="hidden" class="form-control">'
                + '</div>'
                + '</div>';
            this.$element.before(html);
            this.load();
            //监听
            this.$element.prev().find('.captchaWrap-image').click(function (e) {
                _this.imgclick(this, e);
            });
            //获取验证码
            this.$element.prev().find('.captchaWrap-btn-refresh').click(function (e) {
                _this.load()
            });
            return this.$element;
        },
        load: function () {
            //显示loading
            this.$element.loading({logo: false});
            // 重置点击点集
            this.clickPoint = [];
            //渐入
            this.$element.prev().find(".captchaWrap").fadeIn("slow");
            //删除选择标注
            this.$element.prev().find('.captchaWrap-point').remove();
            this.showTip("normal");
            this.getImg();
        },
        clear: function () {
            var _this = this;
            this.$element.parent().find(".captchaWrap").remove();
            if (this.$element.hasClass("success")) {
                this.$element.removeClass("success");
                this.$element.find(".tip_icon").removeClass("success");
            }
            this.$element.addClass("warning");
            this.$element.find(".tip_icon").addClass("warning");
            this.$element.find(".tip_text").text(this.options.temp_tip);
            setTimeout(function () {
                _this.$element.removeClass("warning");
                _this.$element.find(".tip_icon").removeClass("warning");
                _this.$element.find(".tip_text").text(_this.options.normal_tip);
            },1000)
        },
        getImg: function () {
            var _this = this;
            _this.$element.loading({ logo: false });
            $.request({ url: "/api/captcha/click_text?captchaType=REGISTER" }).then(function (res) {
                if (res && res.successful) {
                    var data = res.data;
                    var bgImage = data.bgImage, words = data.words;
                    if (words) {
                        var tip = "请“依次”点击";
                        for (var i = 0; i < 3; i++) {
                            tip += "【" + words[i] + "】"
                        }
                        _this.$element.prev().find(".tip-text:first").html(tip);
                    }
                    var imgBox = _this.$element.prev().find(".captchaWrap-img-box");
                    var $imgWapper = _this.$element.prev().find(".captchaWrap-img-box").find(".imgWapper");
                    var img = new Image();
                    img.src = bgImage;
                    img.onload = function () {
                        _this.$element.loading(false);
                        $imgWapper.html(img);
                        $(img).addClass("captchaWrap-image");
                    }
                    img.onclick = function (e) {
                        _this.imgclick(this, e);
                    }
                    imgBox.fadeIn("slow");
                }
            })
        },
        getText: function () {
            var _this = this;
            $.request({url:this.options.text,data:{type: "register"}}).then(function(data){
                if (data.successful && data.data.words) {
                    var tip = "请“依次”点击";
                    for (var i = 0; i < 3; i++) {
                        tip += "【" + data.data.words[i] + "】"
                    }
                    _this.$element.prev().find(".tip-text:first").html(tip);
                }
            });
        },
        success: function () {
            var imgBox = this.$element.prev().find(".captchaWrap-img-box");
            var tipBox = this.$element.prev().find(".captchaWrap-tip-box");
            this.showTip("success");
            setTimeout(function () {
                imgBox.fadeOut("slow");
                tipBox.fadeOut("slow");
            }, 400);
        },
        showTip: function (type) {
            var _this = this;
            var icon = _this.$element.find(".tip_icon");
            var text = _this.$element.find(".tip_text");
            if (type == 'success') {
                this.$element.addClass("success");
                icon.addClass("success");
                text.text(_this.options.success_tip);
            } else if (type == 'warning') {
                this.$element.addClass("warning");
                icon.addClass("warning");
                text.text(_this.options.warn_tip);
                setTimeout(function () {
                    _this.$element.removeClass("warning");
                    icon.removeClass("warning");
                    text.text(_this.options.normal_tip);
                }, 400);
            }
            return this;
        }

    };
    $.fn.kaptcha = function (options) {
        var kaptcha = new Kaptcha(this, options);
        return kaptcha.init();
    }
})(jQuery, window, document);
function changCaptcha(){
    $.request({
        url: "/api/register/verify/type",
    }).done(function (response) {
        if (response.successful) {
            var data = response.data;
            var smsCodeType = data.smsCodeType;
            if(smsCodeType && smsCodeType == 1){
                utils.storage.setItem("register_flag","true");
                return;
            }
            utils.storage.removeItem("register_flag");
            pn.registerVerificationType = data.registerVerificationType;
            switch (pn.registerVerificationType) {
                case 2 :
                    $(".kaptcha").hide();
                    $(".kaptcha").next(".verification-group-js").show();
                    break;
                case 3 :
                    $(".kaptcha").show();
                    $(".kaptcha").next(".verification-group-js").hide();
                    break;
                default:
                    $(".kaptcha").hide().next(".register-captcha").hide();//自动化测试去除验证码
            }
        }else{
            logConsole(response.message);
        }
    }).fail(function(e){
        logConsole(e);
    });
}
$(function () {
    $('.kaptcha').click(function () {
        if ($(this).hasClass("success")) {
            return;
        }
        if($(this).hasClass("arrow_box")){
            $(this).removeClass("arrow_box").find(".tip_icon").removeClass("shake_img");
        }
        if ($(this).prev().hasClass("captchaWrap")) {
            if ($(this).prev().hasClass("none")) {
                $(this).find(".tip_text").text("点击图片进行验证");
                $(this).prev().fadeIn("fast").removeClass("none");
            } else {
                $(this).find(".tip_text").text("点此进行验证");
                $(this).prev().fadeOut("fast").addClass("none");
            }
        } else {
            //首次点击初始化插件
            $(this).kaptcha();
        }
    });
})
