/**
 * Created by Barden on 2017/6/5.
 */
var constants = {
    //  登录用户名正则表达式
    "loginNameRegular": /(^[a|A|z|Z][s|S|g|G|y|Y][a-zA-Z0-9]{4,20}$)|(^1[3456789][0-9]{9}$)/,
    //  登录时用户密码
    "loginPwdRegular": /^[a-zA-Z0-9]{6,12}$/,
    //  网络电话号码
    "INTERNET_PHONE_REGEX": /^(17[01]|16[257])\d{8}$/,
    //  手机号码正则表达式
    "phoneRegular": /^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$/, 
	//  注册用户名正则表达式
    "registerNameRegular": /^[a-z0-9]{6,10}$/,
    //  注册密码正则表达式
    "registerPwdRegular": /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,10}$/,
    //  真实姓名正则表达式 (中文: 安瓦尔江·阿不都塞买提; 英文: Nick.ST.OB), 长度: 2~20
    "realNameRegular": /(^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5]$)|(^[a-zA-Z][a-zA-Z\s.]{0,18}[a-zA-Z]$)/,
    //  中文姓名 长度: 2~20
    "cnNameRegular": /^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5]$/,
    //  英文姓名 长度: 2~20
    "enNameReguler": /^[a-zA-Z][a-zA-Z\s.]{0,18}[a-zA-Z]$/,
    //  中英文 长度: 2~20; 省/市/银行名称/开户网点
    "generalCnAndEnReguler": /^[\u4e00-\u9fa5_a-zA-Z]{2,20}$/,
    //  收货地址 至少2位，且以汉字开头，可以包含汉字字母和数字
    "addressRuguler": /^([\u4E00-\u9FA5]+)[\dA-Za-z\u4E00-\u9FA5]+$/,
    //  短信/语音验证码 长度: 6位数字
    "smsAndVoiceCaptchaReguler": /^\d{6}$/,
    //  普通验证码 长度: 4位数字
    "generalCaptchaReguler": /^\d{4}$/,
    //  推荐码 长度:5~8位数字
    "recommendCodeRegular": /^\d{5,8}$/,
    //  推荐码code
    "recommendcode": "recommendcode",
    //  忘记密码计时key
    "forgetPwdKey": "forgetPwdKey",
    //  动态码登录计时key
    "smsLoginKey": "smsLoginKey",
    //  VIP 站URL前缀
    "vipPrefix": "",
    //市
    "CITY_NAME_REGEX": /^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5] | [\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。（]{0,18}[\u4e00-\u9fa5][）]?$/

};