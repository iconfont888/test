/***
 * 优惠列表重构
 * <p>author: hodor
 * <p>date: 2019/5/10
 * <p>time: 14:06
 */
var details = "";
var $content = $(".content");
var nowTimes = pn.sys_now ? pn.sys_now : new Date().getTime(); //当前服务器时间
var $countdown = $(".countdown");
$(function(){
    function getPromotions(currentPage,promotionType){
        $.request({
            url:"/api/cms/promotions",
            data:{
                "moduleCode":"010151",
                "pageNumber":currentPage || 1,
                "pageSize":6,
                "type":promotionType || 2,
            }
        }).done(function(res){
            if(res.successful){
                var _data = res.data.list;
                var totalPages = res.data.totalPage //总页数
                var pageSize = res.data.pageSize //每页条数
                var totalCounts = res.data.totalCount // 总条数
                if(_data.length == 0){
                    details = buildPrePopFirst();
                }else{
                    if(promotionType == "1"){
                        $.each(_data,function(index,item){
                            details += prePromotionHtml(item);
                        });
                    }else if(promotionType == "3"){
                        $.each(_data,function(index,item){
                            details += preNotLongTermEffectivePromotionHtml(item);
                        });
                    }else if(promotionType == "4"){
                        $.each(_data,function(index,item){
                            details += endpromotionHtml(item);
                        });
                    }else{
                        $.each(_data,function(index,item){
                            details += infinitepromotionHtml(item);
                        });
                    }
                }
                
                $.jqPaginator('#pagination',{
                    totalPages: totalPages || 1,
                    totalCounts: totalCounts || 1,
                    pageSize: pageSize,
                    currentPage: currentPage,
                    prev: '<li ><a  href="javascript:void(0);">上一页</a></li>',
                    first: '<li ><a  href="javascript:void(0);">首页</a></li>',
                    last: '<li ><a  href="javascript:void(0);">尾页</a></li>',
                    next: '<li ><a  href="javascript:void(0);">下一页</a></li>',
                    page: '<li ><a  href="javascript:void(0);">{{page}}</a></li>',
                    onPageChange: function (page, type) {
                        if(type == "change"){
                            details = "";
                            getPromotions(page,promotionType)
                            $('html,body').animate({
                                scrollTop: $('.promotion-content').offset().top - 100
                            }, 'slow');
                        }
                    }
                });
                $content.html(details);
            }else{
                failure(res.message);
            }
        }).fail(cms_failure);
        
    }
    
    getPromotions(1,2);
    
    $(".menu ul li").on("click",function(){
        details = "";
        $content.html(details);
        getPromotions(1,$(this).index()+1);
    });

    function buildPrePopFirst() {
        return' <div class="section soon empty loaded" style="display: block;">'
            +'<img src="/assets/images/promotions/coming-soon.png">'
            +'<p>暂无新的优惠，去看看其他优惠吧！</p>'
            +'</div>';
    }

    //过往优惠
function endpromotionHtml(promotion) {
    var target = promotion.targetType ? "_blank" : "";
    var html = '<div class="section is-old loaded" style="display: block;">'
        +'     <div class="promo-image">'
        +'	      <a href="' + promotion.defaultAction + '" target="' + target + '">'
        +'	          <img class="passpromotion" src="' + promotion.maxImageHttpUrl + '">'
        +'	      </a>'
        +'	   </div>'
        +'	   <div class="promo-details promo-reall">'
        +'	       <h2 class="section-title">' + promotion.title + '</h2>'
        +'	       <p class="section-description">' + promotion.promotionDescription + '</p>'
        +'            <div class="longtimecountdown">'
        +'               <i></i>活动已结束'
        +'            </div>'
        +'         <div class="link-container">'
        var detailsAction = '';
        if(promotion.detailAction){//是否有可以立即领取的按钮
            detailsAction = '<a class="link orange" href="' + promotion.detailAction + '" target="' + promotion.target + '">立即领取</a>'
        }
        html += detailsAction;
        html +='       <a class="link grey" href="' + promotion.defaultAction + '" target="' + promotion.target + '">查看详情</a>'
        +'         </div>'
        +'    </div>'
        + '	</div>';
    return html;
}

//新人优惠
function prePromotionHtml(promotion) {
    var target = promotion.targetType ? "_blank" : "";
    var html = '<div data-type="before" class="section soon loaded"  style="display:block">'
        +'                            <div class="promo-image">'
        +'                                <a href="' + promotion.defaultAction + '" target="' + target + '">'
        +'                                    <img src="' + promotion.maxImageHttpUrl + '">'
        +'                                </a>'
        +'                            </div>'
        +'                            <div class="promo-details">'
        +'                                <h2 class="section-title">' + promotion.title + '</h2>'
        +'                                <p class="section-description">' + promotion.promotionDescription + '</p>'
        +'                                <div class="countdown" data-begin-time="' + promotion.beginTime + '" data-end-time="' + promotion.endTime + '">'
        /*+'                                     <span><e></e><e>时</e><e>分</e><e></e></span>'*/
        +'                                </div>'
        +'                                <div class="link-container">'
        var detailsAction = '';
        if(promotion.detailAction){//是否有可以立即领取的按钮
            detailsAction = '<a class="link orange" href="' + promotion.detailAction + '" target="' + promotion.target + '">立即领取</a>'
        }
        html += detailsAction;
        html +='       <a class="link grey" href="' + promotion.defaultAction + '" target="' + promotion.target + '">查看详情</a>'
        +'     </div>'
        +'    </div>'
        + '	</div>';
    return html;
    }
    //优惠列表为空时拼接
    function buildPrePopFirst() {
        return' <div class="section soon empty loaded" style="display: block;">'
            +'<img src="/assets/images/promotions/coming-soon.png">'
            +'<p>暂无新的优惠，去看看其他优惠吧！</p>'
            +'</div>';
    }
    /**
     * 限时优惠拼接
     * @param promotion
     * @returns {string}
     */
    function preNotLongTermEffectivePromotionHtml(promotion) {
        var target = promotion.targetType ? "_blank" : "";
        var html = '<div class="section is-new delNew loaded" style="display: block;">'
            + '                            <div class="promo-image">'
            + '                                <a href="' + promotion.defaultAction + '" target="' + target + '">'
            + '                                    <img src="' + promotion.maxImageHttpUrl + '">'
            + '                                </a>'
            + '                            </div>'
            + '                            <div class="promo-details">'
            + '                                <h2 class="section-title">' + promotion.title + '</h2>'
            + '                                <p class="section-description">' + promotion.promotionDescription + '</p>'
            + '                                <div class="countdown" data-begin-time="' + promotion.beginTime + '" data-end-time="' + promotion.endTime + '">'
            /*+ '                                   <i></i>亚游邀您现场观战！<span>02 <e>天</e> 02：20：59</span>'*/
            + '                                </div>'
            + '                                <div class="link-container">'
            var detailsAction = '';
            if(promotion.detailAction){//是否有可以立即领取的按钮
                detailsAction = '<a class="link orange" href="' + promotion.detailAction + '" target="' + promotion.target + '">立即领取</a>'
            }
            html += detailsAction;
            html +='       <a class="link grey" href="' + promotion.defaultAction + '" target="' + promotion.target + '">查看详情</a>'
            +'     </div>'
            +'    </div>'
            + '	</div>';
        return html;
    }

    //长期有效活动拼接
    function infinitepromotionHtml(promotion) {
        var target = promotion.targetType ? "_blank" : "";
        var overtime = '';
        var html = '<div class="section is-new delNew loaded"  style="display:block">'
            +'     <div class="promo-image">'
            +'	      <a href="' + promotion.defaultAction + '" target="' + target + '">'
            +'	          <img src="' + promotion.maxImageHttpUrl + '">'
            +'	      </a>'
            +'	   </div>'
            +'	   <div class="promo-details">'
            +'	        <h2 class="section-title">' + promotion.title + '</h2>'
            +'	        <p class="section-description">' + promotion.promotionDescription + '</p>';
            html += '<div class="countdown" data-begin-time="' + promotion.beginTime + '" data-end-time="' + promotion.endTime + '">'+ overtime +'</div>'
            html +='    <div class="link-container">'
            var detailsAction = '';
            if(promotion.detailAction){//是否有可以立即领取的按钮
                detailsAction = '<a class="link orange" href="' + promotion.detailAction + '" target="' + promotion.target + '">立即领取</a>'
            }
            html += detailsAction;
            html +='       <a class="link grey" href="' + promotion.defaultAction + '" target="' + promotion.target + '">查看详情</a>'
            +'          </div>'
            +'    </div>'
            + '	</div>';
        return html;
    }

    //倒计时开始
    setInterval(timer, 1000);
    function timer(){
        $(".countdown").each(function(){
            var thisTimes = $(this).attr("data-end-time");
            var stratTimes = new Date($(this).attr("data-begin-time").replace(/-/g,'/')).getTime();
            if((thisTimes == "" || thisTimes == undefined) && stratTimes < nowTimes){   //当活动时间已开始并且没有结束时间
                $(this).html("<i></i>本活动长期有效<span></span>");
            }else if(stratTimes < nowTimes){  //当活动时间已开始并且有结束时间
                var countdownEndTimes = new Date(thisTimes.replace(/-/g,'/')).getTime();
                nowTimes = nowTimes + 1000;
                var proTimes = countdownEndTimes - nowTimes;
                var days    = proTimes / 1000 / 60 / 60 / 24;
                var daysRound = Math.floor(days) < 10 ? '0' + Math.floor(days) : Math.floor(days);
                var hours = proTimes / 1000 / 60 / 60 - (24 * daysRound);
                var hoursRound = Math.floor(hours) < 10 ? '0' + Math.floor(hours) : Math.floor(hours);
                var minutes = proTimes / 1000 / 60 - (24 * 60 * daysRound) - (60 * hoursRound);
                var minutesRound = Math.floor(minutes) < 10 ? '0' + Math.floor(minutes) : Math.floor(minutes);
                var seconds = proTimes / 1000 - (24 * 60 * 60 * daysRound) - (60 * 60 * hoursRound) - (60 * minutesRound);
                var secondsRound = Math.floor(seconds) < 10 ? '0' + Math.floor(seconds) : Math.floor(seconds);
                var time = daysRound +':'+ hoursRound + ':' + minutesRound + ':' + seconds;
                var timeTo = '<i></i>活动结束时间：<span>'+ daysRound +'<e>天</e>'+ hoursRound +'<e>时</e>'+ minutesRound +'<e>分</e>'+ secondsRound +'<e>秒</e></span>'
                $(this).html(timeTo);
            }else{  //当活动时间未开始
                nowTimes = nowTimes + 1000;
                var proTimes = stratTimes - nowTimes;
                var days    = proTimes / 1000 / 60 / 60 / 24;
                var daysRound = Math.floor(days) < 10 ? '0' + Math.floor(days) : Math.floor(days);
                var hours = proTimes / 1000 / 60 / 60 - (24 * daysRound);
                var hoursRound = Math.floor(hours) < 10 ? '0' + Math.floor(hours) : Math.floor(hours);
                var minutes = proTimes / 1000 / 60 - (24 * 60 * daysRound) - (60 * hoursRound);
                var minutesRound = Math.floor(minutes) < 10 ? '0' + Math.floor(minutes) : Math.floor(minutes);
                var seconds = proTimes / 1000 - (24 * 60 * 60 * daysRound) - (60 * 60 * hoursRound) - (60 * minutesRound);
                var secondsRound = Math.floor(seconds) < 10 ? '0' + Math.floor(seconds) : Math.floor(seconds);
                var time = daysRound +':'+ hoursRound + ':' + minutesRound + ':' + seconds;
                var timeTo = '<i></i>活动开始时间：<span>'+ daysRound +'<e>天</e>'+ hoursRound +'<e>时</e>'+ minutesRound +'<e>分</e>'+ secondsRound +'<e>秒</e></span>'
                $(this).html(timeTo);
            }
        });
    }
});

