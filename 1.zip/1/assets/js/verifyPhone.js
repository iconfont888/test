/***
 *
 * 验证手机号码以及发送验证码
 *
 * <p>User: Ives
 * <p>Date: 2017/11/2
 * <p>Time: 16:09
 *
 * options: form 必须包含表单元素
 * urls: 请求路径
 *
 */
var VerifyHandler = function (options, urls) {
    var _object = this, _form = options.form, _validator;
    var actions = {
        //手机初始化信息
        init: {
            url: "/api/phone/bound/init",
            type: "GET"
        },
        send: {
            general: {
                url: "/api/sms",
                type: "POST"
            },
            voice: {
                url: "/api/voice",
                type: "POST"
            }
        },
        verify: {
            general: {
                url: "/api/phone/bound",
                type: "PUT"
            },
            voice: {
                url: "/api/voice/verify",
                type: "POST"
            },
            notChangeBindStatus: {
                url: "/api/sms/verify",
                type: "POST",
                data:{type: "bank"}
            },
            mission: {
                url: "/api/mission/voice",
                type: "POST"
            }
        },
        //短信订阅查询手机是否绑定
        verified: {
            url: "/api/sms/subscribe",
            type: "GET"
        },
        right: {
            url: "/api/phone/right",
            type: "GET"
        }
    };
    _object.settings = {
        //  倒计时秒数
        time: 290,
        //是否延迟倒计时
        isDelayCountdown: false,
        //  返回验证成功后返回地址
        url: "",
        //  是否只初始化; 默认完成完整初始化
        isOnlyInit: false,
        //  初始化是否触发发送事件; 默认触发
        isInitSend: true,
        //  短信验证码/语音验证码
        isSendVoice: false,
        //  特例任务中心验证号码
        isMissionVerify: false,
        //  是否改变验证状态
        isGeneralVerify: true,
        //  语音验证码状态
        isVoiceVerify:false,
        //  银行资料页面特殊处理
        isBankType: false,
        //  添加显示 loading 元素
        loadingElement: null,
        //  回调函数
        callback: null,
        form: null,
        showPhone: null,
        newPhone: null,
        phone: null,
        smsType:null,
        error: null,
        resend: null,
        captcha: null,
        parameters: null,
        submit: null,
        validate: {
            onkeyup: null,
            rules: {
                captcha: {
                    required: true,
                    rangelength: [6, 6],
                    digits: /^\d{6}$/
                }
            },
            messages: {
                captcha: {
                    required: "请输入验证码",
                    rangelength: "短信验证码为6位数字!",
                    digits: "短信验证码为6位数字!"
                }
            },
            errorClass: "error failure",
            submitHandler: function () {
                var option = {};
                if (_object.settings.parameters) {
                    $.each(_object.settings.parameters, function (name, item) {
                        if (_object.isJQuery(item)) {
                            option[name] = item.val();
                        } else {
                            option[name] = item;
                        }
                    });
                } else {
                    var newPhone = _object.settings.newPhone.val();
                    var original = _object.settings.originalPhone.val();
                    var smsType = _object.settings.smsType.val();
                    option = {
                        code: _object.settings.captcha.val(),
                        newPhone: newPhone ? newPhone : "",
                        phone: original ? original : "",
                        type: smsType ? smsType : ""
                    };
                }
                _object.submit(option);
            }
        }
    };
    if (actions && typeof actions === "object") {
        $.extend(true, actions, urls);
    }
    if (options && typeof options === "object") {
        $.extend(true, _object.settings, options);
    }
    if (_form && _form.length) {
        _validator = _form.validate(_object.settings.validate);
        if (!_object.settings.form) {
            _object.settings.form = _form;
        }
        if (!_object.settings.loadingElement) {
            _object.settings.loadingElement = _form;
        }
        if (!_object.settings.showPhone) {
            _object.settings.showPhone = _form.find(".js-show-phone").length > 0? _form.find(".js-show-phone"): _form.find(".js-phone");
        }
        if (!_object.settings.newPhone) {
            _object.settings.newPhone = _form.find(".js-new-phone").length > 0? _form.find(".js-new-phone"): _form.find("#newPhone");
        }
        if (!_object.settings.originalPhone) {
            _object.settings.originalPhone = _form.find(".js-original-phone").length > 0? _form.find(".js-original-phone"): _form.find("#oldPhone");
        }
        if (!_object.settings.smsType) {
            _object.settings.smsType = _form.find(".js-sms-type").length > 0? _form.find(".js-sms-type"): _form.find("#smsType");
        }
        if (!_object.settings.error) {
            _object.settings.error = _form.find(".js-verify-msg").length > 0? _form.find(".js-verify-msg"): _form.find(".error-msg");
        }
        if (!_object.settings.resend) {
            _object.settings.resend = _form.find(".js-verify-resend").length > 0 ? _form.find(".js-verify-resend") : _form.find(".btn-resend");
        }
        if (!_object.settings.captcha) {
            _object.settings.captcha = _form.find(".js-verify-captcha").length > 0 ? _form.find(".js-verify-captcha"): _form.find("#captcha");
        }
        if (!_object.settings.submit) {
            _object.settings.submit = _form.find(".js-verify-submit").length > 0 ? _form.find(".js-verify-submit"): _form.find(".btn-submit");
        }
    }
    //  验证: 改变手机验证状态
    var verifyGeneral = function (options) {
        //获取电话号码
        var phone = ""
        $.request({
            url: "/api/customer/info",
            async:false
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                phone = data.phone;
            }else{
                logConsole(response.message);
            }
        }).fail(function(e){
            logConsole(e);
        });
        if (phone){
            //绑定手机号码，改变验证状态
            return $.request({
                type: actions.verify.general.type,
                url: actions.verify.general.url+"/"+phone,
                data: {"captcha": options.code}
            });
        } else {
            return false;
        }

    };

    //  验证: 改变手机验证状态
    var verifyVoice = function (options) {
        options.type = "1";//1标识BQ支付语音验证
        return $.request({
            type: actions.verify.voice.type,
            url: actions.verify.voice.url,
            data: options
        });
    };
    //  验证: 不改变手机验证状态, 仅校验手机号码与验证码
    var verifyEvery = function (options) {
        return $.request({
            type: actions.verify.notChangeBindStatus.type,
            url: actions.verify.notChangeBindStatus.url,
            data: options
        });
    };
    //  验证: 任务中心, 验证手机号码, 调用接口
    var verifyMission = function (options) {
        return $.request({
            type: actions.verify.mission.type,
            url: actions.verify.mission.url,
            data: {
                "actId": options.actId,
                "captcha": options.captcha,
                "type": "GENERAL"
            }
        });
    };
    //  验证
    this.verify = function () {
        //验证语音验证码
        if (_object.settings.isVoiceVerify) {
            return verifyVoice;
        }
        //我的任务手机号码验证
        if (_object.settings.isMissionVerify) {
            return verifyMission;
        }
        //绑定手机号码
        if (_object.settings.isGeneralVerify) {
            return verifyGeneral;
        } else {
            //验证短信验证，不改变验证状态
            return verifyEvery;
        }
    };
    this.sendXHR = function (phone) {
        phone = phone ? phone : "";
        //获取发送验证的类型
        var type =_object.settings.resend.attr("verify-type");
        if (_object.settings.isSendVoice) {
            return $.request({
                type: actions.send.voice.type,
                url: actions.send.voice.url
            });
        } else {
            return $.request({
                type: actions.send.general.type,
                url: actions.send.general.url,
                data: {"phone": phone,"type":type ? type:""}
            });
        }
    };
    //  初始化获取电话号码, 以及绑定事件
    this.init = function () {
        _object.settings.loadingElement.loading({multiple: true});
        if (!_object.settings.isOnlyInit) {
            _object.bind();
        }
        return $.request({
            type: actions.init.type,
            url: actions.init.url
        }).done(function (response) {
            if (response.successful) {
                _object.settings.showPhone.text(response.data.phone);
            } else {
                layer.open({
                    title: ' ',
                    content: response.data,
                    btn: ['确认']
                });
            }
        }).fail(function () {
            layer.open({
                title: ' ',
                content: '服务器遇到错误,请联系客服或稍后再试!',
                btn: ['确认']
            });
        }).always(function () {
            _object.settings.loadingElement.loading(false);
        });
    };
    //  倒计时
    this.countdown = function (time) {
        _object.settings.resend.agcountdown({
            stepTime: time,
            before: function () {
                _object.settings.resend.addClass("timer");
            },
            after: function () {
                _object.settings.resend.removeClass("timer");
                _object.settings.resend.on('click', _object.sendSMS);
            },
            buttonText: "重新发送({})s",
            defaultMsg: "重新发送",
            start: true
        });
    };
    function getMessage(code, data) {
        if (code === undefined || code === null) {
            return data;
        }
        var messageObject = _object.settings.messageObject;
        if (!messageObject) {
            return data;
        }
        if (messageObject["" + code]) {
            return messageObject["" + code];
        }
        return data;
    }

    function insertMessage(code, data) {
        if (code === undefined || code === null) {
            _object.settings.error.removeClass("success").addClass("error failure").text(data);
        }
        var messageObject = _object.settings.messageObject;
        if (!messageObject) {
            _object.settings.error.removeClass("success").addClass("error failure").text(data);
        } else {
            if (messageObject["" + code]) {
                _form.find(".js-phone-msg").removeClass("success").addClass("error failure").text(getMessage(code, data));
            } else {
                _object.settings.error.removeClass("success").addClass("error failure").text(data);
            }
        }
    }

    //  发送验证码
    this.sendSMS = function () {
        var _value = _object.settings.originalPhone.val(),
            _phoneMsg = _object.settings.form.find(".js-phone-msg"),
            _captchaMsg = _object.settings.form.find(".js-captcha-msg");
        if (_object.settings.originalPhone.length > 0) {
            if (!_validator.element(_object.settings.originalPhone)) {
                _object.settings.resend.on('click', _object.sendSMS);
                return;
            }
            if (_value === "" && !constants.phoneRegular.test(_value)) {
                _phoneMsg.removeClass("success").addClass("error failure").text("手机号码输入不完整");
                _object.settings.resend.on('click', _object.sendSMS);
                return;
            }
        }
        //新增银行卡检查手机号码是否校验过2019-1-1 begin
        if(_object.settings.isBankType&& _phoneMsg&&_phoneMsg.text()){
            return;
        }
        //end

        _object.settings.loadingElement.loading({multiple: true});
        if (_object.settings.resend.hasClass("processing-js")) {
            return;
        }
        _object.settings.resend.addClass("processing-js");
        _object.sendXHR(_value).done(function (response) {
            var data = response.data, time = _object.settings.time;
            if(!_VALID.isNormal(data)){
                data = response.message;
            }
            if (response.successful) {
                _object.settings.error.removeClass("failure").addClass("error success").text(data);
                if (_object.settings.isDelayCountdown) {
                    _object.settings.resend.agcountdown({
                        stepTime: 10,
                        before: function () {
                            _object.settings.resend.addClass("bg-success");
                        },
                        after: function () {
                            _object.settings.resend.removeClass("bg-success");
                            _object.countdown(time - 10);
                        },
                        buttonText: "已发送√",
                        defaultMsg: "重新发送",
                        start: true
                    });
                } else {
                    _object.countdown(time);
                }
            } else if (response.code === 5001 || response.code === 6008) {
                time = response.message.replace(/[^\d]*/g, "");
                _object.countdown(time);
            } else {
                _object.settings.resend.on('click', _object.sendSMS);
                if (data.indexOf("手机号码") > -1 && _phoneMsg && _phoneMsg.length) {
                    _phoneMsg.removeClass("success").addClass("error failure").text(getMessage(response.code, data));
                } else if (data.indexOf("验证码") > -1 && _captchaMsg && _captchaMsg.length) {
                    _captchaMsg.removeClass("success").addClass("error failure").text(data);
                } else {
                    _object.settings.error.removeClass("success").addClass("error failure").text(data);
                }
            }
        }).fail(function () {
            _object.settings.resend.on('click', _object.sendSMS);
            layer.open({
                title: ' ',
                content: '服务器遇到错误,请联系客服或稍后再试!',
                btn: ['确认']
            });
        }).always(function () {
            _object.settings.resend.removeClass("processing-js");
            _object.settings.loadingElement.loading(false);
        });
    };

    //  提交验证
    this.submit = function (options) {
        if(options.type==='bound-sub'){
            options.type="bound";
            _object.settings.url=location.pathname;
        }
        _object.settings.loadingElement.loading({multiple: true});
        if (_object.settings.submit.hasClass("processing-js")) {
            return;
        }
        _object.settings.submit.addClass("processing-js");
        _object.verify()(options).done(function (response) {
            if (response.successful) {
                _object.settings.error.removeClass("failure").addClass("error success").text(response.data);
                if (_object.settings.url && typeof _object.settings.url === "string") {

                    window.location.href = _object.settings.url;
                }
            // } else if (response.code >= 6000 && response.code < 7000) {
            //     layer.open({
            //         title: ' ',
            //         content: response.data,
            //         btn: ['确认'],
            //         yes: function () {
            //             if (_object.settings.url && typeof _object.settings.url === "string") {
            //                 window.location.href = _object.settings.url;
            //             } else {
            //                 window.location.href = "/";
            //             }
            //         }
            //     });
            // } else if (response.code >= 7000 && response.code < 8000) {
            //     layer.open({
            //         title: ' ',
            //         content: response.data,
            //         btn: ['确认']
            //     });
            } else {
                insertMessage(response.code, response.message);
            }
        }).done(function (response) {
            if (response.successful) {
                _object.settings.callback();
            }
        }).fail(function () {
            layer.open({
                title: ' ',
                content: '服务器遇到错误,请联系客服或稍后再试!',
                btn: ['确认']
            });
        }).always(function () {
            _object.settings.loadingElement.loading(false);
            _object.settings.submit.removeClass("processing-js");
        });
    };

    //  绑定事件
    this.bind = function () {
        if (_object.settings.isInitSend) {
            _object.settings.resend.on("click", _object.sendSMS).trigger("click");
        } else {
            _object.settings.resend.on("click", _object.sendSMS);
        }
        if (_object.settings.submit[0].tagName === "A") {
            _object.settings.submit.off("click");
            _object.settings.submit.on("click", function () {
                if (_object.settings.originalPhone.length > 0 && _object.settings.isBankType) {
                    var _value = _object.settings.originalPhone.val();
                    if (_value === "" && !constants.phoneRegular.test(_value)) {
                        _object.settings.form.find(".js-phone-msg")
                            .removeClass("success")
                            .addClass("error failure").text("手机号码输入不完整");
                        _object.settings.resend.on("click", _object.sendSMS);
                        return;
                    }
                }
                _object.settings.form.submit();
            });
        }
    };

    //  短信订阅是否已验证
    this.verified = function (verified, unverified, failure) {
        _object.settings.loadingElement.loading({multiple: true});
        $.request({
            type: actions.verified.type,
            url: actions.verified.url
        }).done(function (response) {
            if (response.successful) {
                if (response.data.checkBound) {
                    if (verified && typeof verified === "function") {
                        verified(response);
                    }
                } else {
                    if (unverified && typeof unverified === "function") {
                        unverified(response);
                    }
                }
            } else {
                /* 请求返回失败时, 默认为未验证状态 */
                if (unverified && typeof unverified === "function") {
                    unverified(response);
                }
            }
        }).fail(function () {
            if (failure && typeof failure === "function") {
                failure(response);
            }
        }).always(function () {
            _object.settings.loadingElement.loading(false);
        });
    };
    /**
     * 验证电话号码是否正确
     *
     * object =
     * {
     *       isShowLoaded: boolean 否显示loading效果
     *       phone: val,       电话号码
     *       correct: func,   正确回调函数
     *       incorrect: func, 不正确回调函数
     *       failure: func    请求失败回调函数
     *   }
     *  phone: 默认值
     *  @see VerifyHandler #settins #originalPhone
     *  @param _o object
     */
    this.right = function (_o) {
        if (_o.isShowLoaded) {
            _object.settings.loadingElement.loading({multiple: true});
        }
        var phone = (_o.phone || _object.settings.originalPhone.val());
        $.request({
            type: actions.right.type,
            url: actions.right.url,
            data: {phone: phone}
        }).done(function (response) {
            if (response.successful) {
                if (_o.correct && typeof _o.correct === "function") {
                    _o.correct();
                }
            } else {
                if (_o.incorrect && typeof _o.incorrect === "function") {
                    _o.incorrect(response.message);
                }
            }
        }).fail(function () {
            if (_o.failure && typeof _o.failure === "function") {
                _o.failure();
            }
        }).always(function () {
            if (_o.isShowLoaded) {
                _object.settings.loadingElement.loading(false);
            }
        });
    };
    this.isJQuery = function (o) {
        return !!(o && o.length && (typeof jQuery === "function" || typeof jQuery === "object") && o instanceof jQuery);
    };
};




