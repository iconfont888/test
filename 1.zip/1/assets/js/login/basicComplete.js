/**
 * Created by Barden on 2017/6/23.
 */
$(document).ready(function () {
    // Get Started
    $.cookie(constants.recommendcode, "", {path: '/'});
    var _key = "_NEW_PERSON_VERSION_KEY_";
    localStorage.setItem('register_key', _key);
});

$(document).ready(function () {

    $("#copy").on('click', function () {
        var name = $("#copyname").val();
        window.utils.copy(name);
        $('html,body').scrollTop(0);
        $(this).text('复制成功');

    });
});
     
