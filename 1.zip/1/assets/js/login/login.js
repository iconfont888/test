/***
 *
 * 新版登录
 *
 */
var request = new RequestHelp();
$(function () {
    //  登录成功后, 回调地址
    var redirect = $("form input[name='redirect']").val() || location.pathname + location.search;

    // $("#quick-login-btn").on("click", function () {
    //     $("form input[name='redirect']").val(location.pathname);
    // });

    var $loginModal = $("#loginModal");
    var $signInWrap = $(".sign-in-wrap"), $quickLogin = $("#quick-login"), $phoneLogin = $("#phone-login"),
        $forgetPasswordForm = $(".forget-password-wrap form"),
        $passwordLoginForm = $quickLogin.find("form"),
        $phoneLoginForm = $phoneLogin.find("form");

    $loginModal.find(".nav-tabs a[href='#quick-login']").on("click", function () {
        if(!$(this).parent().hasClass("active")){
            utils.getImageCode("/api/captcha?site=10&type=login&_d=" + (1 - new Date()),$passwordLoginForm.find(".verification-group-js img"));
        }
    });

    $passwordLoginForm.add($phoneLoginForm).find("input").on("input", function () {
        var $this = $(this), value = $this.val(), name = $this.attr("name");
        setTimeout(function () {
            if (name === "loginName") {
                value = $.trim(value.toLowerCase());
                if (value.length > 20) {
                    $this.val(value.substr(0, 20));
                } else {
                    $this.val(value);
                }
            }
            if (name === "password") {
                $this.val(value.substr(0, 10));
            }
        }, 0);
    });

    //  密码登录
    new ValidatorFrom($passwordLoginForm, {
        validationFunction: {
            "loginName": function ($this) {
                var value = $this.val().toLowerCase();
                if (!value) {
                    return {successful: false, message: "手机号码/游戏账号不能为空"};
                }
                if (constants.INTERNET_PHONE_REGEX.test(value)) {
                    return {successful: false, message: "无效号码，属于网络运营商"};
                }
                if (!constants.loginNameRegular.test(value)) {
                    return {successful: false, message: "请输入正确手机号码或游戏账号"};
                }
                return {successful: true};
            },
            "pwd": function ($this) {
                var value = $this.val();
                if (!value) {
                    return {successful: false, message: "游戏密码不能为空"};
                }
                if (!value || value.length < 8) {
                    return {successful: false, message: "请输入8~12位的密码"};
                }
                if (value.length > 13) {
                    return {successful: false, message: "密码最多输入12位"};
                }
                if (!constants.loginPwdRegular.test(value)) {
                    return {successful: false, message: "密码格式错误"};
                }
                return {successful: true};
            },
            "captcha": function ($this) {
                var isDisabled = $this.attr("disabled"), value = $this.val();
                if (_VALID.isNormal(isDisabled)) {
                    return {successful: true};
                }
                if (!value) {
                    return {successful: false, message: "验证码不能为空"};
                }
                if (!constants.generalCaptchaReguler.test(value)) {
                    return {successful: false, message: "验证码不正确"};
                }
                return {successful: true};
            }
        },
        validationCallBack: showError,
        submit: function () {
            var $submit = $passwordLoginForm.find(".btn-submit");
            if ($submit.hasClass("progressing-js")) {
                return;
            }
            $submit.addClass("progressing-js");
            $signInWrap.loading({logo: false});
            var loginName = $passwordLoginForm.find("input[name='loginName']").val();
            var password = $passwordLoginForm.find("input[name='pwd']").val();
            var captcha = $passwordLoginForm.find("input[name='captcha']").val();
            var formData = {"loginName":loginName,"password":password,"verification":captcha,"isToken":true};
            $.request({
                type: "POST",
                url: "/api/login",
                encrypt: true,
                data: formData,
                async:false
            }).done(function (response) {
                if (response.successful) {
                    var res = response.data;
                    var _user = {
                        userId: res.userId,
                        userName: res.loginName,
                        userType: res.userType,
                        userLevel: res.userLevel,
                        AG_AUTH_TOKEN: res.accessToken,
                        recommendCode: res.recommendCode
                    };
                    //  保存用户信息
                    AG_INIT.setUser(_user);
                    //泡吧跳转
                    if(utils.getQueryString("min")=="true"){
                        window.parent.postMessage({token:res.accessToken},'*');
                    }
                    var egame_url = utils.sessionStorage.getItem("gameUrl");
                    if(egame_url){
                        window.open(egame_url,"_blank");
                        utils.sessionStorage.removeItem("gameUrl");
                        $passwordLoginForm.find("input[name='redirect']").val("");
                        window.location.reload();
                        return;
                    }
                    //  跳转到首页
                    if (res.data) {
                        var url = res.data.split("?");
                        gameUrl=utils.sessionStorage.getItem("redirect_gameUrl");
                        if(gameUrl){
                            window.open(url[0] + gameUrl + "?" + url[1],"_blank");
                            utils.sessionStorage.removeItem("redirect_gameUrl");
                            window.location.href = url[0] + redirect + "?" + url[1];
                        }else{
                            if (redirect) {
                                window.location.href = url[0] + redirect + "?" + url[1];
                            } else {
                                window.location.href = res.data;
                            }
                        }

                    } else {
                        //改变url地址，不刷新页面
                        if (redirect) {
                            gameUrl=utils.sessionStorage.getItem("redirect_gameUrl");
                            if(gameUrl){
                                window.open(gameUrl,"_blank");
                                utils.sessionStorage.removeItem("redirect_gameUrl");
                                window.location.reload();
                            }else{
                                window.location.href = redirect;
                            }
                        } else {
                            window.location.reload();
                        }
                    }
                } else {
                    var $captcha = $passwordLoginForm.find("input[name='captcha']");
                    var $password = $passwordLoginForm.find("input[name='pwd']");
                    switch (response.code || '') {
                        case 9611:
                            $passwordLoginForm.find(".verification-group-js").show();
                            break;
                        case 9699:
                            var $loginName = $passwordLoginForm.find("input[name='loginName']");
                            if ($loginName.filter(":visible").length) {
                                showError(response, "", $loginName);
                            } else {
                                showError(response, "", $password);
                            }
                            break;
                        case 6201:
                        case 6200:
                            showError(response, "", $captcha);
                            break;
                        default:
                            showError(response, "", $password);
                            break;
                    }
                    $passwordLoginForm.find(".verification-group-js img").trigger("click");
                }
            }).always(function () {
                $submit.removeClass("progressing-js");
                $signInWrap.loading(false);
            });
        }
    });
    $passwordLoginForm.find(".btn-submit").on("click", function () {
        $passwordLoginForm.submit();
    });
    $passwordLoginForm.on("keydown", function (e) {
        if (e.keyCode === 13) {
            $(this).submit()
        }
    });
    $passwordLoginForm.find("[name='captcha']").on("keyup blur", function (e) {
        var val = $(this).val();
        val = val.replace(/[^0-9]/ig,"");
        $(this).val(val);
    });
    $passwordLoginForm.find("input[name='pwd']").on("propertychange input", function (event) {
        var $this = $(this);
        var pwd = $this.val();
        if (pwd.length > 12) {
            $this.val($this.val().substr(0, 12));
            var $wrapper = $this.parents('.form-group');
            $wrapper.find("p").remove();
            $("<p class='error help-block has-error'></p>").html('密码最多输入12位').appendTo($wrapper);
        }
    });

    //  短信登录
    var phoneLoginValidator = new ValidatorFrom($phoneLoginForm, {
        validationFunction: {
            "loginName": function ($this) {
                var value = $.trim($this.val().toLowerCase());
                if (!value) {
                    return {successful: false, message: "手机号码/游戏账号不能为空"};
                }
                if (constants.INTERNET_PHONE_REGEX.test(value)) {
                    return {successful: false, message: "无效号码，属于网络运营商"};
                }
                if (!constants.loginNameRegular.test(value)) {
                    return {successful: false, message: "请输入正确手机号码或游戏账号"};
                }
                return {successful: true};
            },
            "captcha": function ($this) {
                var value = $this.val();
                if (!value) {
                    return {successful: false, message: "动态密码不能为空"};
                }
                if (!constants.smsAndVoiceCaptchaReguler.test(value)) {
                    return {successful: false, message: "动态码格式错误"};
                }
                return {successful: true};
            }
        },
        validationCallBack: showError,
        submit: function () {
            var $submit = $phoneLoginForm.find(".btn-submit");
            if ($submit.hasClass("progressing-js")) {
                return;
            }
            $submit.addClass("progressing-js");
            $signInWrap.loading({logo: false});
            var loginName = $phoneLoginForm.find("input[name='loginName']").val();
            var captcha = $phoneLoginForm.find("input[name='captcha']").val();
            var formData = {"loginName":loginName,"code":captcha,"isToken":true};

            $.request({
                type: "POST",
                url: "/api/sms-login",
                encrypt: true,
                data: formData
            }).done(function (response) {
                if (response.successful) {
                    var res = response.data;
                    var _user = {
                        userId: res.userId,
                        userName: res.loginName,
                        userType: res.userType,
                        userLevel: res.userLevel,
                        AG_AUTH_TOKEN: res.accessToken,
                        recommendCode: res.recommendCode
                    };
                    //  保存用户信息
                    AG_INIT.setUser(_user);
                    //  跳转到首页
                    if (res.data) {
                        var url = res.data.split("?");
                        gameUrl=utils.sessionStorage.getItem("redirect_gameUrl");
                        if(gameUrl){
                            window.open(url[0] + gameUrl + "?" + url[1],"_blank");
                            utils.sessionStorage.removeItem("redirect_gameUrl");
                            window.location.href = url[0] + redirect + "?" + url[1];
                        }else{
                            if (redirect) {
                                var url = res.data.split("?");
                                window.location.href = url[0] + redirect + "?" + url[1];
                            } else {
                                window.location.href = res.data;
                            }
                        }

                    } else {
                        //改变url地址，不刷新页面
                        if (redirect) {
                            gameUrl=utils.sessionStorage.getItem("redirect_gameUrl");
                            if(gameUrl){
                                window.open(gameUrl,"_blank");
                                utils.sessionStorage.removeItem("redirect_gameUrl");
                                window.location.reload();
                            }else{
                                window.location.href = redirect;
                            }
                        } else {
                            window.location.reload();
                        }
                    }
                } else {
                    switch (response.code) {
                        case 6016:
                        case 6017:
                        case 6018:
                        case 6019:
                        case 6200:
                        case 6201:
                            showError(response, "", $phoneLoginForm.find("input[name='captcha']"));
                            break;

                        default:
                            var $loginName = $phoneLoginForm.find("input[name='loginName']");
                            if ($loginName.filter(":visible").length) {
                                showError(response, "", $loginName);
                            } else {
                                showError(response, "", $phoneLoginForm.find("input[name='code']"));
                            }
                            break;
                    }
                }
            }).always(function () {
                $signInWrap.loading(false);
                $submit.removeClass("progressing-js");
            });
        }
    });
    $phoneLoginForm.on("keydown", function (e) {
        if (e.keyCode === 13) {
            $(this).submit();
        }
    });
    $phoneLoginForm.find("a.btn-submit").on("click", function () {
        $phoneLoginForm.submit();
    });
    $phoneLoginForm.find(".btn-resend").on("click", function () {
        var $button = $(this), $loginName = $phoneLoginForm.find("input[name='loginName']");
        var $captcha = $phoneLoginForm.find("input[name='captcha']");
        var loginName = $.trim($loginName.val()), interrupt = "interrupt";
        if ($button.hasClass("progressing-js") || $button.hasClass("interrupt")) {
            return;
        }
        $button.addClass("progressing-js");
        $signInWrap.loading({logo: false});
        phoneLoginValidator.validation("loginName").done(function (response) {
            if (!response || !response.successful) {
                return;
            }
            $.request({
                type: "POST",
                url: "/api/sms-login/send",
                encrypt: true,
                data: {"loginName": loginName}
            }).done(function (response) {
                if (response.successful) {
                    countdown($button, interrupt);
                } else {
                    switch (response.code) {
                        case 5002:
                        case 9631:
                        case 9632:
                        case 9635:
                            if ($loginName.filter(":visible").length) {
                                showError(response, "", $loginName);
                            } else {
                                showError(response, "", $captcha);
                            }
                            break;
                        case 9639:
                            countdown($button, interrupt, response.message.replace(/[^\d]/g, ""));
                            break;
                        default:
                            showError(response, "", $captcha);
                            break;

                    }
                }
            });
        }).always(function () {
            $signInWrap.loading(false);
            $button.removeClass("progressing-js");
        });
    });

    //  找回密码
    //  第一步: 短信验证手机号码
    var $forgetWrap = $(".forget-password-wrap");
    var $forgetWrap2 = $(".forget-password-wrap2");
    var $forgetUpdateForm = $forgetWrap2.find("form");
    var forgetPasswordValidator = new ValidatorFrom($forgetPasswordForm, {
        validationFunction: {
            "loginName": function ($this) {
                var value = $.trim($this.val().toLowerCase());
                if (!value) {
                    return {successful: false, message: "手机号码不能为空"};
                }
                if (!/^\d{11}$/.test(value)) {
                    return {successful: false, message: "手机号码格式不正确"};
                }
                if (constants.INTERNET_PHONE_REGEX.test(value)) {
                    return {successful: false, message: "无效号码，属于网络运营商"};
                }
	            if (!constants.phoneRegular.test(value)) {
                    return {successful: false, message: "无效手机号码，请确认"};
                }
                return {successful: true};
            },
            "captcha": function ($this) {
                var value = $this.val();
                if (!value) {
                    return {successful: false, message: "动态密码不能为空"};
                }
                if (!constants.smsAndVoiceCaptchaReguler.test(value)) {
                    return {successful: false, message: "动态码格式错误"};
                }
                return {successful: true}
            }
        },
        validationCallBack: showError,
        submit: function () {
            var $submit = $forgetPasswordForm.find(".btn-submit");
            if ($submit.hasClass("progressing-js")) {
                return;
            }
            $submit.addClass("progressing-js");
            $forgetWrap.loading({logo: false});
            var $loginName = $forgetPasswordForm.find("input[name='loginName']"),
                $captcha = $forgetPasswordForm.find("input[name='captcha']");
            var loginName = $loginName.val();
            var formData = $forgetPasswordForm.serialize()
                .replace("loginName=" + loginName, "loginName=" + loginName);
            $.request({
                type: "POST",
                url: "/api/sms/verify",
                encrypt: true,
                data: {
                    "code": $captcha.val(),
                    "phone": loginName,
                    "type": "forgot"
                }
            }).done(function (response) {
                if (response.successful) {
                    $forgetPasswordForm.parents('.modal-content').hide();
                    $forgetPasswordForm.parents('.modal-content').next().removeClass("hidden").fadeIn('fast');
                } else {
                    switch (response.code) {
                        case -200:
                        case -201:
                        case -202:
                        case -300:
                            showError(response, "", $captcha);
                            break;
                        case -203:
                            showError(response, "", $captcha);
                            break;
                        default:
                            showError(response, "", $captcha)
                    }
                }
            }).always(function () {
                $forgetWrap.loading(false);
                $submit.removeClass("progressing-js");
            });
        }
    });
    $forgetWrap.find(".btn-resend").on("click", function () {
        var $button = $(this),
            $loginName = $forgetPasswordForm.find("input[name='loginName']"),
            $captcha = $forgetPasswordForm.find("input[name='captcha']");
        var loginName = $.trim($loginName.val()), interrupt = "interrupt";
        if ($button.hasClass("progressing-js") || $button.hasClass(interrupt)) {
            return;
        }
        $button.addClass("progressing-js");
        $forgetWrap.loading({logo: false});
        forgetPasswordValidator.validation("loginName").done(function (response) {
            if (!response || !response.successful) {
                return;
            }
            $.request({
                type: 'POST',
                url: "/api/sms",
                encrypt: true,
                data: {"type": "forgot", "phone": loginName}
            }).done(function (response) {
                var code = response.code;
                if (response.successful) {
                    countdown($button, interrupt);
                } else {
                    if (response.message && code && code === -200) {
                        countdown($button, interrupt, response.message.replace(/[^\d]/g, ""));
                    } else {
                        switch (code) {
                            case -200:
                            case -201:
                                showError(response, "", $captcha);
                                break;
                            default:
                                showError(response, "", $loginName);
                                break;
                        }
                    }
                }
            });
        }).always(function () {
            $forgetWrap.loading(false);
            $button.removeClass("progressing-js");
        });

    });
    $forgetWrap.find(".btn-submit").on("click", function () {
        $forgetPasswordForm.submit();
    });
    //  第二步: 修改密码
    new ValidatorFrom($forgetUpdateForm, {
        validationFunction: {
            "pwd": function ($this) {
                var value = $this.val();
                if (!value) {
                    return {successful: false, message: "请输入您的密码"};
                }
                if (!constants.registerPwdRegular.test(value)) {
                    return {successful: false, message: "密码格式错误"};
                }
                return {successful: true};
            },
            "confirm": function ($this) {
                var value = $this.val();
                if (!value) {
                    return {successful: false, message: "请输入您的密码"};
                }
                if (!constants.registerPwdRegular.test(value)) {
                    return {successful: false, message: "密码格式错误"};
                }
                var pwd = $forgetUpdateForm.find("input[name='pwd']").val();
                if (value !== pwd) {
                    return {successful: false, message: "两次密码不一致"};
                }
                return {successful: true}
            }
        },
        validationCallBack: showError,
        submit: function () {
            var $submit = $forgetUpdateForm.find(".btn-submit");
            if ($submit.hasClass("progressing-js")) {
                return;
            }
            $submit.addClass("progressing-js");
            $forgetWrap2.loading({logo: false});
            var $pwd = $forgetUpdateForm.find("input[name='pwd']");
            var $confirm = $forgetUpdateForm.find("input[name='confirm']");
            var pwd = $pwd.val(), confirm = $confirm.val();
            var phone = $forgetPasswordForm.find("input[name='loginName']").val();
            var formData = $forgetUpdateForm.serialize()
                .replace("pwd=" + pwd, "pwd=" + pwd)
                .replace("confirm=" + confirm, "confirm=" + confirm);
            $.request({
                type: 'POST',
                url: "/api/password/forgot",
                encrypt: true,
                data: {"password": pwd, "phone": phone}
            }).done(function (response) {
                if (response.successful) {
                    $forgetUpdateForm.parents('.modal-content').hide();
                    $forgetUpdateForm.parents('.modal-content').next().removeClass("hidden").fadeIn('fast');
                } else {
                    switch (response.code) {
                        case -100:
                        case -101: {
                            $forgetUpdateForm.parents('.modal-content').hide();
                            $forgetUpdateForm.parents('.modal-content').prev().removeClass("hidden").fadeIn('fast');
                            break;
                        }
                        case -200:
                        case -300:
                            showError(response, "", $pwd);
                            break;
                        default:
                            showError(response, "", $confirm);
                            break;
                    }
                }
            }).always(function () {
                $forgetWrap2.loading(false);
                $submit.removeClass("progressing-js");
            });
        }
    });
    $forgetUpdateForm.find(".btn-submit").on("click", function () {
        $forgetUpdateForm.submit();
    });

    function showError(response, key, $node) {
        var $wrapper = $node.parents('.form-group');
        $wrapper.find("p").remove();
        if (!response.successful) {
            $("<p class='error help-block has-error'></p>").html(response.message).appendTo($wrapper);
        }
    }

    function countdown($node, flag, time) {
        $node.agcountdown({
            stepTime: time || 290,
            before: function () {
                $node.addClass(flag);
            },
            after: function () {
                $node.removeClass(flag);
            },
            buttonText: "重新发送({})s",
            defaultMsg: "发送动态码",
            start: true
        });
    }

});

