/***
 *
 * 我的任务
 *
 */
$(function () {
    var $main = $(".u-main");
    $main.loading({multiple: true});
    missionHelper.init().done(function () {
        var $umission = $(".u-mission"), $modalEnvelope = $('#modal-envelope');
        var apply = function ($current) {
            var $li = $current.parents("li");
            $.request({
                type: "POST",
                url: "/api/mission",
                data: {"actId": $li.data("id"), "type": 'GENERAL'}
            }).done(function (response) {
                if (response.successful) {
                    var data = response.data;
                    if (data.url) {
                        layer.open({
                            title: ' ',
                            btn: ['立即开刮'],
                            closeBtn: 0,
                            yes: function (index) {
                                var cardId = data.url.split("=")[1]
                                window.open("/game/play/scg/index.html?cardId=" + cardId);
                                layer.close(index);
                            },
                            content: "恭喜您获得一张刮刮卡!"
                        });
                    } else {
                        layer.open({
                            title: ' ',
                            yes: function (index) {
                                layer.close(index);
                            },
                            content: data.data || "领取成功!"
                        });
                    }
                } else {
                    failure(response.message);
                }
            }).fail(function (e) {
                logConsole(e);
            });
        };
        //  电话号码验证工具类初始化
        var $verifyPhoneForm = $("#verifyPhoneForm");
        var verifyHandler = new VerifyHandler({
            form: $verifyPhoneForm,
            showPhone: $(".js-show-phone"),
            isInitSend: false,
            isSendVoice: true,
            isMissionVerify: true,
            parameters: {
                actId: "",
                captcha: ""
            },
            callback: function () {
                var $btnSendCode = $verifyPhoneForm.find(".btn-resend");
                $btnSendCode.agcountdown({
                    after: function () {
                        $btnSendCode.one('click', verifyHandler.sendSMS());
                    },
                    defaultMsg: "获取语音验证码",
                    start: false,
                    reset: true
                });
            },
            validate: {
                errorElement: "span",
                errorClass: "empty_null",
                errorPlacement: function (error) {
                    $verifyPhoneForm.find(".error-msg")
                        .removeClass("success").addClass("error failure").html(error);
                },
                success: function (label) {
                    for (var i = 0; i < label.length; i++) {
                        $(label).parent().removeClass("error failure success").empty();
                    }
                }
            }
        });
        //  显示电话号码
        verifyHandler.init();
        $(document).on("click", ".u-premise-condition a", function () {
            if ($(this).hasClass("complete") || $(this).hasClass("undefined")) {
                return;
            }
            var $current = $(this);
            verifyHandler.settings.callback = function () {
                $modalEnvelope.modal("hide");
                $current.removeClass("undone").addClass("complete");
            };
            verifyHandler.settings.parameters = {
                actId: $(this).parents("li").data("id"),
                captcha: $verifyPhoneForm.find("#captcha")
            };
            $modalEnvelope.find(".modal-title").text("【" + $(this).data("name") + "】");
            $modalEnvelope.modal("show");
        });
        $(document).on("click", ".btn-receive-award", function () {
            apply($(this));
        });
        $umission.on("click", "a[href='#modal-rules']", function () {
            $("#modal-rules").find(".modal-body").html($(this).find(".rule-content").html());
        });
    }).always(function () {
        $main.loading(false);
    });
});
