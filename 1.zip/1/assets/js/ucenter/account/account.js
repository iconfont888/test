var LEVEL_AMOUNT = [0, 0, 100000, 500000, 1000000, 3000000, 6000000];
var VIDEO_LEVEL_RATE = [0, "0.60%", "0.60%", "0.60%", "0.70%", "0.80%", "0.90%"];
var SLOT_LEVEL_RATE = [0, "1.00%", "1.00%", "1.00%", "1.00%", "1.00%", "1.00%"];
var FISHING_LEVEL_RATE = [0, "1.00%", "1.00%", "1.00%", "1.00%", "1.00%", "1.00%"];
var SPORT_LEVEL_RATE = [0, "0.40%", "0.40%", "0.60%", "0.60%", "0.80%", "0.80%"];
var LOTTERY_LEVEL_RATE = [0, "1.00%", "1.00%", "1.00%", "1.00%", "1.00%", "1.00%"];
var LEVEL_BONUS = [0, 0, 120, 400, 600, 2000, 4000];
var STAR_LEVEL = ["零", "一", "二", "三"];
var PERCENTAGE_AMOUNT = [0, 1, 100, 1000, 10000, 30000, 50000, 80000, 100000, 300000, 500000, 800000, 1000000, 2000000, 3000000, 6000000, 10000000, 50000000, 100000000, 300000000, 500000000];
var PERCENTAGE_VALUE = [0, 2, 5, 10, 20, 30, 35, 45, 50, 55, 60, 70, 72, 76, 78, 80, 88, 90, 95, 98, 99];
var LEVEL_RATE = VIDEO_LEVEL_RATE;
var USER_LEVEL = ['新会员','一星级','二星级','三星级','VIP4','VIP5','VIP6','VIP7'];

$(document).ready(function() {
    //设置用户信息
    if(pn.userName){
        $("#account-user-name").html(pn.userName);
    }
    $("#account-user-level").addClass("level-"+pn.userLevel);
    $("#account-user-level").html(USER_LEVEL[pn.userLevel]);
    if(pn.beforeLoginDate){
        var beforeLoginDate= pn.beforeLoginDate;
        $("#account-before-login-date").append(beforeLoginDate)
    }else {
        $("#account-before-login-date").append("无记录");
    }
    if (pn.userLevel<6){
        var nextLevelHtml = "";
        if (pn.userLevel ==0){
            nextLevelHtml = '<div class="unit">'
                +'充值即可晋升 <span class="next-level-js">一星级</span><br/>'
                +'<a href="/ucenter/pay/payIndex" class="btn btn-sm link-loding-gobut next-level-link-js">立即充值 </a>'
                +'</div>';
        } else {
            nextLevelHtml ='<div class="unit next-level-group-div">'
                +'距离<span class="next-level-js">--</span>还差'
                +'<h3 class="next-level-amount-js">--</h3>'
                +'<a href="/game/show/lobby" class="btn btn-sm link-loding-gobut next-level-link-js">立即投注 </a>'
                +'</div>';
        }
        $(".vip-header.next-level-group-div").before(nextLevelHtml);
    }else {
        $(".next-level-group-div").hide();
    }
    var recommendHtml = "";
    if (pn.recommendCode){
        recommendHtml = '<span>'+pn.recommendCode+'</span>';

        $("#copy_link_button").attr("data-clipboard-text",location.href.replace(/(^.*?\/\/.*?\/).*/, "$1") + "register?recommendcode=" + pn.recommendCode);
        $("#copy_link_button").on("click", function () {
            var text = $(this).data("clipboardText");
            utils.copy(text);
            layer.alert('您已成功复制链接[' + text + ']，可将此链接发送给您的朋友进行账号注册',
                {maxWidth: 610, title: " "});
        });

    }else {
        recommendHtml = '<a href="/ucenter/recommend/code/create" class="btn btn-referal">点击获取推荐码</a>';

        $(".dl-horizontal").addClass("hidden");
    }
    $("#account-recommend").html(recommendHtml);

})
function updateNextLevel(userlevel, weeksBetAmount) {
    var nextLevel = userlevel || (parseInt(pn.userLevel || 0) + 1);
    if (nextLevel > 6) {
        return 0;
    }
    var $nextLevel = $(".next-level-js"),
        $nextLevelRate = $(".next-level-rate-js"),
        $nextLevelBonus = $(".next-level-bonus-js");
    if (nextLevel > 3) {
        $nextLevel.text("VIP" + nextLevel);
    } else {
        $nextLevel.text(STAR_LEVEL[nextLevel] + "星级");
    }
    weeksBetAmount = weeksBetAmount || parseFloat($("#weeks_betamount").text()) || 0;
    var amount = LEVEL_AMOUNT[nextLevel];
    var nextLevelAmount = (amount - weeksBetAmount).toFixed(2);
    if (nextLevelAmount < 0 && nextLevel > 1) {
        var valueBet = LEVEL_AMOUNT.concat(weeksBetAmount);
        var _sort = valueBet.sort(function (a, b) {
            if (typeof a === 'string') {
                return -1;
            }
            if (typeof b === 'string') {
                return -1;
            }
            return a - b
        });
        var indexOf = _sort.indexOf(weeksBetAmount);
        indexOf = indexOf > 6 ? 6 : indexOf;

        if (indexOf > 3) {
            $nextLevel.text("VIP" + indexOf);
        } else {
            $nextLevel.text(STAR_LEVEL[indexOf] + "星级");
        }
        $nextLevelRate.html(LEVEL_RATE[indexOf]);
        $nextLevelBonus.html(LEVEL_BONUS[indexOf]);

        nextLevelAmount = (LEVEL_AMOUNT[indexOf] - weeksBetAmount).toFixed(2);
        nextLevelAmount = nextLevelAmount < 0 ? 0 : nextLevelAmount;
    } else {
        $nextLevelRate.html(LEVEL_RATE[nextLevel]);
        $nextLevelBonus.html(LEVEL_BONUS[nextLevel]);
    }
    $(".next-level-amount-js").html(window.utils.amountFormatter(nextLevelAmount));
    return nextLevel;
}

function updateRate() {
    $(".chart-wrap .bars li").each(function (index, item) {
        if (index) {
            $(item).find("em").text(LEVEL_RATE[index]);
        }
    });
}

function canvasRound() {
    // 顶部数字动画
    var canvas = document.getElementById('canvas');
    var spanProcent = document.getElementById('procent');
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d');
        var posX = canvas.width / 2,
            posY = canvas.height / 2,
            fps = 1000 / 200,
            procent = 0,
            oneProcent = 360 / 100,
            result = oneProcent * (parseInt($('#procent').text(), 10) || 0);

        ctx.lineCap = 'square';

        function arcMove() {
            var deegres = 0;
            var acrInterval = setInterval(function () {
                deegres += 1;
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                procent = deegres / oneProcent;
                spanProcent.innerHTML = procent.toFixed();
                $('.stats > span').html(procent.toFixed());
                ctx.beginPath();
                ctx.arc(posX, posY, 30, (Math.PI / 180) * 270, (Math.PI / 180) * (270 + 360));
                ctx.strokeStyle = '#dfdfdf';
                ctx.lineWidth = '8';
                ctx.stroke();
                ctx.beginPath();
                ctx.strokeStyle = '#ff6a00';
                ctx.lineWidth = '8';
                ctx.arc(posX, posY, 30, (Math.PI / 180) * 270, (Math.PI / 180) * (270 + deegres));
                ctx.stroke();
                if (deegres >= result) {
                    clearInterval(acrInterval);
                }
            }, fps);
        }

        arcMove();

    }
}

$(function () {
    canvasRound();
    (function () {
        var level = parseInt(pn.userLevel || 0);
        if (level > 6) {
            level = 6;
        }
        var curRate = LEVEL_RATE[level];
        var here = '<span class="is-here"><em>' + curRate + '</em><i class="fa fa-angle-double-down"></i></span>';
        var $history = $('.u-account .bars li:lt(' + level + ')');
        $history.find("em").remove().end().find(".tip-message").remove();
        if (level) {
            $('.u-account .bars li:eq(' + level + ')').find("em").remove().end().find(".tip-message").remove().end().prepend(here);
        }
        $('.u-account .bars li:gt(' + level + ') .bar').addClass("null");
    })();
    (function () {
        var i;
        var $amount = 30;
        for (i = 1; i < 7; i++) {
            $('.u-account .bars li:eq(' + i + ') .bar').animate({'height': $amount}, 850);
            $amount = $amount + 30;
        }
    })();

    //获取本周投注额
    $.request({
        url: "/api/bet-amount/weeks"
    }).done(function (response) {
        if (response.successful){
            var data = response.data;
            var weeksBetAmount = parseFloat(data);
            $("#weeks_betamount").html(window.utils.amountFormatter(weeksBetAmount));
            updateNextLevel(null, weeksBetAmount);
            var value = [weeksBetAmount].concat(PERCENTAGE_AMOUNT);
            var ranking = (value.sort(function (a, b) {
                return a - b
            })).indexOf(weeksBetAmount) - 1;
            var v = PERCENTAGE_VALUE[ranking >= 0 ? ranking : 0];
            $('#procent').html(v);
            $('#procent-value').html(v);
            canvasRound();
        }
    });


    //验证手机状态
    $.request({
        url: "/api/phone/bound/init"
    }).done(function (response) {
        if (response.data.verifyStatus) {
            $("#phone-status").hide();
        }
    });

    updateRate();
    var $rebateWwitch = $(".btns.rebate-switch-js");
    $rebateWwitch.on("click", "a", function () {
        var $this = $(this), gameKind = $this.data("gameKind");
        $rebateWwitch.find("a").removeClass("active");
        $this.addClass("active");
        switch (gameKind) {
            case "SLOT":
                LEVEL_RATE = SLOT_LEVEL_RATE;
                break;
            case "FISHING":
                LEVEL_RATE = FISHING_LEVEL_RATE;
                break;
            case "VIDEO":
                LEVEL_RATE = VIDEO_LEVEL_RATE;
                break;
            case "SPORT":
                LEVEL_RATE = SPORT_LEVEL_RATE;
                break;
            case "LOTTERY":
                LEVEL_RATE = LOTTERY_LEVEL_RATE;
                break;
            default:
                LEVEL_RATE = SLOT_LEVEL_RATE;
                break;
        }
        updateRate();
        updateNextLevel();


    });

    async_load_credit();

});

//  登录设定
$(function () {
    var $phoneModal = $("#user-phone");
    var $loginSet = $(".login-setting-js");
    var $smsLogin = $("table tr input[type='checkbox'][name='smsLogin']");
    var $passwordLogin = $("table tr input[type='checkbox'][name='passwordLogin']");
    $loginSet.on("click", function () {
        var $info = $(".section-1 .info");
        $info.loading({multiple: true});
        $.request({
            url: "/api/login-set"
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                if (!data.bindStatus) {
                    new VerifyHandler({
                        form: $("#verifyPhoneForm"),
                        isInitSend: false,
                        loadingElement: $phoneModal.find(".modal-body"),
                        callback: function () {
                            $phoneModal.find(".modal-title").text("登录设定")
                                .end().find(".msection-1").fadeOut()
                                .end().find(".msection-2").fadeIn();
                        }
                    }).init().done(function () {
                        $phoneModal.modal("show");
                    });
                } else {
                    $phoneModal.find(".modal-title").text("登录设定")
                        .end().find(".msection-1").fadeOut()
                        .end().find(".msection-2").fadeIn()
                        .end().modal("show");
                }
                $smsLogin.prop("checked", data.sms);
                $passwordLogin.prop("checked", data.password);
            } else {
                layer.open({
                    title: ' ',
                    btn: ['确定'],
                    closeBtn: 0,
                    content: '<p>' + response.data + '</p>',
                    yes: function () {
                        window.location.reload();
                    }
                });
            }
        }).always(function () {
            $info.loading(false)
        });
    });

    $smsLogin.add($passwordLogin).on("change", function () {
        var $this = $(this);
        var fail = function ($this, data) {
            $this.prop("checked", !$this.prop("checked"));
            layer.open({
                title: ' ',
                content: data,
                btn: ['确认']
            });
        };
        $phoneModal.find(".modal-body").loading({multiple: true});
        $.request({
            type: 'PUT',
            url: "/api/login-set",
            data: {
                smsLogin: $smsLogin.prop("checked"),
                passwordLogin: $passwordLogin.prop("checked")
            }
        }).done(function (response) {
            if (!response.successful) {
                fail($this, response.message);
            }
        }).fail(function () {
            fail($this, "服务器发生错误,请稍后再试或联系客服");
        }).always(function () {
            $phoneModal.find(".modal-body").loading(false);
        });
    });
});
