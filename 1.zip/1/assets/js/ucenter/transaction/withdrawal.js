/**
 * Created by Lorry on 2017/6/13.
 */

var init_widthraw = function () {
        init_tabs({
            beginTimeWidget: 'withdraw_begin_time',
            endTimeWidget: 'withdraw_end_time',
            pagingWidget: 'withdraw_pagging',
            dataUrl: '/api/withdrawal/record',
            searchWidget: 'withdraw_search',
            tabGrid: 'tab-1-grid',
            requestData: {},
            searchType: {name:'withdrawFlag',id:'withdrawFlag'},
            fieldList: [
                {
                    name: "createDate", title: "申请时间", type: "text", width: 50, align: 'center',
                    itemTemplate: function (value, item) {
                        return value.replace(/-/, '/').replace(/-/, '/');
                    }
                },
                {name: "requestId", title: "提现单号", type: "text", width: 50, align: 'center'},
                {
                    name: "accountId",
                    title: "提现银行卡",
                    type: "text",
                    width: 50,
                    sorting: false,
                    align: 'center',
                    itemTemplate: function (value, item) {
                        var bankNameno = item.accountId.substr(item.accountId.length - 4);
                        var accountType = item.accountType;
                        if (accountType === "BTC") {
                            accountType = "比特币";
                        }else if(accountType === "ETH"){
                            accountType = "以太币";
                        }
                        return accountType + "&nbsp;&nbsp;&nbsp;" + bankNameno;
                    	
                    }
                },{
                    name: "amount",
                    title: "提现金额",
                    type: "text",
                    width: 50,
                    sorting: false,
                    align: 'center',
                    itemTemplate: function (value, item) {
                        if (item.accountType === "BTC") {
                            return utils.amountFormatter(value) + "(" + item.originalAmount + "比特币)";
                        }else if (item.accountType === "ETH") {
                            return utils.amountFormatter(value) + "(" + item.originalAmount + "以太币)";
                        }
                        return utils.amountFormatter(value);
                    }
                },
                {
                    name: "flag", title: "状态", type: "text", width: 20, align: 'center',
                    itemTemplate: function (value, item) {
                        switch (value) {
                            case 0:
                                return '等待处理';
                            case 1:
                                return '等待支付';
                            case 2:
                                return '支付完成';
                            case 3:
                                return '支付失败';
                            case 9:
                                return '处理中';
                            case -1:
                                return '已取消';
                            case -2:
                                return '已取消';
                            case -3:
                                return '审批拒绝';
                        }
                    }
                },
                {
                    name: "edit",
                    title: "操作",
                    type: "text",
                    width: 30,
                    align: 'center',
                    itemTemplate: function (value, item) {
                        if (item.flag === 0) {
                            return '<a  onclick="cancelWithdraw(\'' + item.requestId + '\');" class="btn btn-cancel pointer-link">取消</a>';
                        }
                        return '';
                    }
                },
                {
                    name: "remark",
                    title: "备注",
                    type: "text",
                    width: 70,
                    align: 'center',
                }
            ]
        });
    },
    cancelWithdraw = function (requestId) {
        layer.confirm('您确定要取消本次提现吗？', {
                skin: 'btn-reverse',
                title: ' ',
                btn: ['不取消', '确定'] //按钮
            },
            function (index) {
                layer.close(index);
            }, function () {
                $.request({
                    type: 'PUT',
                    url: "/api/withdrawal/cancel/" + requestId,
                    data: {
                        'requestId': requestId
                    }
                }).done(function (response) {
                    if (response.successful && true == response.successful) {
                        layer.msg('您的提现申请已成功取消！', {
                            time: 5000, //5s后自动关闭
                            btn: ['知道了，谢谢！']
                        });
                    } else {
                        layer.alert('操作失败！<br />' + response.message + '<br />请联系<a href="javascript:;" class="as-cs">在线客服</a>处理！', {title: ' '});
                    }
                }).fail(function (e) {
                    lib.log(e);
                }).always(function (e) {
                    reload_grid();
                });
            });
    };