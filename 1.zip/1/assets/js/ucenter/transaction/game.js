var currentPageNumber = 0;
var totalPageNumber = 0;

function queryGameRecord(pageIndex) {
    currentPageNumber = pageIndex;
    //请求参数
    var data = {
        platformId: $("#gameRecord_gamePlatformId").val(),
        beginTime: $("#gameRecord_beginDateTime").val(),
        endTime: $("#gameRecord_endDateTime").val(),
        pageIndex: pageIndex
    };
    var gamePlatId=utils.getQueryString("gamePlatId");
    if(gamePlatId && !data.platformId){
        return;//未加载完游戏类型配置直接返回；
    }
    var loadingObj = $("#tab-5");
    loadingObj.loading();
    $.request({
        url: "/api/game/record",
        data: data
    }).done(function (response) {
        $.extend(response.data, {
            currentPageNumber: pageIndex
        });
        if (response.successful) {
            totalPageNumber = response.data.totalPageNumber;
            if (response.data.totalDataCount && response.data.totalDataCount > 0) {
                //有数据
                var html = '<tr><th>时间</th><th>平台</th><th>游戏类型</th><th>投注单号</th><th>投注金额</th><th>有效投注额</th><th>派彩金额</th><th>备注说明</th></tr>';
                var data = response.data.data;
                var account = "0";
                var validAccount = "0";
                var cusAccount = "0";
                for (var i = 0; i < data.length; i++) {
                    var remark = "";
                    if(data[i].bankerPoint !== "" && data[i].playerPoint !== ""){
                        remark = "庄:" + data[i].bankerPoint + "&nbsp;&nbsp;&nbsp;闲:" + data[i].playerPoint;
                        if(data[i].bankerPoint === data[i].playerPoint){
                            remark = "&nbsp;&nbsp;&nbsp;和";
                        }
                    }
                    var gameType = data[i].gameType ? data[i].gameType : "";
                    if (gameType && gameType === "DT" && data[i].dragonPoint && data[i].dragonPoint !== "" && data[i].tigerPoint && data[i].tigerPoint !== "") {
                        remark = "龙:" + data[i].dragonPoint + "&nbsp;&nbsp;&nbsp;虎:" + data[i].tigerPoint;
                        if (data[i].dragonPoint === data[i].tigerPoint) {
                            remark = "&nbsp;&nbsp;&nbsp;和";
                        }
                    }
                    var remarkData = data[i].remark;
                    if(remarkData){
                        remark = remarkData;
                    }
                    account = changeToDecimal(data[i].account);
                    validAccount = changeToDecimal(data[i].validAccount);
                    cusAccount = changeToDecimal(data[i].cusAccount);

                    html += '<tr><td>' + data[i].billTime + '</td><td>' + getPlatformName(data[i]) + '</td><td>' + data[i].gameName + '</td><td>' + data[i].billNo + '</td><td>' + account + '</td><td>' + validAccount + '</td><td>' + cusAccount + '</td><td>' + remark + '</td></tr>';
                }
                html += gameRecordPage(response.data);
                $("#gameRecord_table").html(html);
            } else {
                gameRecordTableEmptyData();
            }
        } else {
            gameRecordTableEmptyData();
            if (response.code === 10005) {
                serverErrorLayer(response.code, "请求过于频繁, 请稍后重试!");
                return;
            }
            if(response.code === 10000){
                layer.confirm(
                    '仅支持查询15天内的游戏记录',
                    {
                        title: ' ',
                        btn: ["确定"]
                    },
                    function (index) {
                        layer.close(index);
                    }
                );
                return;
            }
            serverErrorLayer(response.code,response.message);
        }
    }).fail(function (e) {
        logConsole(e);
        gameRecordTableEmptyData();
    }).always(function () {
        loadingObj.loading("close");
        bindingEvent();
    });
}

function bindingEvent() {
    //查询按钮单击事件
    $("#gameRecord_search").off("click").on("click", function () {
        queryGameRecord(1);
    });

    $(".gameRecord.fa.fa-step-backward").off("click").on("click", function () {
        if (currentPageNumber <= 1) {
            return;
        }
        queryGameRecord(1);
    });
    $(".gameRecord.fa.fa-backward").off("click").on("click", function () {
        if (currentPageNumber <= 1) {
            return;
        }
        queryGameRecord(currentPageNumber - 1);
    });
    $(".gameRecord.fa.fa-forward").off("click").on("click", function () {
        if (currentPageNumber === totalPageNumber) {
            return;
        }
        queryGameRecord(currentPageNumber + 1);
    });
    $(".gameRecord.fa.fa-step-forward").off("click").on("click", function () {
        if (currentPageNumber === totalPageNumber) {
            return;
        }
        queryGameRecord(totalPageNumber);
    });
}

//无数据
function gameRecordTableEmptyData() {
    var html = '<tr><th>时间</th><th>平台</th><th>游戏类型</th><th>投注单号</th><th>投注金额</th><th>有效投注额</th><th>派彩金额</th><th>备注说明</th></tr>';
    html += '<tr><td colspan="8">所选时间段内暂无记录!</td></tr>';
    var data = {totalPageNumber: 0, currentPageNumber: 0, betAmount: 0, validBetAmount: 0, payoutAmount: 0};
    html += gameRecordPage(data);
    $("#gameRecord_table").html(html);
}

//分页
function gameRecordPage(data) {
    var html = '';
    html += '<tr class="last">';
    html += '   <td colspan="4" class="text-right">';
    html += '       <div class="pull-left form-inline">';
    html += '           <div class="form-group">';
    html += '               <button class="btn btn-default"><i class="gameRecord fa fa-step-backward"></i></button>';
    html += '               <button class="btn btn-default"><i class="gameRecord fa fa-backward"></i></button>';
    html += '           </div>';
    html += '           <div class="form-group">';
    html += '               第 <input type="text" class="form-control page-no" readonly value="' + data.currentPageNumber + '"> 页 共' + data.totalPageNumber + '页';
    html += '           </div>';
    html += '           <div class="form-group">';
    html += '               <button class="btn btn-default"><i class="gameRecord fa fa-forward"></i></button>';
    html += '               <button class="btn btn-default"><i class="gameRecord fa fa-step-forward"></i></button>';
    html += '           </div>';
    html += '       </div>';
    html += '   </td>';
    html += '   <td><b>共计: </b>' + data.betAmount + '</td>';
    html += '   <td>' + data.validBetAmount + '</td>';
    html += '   <td>' + data.payoutAmount + '</td>';
    html += '   <td></td>';
    html += '</tr>';
    return html;
}

$(function () {
    initDateTime();
    initGamePlatformSelect();
    gameRecordTableEmptyData();
    bindingEvent();

    function initDateTime() {
        var beginDateTime = getStartDateTime();
        var endDateTime = getEndDateTime();

        //只能查询15天以内的数据
        //一进入页面开始时间和结束时间默认区间15天
        $("#gameRecord_beginDateTime").datetimepicker({
            lang: 'ch',
            format: "Y-m-d H:i:00",
            value: beginDateTime.format("yyyy-MM-dd hh:mm:ss"),
            minDate: beginDateTime,
            maxDate: endDateTime,
            minTime: '00:00',
            maxTime: '23:59',
            step: 10
        });
        $("#gameRecord_endDateTime").datetimepicker({
            lang: 'ch',
            format: "Y-m-d H:i:00",
            value: endDateTime.format("yyyy-MM-dd hh:mm:ss"),
            minDate: beginDateTime,
            maxDate: endDateTime,
            minTime: '00:00',
            maxTime: '23:59',
            step: 10
        });
    }

    function initGamePlatformSelect() {
        var loadingObj = $("#tab-5");
        loadingObj.loading();
        $.request({
            url:  "/api/game/config/record",
        }).done(function (response) {
            if (response.successful) {
                var $select = $("#gameRecord_gamePlatformId");
                
                var options = [];
                var data = response.data.gameConfigMap;
                
                var arr = new Array();

                for (var key in data) {
                    arr.push(data[key]);
                }

                arr.sort(function (a, b) {
                    return a["sort"] - b["sort"];
                });

                for (let i = 0; i < arr.length; i++) {
                    options.push('<option value="' + arr[i].value + '">' + arr[i].text + '</option>');
                }

                $select.append(options.join(''));
                var gamePlatId=utils.getQueryString("gamePlatId");
                if(gamePlatId){
                    $select.val(gamePlatId);
                    // queryGameRecord(1);//手动调用
                }
            } else {
                serverErrorLayer(response.code, response.message);
            }
        }).fail(function (e) {
            logConsole(e);
            gameRecordTableEmptyData();
        }).always(function () {
            loadingObj.loading("close");
            bindingEvent();
        });
    }

    //得到15天内开始时间
    function getStartDateTime(millisec) {
        var millisecTem;
        if (!millisec) {
            millisecTem = pn.sys_now;
        }
        var date = new Date(millisecTem);
        date.setDate(date.getDate() - 14);
        date.setHours(0, 0, 0, 0);
        return date;
    }

    //得到15天内结束时间
    function getEndDateTime(millisec) {
        var millisecTem;
        if (!millisec) {
            millisecTem = pn.sys_now;
        }
        var date = new Date(millisecTem);
        date.setHours(23, 59, 59, 999);
        return date;
    }
});

function changeToDecimal(v){
    v = v.toString();
    if(v.indexOf(".") !== -1){
        return v;
    }
    return v + ".00";
}

function serverErrorLayer(errorCode, msg) {
    msg = msg ? msg : "服务器发生异常";
    if (errorCode) {
        msg = msg + "[" + errorCode + "]";
    }
    layer.confirm(
        msg,
        {
            title: ' ',
            btn: ["联系客服"]
        },
        function (index) {
            layer.close(index);
            //模拟客服单击事件
            $(".as-cs").trigger("click");
        }
    );
}

function getPlatformName(data){
    if(!data || !data.platformId){
        return "";
    }
    var platformId = data.platformId + "";
    var gameKind = data.gameKind + "";
    if(platformId && gameKind){
        if(platformId === "003" && gameKind === "3"){
            return "AG旗舰厅";
        }
        if(platformId === "026" && gameKind === "3"){
            return "AG国际厅";
        }
        if(platformId === "036" && gameKind === "2"){
            return "AG赌场厅";
        }
        if(platformId === "026" && gameKind === "5"){
            return "AG电游";
        }
        if(platformId === "064" && gameKind === "3"){
            return "AS真人棋牌";
        }
        if(platformId === "068" && gameKind === "5"){
            return "PP电游";
        }
        if(platformId === "052" && gameKind === "5"){
            return "PNG电游";
        }
        if(platformId === "027" && gameKind === "5"){
            return "TTG电游";
        }
        if(platformId === "035" && gameKind === "5"){
            return "MG电游";
        }
        if(platformId === "039" && gameKind === "5"){
            return "PT电游";
        }
        if(platformId === "067" && gameKind === "5"){
            return "SW电游";
        }
        if(platformId === "026" && gameKind === "8"){
            return "AG捕鱼王";
        }
        if(platformId === "031" && gameKind === "1"){
            return "沙巴体育";
        }
        if(platformId === "026" && gameKind === "1"){
            return "AG国际体育";
        }
        if(platformId === "071" && gameKind === "12"){
            return "QG刮刮彩";
        }
        if(platformId === "075" && gameKind === "12"){
            return "VR彩票";
        }
        if(platformId === "079" && gameKind === "12"){
            return "乐门彩票";
        }
        if(platformId === "073" && gameKind === "1"){
            return "亚游劲彩";
        }
        if(platformId === "026" && gameKind === "1"){
            return "AG国际体育";
        }
        if(platformId === "080" && gameKind === "5"){
            return "RTG电游";
        }
        if(platformId === "076" && gameKind === "1"){
            return "亚游电竞";
        }

    }
    return "";
}