/**
 * Created by Lorry on 2017/6/13.
 */

init_buy = function () {
    var _params = {
        beginTimeWidget: 'buy_begin_time',
        endTimeWidget: 'buy_end_time',
        pagingWidget: 'buy_paging',
        dataUrl: '/api/lottery/buy/record',
        searchWidget: 'buy_search',
        tabGrid : 'tab-6-grid',
        requestData: {
        },
        searchType : {
            id : 'buy_issue',
            name : 'actId'
        },
        fieldList: [
            {name: "buyType", title: "购买类型", type: "text", width: 40, align:'center'},
            {name: "actName", title: "活动名称", type: "text", width: 60, align:'center'},
            {name: "srcAmount", title: "购券前金额", type: "text", width: 50, sorting: false, align: 'center'},
            {name: "buyAmount", title: "支出金额", type: "text", width: 40, align: 'center'},
            {name: "dstAmount", title: "购券后金额", type: "text", width: 50, sorting: false, align: 'center'},
            {name: "buyDate", title: "支出时间", type: "text", width: 50, sorting: false, align: 'center'},
            {name: "remark", title: "备注", type: "text", width: 100, sorting: false, align: 'center'}
        ]
    };

    $.request({
        url: '/api/lottery/act/list'
    }).done(function (res) {
        var _d = res.data;
        var $options = [];
        var date = new Date();
        for(var i = 0; i < _d.length; i++) {
            $options.push('<option value="'+ _d[i]['actId'] +'">'+ _d[i]['actName'] +'</option>');
        }
        $('#buy_issue').html($options.join(''));

        init_tabs(_params);
    }).fail(function () {
        init_tabs(_params);
    }).always(function () {
        // init_tabs(_params);
    });
};