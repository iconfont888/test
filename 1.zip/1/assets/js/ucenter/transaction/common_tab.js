/**
 * Created by Lorry on 2017/6/13.
 */
var withdrawInitFlag = false, depositInitFlag = false, rebateInitFlag = false, promotionInitFlag = false, buyInitFlag = false;
var configs,
    search_types = {
        withdraw: 'withdrawalFlag',
        deposit: 'deposit_type',
        rebate: 'rebate_type',
        promotion: 'promotion_type',
        buy: 'buy_issue'
    },
    init_tabs = function (_configs) {
        configs = _configs;
        var
            _today = new Date(pn.sys_now),
            getTuday = function () {
                var month = _today.getMonth() + 1;
                var day = _today.getDate();
                return _today.getFullYear() + '-' +
                    (month < 10 ? '0' + month : month) + '-' +
                    (day < 10 ? '0' + day : day);
            },
            initBeginTime = function () {
                var date = new Date(pn.sys_now);
                date.setHours(0, 0, 0);
                date.setDate(date.getDate() - 2);
                return getDateValue(date);
            },
            initEndTime = function () {
                var date = new Date(pn.sys_now);
                date.setHours(23, 59, 59);
                return getDateValue(date);
            },
            getDateValue = function (date) {
                var year = date.getFullYear();
                var month = date.getMonth();
                var day = date.getDate();
                var hours = date.getHours();
                var minutes = date.getMinutes();
                var seconds = date.getSeconds();

                month += 1;
                month = (month < 10 ? '0' + month : month);
                day = (day < 10 ? '0' + day : day);
                hours = (hours < 10 ? '0' + hours : hours);
                minutes = (minutes < 10 ? '0' + minutes : minutes);
                seconds = (seconds < 10 ? '0' + seconds : seconds);

                return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
            },
            getMinDate = function () {
                var year, month, day;
                year = _today.getFullYear();
                month = _today.getMonth();
                day = _today.getDate() - 14;
                return new Date(year, month, day);
            },
            getMaxDate = function () {
                var year, month, day;
                year = _today.getFullYear();
                month = _today.getMonth();
                day = _today.getDate();
                return new Date(year, month, day);
            },
            getBeginMaxDate = function () {
                var endSelect = $('#' + configs.endTimeWidget).val();
                return new Date(Date.parse(endSelect.replace(/-/g, "/")));
            },
            beginTime = $('#' + configs.beginTimeWidget).datetimepicker({
                lang: 'ch',
                format: "Y-m-d H:i:00",
                value: initBeginTime(),
                minDate: getMinDate(),
                maxTime: '23:59',
                minTime: '00:00',
                step: 10,
                onShow: function () {
                    this.setOptions({
                        maxDate: getBeginMaxDate()
                    })
                }

            }),
            getEndMinDate = function () {
                var beginSelect = $('#' + configs.beginTimeWidget).val();
                return new Date(Date.parse(beginSelect.replace(/-/g, "/")));
            },
            endTime = $('#' + configs.endTimeWidget).datetimepicker({
                lang: 'ch',
                format: "Y-m-d H:i:00",
                value: initEndTime(),
                maxDate: getMaxDate(),
                maxTime: '23:59',
                minTime: '00:00',
                step: 10,
                onShow: function () {
                    this.setOptions({
                        minDate: getEndMinDate()
                    })
                },
                onSelectTime: function () {
                    var beginSelect = $('#' + configs.beginTimeWidget).val();
                    var beginDate = new Date(Date.parse(beginSelect.replace(/-/g, "/")))

                    var endSelect = $('#' + configs.endTimeWidget).val();
                    var endDate = new Date(Date.parse(endSelect.replace(/-/g, "/")))

                    if (beginDate >= endDate) {
                        layer.alert("结束时间不能在开始时间之前，请您重新选择日期范围!", {title: " "});
                    }
                }
            }),
            jsGrid = $("#" + _configs.tabGrid);

        var $record = jsGrid.parent();
        // 第<span><input name='page' style='width: 20px;'></span>
        jsGrid.jsGrid({
            width: "100%",
            height: "auto",
            paging: true,
            pageLoading: true,
            tableClass: 'jsgrid-table table',
            pageSize: 10,
            pageIndex: 1,
            autoload: true,
            // loadMessage: "请稍后",
            pagerContainer: "#" + configs.pagingWidget,
            pagePrevText: "<",
            pageNextText: ">",
            pageButtonCount: 0,
            pageNavigatorNextText: "&#8230;",
            pageNavigatorPrevText: "&#8230;",
            pageFirstText: "<<",
            pageLastText: ">>",
            //pagerFormat: " {first} {prev} {pages} {next} {last}  &nbsp;&nbsp; {pageIndex} of {pageCount}",
            pagerFormat: " {first} {prev} {next} {last} ",
            noDataContent: "<div class='no-data'>所选时间段内暂无记录！</div>",
            loadShading: true,
            loadIndication: false,
            controller: {
                loadData: function (filter) {
                    var d = $.Deferred();
                    $record.loading();
                    $('.loading-container').attr('style', '');
                    $('.loading-logo').attr('style', 'top: 50%;left: 40%;');
                    var beginTime = $("#" + configs.beginTimeWidget).val();
                    var endTime = $("#" + configs.endTimeWidget).val();
                    var userAgent = navigator.userAgent;
                    if(userAgent.toLowerCase().match(/rv:([\d.]+)\) like gecko/)) {  // 兼容IE11
                        beginTime.replace('-','/');
                        endTime.replace('-','/');
                    }

                    $.extend(configs.requestData, {
                        page_number: filter.pageIndex,
                        page_size: filter.pageSize,
                        beginTime: beginTime,
                        endTime: endTime
                    });

                    if(configs.searchType.name == 'withdrawFlag') {
                        $.extend(configs.requestData, {
                            withdrawFlag : $('#' + configs.searchType.id).val()
                        });
                    } else if(configs.searchType.name == 'depositType') {
                        $.extend(configs.requestData, {
                            paymentFlag : $('#paymentFlag').val(),
                            orderType:$('#orderType').val()
                        });
                    } else if(configs.searchType.name == 'washCodeType') {
                        $.extend(configs.requestData, {
                            washCodeType : $('#' + configs.searchType.id).val()
                        });
                    } else if(configs.searchType.name == 'actId') {
                        $.extend(configs.requestData, {
                            actId : $('#' + configs.searchType.id).val()
                        });
                    }

                    $.request({
                        url: configs.dataUrl,
                        data: configs.requestData
                    }).done(function (response) {
                        var res = response.data;
                        var total = 0;
                        var subtotalAmount = 0;
                        var totalAmount = 0;
                        var data = [];
                        if(res){
                            total = res.total? res.total:0;
                            subtotalAmount = res.subtotalAmount ? res.subtotalAmount :0;
                            totalAmount = res.totalAmount? res.totalAmount:0;
                            data = res.data ? res.data:[];
                        }
                        //解决翻页之后选择其他条件查询，分页控件和数据加载错误的问题
                        if (total>0&&data.length<=0){
                            //跳转到第一页
                            $(".fa.fa-step-backward").click();
                        }
                        d.resolve({data: data, itemsCount: total});

                        var begin_size = (filter.pageIndex - 1) * filter.pageSize;begin_size += 1;
                        var place_total = total;
                        if (place_total == 0) {
                            begin_size = 0;
                        }
                        var end_size = begin_size + data.length;end_size -= 1;
                        $('.subtotal-amount').each(function (index) {
                            $(this).text(subtotalAmount);
                        });
                        $('.total-amount').each(function (index) {
                            $(this).text(totalAmount);
                        });

                        $('.page_angle').each(function (index) {
	                        if(end_size === -1) {
		                        end_size = 0;
	                        }
                            $(this).text('显示' + begin_size + '到' + end_size + ',共' + place_total + '记录');
                        });
                        $('.total_page_pl').each(function () {
                            if (place_total == 0) {
                                $(this).parent().find('input').val(0);
                            } else {
                                $(this).parent().find('input').val(filter.pageIndex);
                            }
                            var _pages = parseInt((place_total / filter.pageSize)) + ((place_total % filter.pageSize) > 0 ? 1 : 0);
                            $(this).text(' 共 ' + _pages + ' 页');
                        });

                    }).fail(function () {
                        d.resolve({data: [], itemsCount: 0});
                    }).always(function () {
                        $record.loading('close');
                    });
                    return d.promise();
                }
            },
            fields: configs.fieldList
        });

        function jsGridLoadData() {
            $("#" + configs.searchWidget).on("click", function () {
                var beginSelect = $('#' + configs.beginTimeWidget).val();
                var beginDate = new Date(Date.parse(beginSelect.replace(/-/g, "/")))

                var endSelect = $('#' + configs.endTimeWidget).val();
                var endDate = new Date(Date.parse(endSelect.replace(/-/g, "/")))

                if (beginDate >= endDate) {
                    layer.alert("结束时间不能在开始时间之前，请您重新选择日期范围!", {title: " "});
                } else {
                    jsGrid.jsGrid("loadData");
                }
            });
        }

        var tab_item, tab_grid_item;
        switch (configs.tabGrid) {
            case 'tab-1-grid':
                tab_item = 'paging-1-grid';
                tab_grid_item = 'withdraw_pagging';
                if (withdrawInitFlag === false) {
                    jsGridLoadData();
                    pagingFooter($('#' + tab_grid_item), $('#' + tab_item));
                    withdrawInitFlag = true;
                }
                break;
            case 'tab-2-grid':
                tab_item = 'paging-2-grid';
                tab_grid_item = 'deposit_paging';
                if (depositInitFlag === false) {
                    jsGridLoadData();
                    pagingFooter($('#' + tab_grid_item), $('#' + tab_item));
                    depositInitFlag = true;
                }
                break;
            case 'tab-3-grid':
                tab_item = 'paging-3-grid';
                tab_grid_item = 'rebate_paging';
                if (promotionInitFlag === false) {
                    jsGridLoadData();
                    pagingFooter($('#' + tab_grid_item), $('#' + tab_item));
                    promotionInitFlag = true;
                }
                break;
            case 'tab-4-grid':
                tab_item = 'paging-4-grid';
                tab_grid_item = 'promotion_paging';
                if (rebateInitFlag === false) {
                    jsGridLoadData();
                    pagingFooter($('#' + tab_grid_item), $('#' + tab_item));
                    rebateInitFlag = true;
                }
                break;
            case 'tab-6-grid':
                tab_item = 'paging-6-grid';
                tab_grid_item = 'buy_paging';
                if (buyInitFlag === false) {
                    jsGridLoadData();
                    pagingFooter($('#' + tab_grid_item), $('#' + tab_item));
                    buyInitFlag = true;
                }
                break;
        }

    },
    reload_grid = function () {
        $("#" + configs.searchWidget).click();
    },
    reset_tab = function (_tab) {
        switch (_tab) {
            case 'tab-1':
                init_widthraw();
                break;
            case 'tab-2':
                init_deposit();
                break;
            case 'tab-3':
                init_rebate();
                break;
            case 'tab-4':
                init_promotion();
                break;
            case 'tab-5':
                queryGameRecord(1);
                break;
            case 'tab-6':
                init_buy();
                break;
        }
    },
    pagingFooter = function ($Grid, $record) {
        $record.find(".refresh,.search-js").on("click", function () {
            reload_grid();
        });
        $record.find(".forward").on("click", function () {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(2) a").trigger("click");
        });
        $record.find(".backward").on("click", function () {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(1) a").trigger("click");
        });
        $record.find(".step-backward").on("click", function () {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(0) a").trigger("click");
        });
        $record.find(".step-forward").on("click", function () {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(3) a").trigger("click");
        });
    },
    init_widthraw, init_deposit, init_rebate, init_promotion, init_buy;

$(document).ready(function () {
    var oneTimeFlag = true;
    $(".u-transaction>.nav-tabs-template a").off('shown.bs.tab').on('shown.bs.tab', function (e) {
        var gamePlatId=utils.getQueryString("gamePlatId");
        if(gamePlatId && gamePlatId == "NBT" && oneTimeFlag){
            oneTimeFlag = false;
            return reset_tab("tab-5");
        }
        reset_tab($(this).attr("href").substr(1));
    });
    if (typeof tab_index === 'undefined') {
        tab_index = 'withdraw';
    }
    switch (tab_index) {
        case 'withdraw':
            $('ul.nav.nav-tabs.nav-tabs-template li>a:eq(0)').tab("show");
            break;
        case 'deposit':
        case 'reCharge':
            $('ul.nav.nav-tabs.nav-tabs-template a[href="#tab-2"]').tab("show");
            break;
        case 'washCode':
            $('ul.nav.nav-tabs.nav-tabs-template li>a:eq(2)').tab("show");
            break;
        case 'tab-4':
            $('ul.nav.nav-tabs.nav-tabs-template li>a:eq(3)').tab("show");
            break;
        case 'tab-6':
            $('ul.nav.nav-tabs.nav-tabs-template li>a:eq(3)').tab("show");
            break;
        default:
            $('ul.nav.nav-tabs.nav-tabs-template li>a:eq(0)').tab("show");
            break;
    }
});