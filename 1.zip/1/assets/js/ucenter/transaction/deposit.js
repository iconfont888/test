/**
 * Created by Lorry on 2017/6/13.
 */

init_deposit = function () {
    init_tabs({
        beginTimeWidget: 'deposit_begin_time',
        endTimeWidget: 'deposit_end_time',
        pagingWidget: 'deposit_paging',
        dataUrl: '/api/payment/record',  //充值记录
        searchWidget: 'deposit_search',
        tabGrid : 'tab-2-grid',
        requestData: {},
        searchType : {
            id : 'deposit_type',
            name : 'depositType'
        },
        fieldList: [
            {name: "createdDate", title: "申请时间", type: "text", width: 60, align: 'center'},
            {name: "orderNo", title: "充值单号", type: "text", width: 87, align: 'center'},
            {
                name: "amount", title: "充值金额", type: "text", width: 50, align: 'center',
                itemTemplate: function (value, item) {
	                var btcAmount = item.btcAmount;
	                var handleAmount = item.handleAmount;
	                if (item.orderType === "111107") {
		                if(item.orderFlagZH !== "成功") {
			                value = '';
		                }
                        return value + "(" + btcAmount + "比特币)";
                    }
                    if (item.orderType === "ETH") {
                        return value + "(" + btcAmount + "以太币)";
                    }
                    if(handleAmount > 0){
                        return value.toFixed(2) + " (手续费" + handleAmount + ")";
                    }
                    return value;
                }
            },
            {
                name: "orderType", title: "充值类型", type: "text", width: 51, align:'center',
                itemTemplate: function (value, item) {
                    switch (value) {
                        case "111105":
                            return "网银在线支付";
                        case "113001":
                            return "点卡支付";
                        case "111906":
                            return "支付宝扫码";
                        case "111808":
                            return "微信扫码";
                        case "111805":
                            return "QQ扫码";
                        case "111806":
                            return "微信支付";
                        case "111905":
                            return "支付宝支付";
                        case "111110":
                            return "V币支付";
                        case "111807":
                            return "QQ支付";
                        case "111112":
                            return "银联扫码";
                        case "111113":
                            return "银联快捷支付";
                        case "114000":
                            return "京东扫码";
                        case "111106":
                            return "人工存款";
                        case "111107":
                            return "比特币支付";
                        case "111108":
                            return "以太币支付";
                        case "116001":
                            return "快充";
                        case "120001":
                            return "云闪付";
                        default:
                            return "在线支付";
                    }
                }
            },
            {
                name: "orderFlag", type: "text", title: "状态", width: 40, align:'center',
                itemTemplate: function (value, item) {
                    switch (value) {
                        case "success":
                            return "成功";
                        case "wait":
                            return "等待";
                        case "failed":
                            return "失败";
                        default:
                            return "等待";
                    }
                }
            },
            {
                name: "finishTime", type: "text", title: "到账时间", width: 40, align: 'center',
                itemTemplate: function (value, item) {
                    var orderFlag = item.orderFlag;
                    switch (orderFlag) {
                        case "success":
                            return value;
                        case "wait":
                            return "";
                        case "failed":
                            return "";
                        default:
                            return "";
                    }
                }
            }
        ]
    });
};

$(function () {
    $("#orderType").on("change",function () {
        var data_value = $(this).val();
        var tip = "";
        if('ONLINE_PAYMENT' == data_value){
            tip = "温馨提示：在线支付类型包含 在线支付、扫码支付、APP支付";
        }
        $("#orderTypeTip").text(tip);
    })
});