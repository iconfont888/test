/**
 * Created by Lorry on 2017/6/13.
 */

var gameKinds = {
    VIDEO : '真人视讯',
    FISHING : '捕鱼游戏',
    SLOT : '电子游戏',
    SPORT : '体育电竞',
    LOTTERY : '彩票',
    AGTEL : '电投',
    NIUNIU : '牛牛',
    THREED : 'THREED'
};

init_rebate = function () {
    init_tabs({
        beginTimeWidget: 'rebate_begin_time',
        endTimeWidget: 'rebate_end_time',
        pagingWidget: 'rebate_paging',
        dataUrl: '/api/rebate/record',
        searchWidget: 'rebate_search',
        tabGrid : 'tab-3-grid',
        requestData: {
        },
        searchType : {
            id : 'rebate_type',
            name : 'washCodeType'
        },
        fieldList: [
            {name: "createdDate", title: "申请时间", type: "text", width: 60, align:'center'},
            {name: "lastUpdate", title: "到账时间", type: "text", width: 60, align:'center',
                itemTemplate: function (value, item) {
                    if (item.flag === 2) {
                        return value;
                    }
                    return '--';
                }
            },
            {name: "rebateMode", title: "洗码类型", type: "text", width: 50, sorting: false, align: 'center'},
            {name: "Amount", title: "洗码金额", type: "text", width: 40, align: 'center'},
            {name: "gameKind", title: "游戏类型", type: "text", width: 50, sorting: false, align: 'center'},
            {name: "flagZH", type: "text", title: "状态", width: 40, align: 'center'}
        ]
    });
};