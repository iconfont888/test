/**
 * Created by Lorry on 2017/6/13.
 */
init_promotion = function () {
    init_tabs({
        beginTimeWidget: 'promotion_begin_time',
        endTimeWidget: 'promotion_end_time',
        pagingWidget: 'promotion_paging',
        dataUrl: '/api/promotion/record',
        searchWidget: 'promotion_search',
        tabGrid : 'tab-4-grid',
        requestData: {},
        searchType : {},
        fieldList: [
            {name: "createdDate", title: "申请时间", type: "text", width: 50, align:'center'},
            {name: "lastUpdate", title: "到账时间", type: "text", width: 50, align:'center'},
            {
                name: "Amount", title: "优惠金额", type: "text", width: 50, align: 'center',
                itemTemplate: function (value, item) {
                    if (value === 0) {
                        return parseFloat(item.refAmount).toFixed(2);
                    }
                    return parseFloat(value).toFixed(2);
                }
            },
            {name: "promotionName", title: "优惠类型", type: "text", width: 50, sorting: false, align: 'center'},
            {
                name: "flagZH", type: "text", title: "状态", width: 40, align:'center'/*,
                itemTemplate: function (value, item) {
                    switch (value){
                        case 'PENDING':
                            value = '等待处理';
                            break;
                        case 'ONGOING':
                            value = '处理中';
                            break;
                        case 'PENDING_ONGOING':
                            value = '待核';
                            break;
                        case 'APPROVED':
                            value = '已通过';
                            break;
                        case 'CANCELLED':
                            value = '客户取消';
                            break;
                        case 'CANCEL_CSO':
                            value = '后台取消';
                            break;
                        case 'REJECTED':
                            value = '审批拒绝';
                            break;
                    }
                    return value;
                }*/
            }
        ]
    });
};