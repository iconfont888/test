/***
 *
 * 修改电话号码
 *
 */
$(function () {
    var oldMessage = "";
    var isExisting = false;
    function initPhone() {
        $.request({
            type: 'POST',
            url: "/api/phone/progress",
            async:false
        }).done(function (response) {
            var data = response.data;
            if (response.successful) {
                isExisting = data.isExisting;
                //1:手机修改无进度，2：手机修改中
                if (data.progress === 1) {
                    $("#verifyPhoneForm").show();
                } else {
                    showUpdatePhoneForm();
                }

            }
        });
    }

    /**
     * @description 第一步验证通过，显示第二步验证新手机号码表单
     */
    var showUpdatePhoneForm = function () {
        $('.progress-bg').animate({
            width: 290
        }, 500, function () {
            $(".section-2").fadeIn().siblings().fadeOut();
        });
        $('.arrow').animate({
            left: 225
        }, 500);
    };

    //渲染页面
    initPhone();

    $(".umenu-wrap dd[data-sidebar='u_person_phoneIndex']").addClass("active");
    var $updatePhoneForm = $("#updatePhoneForm"), $umain = $(".u-main");
            var $verifyPhoneForm = $("#verifyPhoneForm"),
                $phoneError = $verifyPhoneForm.find(".js-phone-msg"),
                $accountDigits = $(".num");

    if (isExisting === "true") {
        var ajaxGetPhoneInit = $.request({
            type: "GET",
            url: "/api/phone/bound/init",
            dataType: 'JSON'
        });

        /**
         * 初始化设置电话以及事件绑定
         */
        ajaxGetPhoneInit.done(function (response) {
            if (response.successful) {
                var data = response.data;
                $(".js-show-phone").html(data.phone);
            }
        }).fail(function () {
            layer.open({content: "服务器遇到错误,请联系客服或稍后再试!", title: ' '});
        });
    } else {
        $.validator.addMethod("verifyPhoneCheckCaptchaRemote", function (v, e, param) {
            var verifyStatus = $(e), value = v;
            var method = "verifyPhoneCheckCaptchaRemote";
            var previous = this.previousValue(e, method),
                validator, data, optionDataString;
            if (!this.settings.messages[e.name]) {
                this.settings.messages[e.name] = {};
            }
            previous.originalMessage = previous.originalMessage || this.settings.messages[e.name][method];
            this.settings.messages[e.name][method] = previous.message;
            var oldPhoneVal = $verifyPhoneForm.find("input[name='originalPhone']").val() || '';
            param = typeof param === "string" && {url: param} || param;
            optionDataString = $.param($.extend({data: value}, param.data));
            if (previous.old === optionDataString) {
                return previous.valid;
            }
            this.startRequest(e);
            previous.old = optionDataString;
            validator = this;
            data = {};
            data[e.name] = value;
            data["phone"] = oldPhoneVal;
            data["type"] = "change_phone_old";
            $.request({
                type: "POST",
                url: "/api/sms/verify",
                encrypt: true,
                data: data
            }).done(function (response) {
                var valid = response.successful;
                if (valid) {
                    var submitted = validator.formSubmitted;
                    validator.prepareElement(e);
                    validator.formSubmitted = submitted;
                    validator.successList.push(e);
                    previous.valid = valid;
                    validator.element(e);
                } else {
                    var errors = {};
                    oldMessage = response.message;
                    errors[e.name] = previous.message = "<i></i>" + response.message;
                    validator.invalid[e.name] = true;
                    validator.showErrors(errors);
                }
                previous.valid = valid;
                validator.stopRequest(e, valid);
            });
            return "pending";

        }, "");

        $.validator.addMethod("updatePhoneCheckCaptchaRemote", function (v, e, param) {
            var $e = $(e), value = v;
            var method = "updatePhoneCheckCaptchaRemote";
            var previous = this.previousValue(e, method),
                validator, data, optionDataString;
            if (!this.settings.messages[e.name]) {
                this.settings.messages[e.name] = {};
            }
            previous.originalMessage = previous.originalMessage || this.settings.messages[e.name][method];
            this.settings.messages[e.name][method] = previous.message;

            param = typeof param === "string" && {url: param} || param;
            optionDataString = $.param($.extend({data: value}, param.data));
            var newPhoneVal = $updatePhoneForm.find("input[name='phone']").val() || '';
            if (previous.old === optionDataString && previous.oldNewPhone === newPhoneVal) {
                return previous.valid;
            }
            this.startRequest(e);
            previous.old = optionDataString;
            previous.oldNewPhone = newPhoneVal;
            validator = this;
            data = {};
            data[e.name] = value;
            data["phone"] = newPhoneVal;
            data["type"] = "change_phone_old";
            $.request({
                type: 'POST',
                url: "/api/sms/verify",
                encrypt: true,
                data: data
            }).done(function (response) {
                var valid = response.successful;
                if (valid) {
                    var submitted = validator.formSubmitted;
                    validator.prepareElement(e);
                    validator.formSubmitted = submitted;
                    validator.successList.push(e);
                    previous.valid = valid;
                    validator.element(e);
                } else {
                    var errors = {};
                    oldMessage = response.message;
                    errors[e.name] = previous.message = "<i></i>" + response.message;
                    validator.invalid[e.name] = true;
                    validator.showErrors(errors);
                }
                previous.valid = valid;
                validator.stopRequest(e, valid);
            });
            return "pending";

        }, "");

        /**
         * 第二步 验证新手机号码
         * @description 点击提交表单
         */
        $updatePhoneForm.find(".js-verify-submit").on("click", function () {
            if ($(this).hasClass("progressing-js") || $(this).hasClass("invalid")) {
                return;
            }
            $updatePhoneForm.submit();
        });

        /**
         * 第二步 验证新手机号码
         * @description 表单验证
         */
        $updatePhoneForm.validate({
            onkeyup: null,
            submitHandler: updatePhoneSubmitHandler,
            rules: {
                code: {
                    required: true,
                    minlength: 6,
                    maxlength: 6,
                    digits: true
                },
                phone: {
                    required: true,
                    digits: true,
                    minlength: 11,
                    maxlength: 11,
                    regex: constants.phoneRegular
                }
            },
            messages: {
                code: {
                    required: "<i></i>验证码不能为空",
                    minlength: "<i></i>验证码不能少于6位数",
                    maxlength: "<i></i>验证码不能少于6位数",
                    digits: "<i></i>验证码由6位数字组成"
                },
                phone: {
                    required: "<i></i>新手机号码不能为空",
                    digits: "<i></i>格式不正确，手机号码仅支持输入数字",
                    minlength: "<i></i>手机号码不能少于11位数",
                    maxlength: "<i></i>手机号码由11位数字组成"
                }
            },
            errorElement: "span",
            success: "success",
            showErrors: function () {
                this.defaultShowErrors();
            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parents(".col-2").next('.col-2')
                    .find(".reminder"));
                var $t = element.parents(".col-2").next('.col-2')
                    .find(".reminder span.error");
                if (!$t.find("i").length) {
                    $t.prepend("<i></i>");
                }
            },
            highlight: function (element, errorClass, validClass) {
                $(element).parents(".col-2").next('.col-2').find(".reminder span").addClass("error").removeClass("success");
            },
            unhighlight: function (element, errorClass, validClass) {
                if ($(element).parents(".col-2").next('.col-2').find(".reminder span").length > 1) {
                    $(element).parents(".col-2").next('.col-2').find(".reminder span").last().remove();
                }
                if (element.name === "phone") {
                    $(element).parents(".col-2").next('.col-2').find(".reminder span").html("<i></i>可用").addClass("success").removeClass("error");
                } else {
                    $(element).parents(".col-2").next('.col-2').find(".reminder span").html("<i></i>输入正确").addClass("success").removeClass("error");
                }
            }
        });

        var $btnSendCode = $updatePhoneForm.find(".btn-resend");
        /**
         * 倒计时
         * @param $resend
         * @param time
         */
        var updatePhoneCountdown = function ($resend, time) {
            $resend.agcountdown({
                before: function () {
                    $resend.addClass("timer");
                },
                after: function () {
                    $resend.removeClass("timer");
                },
                stepTime: time,
                buttonText: "{} 秒",
                defaultMsg: "重新发送",
                start: true
            });
        };

        /**
         * 第二步 验证新手机号码
         * @description 发送验证码方法
         */
        function sendCode() {
	        var phone = $updatePhoneForm.find("input[name='phone']").val();
            var $submit = $updatePhoneForm.find(".btn-resend");
            var re = new RegExp(constants.phoneRegular);	 //判断用户名是否正确
            if (lib.hasValue(phone) && re.test(phone)) {
	            if ($submit.hasClass("progressing-js")) {
                    return;
                }
                $submit.addClass("progressing-js");
                $umain.loading({multiple: true});
                $.request({
                    type: 'POST',
                    url: "/api/sms",
                    encrypt: true,
                    data: {"type": 'change_phone_new', "phone": phone}
                }).done(function (response) {
                    if (response.successful) {
                        $btnSendCode.agcountdown({
                            stepTime: 10,
                            after: function () {
                                updatePhoneCountdown($btnSendCode, 290);
                            },
                            buttonText: "已发送<li class='fa fa-check'></li>",
                            defaultMsg: "重新发送",
                            start: true
                        });
                    } else if (response.code === 6008) {
	                    updatePhoneCountdown($btnSendCode, response.message.replace(/[^\d]*/g, ""));
                    } else {
	                    if (response.message.indexOf("号码") > -1 || response.message.indexOf("电话") > -1) {
                            $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + response.message});
                        } else {
		                    $updatePhoneForm.validate().showErrors({"code": "<i></i>" + response.message});
                        }
                    }
                }).always(function () {
                    $umain.loading(false);
                    $submit.removeClass("progressing-js");
                });
            } else {
	            $updatePhoneForm.validate().element($updatePhoneForm.find("input[name='phone']"));
	            if(constants.INTERNET_PHONE_REGEX.test(phone)) {
		            $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "无效号码，属于网络运营商"});
	            } else if(!constants.phoneRegular.test(phone) && phone.length === 11) {
		            $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "手机号码不正确"});
	            }
            }
        }

        /**
         * 第二步 验证新手机号码
         * @description 点击调用发送验证码方法
         */
	    $btnSendCode.on("click", function () {
            sendCode();
        });

	    $("#newPhone").blur(function () {
		    var phone = $(this).val();
		    if(constants.INTERNET_PHONE_REGEX.test(phone)) {
			    $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "无效号码，属于网络运营商"});
		    } else if(!constants.phoneRegular.test(phone) && phone.length === 11) {
			    $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "手机号码不正确"});
		    }
	    });

        /**
         * 第二步 验证新手机号码
         * @description 表单验证通过后提交处理方法
         * @param form
         */
        function updatePhoneSubmitHandler(form) {
            var $form = $(form), submit = $form.find(".btn-submit");
            $umain.loading({multiple: true});
            var newPhone = $form.find("input[name='phone']").val();
            var code = $form.find("input[name='code']").val();
            $.request({
                type: 'PUT',
                url: "/api/phone",
                encrypt: true,
                data: {phone:newPhone,code:code}
            }).done(function (response) {
                if (response.successful) {
                    $(".section-3").find(".forms-input p").text(response.data);
                    $('.progress-bg').animate({
                        width: 466
                    }, 500, function () {
                        $(".section-3").fadeIn().siblings().fadeOut();
                    });
                    $('.arrow').animate({
                        left: 415
                    }, 500);
                } else {
                    var message = response.data || response.message;
                    if (message.indexOf("号码") > -1 || message.indexOf("电话") > -1) {
                        $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + message});
                    } else {
                        $updatePhoneForm.validate().showErrors({"code": "<i></i>" + message});
                    }
                }
            }).always(function () {
                submit.prop("disabled", false);
                $umain.loading(false);
            });
        }

        /**
         * 初始化设置电话以及事件绑定
         */
        $.request({
            type: "GET",
            url: "/api/phone/bound/init",
            dataType: 'JSON'
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                var _phone = data.phone.replace(/\*/g, ""), isVerified = data.isVerified;
                $(".phone-prefixes").text(_phone.substring(0, 3));
                $(".phone-suffix").text(_phone.substring(_phone.length - 1, _phone.length));
                if (isVerified) {
                    //  验证成功
                    $('.progress-bg').animate({
                        width: 290
                    }, 500, function () {
                        $(".section-2").fadeIn().siblings().fadeOut();
                    });
                    $('.arrow').animate({
                        left: 225
                    }, 500);
                }
            }
        }).fail(function () {
            layer.open({
                content: "服务器遇到错误,请联系客服或稍后再试!",
                title: ' ',
                btn: ['确认']
            });
        });


        $('input').keyup(function () {
            var $emptyFields = $('.section-1 :input').filter(function () {
                return $.trim(this.value) === "";
            });
            var $emptyFields2 = $('.section-2 :input').filter(function () {
                return $.trim(this.value) === "";
            });
            if (!$emptyFields.length) {
                $('.section-1 .submit a').removeClass('invalid').attr('data-selection', 'section-2');

            }
            if (!$emptyFields2.length) {
                var phone = $("#newPhone").val();

                if(constants.INTERNET_PHONE_REGEX.test(phone)) {
                    $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "无效号码，属于网络运营商"});
                    $('.section-2 .submit a').addClass('invalid');
                } else if(!constants.phoneRegular.test(phone) && phone.length === 11) {
                    $updatePhoneForm.validate().showErrors({"phone": "<i></i>" + "手机号码不正确"});
                    $('.section-2 .submit a').addClass('invalid');
                }else{
                    $('.section-2 .submit a').removeClass('invalid').attr('data-selection', 'section-3');
                }
            }
        });

        /**
         * 验证输入的原手机号码是否正确
         */
        var verifyPhoneRight = function (phone) {
            if (!lib.hasValue(phone) || phone.length === 4) {
                $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + "原手机号码不能为空");
                return;
            } else if (!new RegExp(constants.phoneRegular).test(phone)) {
                $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + "手机号码输入不完整");
                return;
            }
            return $.request({
                type: 'POST',
                url: '/api/phone/original',
                data: {phone: phone},
                encrypt: true,
                dataType: "json"
            }).done(function (response) {
                if (!response.successful) {
                    var message = response.data || response.message;
                    if (response.code === 5050) {
                        $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + message);
                    } else {
                        $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + message);
                    }
                } else {
                    $phoneError.addClass("success").removeClass("error").html('<i></i>输入正确');
                }
            });
        };

        var $btnSendCodeVerify = $verifyPhoneForm.find(".btn-resend");

        /**
         * 第一步 验证原手机号码
         * @description 异步发送手机验证码方法
         */
        function ajaxVerifyPhoneSendCode() {
            var phone = $verifyPhoneForm.find("input[name='originalPhone']").val().toLowerCase();
            var verifyPhoneRightVal = verifyPhoneRight(phone);
            if (!verifyPhoneRightVal) {
                return;
            }
            verifyPhoneRightVal.done(function (response) {
                if (response.successful) {
                    $(".u-main").loading({multiple: true});
                    $.request({
                        type: 'POST',
                        url: "/api/sms",
                        encrypt: true,
                        data: {type: 'change_phone_old', phone: phone}
                    }).done(function (response) {
                        var time = 300;
                        if (response.successful) {
                            $btnSendCodeVerify.agcountdown({
                                stepTime: 10,
                                after: function () {
                                    updatePhoneCountdown($btnSendCodeVerify, 290);
                                },
                                buttonText: "已发送<li class='fa fa-check'></li>",
                                defaultMsg: "重新发送",
                                start: true
                            });
                        } else if (response.code === 5002) {
                            time = response.message.replace(/[^\d]*/g, "");
                            updatePhoneCountdown($btnSendCodeVerify, time);
                        } else {
                            $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + response.message);
                        }
                    }).fail(function () {
                        layer.open({
                            content: '服务器遇到错误,请联系客服或稍后再试!',
                            btn: ['确认']
                        });
                    }).always(function () {
                        $(".u-main").loading(false);
                    });
                }
            });
        }

        /**第一步 验证原手机号码
         * @description 点击发送手机验证码
         **/
        $btnSendCodeVerify.on("click", function () {
            ajaxVerifyPhoneSendCode();
        });

        /**
         * 第一步 验证原手机号码
         * @description 点击提交表单
         */
        $verifyPhoneForm.find(".js-verify-submit").on("click", function () {
            if ($(this).hasClass("progressing-js") || $(this).hasClass("invalid")) {
                return;
            }
            var $originalPhone = $verifyPhoneForm.find("input[name='originalPhone']");
            if (!$originalPhone.val()) {
                $phoneError.show().addClass("error").removeClass("success").html("<i></i>" + "手机号码输入不完整");
                return;
            }
            $verifyPhoneForm.submit();
        });
        /**
         * 第一步 验证原手机号码
         * @description 表单验证
         */
        $verifyPhoneForm.validate({
            onkeyup: null,
            submitHandler: function (form) {
                var $form = $(form), submit = $form.find(".js-verify-submit");
                if (submit.hasClass("progressing-js") || submit.hasClass("invalid")) {
                    return;
                }
                submit.addClass("progressing-js");
                $(".u-main").loading();
                var originalPhone = $form.find("input[name='originalPhone']").val();
                var code = $form.find("input[name='code']").val();
                $.request({
                    type: 'POST',
                    url: "/api/sms/verify",
                    encrypt: true,
                    data: {
                        "type": "change_phone_old",
                        "code": code,
                        "phone": originalPhone
                    }
                }).done(function (response) {
                    if (response.successful) {
                        showUpdatePhoneForm();
                    } else {
                        var message = response.message;
                        if (message.indexOf("号码") > -1 || message.indexOf("电话") > -1) {
                            $phoneError.show().html("<i></i>" + message);
                        } else {
                            $verifyPhoneForm.validate().showErrors({"code": "<i></i>" + message});
                        }
                    }
                }).always(function () {
                    submit.removeClass("progressing-js");
                    $(".u-main").loading(false);
                });
            },
            rules: {
                code: {
                    required: true,
                    rangelength: [6, 6],
                    digits: /^\d{6}$/
                }
            },
            messages: {
                code: {
                    required: "<i></i>验证码不能为空",
                    rangelength: "<i></i>验证码不能少于6位数",
                    digits: "<i></i>验证码由6位数字组成"
                }
            },
            errorElement: "span",
            success: "success",
            showErrors: function () {
                this.defaultShowErrors();
            },
            errorPlacement: function (error, element) {
                if (element.attr("name") === "code") {
                    error.appendTo(element.parents(".col-2").next('.col-2')
                        .find(".reminder"));
                    var $t = element.parents(".col-2").next('.col-2')
                        .find(".reminder span.error");
                    if (!$t.find("i").length) {
                        $t.prepend("<i></i>");
                    }
                }
            },
            highlight: function (element, errorClass, validClass) {
                if (element.name === "code") {
                    $(element).parents(".col-2").next('.col-2').find(".reminder span").addClass("error").removeClass("success");
                }
            },
            unhighlight: function (element, errorClass, validClass) {
                if (element.name === "code") {
                    if ($(element).parents(".col-2").next('.col-2').find(".reminder span").length > 1) {
                        $(element).parents(".col-2").next('.col-2').find(".reminder span").last().remove();
                    }
                    $(element).parents(".col-2").next('.col-2').find(".reminder span").html("<i></i>输入正确").addClass("success").removeClass("error");
                }
            }

        });

        $accountDigits.keypress(function () {
            this.value = "";
        }).keydown(function (e) {
            if (this.value === "") {
                if ((e.which === 8 || e.which === 46) && $(this).text() === '') {
                    $(this).parent().prev().find('.num').val('').focus();
                }
            }
        }).keyup(function () {
            if (this.value && !/\d/g.test(this.value)) {
                $(this).val("");
                return;
            }
            if (this.value.length === this.maxLength) {
                $(this).parent().next().find('.num').prop("disabled", false).focus();
            }
            $accountDigits.removeClass('active');
        }).on("blur input", function () {
            var prefixes = $verifyPhoneForm.find(".phone-prefixes").text(),
                suffix = $verifyPhoneForm.find(".phone-suffix").text(),
                middle = "";
            $verifyPhoneForm.find("#originalPhone").val("");
            $accountDigits.each(function (index, item) {
                middle += $(item).val();
            });
            var phone = prefixes + middle + suffix;
            $verifyPhoneForm.find("#originalPhone").val(phone);
            verifyPhoneRight($verifyPhoneForm.find("#originalPhone").val());
        });

        /**
         * 第一步 验证原手机号码
         * @description 输入框请做限制，限制验证码最多只能填写6位数，输入6位数又继续输入时，出现提示：验证码最多只有6位数
         */
        $verifyPhoneForm.find("input[name='code']").on("propertychange input", function () {
            var $this = $(this);
            var pwd = $this.val();
            if (pwd.length > 6) {
                $verifyPhoneForm.validate().showErrors({"code": "<i></i>验证码最多只有6位数"});
                $this.val($this.val().substr(0, 6));
            }
        });

        /**
         * 第二步 验证新手机号码
         * @description 输入框请做限制，限制验证码最多只能填写6位数，输入6位数又继续输入时，出现提示：验证码最多只有6位数
         */
        $updatePhoneForm.find("input[name='code']").on("propertychange input", function () {
            var $this = $(this);
            var pwd = $this.val();
            if (pwd.length > 6) {
                $updatePhoneForm.validate().showErrors({"code": "<i></i>验证码最多只有6位数"});
                $this.val($this.val().substr(0, 6));
            }
        });
    }
});