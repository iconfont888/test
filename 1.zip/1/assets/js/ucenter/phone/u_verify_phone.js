$(document).ready(function() {
//    $(".umenu-wrap dd[data-sidebar='u_person_phoneIndex']").addClass("active");
    new VerifyHandler({
        form: $("#verifyPhoneForm"),
        url: "/ucenter/account/",
        isInitSend: false
    }).init();
});
