/***
 *
 * 站内信
 *
 */
$(function () {
    var $verifyPhoneForm = $("#verifyPhoneForm"), $subscribe = $(".js-table-subscribe");
    var verifyHandler = new VerifyHandler({
        url: "/ucenter/subscribe",
        form: $verifyPhoneForm,
        showPhone: $(".js-show-phone"),
        isInitSend: false,
        loadingElement: $(".mobile-wrap"),
        validate: {
            errorClass: "empty",
            errorPlacement: function (error) {
                $verifyPhoneForm.find(".error-msg")
                    .removeClass("success").addClass("error failure").html(error);
            },
            success: function (label) {
                for (var i = 0; i < label.length; i++) {
                    $(label).parent().removeClass("error failure success").empty();
                }
            }
        }
    });

    var _deferred = $.Deferred();

    // 初始化查询手机号码验证状态
    var verified = function (res) {
        $verifyPhoneForm.remove();
        res.data['isVerified'] = true;
        _deferred.resolve(res);
    };
    var unverified = function (res) {
        res.data['isVerified'] = false;
        _deferred.resolve(res);
        $subscribe.loading({multiple: true, onlyMask: true});
    };
    var failure = function (res) {
        _deferred.reject(res);
    };

    //  初始化短信订阅配置
    var setSubscribe = function (config) {
        return '<tr>'
            + '     <td>登录提示</td>'
            + '     <td><label class="switcher"><input name="login" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.login === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '     <td>优惠添加</td>'
            + '     <td><label class="switcher"><input name="promotions" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.promotions === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '</tr>'
            + '<tr class="highlight">'
            + '     <td>联系电话修改</td>'
            + '     <td><label class="switcher"><input name="modifyPhone" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.modifyPhone === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '     <td>银行资料修改</td>'
            + '     <td><label class="switcher"><input name="modifyBankingData" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.modifyBankingData === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '</tr>'
            + '<tr>'
            + '     <td>充值提示</td>'
            + '     <td><label class="switcher"><input name="deposit" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.deposit === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '     <td>姓名修改</td>'
            + '     <td><label class="switcher"><input name="modifyAccountName" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.modifyAccountName === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '</tr>'
            + '<tr class="highlight">'
            + '     <td>提现提示</td>'
            + '     <td><label class="switcher"><input name="withdrawal" class="type-sms" type="checkbox" ' + (config.smsSubscribeVO.withdrawal === 1 ? 'checked' : '') + '><span><i></i></span></label></td>'
            + '     <td></td>'
            + '     <td></td>'
            + '</tr>';
    };
    var subscribeHandler = function ($current) {
        $subscribe.loading({multiple: true});
        $.request({
            type: 'PUT',
            url: '/api/sms/subscribe',
            data: {'configAttrName': $current.attr("name")},
            dataType: 'JSON'
        }).done(function (res) {
            if (res.successful) {
                // To success
            } else {
                $current.prop("checked", !!$current.attr("checked"));
                var html = "<li class='list-group-item list-group-item-warning'>" + res.message + "</li>";
                layer.alert(html, {title: ' '});
            }
        }).fail(function(e){
            logConsole(e);
        }).always(function () {
            $subscribe.loading(false);
        });
    };
    var initSubscribes = function (res) {
        if (res.successful) {
            var tbody = setSubscribe(res.data);
            $(tbody).on("change", "input.type-sms", function () {
                var $this = $(this), isVerified = $("#verifyPhoneForm").length;
                if (!isVerified) {
                    subscribeHandler($this);
                } else {
                    $this.prop("checked", !!$this.attr("checked"));
                    var html = "<li class='list-group-item list-group-item-warning'>请先验证手机号码</li>";
                    layer.alert(html, {title: ' '});
                }
            }).appendTo($subscribe.find("tbody"));
        }
    };

    _deferred.promise(verifyHandler.verified(verified, unverified, failure))
        .done(function (res) {
            verifyHandler.init(res.data.isVerified)
        })
        .done(function (res) {
            initSubscribes(res);
        });
});