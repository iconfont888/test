var UCenterHelper = function () {
    if (window.uCenterHelper) {
        return window.uCenterHelper;
    }
    this.getBalance = function () {
        return $.request({
            type: 'GET',
            url: "/api/balance",
            dataType: 'json',
            cache: false
        });
    };
    this.getWeeksBetAmount = function () {
        return $.request({
            type: 'GET',
            url: "/api/rebate/week-record",
            dataType: 'json',
            cache: false
        })
            .then(function (response) {
                return response.data;
            })
            .fail(function () {
                return 0;
            });
    };
    this.vipLevelAmount = function (level) {
        var list = [50000000, 100000000];

        if (level === undefined) {
            return list;
        }
        return list[level];
    }
};
window.uCenterHelper = new UCenterHelper();
