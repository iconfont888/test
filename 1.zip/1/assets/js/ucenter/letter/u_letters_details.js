/***
 *
 * 站内信
 *
 * <p>date: 2017/12/1
 * <p>time: 16:22
 *
 */
$(function () {
    //historyPage.history.pop();
    var id = utils.getQueryString('id');
    $.request({
        url: '/api/letters/detail/'+parseInt(id),
        success: function (response) {
            var res = response.data;
            if (!response.successful) {
                var errorLayer = layer.open({
                    title: ' ',
                    className: 'icon-no',
                    btn: ['确定'],
                    btnActive: 0,
                    btnClose: false,
                    content: '<p id="'+res.id+'">'+response.message+'</p>',
                    yes: function() {
                        layer.close(errorLayer);
                        window.location.href = "/ucenter/letters";
                    }
                });
                return;
            }
            if(!_VALID.isNormal(res.data)){
                $('.u-letter').find('.panel.panel-default')[1].show();
                $('.u-letter').find('.panel.panel-default')[0].hide();
                return;
            }
            setHeaderUnreadMessages();
            var data = res.data;
            var icon = data["icon"],
                iconLink = data["iconLink"],
                title = data["title"],
                createdDate = data["createdDate"],
                content = data["content"];
            var $content = $("<div>"+content+"</div>");
            content = $content.text();
            var imgTag = "";
            createdDate = createdDate.substr(0, 16);
            if(_VALID.isNormal(icon)){
                imgTag = "<img src="+icon+">";
                if(_VALID.isNormal(iconLink)){
                    imgTag = "<a href='"+iconLink+"'>" + imgTag + "</a>";
                }
            } else {
                $('.u-letter').find('.u-letter-body')[0].remove();
            }
            var elements = $('<h2 style="word-break: break-word;">'+title+'</h2>'
            +imgTag
            +'<div class="msg-content" style="word-break: break-word;">'+content+'<div class="time">'+createdDate+'</div>'+'</div>');

            $('.u-letter-title').html(title+'<small>'+createdDate+'</small>');
            $('.u-letter-body .ug-image img').attr("src",icon);
            $('.u-detail').html('<span id="'+data.id+'">'+content+'</span>');
        },
        error: function(xhr,textStatus,err){
			console.log("error: " + err);
		}
    });
});
