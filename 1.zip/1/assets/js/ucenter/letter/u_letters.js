/***
 *
 * 站内信
 *
 */
$(function () {
    var $list = $(".letter-list");
    var _STATUS = {
        all: "ALL",// 全部
        read: "READ",// 已读
        unread: "UNREAD"// 未读
    };
    var _MSGTYPE = {
        notice:1,
        preferential:0
    }
    if ($list.length) {
        var buildHtml = function (index, page, item, msgType) {
            var id = item["id"],
                title = item["title"],
                contentLenth = item["content"][0],
                icon = item["icon"],
                planSendtime = item["planSendtime"],
                createDate = item["createdDate"],
                // iconLink = item["iconLink"],
                status = item["status"];
            if(planSendtime){
                createDate = planSendtime;
            }
            createDate = createDate.substring(0,16);
            contentLenth = contentLenth.replace(/\/\*[\s\S]*?\*\//g, "").replace(/<!--[\s\S]*?-->/g, "");//删除注释
            var $content = $("<div>"+contentLenth+"</div>");
            var content = null;
            if($content.html().indexOf("<img")>-1){
                content = $content.html().replace(/<(?!\/?img)[^<>]*>/ig,"");
            }else{
                content = $content.text();
                content = content.length > 58? content.substring(0,60)+"...":content;
            }
            var imgTag = "";
            if((icon != "" && icon != undefined)&& index == 0){
                imgTag += "<img src='"+icon+"' alt>"
            }
            var classStatus = status === 0 ? "not-read" : "";
            var hrefA = '/ucenter/letter/details/index.html?id=' + id + "&msgType=" + msgType;
            var retr = '<li>' +
                '<input type="checkbox" class="form-control" value="'+id+'">' +
                '<a class="trun-right" href="'+hrefA+'">' +
                '<h3 class="' + classStatus + '">' + title + '<span class="s-right">' + createDate + '</span></h3>' +
                '<p>' + content + '</p>' +
                imgTag + '</a>' +
                '</li>';
            return retr;
        };

        var getLetterData = function (page, status, msgType, init) {
            var _d = $.Deferred();
            page = page || 1;
            $(".u-main").loading();
            $(".letter-list").empty();
            $("#pagging").empty();
            $.request({
                type: 'GET',
                url: "/api/letters?msgType=" + msgType + "&page_number=" + page + "&page_size=" + 6 + "&status=" + status,
                dataType: 'JSON'
            }).done(function (response) {
                var data = response.data;
                if (response.successful) {
                    var list = data["details"] || [];
                    var total;
                    if(msgType == 0){
                        total = data["total"]["perferential"];
                    }else {
                        total = data["total"]["notice"];
                    }
                    if(total == 0){
                        $("#pagging>").remove();
                        $(".list-group").append("<li style='text-align: center;'><h3>暂无数据</h3></li>");
                    }
                    if (list.length > 0) {
                        var tabHtml = [];
                        $.each(list, function (index, item) {
                            tabHtml.push(buildHtml(index,page,item,msgType));
                        });
                        $(".letter-list").html(tabHtml.join(""));
                        _d.resolve({isEmpty: false});
                        $.jqPaginator('#pagging',{
                            totalCounts: total,
                            pageSize: 6,
                            visiblePages: 3,
                            currentPage: page,
                            prev: ' <li style="margin:0 4px"><a href="#">上一页</a></li>',
                            next: ' <li style="margin:0 4px"><a href="#">下一页</a></li>',
                            page: '<li style="margin:0 4px"><a href="#">{{page}}</a></li>',
                            onPageChange: function (num, type) {
                                if (num != page) {
                                    getLetterData(num, status,msgType,false);
                                }
                            }
                        });
                    } else {
                        _d.resolve({isEmpty: true});
                    }

                    //绑定事件
                    unbind();
                    bind();
                } else {
                    $list.append("<li style='text-align: center;'><h3>" + data + "</h3></li>")
                    _d.resolve({isEmpty: true});
                }
                var flag = $('#male').prop('checked');
                if(flag){
                    $('.u-letter .list-group input[type=checkbox]').prop('checked',flag);
                }
            }).always(function () {
                $(".u-main").loading('close');
            });
            return _d;
        };

        var bind = function () {
            $('#male').on('click', function () {
                var flag = $(this).prop('checked');
                $('.u-letter .list-group input[type=checkbox]').prop('checked', flag);
                $("label.btn-select-all").text(!flag ? '全选' : '取消全选');
            });
            $('.u-letter .btn-del').on('click', function () {
                var $values = $('.u-letter .list-group input:checked');
                var $all = $("#male").is(':checked');
                var msgType = $(".yh-tabs .active a").attr("data-value");
                if ($values.length) {
                    var ids = [];
                    $values.each(function (index, item) {
                        ids.push(item.value);
                    });
                    $(".u-letter").loading();
                    $.request({
                        type: 'DELETE',
                        url: "/api/letters/"+msgType+"?ids="+ids.join(","),
                        dataType: 'JSON',
                        cache: false
                    }).done(function () {
                        /* To success */
                    }).always(function () {
                        $(".yh-tabs li.active").find("a").trigger("click");
                        updataUnRead();
                        // window.location.reload();
                    });
                } else {
                    layer.alert("<li class='list-group-item list-group-item-warning'>请选择需要\<删除\>的消息</li>", {title: ' '});
                }
            });
            $('.u-letter .btn-cancel').on('click', function () {
                var $values = $('.u-letter .list-group input:checked');
                var $all = $("#male").is(':checked');
                var msgType = $(".yh-tabs .active a").attr("data-value");
                if ($values.length) {
                    $(".u-content").loading();
                    var ids = [];
                    $values.each(function (index, item) {
                        ids.push(item.value);
                    });
                    $.request({
                        type: 'PUT',
                        url: "/api/letters/READ",
                        dataType: 'JSON',
                        data: {
                            ids: ids.join(","),
                            'msgType': msgType
                        },
                        cache: false
                    }).done(function (res) {
                        var success = res.successful, data = res.data;
                        if (success) {
                            // window.location.reload();
                            $(".yh-tabs li.active").find("a").trigger("click");
                            updataUnRead();
                        } else {
                            layer.alert("<li class='list-group-item list-group-item-warning'>" + data + "</li>", {title: ' '});
                        }
                    }).fail(function () {
                        layer.alert("服务器遇到错误,请联系客服或稍后再试!", {title: ' '});
                    }).always(function () {
                        $(".u-content").loading("close");
                    });
                } else {
                    layer.alert("<li class='list-group-item list-group-item-warning'>请选择需要\<标记已读\>的消息</li>", {title: ' '});
                }
            });
        };

        var unbind = function () {
            $('.u-letter .btn-select-all').off('click');
            $('.u-letter .btn-del').off('click');
            $('.u-letter .btn-cancel').off('click');
        };

        var init = function (page, status, msgType) {
            getLetterData(page, status, msgType, true)
        };

        init($list.data("init"), _STATUS.all,_MSGTYPE.preferential);

        $(".dropdown-menu li a").on("click", function () {
            $(".u-letter .btn-select-all").data('checked', false);
            var msgType = $(".yh-tabs").find("li.active>a").attr("data-value");
            init(1, $(this).data("href"),msgType);
        });

        $("a[data-toggle=tab]").on("click",function () {
            var msgType = $(this).attr("data-value");
            getLetterData(1,_STATUS.all,msgType,true);
        })
    };

});

$(function () {
    //初始化站内信详情
    var id = utils.getQueryString("id");
    var msgType = utils.getQueryString("msgType");
    //如果浏览器参数中没有id就显示没有站内信
    if(!id){
        $("#noDetail").removeClass("hide");
        return false;
    }
    $.request({
        url: '/api/letters/detail/' + id,
        data: {'msgType': msgType}
    }).done(function (response) {
        if (response.successful) {
            var data = response.data;
            if (data.data) {
                var detail = data.data;
                $("#redDetail").removeClass("hide");
                $("#redDetail .idTitle").attr("id", detail.id);

                $("#redDetail .idTitle span").html(detail.title);
                //时间需要格式化
                var times = detail.createdDate.substring(0, 16);
                var planSendtime = detail["planSendtime"];
                if(planSendtime){
                    times = planSendtime.substring(0, 16);
                }
                $("#redDetail .idTitle small").html(times);

                var $content = $("<div>" + detail.content + "</div>");

                $("#redDetail .details-box").html($content.text());
                var fenyeHtml = "";
                if (data.preIndex > 0) {
                    fenyeHtml += '<a href="/ucenter/letter/details/index.html?id=' + data.preIndex + '&msgType=' + detail.msgType + '" class="btn-submit"> 上一篇 </a>';
                }
                if (data.nextIndex > 0) {
                    fenyeHtml += '<a href="/ucenter/letter/details/index.html?id=' + data.nextIndex + '&msgType=' + detail.msgType + '" class="btn-submit"> 下一篇 </a>';
                }
                fenyeHtml += '<a href="/ucenter/letters" class="btn-submit">返 回</a> <a class="btn-submit btn-del pointer-link">删除</a>';
                $("#redDetail .u-letter-foot").html(fenyeHtml);

                if (detail.icon) {
                    $("#havedetailicon").removeClass("hide");
                    $("#havedetailicon a").attr("href", detail.iconLink);
                    $("#havedetailicon img").attr("src", detail.icon);
                }
            } else {
                $("#noDetail").removeClass("hide");
            }
        } else {
            if (response.code === 500) {
                $("#noDetail").removeClass("hide");
            }
        }
    });

    var $title = $(".u-letter-title");
    if ($title.length) {
        var id = $title.find("p").attr("id");
        if (id) {
            //标记为已读
            $.request({
                type: "PUT",
                url: '/api/letters/READ',
                data: {
                    "ids": id,
                    "msgType": msgType
                },
                dataType: "JSON"
            });
        }

        // 删除站内信详情
        $("body").on("click", ".u-details .btn-del", function(){
            var id = $title.find("p").attr("id");
            $(".u-content").loading();
            $.request({
                type: 'DELETE',
                url: "/api/letters/"+msgType+"?ids="+id
            }).done(function () {
            }).always(function () {
                window.location.href = "/ucenter/letters";
            });
        });
    }
})

//更新未读
function updataUnRead() {
    $.request({
        url: '/api/letters/unread'
    }).done(function (res) {
        if(res.successful){
            var data = res.data;
            var noticeCount = data.notice;
            var perferentialCount = data.perferential;
            var count = noticeCount + perferentialCount;
            count > 0?$(".badge.letter").text(count).show():$(".badge.letter").hide();
            var $yhTabs = $(".yh-tabs");
            if ($yhTabs.length) {
                setUnRead($yhTabs,perferentialCount,noticeCount);
            }
        }else{
            logConsole(res.message);
        }
    }).fail(function(e){
        logConsole(e);
    });
};

//  设置未读
function setUnRead($yhTabs,perferential,notice){
    var perferentialTag = $yhTabs.find("a[data-value=0]");
    var noticeTag = $yhTabs.find("a[data-value=1]");
    if(perferential){
        noticeTag.parent().find(".badge").remove();
        perferentialTag.parent().append('<em class="badge">' + perferential + '</em>');
    } else {
        perferentialTag.parent().find(".badge").remove();
    }
    if (notice) {
        noticeTag.parent().find(".badge").remove();
        noticeTag.parent().append('<em class="badge">' + notice + '</em>');
    } else {
        noticeTag.parent().find(".badge").remove();
    }
};
