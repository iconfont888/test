/**
 * Created by Lorry on 2017/6/14.
 */
var $jsGrid = $("#tab_grid");
$(function() {
    initData();

    $jsGrid.jsGrid({
        width: "100%",
        height: "auto",
        paging: true,
        pageLoading: true,
        pageSize: 8,
        pageIndex: 1,
        autoload: true,
        pagerContainer: "#tab_paging",
        pagePrevText: "<",
        pageNextText: ">",
        pageButtonCount: 5,
        pageNavigatorNextText: "&#8230;",
        pageNavigatorPrevText: "&#8230;",
        pageFirstText: "<<",
        pageLastText: ">>",
        pagerFormat: " {first} {prev} {next} {last} ",
        noDataContent: "<div class='no-data'>暂无数据！</div>",
        loadShading: true,
        controller: {
            loadData: function(filter) {
                var d = $.Deferred();

                $.ajax({
                    url: "/api/friends/recommend-data",
                    type: "get",
                    accept: "application/json",
                    dataType: "json",
                    headers: {
                        "X-Website-Code": "MAIN_PC"
                    },
                    data: {
                        page_number: filter.pageIndex,
                        page_size: filter.pageSize
                    }
                }).done(function(response) {
                    if (response['customer.error.message']) {
                        d.resolve({ data: [], itemsCount: 0 });
                        return;
                    }
                    d.resolve({
                        data: response.data.data,
                        itemsCount: response.data.total
                    });

                    var begin_size = (filter.pageIndex - 1) * filter.pageSize;
                    begin_size += 1;
                    var end_size = begin_size + response.data.data.length;
                    end_size -= 1;
                    var place_total = response.data.total;
                    if (place_total == 0) {
                        begin_size = 0;
                    }

                    $('.page_angle').text('显示' + begin_size + '到' + end_size + ',共' + place_total + '记录');

                    if (place_total == 0) {
                        $('.total_page_pl').parent().find('input').val(0);
                    } else {
                        $('.total_page_pl').parent().find('input').val(filter.pageIndex);
                    }
                    var _pages = parseInt((place_total / filter.pageSize)) + ((place_total % filter.pageSize) > 0 ? 1 : 0);
                    $('.total_page_pl').text(' 共 ' + _pages + ' 页');

                }).fail(function() {
                    d.resolve({ data: [], itemsCount: 0 });
                });
                return d.promise();
            }
        },
        fields: [
            { name: "loginName", title: "被推荐人", type: "text", width: 70, align: 'center' },
            {
                name: "validState",
                title: '推荐状态<span type="button" class="btn-link" data-toggle="tooltip" data-placement="top" title="1星级及以上的被推荐人，将视为有效活跃会员。如果您朋友是无效会员，请让您的好友进行充值，充值成功后即可自动成为有效会员。"><i class="fa fa-question-circle"></i></span>',
                type: "text",
                width: 70,
                align: 'center',
                itemTemplate: function(value, item) {
                    var flag = "";
                    if (value === 1) {
                        flag = "有效";
                    } else {
                        flag = "无效";
                    }
                    return flag;
                }
            },
            {
                name: "contributionLimit",
                title: "有效投注额",
                type: "text",
                width: 60,
                align: 'center',
                itemTemplate: function(value, item) {
                    return (value).toFixed(2);
                }
            },
            {
                name: "agentCommission",
                title: "奖金金额",
                type: "text",
                width: 60,
                align: 'center',
                itemTemplate: function(value, item) {
                    return (Math.round(value * 100) / 100).toFixed(2);
                }
            }
        ]
    });
    $("#tab_grid").css("position", 'static');

    $('[data-toggle="tooltip"]').tooltip();

    $('#bort_copy_code').click(function() {
        load_bord_code();
    });
    $('#btnCopy').click(function() {
        load_bord_link();
    });
    pagingFooter($('#tab_paging'), $('#paging-4-grid'));
});

function getRealTime(value) {
    /**
     *
     * @author candice
     * 解决问题： ie时间问题解决
     *
     **/
    return new Date(Date.parse(value.replace(/-/g, "/")));
}

function initData() {
    var recommendCode = "";
    var recommendCommission = '0.00';
    var totalValidCustomers = '0';
    var validTurnover = '0.00';
    var amountYear = '0.00';
    //请求初始化接口
    /* var _index = utils.loading();*/
    $.request({
        url: '/api/friends'
    }).done(function(response) {
        var data = response.data;
        if (response.successful) {
            $("#startDateTime").html(getRealTime(data.startDateTime).format("yyyy-MM-dd"));
            $("#endDateTime").html(getRealTime(data.endDateTime).format("yyyy-MM-dd"));
            $("#year_friend").html(getRealTime(data.startDateTime).format("yyyy"));
            var amountYear = data.amountYear;
            $(".total-bet-year-js").html(amountYear == 0 ? '0.00' : utils.amountFormatter(amountYear));
            recommendCode = data.recommendCode;
            //总佣金
            recommendCommission = data.recommendCommission;
            //推荐好友数量
            totalValidCustomers = data.totalValidCustomers;
            //总有效投注额
            validTurnover = data.validTurnover;
        }

        if (recommendCode) {
            $('#codetext').html(recommendCode);
            $('#recommend-code-copy').text(recommendCode);
            $.request({
                url: '/api/customer/domain'
            }).done(function(res) {
                var recommendlink = res.successful && res.data.domainName && res.data.status == 1 ? res.data.domainName.replace(/(\/*$)/g, "") + "/register" : location.href.replace(/(^.*?\/\/.*?\/).*/, "$1") + "/register?recommendcode=" + recommendCode;
                $('#recommend-link').val(recommendlink);
                var mobilelink;
                if (pn && pn.moblefrend && pn.host) {
                    mobilelink = res.successful && res.data.domainName && res.data.status == 1 ? res.data.domainName.replace(/(\/*$)/g, "") + "/register" : pn.host.replace(/(\/*$)/g, "") + "/register?recommendcode=" + recommendCode;
                    createQr(pn.moblefrend + '?url=' + $.base64.encode(mobilelink));
                } else {
                    $.request({
                        url: '/api/app/downloadUrl'
                    }).done(function(res1) {
                        if (res1.successful) {
                            AG_INIT.resetParam("moblefrend", res1.data.moblefrend);
                            AG_INIT.resetParam("host", res1.data.host);
                            mobilelink = res.successful && res.data.domainName && res.data.status == 1 ? res.data.domainName.replace(/(\/*$)/g, "") + "/register" : res1.data.host.replace(/(\/*$)/g, "") + "/register?recommendcode=" + recommendCode;
                            createQr(res1.data.moblefrend + '?url=' + $.base64.encode(mobilelink));
                        } else {
                            mobilelink = res.successful && res.data.domainName && res.data.status == 1 ? res.data.domainName.replace(/(\/*$)/g, "") + "/register" : (pn && pn.mainMobileUrl ? pn.mainMobileUrl.replace(/(\/*$)/g, "") + "/register?recommendcode=" + recommendCode : location.origin.replace(/(\/*$)/g, "") + "/register?recommendcode=" + recommendCode);
                            createQr("http://wx.cdnp3.com/dowlond/qr/frend/" + "?url=" + $.base64.encode(mobilelink));
                        }
                    }).fail(function(e) {
                        logConsole(e);
                    });
                }
            });
        } else {
            $(".qrcode img").hide();
            $('.recommended-code-js').show();
        }

        //格式化金额
        $("#recommendCommission").text(recommendCommission == 0 ? '0.00' : utils.amountFormatter(recommendCommission));
        $("#validTurnover").text(validTurnover == 0 ? '0.00' : utils.amountFormatter(validTurnover));
        $("#totalValidCustomers").text(totalValidCustomers);
    }).fail(function(e) {
        logConsole(e);
    });
}

var createQr = function(host) {
    //生成二维码
    $('#recommend-qr-code').qrcode({
        width: "124",
        height: "124",
        text: host
    });
    var qrcode = document.getElementById("recommend-qr-code");
    var canvas = qrcode.firstElementChild;
    $(".qrcode img").attr("src", canvas.toDataURL('image/png'));
};

var load_bord_code = function() {
        var clipBoard = new Clipboard('#bort_copy_code', {});
        clipBoard.on('success', function(e) {
            layer.alert('您已成功复制推荐码[' + e.text + ']', '可将此推荐码发送给您的朋友进行账号注册');
        });
        clipBoard.on('error', function(e) {
            lib.log(e);
        });
    },

    load_bord_link = function() {
        var value = $("#recommend-link").val();
        utils.copy('【A·G亞游集团|眞·人游戏第一品牌 新人首充送8888】' + value + '，点击链接即可注册');
        layer.alert("尊敬的用户，您已成功复制推荐链接，快分享给好友吧！",{title:' '});
    },
    pagingFooter = function($Grid, $record) {
        $record.find(".refresh,.search-js").on("click", function() {
            $jsGrid.jsGrid("loadData");
        });
        $record.find(".forward").on("click", function() {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(2) a").trigger("click");
        });
        $record.find(".backward").on("click", function() {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(1) a").trigger("click");
        });
        $record.find(".step-backward").on("click", function() {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(0) a").trigger("click");
        });
        $record.find(".step-forward").on("click", function() {
            $Grid.find(".jsgrid-pager .jsgrid-pager-nav-button:eq(3) a").trigger("click");
        });
    };