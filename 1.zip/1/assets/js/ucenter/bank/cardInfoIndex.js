/***
 *
 * 银行资料 CRUD
 *
 * <p>User: Ives
 * <p>Date: 2017/11/10
 * <p>Time: 17:14
 *
 */
var _PROVINCE_NAME_ = [
    {
        "intact": "内蒙古自治区",
        "short": "内蒙古"
    },
    {
        "intact": "广西壮族自治区",
        "short": "广西"
    },
    {
        "intact": "宁夏回族自治区",
        "short": "宁夏"
    },
    {
        "intact": "新疆维吾尔自治区",
        "short": "新疆"
    },
    {
        "intact": "西藏自治区",
        "short": "西藏"
    },
    {
        "intact": "香港特别行政区",
        "short": "香港"
    },
    {
        "intact": "澳门特别行政区",
        "short": "澳门"
    }
];


var getCurrencyTypeZh = function (currency) {
    currency = currency || "CNY";
    switch (currency) {
        case "CNY":
            return "银行卡";
        case "BTC":
            return "比特币钱包";
        case "ETH":
            return "以太币钱包";
    }

};

var getCurrencyZh = function (currency) {
    currency = currency || "CNY";
    switch (currency) {
        case "CNY":
            return "人民币";
        case "BTC":
            return "比特币";
        case "ETH":
            return "以太币";
    }

};
$.validator.addMethod("originalPhoneRemote", function (value, element, param, method) {
    if (this.optional(element)) {
        return "dependency-mismatch";
    }
    method = typeof method === "string" && method || "originalPhoneRemote";
    var previous = this.previousValue(element, method),
        validator, data, optionDataString;
    if (!this.settings.messages[element.name]) {
        this.settings.messages[element.name] = {};
    }
    previous.originalMessage = previous.originalMessage || this.settings.messages[element.name][method];
    this.settings.messages[element.name][method] = previous.message;
    param = typeof param === "string" && {url: param} || param;
    optionDataString = $.param($.extend({data: value}, param.data));
    if (previous.old === optionDataString) {
        return previous.valid;
    }
    previous.old = optionDataString;
    validator = this;
    this.startRequest(element);
    data = {};
    data[element.name] = value;

    $.request($.extend(true, {
        mode: "abort",
        port: "validate" + element.name,
        dataType: "json",
        data: {originalPhone: encryptByDES(value)},
        context: validator.currentForm,
        success: function (response) {
            var valid = response.successful,
                errors, message, submitted;

            validator.settings.messages[element.name][method] = previous.originalMessage;
            if (valid) {
                submitted = validator.formSubmitted;
                validator.resetInternals();
                validator.toHide = validator.errorsFor(element);
                validator.formSubmitted = submitted;
                validator.successList.push(element);
                validator.invalid[element.name] = false;
                validator.showErrors();
            } else {
                errors = {};
                message = response.message || validator.defaultMessage(element, {
                    method: method,
                    parameters: value
                });
                errors[element.name] = previous.message = message;
                validator.invalid[element.name] = true;
                validator.showErrors(errors);
            }
            previous.valid = valid;
            validator.stopRequest(element, valid);
        },
        error: function(xhr,textStatus,err){
			console.log("error: " + err);
		}
    }, param));
    return "pending";
}, "");


//  银行资料
$(function () {
    __message = "";
    if (lib.hasValue(__message)) {
        layer.alert(__message, {title: ' '});
    }

    var $uBank = $(".u-bank"),
        $bankCountry = $("#bankCountry"),
        $bankCity = $("#bankCity"),
        $addBankForm = $("#addBankForm"),
        $addBitcoinForm = $("#addBitcoinForm"),
        $addEthcoinForm = $("#addEthcoinForm"),
        $error = $addBankForm.find(".error-msg");
    //  添加银行卡HTML
    var addHtml = function (currency) {
        var accountType = getCurrencyTypeZh(currency);
        var modal = "";
        switch (currency) {
            case "BTC":
                modal = "modal-bitcoin-add";
                break;
            case "ETH":
                modal = "modal-ethcoin-add";
                break;
            default:
                modal = "modal-add";
                break;
        }
        return " <div class='my-card-wrap'>"
            + "     <div class='add-card center-wrap'>"
            + "         <div class='js-add-table center-content' data-add-modal='" + modal + "' data-currency='" + currency + "' data-toggle='modal'>"
            + "             <h4 class='text-center'>"
            + "                 <i class='icon-plus-circle-o'></i> 添加" + accountType
            + "             </h4>"
            + "         </div>"
            + "     </div>"
            + "</div>";
    };
    //  初始化生成银行页面数据
    var initBankHtml = function (index, item) {
        var def = item.def === 1 ? "checked disabled" : "";
        var bred = item.def === 1 ? "bred" : "";
        var bankname = item['bankName'], encodebankname = encodeURI(bankname);
        var image = "/assets/images/user/bank_icons/" + encodebankname + ".jpg";
        var province = provinceFilter({name: item.province});
        if (item.city === undefined) {
            item["city"] = "";
        }
        var city = item.city.substring(0, 9);
        if (item.branch === undefined) {
            item["branch"] = "";
        }
        var branch = item.branch.substring(0, 14);
        var carNo = item.cardNo.substring(item.cardNo.length - 14);
        var img = new Image();
        img.onerror = function () {
            $(".b_bank[data-name='" + bankname + "']").html(bankname).css({'padding-top': '5px', 'color': 'black'});
        };
        var defaultSpan = index !== 0 ? "pointer-link" : "";

        var icon, defBank = "";
        if (item.currency === "CNY") {
            icon = "<div data-name='" + bankname + "' class='icon-bank b_bank' style='background-image: url(" + image + ")'></div>";
        } else if (item.currency === "BTC") {
            icon = "<div  class='icon-bank bitcoin_bank col-xs-4'>比特币</div>";
            item.name = "&nbsp;";
            province = "&nbsp;";
            branch = "&nbsp;";
            item.type = "比特币钱包";
            defBank = "style='visibility: hidden'";
        } else {
            icon = "<div  class='icon-bank ether_bank col-xs-4'>以太币</div>";
            item.name = "&nbsp;";
            province = "&nbsp;";
            branch = "&nbsp;";
            item.type = "以太币钱包";
            defBank = "style='visibility: hidden'";
        }
        //  显示银行卡模板
        var html =
            " <div class='my-card-wrap clearfix'>"
            + "     <input data-currency='" + item.currency + "' type='hidden' class='js-bank-id' value='" + item.id + "'>"
            + "     <div class='my-card " + bred + "'>"
            + "         <a class='del'></a>"
            + "         <div class='card-type clearfix'>"
            + icon
            + "             <span style='overflow: hidden;white-space: pre;' class='col-xs-7 pull-right text-right'>" + province + " " + city + "</span>"
            + "               <small class='col-xs-9 pull-right text-right'>" + branch + "</small>"
            + "         </div>"
            + "         <h4> " + item.name + " "
            + "         </h4>"
            + "             <span class='col-xs-4 pull-left text-left '>" + item.type + "</span>"
            + "             <small class='col-xs-5 pull-right text-right real-weight'>" + carNo + "</small>"
            + "         <div class='card-address clearfix'>"
            + "             <div " + defBank + " class='payment-bank pull-right js-def-bank'>"
            + "                 <input type='checkbox' class='dpb' " + def + ">"
            + "                 <span class='" + defaultSpan + "'>默认收款银行</span>"
            + "             </div>"
            + "         </div>";
        if (item.def !== 1 || item.currency !== "CNY") {
            html +=
                " <div class='overlay pull-left'>"
                + "     <div class='center-wrap'>"
                + "         <a class='delete button-red' data-toggle='modal'>删除</a>"
                + "     </div>"
                + "</div>";
        }
        html += "</div></div>";
        if (item.currency === "CNY") {
            $uBank.find(".card-row>div[data-currency='CNY']:eq(" + index + ")").append(html);
            img.src = image;
        } else if (item.currency === "BTC") {
            $uBank.find(".card-row>div.bitcoin-wrap").append(html)
        } else {
            $uBank.find(".card-row>div.ethcoin-wrap").append(html)
        }

    };


    //  添加空白添加银行卡Table
    var addBlankCard = function () {
        $uBank.find(".card-row>div").each(function (index, item) {
            var $item = $(item);
            if (!$.trim($item.html())) {
                $item.append(addHtml($item.data("currency")));
            }
        });
    };
    //-----------Begin-----Ajax 请求---------------------------------//
    var district = function (province, $select) {
        $select.empty();
        if (province === "") {
            $addBankForm.validate().element($("#bankCity"));
            $addBankForm.validate().element($("#bankCountry"));
            $select.append("<option value=''>请选择开户市</option>");
            return;
        }
        $(".u-bank").loading();
        $.request({
            type: "GET",
            url: "/api/banks/provinces-bankNames",
            data: "province=" + encodeURI(province),
            dataType: "JSON"
        }).done(function (res) {
            var data = res.data;
            if (res.successful) {
                if ($select.attr("id") === "bankCountry") {
                    $select.append("<option value=''>请选择开户省</option>");
                } else {
                    $select.append("<option value=''>请选择开户市</option>");
                }
                $.each(data.provinces, function (index, item) {
                    $select.append("<option value='" + item + "'>" + item + "</option>")
                });
            } else {
                var html = "<li class='list-group-item list-group-item-warning'>" + data.provinces + "</li>";
                layer.alert(html, {title: ' '});
            }
        }).fail(function () {
            layer.alert("服务器遇到错误,请联系客服或稍后再试!", {title: ' '});
        }).always(function () {
            $(".u-bank").loading('close');
        });
    };
    var addBank = function () {
        var $submit = $addBankForm.find(".btn-submit");
        $("#modal-add").find(".modal-content").loading();
        if ($submit.hasClass("processing-js")) {
            return;
        }
        $submit.addClass("processing-js");
        $.request({
            url: "/api/banks",
            type: "POST",
            data: $addBankForm.serialize(),
            dataType: "json"
        })
            .done(function (res) {
                var success = res.successful, data = res.data || res.message;
                if (success) {
                    var status = success ? "success" : "warning",
                        html = '<li class="list-group-item list-group-item-' + status + '">' + data + '</li>';
                    layer.open({
                        title: ' ',
                        btn: ['确定'],
                        closeBtn: 0,
                        yes: function () {
//                            window.location.href = (_redirect || res.url || "/ucenter/bank/bankIndex");
                            window.location.href = "/ucenter/bank/bankIndex";
                        },
                        content: html
                    });
                } else {
                    $error.html("<i class='error-text-orange'>" + data + "</i>");
                }
            })
            .always(function () {
                $submit.removeClass("processing-js");
                $("#modal-add").find(".modal-content").loading("close");
            });
    };
    var addVirtual = function (f) {
        var t = this, $form = $(f);
        var $submit = $form.find(".btn-submit"), $modal = $form.parents(".modal");
        $form.parents(".modal-content").loading();
        if ($submit.hasClass("processing-js")) {
            return;
        }
        $submit.addClass("processing-js");
        var currency = $form.find("input[name='currency']");
        $.request({
            url: "/api/banks/virtual",
            type: "POST",
            data: $form.serialize(),
            dataType: "json"
        })
            .done(function (res) {
                var success = res.successful, data = res.data;
                if (success) {
                    $modal.modal("hide");
                    layer.open({
                        title: ' ',
                        btn: ['确定'],
                        skin: 'btn-reverse',
                        closeBtn: 0,
                        end: function () {
//                            window.location.href = (_redirect || res.url || "/ucenter/bank/bankIndex");
                            window.location.href = "/ucenter/bank/bankIndex";
                        },
                        content: "恭喜您新增" + getCurrencyTypeZh(currency.val()) + "成功！"
                    });
                } else {
                    t.showErrors({"accountNo": data});
                }
            })
            .always(function () {
                $submit.removeClass("processing-js");
                $form.parents(".modal-content").loading("close");
            });
    };
    var initBankInfo = function () {
        $(".u-content").loading();
        return $.request({
            type: "GET",
            url: "/api/banks",
            dataType: "JSON"
        }).done(function (response) {
            var res = response.data;
            if (response.successful) {
                var bankArray = res.banks, virtualArray = res.virtual, total = bankArray.length + virtualArray.length;
                if (total) {
                    bankArray.sort(function (a, b) {
                        return a.def - b.def;
                    });
                    $("#bankAccountName").prop("disabled", !!bankArray.length);
                    bankArray = bankArray.concat(virtualArray);
                    $.each(bankArray, function (index, item) {
                        if (item.currency === "CNY") {
                            $("#bankType").val(item['type']);
                            $("#name").val(item['name']);
                        }
                        if (!index && item.currency === "CNY") {
                            item.def = 1;
                        }
                        initBankHtml(index, item);
                    });
                }
                addBlankCard(5 - total);
            } else {
                var html = "<li class='list-group-item list-group-item-warning'>" + res.data + "</li>";
                layer.alert(html, {title: ' '});
            }
        }).fail(function () {
            layer.alert("服务器遇到错误,请联系客服或稍后再试!", {title: ' '});
        }).always(function () {
            $(".u-content").loading("close");
        });
    };
    var initAddForm = function () {
        $(".u-main").loading();
        $.request({
            type: 'GET',
            url: "/api/banks/provinces-bankNames",
            dataType: "JSON"
        }).done(function (res) {
            var bankAccountName = $addBankForm.find("[name='bankAccountName']");
            var rd = bankAccountName.attr("readonly");
            if (rd !== 'readonly') {
                bankAccountName.val();
            }
            if (res.successful) {
                var data = res.data;

                var bankCountry = $addBankForm.find("[name='bankCountry']"),
                    bankName = $addBankForm.find("[name='bankName']");
                bankAccountName.val($("#name").val());
                bankCountry.append("<option value=''>请选择开户省</option>");
                $.each(data.provinces, function (index, item) {
                    bankCountry.append("<option value='" + item + "'>" + item + "</option>")
                });
                bankName.append("<option value=''></option>");
                $.each(data.bankNames, function (index, item) {
                    bankName.append("<option value='" + item + "'>" + item + "</option>")
                });
                bankName.select2({
                    language: "zh-CN",
                    placeholder: "请选择银行"
                });
            } else {
                layer.alert(res.data, {title: ' '});
            }
        })
            .fail(function () {
                layer.alert("服务器遇到错误,请联系客服或稍后再试!", {title: ' '});
            })
            .always(function () {
                $(".u-main").loading('close');
            });
    };
    var deleteBank = function (bankId, currency) {
        $.request({
            type: "DELETE",
            url: '/api/banks/' + bankId + "?currency=" + currency || "CNY",
            dataType: "JSON"
        }).done(function (response) {
            var success = response.successful, data = response.data;
            if (success) {
                location.reload();
            } else {
                var status = success ? "success" : "warning",
                    html = "<li class='list-group-item list-group-item-" + status + "'>" + data + "</li>";
                layer.alert(html, {title: ' '});
            }
        });
    };
    //-----------End---------Ajax 请求------------------------------//

    //-----------Begin------------初始化方法调用-----------------------------//
    initBankInfo().done(initAddForm);
    //-----------End------------初始化方法调用-------------------------------//

    //  删除选中卡
    $(document).on('click', '.u-bank .delete', function () {
        var $this = $(this);
        var $bank = $this.parents('.my-card-wrap').find('.js-bank-id');
        var currency = $bank.data("currency");
        var txt;
        if (currency === "BTC") {
            txt = '您确定要删除已绑定的比特币钱包地址?';
        } else if (currency === "ETH") {
            txt = '您确定要删除已绑定的以太币钱包地址?';
        } else {
            txt = '您确定要删除已绑定的银行卡?';
        }
        layer.confirm(txt, {
            btn: ['确定', '取消'],
            icon: 3,
            title: ' '
        }, function () {
            deleteBank($bank.val(), currency);
        });
    });

    //  设置默认银行卡
    $(document).on('click', '.u-bank .dpb', function () {
        var $current = $(this);
        var $notCurrent = $('.dpb').not(this);
        var bankId = $current.parents('.my-card-wrap').find('.js-bank-id').val();
        if ($(this).is(':checked')) {
            $(".u-bank").loading();
            $.request({
                type: "PUT",
                url: "/api/banks/" + bankId,
//                data: {userBankId: $current.parents('.my-card-wrap').find('.js-bank-id').val()},
                dataType: "JSON"
            }).done(function (response) {
                var success = response.successful;
                if (success) {
                    $current.prop('disabled', true).parents('.my-card').addClass('bred');
                    $notCurrent.prop('checked', false).parents('.my-card').removeClass('bred');
                    $notCurrent.prop('disabled', false);
                }
                var message = response.data || response.message;
                var status = success ? "success" : "warning",
                    html = "<li class='list-group-item list-group-item-" + status + "'>" + message + "</li>";
                layer.open({
                    title: ' ',
                    btn: ['确定'],
                    closeBtn: 0,
                    yes: function () {
                        window.location.href = "/ucenter/bank/bankIndex";
                    },
                    content: html
                });
            }).fail(function () {
                layer.alert("服务器遇到错误,请联系客服或稍后再试!", {title: ' '});
            }).always(function () {
                $(".u-bank").loading("close");
            });
        }
    });

    //  添加银行卡Form提交
    $('.modal-add .btn-submit').on('click', function () {
        $addBankForm.submit();
    });
    //  添加比特币Form提交
    $("#modal-bitcoin-add").find('.btn-submit').on('click', function () {
        $addBitcoinForm.submit();
    });

    $("#modal-ethcoin-add").find('.btn-submit').on('click', function () {
        $addEthcoinForm.submit();
    });

    jQuery.validator.addMethod("checkUnique", function (value, element) {
        var isUnique = false;
        $.request({
            url: "/api/banks/check-account",
            async: false,   //要指定不能异步,必须等待后台服务校验完成再执行后续代码
            data: {accountNo: value}
        }).done(function (res) {
            if (res.successful) {
                isUnique = true;
            } else {
                isUnique = false;
            }
        });
        return isUnique;
    });

    //  添加银行表单验证
    $addBankForm.validate({
        onkeyup: null,
        errorElement: "span",
        submitHandler: addBank,
        showErrors: function () {
            this.defaultShowErrors();
        },
        errorPlacement: function (error, element) {
            $(error).addClass("error failure");
            element.parent().append(error);
        },
        success: function (label) {
            for (var i = 0; i < label.length; i++) {
                $(label).remove();
            }
        },
        rules: {
            bankAccountName: {
                required: true,
                regex: constants.realNameRegular
            },
            bankName: {
                required: true,
                regex: constants.generalCnAndEnReguler
            },
            bankAccountNo: {
                required: true,
                number: true,
                rangelength: [16, 19],
                checkUnique: true
            },
            bankCountry: {
                required: true,
                regex: constants.generalCnAndEnReguler
            },
            bankCity: {
                required: true
            },
            branchName: {
                required: true,
                regex: constants.generalCnAndEnReguler
            }
        },
        messages: {
            bankAccountName: {
                required: "用户名必须填写",
                regex: "必须为汉字或者英文,最少2位"
            },
            bankName: {
                required: "银行名称必须选择",
                regex: "暂不支持您所选的银行,请联系客服"
            },
            bankAccountNo: {
                required: "银行账号不能为空",
                number: "银行账号由16-19位数字组成",
                rangelength: "银行账号由16-19位数字组成",
                checkUnique: "您输入的卡号已经存在"

            },
            bankCountry: {
                required: "开户银行所在省份必须选择",
                regex: "您所选的开户银行所在省份不存在或不支持"
            },
            bankCity: {
                required: "开户银行所在城市必须选择"
            },
            branchName: {
                required: "开户银行所在地址必须填写",
                regex: "开户行地址需不少于2位汉字或字母"
            }
        }
    });

    //  添加比特币表单验证
    $addBitcoinForm.validate({
        onkeyup: null,
        errorElement: "span",
        submitHandler: addVirtual,
        errorPlacement: function (error, element) {
            $(error).addClass("error failure");
            element.parent().append(error);
        },
        success: function (label) {
            for (var i = 0; i < label.length; i++) {
                $(label).remove();
            }
        },
        rules: {
            accountNo: {
                required: true,
                regex: /^\w{26,34}$/
            }

        },
        messages: {
            accountNo: {
                required: "钱包地址必须填写!",
                regex: "比特币地址不符合规则,请检查!"
            }
        }
    });

    //  添加以太币表单验证
    $addEthcoinForm.validate({
        onkeyup: null,
        errorElement: "span",
        submitHandler: addVirtual,
        errorPlacement: function (error, element) {
            $(error).addClass("error failure");
            element.parent().append(error);
        },
        success: function (label) {
            for (var i = 0; i < label.length; i++) {
                $(label).remove();
            }
        },
        rules: {
            accountNo: {
                required: true,
                regex: /^\w{30,50}$/
            }

        },
        messages: {
            accountNo: {
                required: "钱包地址必须填写!",
                regex: "以太币地址不符合规则,请检查!"
            }
        }
    });
    //  省市联级
    $bankCountry.on('change', function () {
        district($(this).val(), $bankCity);
    });
    //  select2 输入框占位符
    $(document).one('click', '.select2-selection', function () {
        $(".select2-search__field").attr("placeholder", "在此输入关键字搜索")
    });
    //------Begin----BIN码自动识别银行卡-----------------------//
    var identify = function () {
        var bin = searchBank({bin: $("#bankAccountNo").val().substring(0, 6)});
        var $bankName = $("#bankName"), $bankAccountType = $("#bankAccountType");
        var bankNameValue = "", bankAccountTypeValue = "";
        if (bin.length) {
            var bankName = (bin[0].bankName).indexOf("农村信用") >= 0 ? "农村信用社" : bin[0].bankName;
            bankNameValue = $bankName.find("option[value='" + bankName + "']").text() || "";
            bankAccountTypeValue = $bankAccountType.find("option[value='" + bin[0].type + "']").val();
        }
        // $bankName.val(bankNameValue);
        // $bankName.trigger('change');
        $bankAccountType.val(bankAccountTypeValue || "DEBIT");
    };
    $("#bankAccountNo").on("blur", function () {
        identify();
    });
    $("#bankName").on("change", function () {
        $addBankForm.validate().element($("#bankName"));
    });
    $(".icon-bank").error(function () {
        $(this).html($(this).attr("data-name"));
    });

    //------End----BIN码自动识别银行卡------------------------//

    function provinceFilter(option) {
        var names = $.grep(_PROVINCE_NAME_, function (n/*, i*/) {
            return n.intact === option.name;
        });
        return names.length > 0 ? names[0].short : option.name;
    }

    function searchBank(option) {
        return $.grep(_bins, function (n/*, i*/) {
            return n.bin === option.bin;
        });
    }
});

//  验证电话号码
$(function () {
    var $verifyPhoneModal = $("#modal-phone-edit"),
        $verifyPhoneForm = $("#verifyPhoneForm"),
        $phoneError = $verifyPhoneForm.find(".js-phone-msg");
    var addBankClickHandle = function () {
        var $this = $(this), $modal = $('#' + $this.data("addModal"));
        $modal.modal("show");
    };
    var showAddBankModal = function () {
        var $btnSendCode = $verifyPhoneForm.find(".btn-resend");
        $btnSendCode.agcountdown({
            after: function () {
                $btnSendCode.on('click', verifyHandler.sendSMS);
            },
            defaultMsg: "发送手机动态码",
            start: false,
            reset: true
        });
        $verifyPhoneModal.modal('hide');
        var currency = $verifyPhoneModal.find(".modal-title").data("currency");
        if (currency === "CNY") {
            $('#modal-add').modal('show');
        } else if (currency === "BTC") {
            $('#modal-bitcoin-add').modal('show');
        } else {
            $('#modal-ethcoin-add').modal('show');
        }
        $(document).off('click.add', '.my-card-wrap .js-add-table');
        $(document).on('click.add', '.my-card-wrap .js-add-table', addBankClickHandle);
    };

    var verifyHandler = new VerifyHandler({
        isInitSend: false,
        isGeneralVerify: false,
        isBankType: true,
        form: $verifyPhoneForm,
        originalPhone: $("#originalPhone"),
        callback: showAddBankModal,
        validate: {
            rules: {
                originalPhone: {
                    required: true,
                    rangelength: [11, 11],
                    regex: constants.phoneRegular,
                    originalPhoneRemote: {
                        url: "/api/phone/right",
                        type: "GET"
                    }
                },
                captcha: {
                    required: true,
                    rangelength: [6, 6],
                    digits: /^\d{6}$/
                }
            },
            messages: {
                originalPhone: {
                    required: "请输入手机号码",
                    rangelength: "请输入完整的手机号码",
                    regex: "请输入正确的手机号码",
                    originalPhoneRemote: "手机号码不正确"
                },
                captcha: {
                    required: "请输入验证码",
                    rangelength: "短信验证码为6位数字!",
                    digits: "短信验证码为6位数字!"
                }
            },
            showErrors: function () {
                this.defaultShowErrors();
            },
            errorPlacement: function (error, element) {
                $(error).addClass("error failure");
                $(".js-" + $(element).attr("id") + "-msg").append(error);
            }
        }
    });

    $.when(verifyHandler.init()).then(function (response) {
        if (response.successful) {
            var data = response.data;
            var _phone = data.phone.replace(/\*/g, "");
            $(".phone-prefixes").text(_phone.substring(0, 3));
            $(".phone-suffix").text(_phone.substring(_phone.length - 1, _phone.length));
            $.request({
                type: "GET",
                url: "/api/banks/phone",
                dataType: "json"
            }).done(function (response) {
                if (response.successful) {
                    var data = response.data;
                    var isVerified = data.isVerified;
                    if (isVerified) {
                        $(document).on('click.add', '.my-card-wrap .js-add-table', addBankClickHandle);
                    } else {
                        $(document).on('click.add', '.my-card-wrap .js-add-table', function () {
                            var $this = $(this), $modal = $('#modal-phone-edit'), currency = $this.data("currency");
                            var title = getCurrencyTypeZh(currency);
                            $modal.find(".modal-title").attr("data-currency", currency).text("新增" + title);
                            $modal.modal("show");
                        });
                    }
                }
            });
        }
    });

    $verifyPhoneModal.on('shown.bs.modal', function () {
        $('.add-account-number .active').focus();
    });
    var $accountDigits = $(".account-digits");
    $accountDigits.keypress(function () {
        this.value = "";
    }).keydown(function (e) {
        if (this.value === "") {
            if ((e.which === 8 || e.which === 46) && $(this).text() === '') {
                $(this).prev('input').val('').focus();
            }
        }
    }).keyup(function () {
        if (this.value && !/\d/g.test(this.value)) {
            $(this).val("");
            return;
        }
        if (this.value.length === this.maxLength) {
            $(this).next('.account-digits').prop("disabled", false).focus();
        }
        $('.account-digits').removeClass('active');
    }).blur(function () {
        var prefixes = $verifyPhoneForm.find(".phone-prefixes").text(),
            suffix = $verifyPhoneForm.find(".phone-suffix").text(),
            middle = "";
        $verifyPhoneForm.find("#originalPhone").val("");
        $accountDigits.each(function (index, item) {
            middle += $(item).val();
        });
        var phone = prefixes + middle + suffix;
        if (!constants.phoneRegular.test(phone)) {
            $phoneError.addClass("error failure").text("请输入完整的手机号码");
            return false;
        }
        $verifyPhoneForm.find("#originalPhone").val(phone);
        var correct = function () {
                $phoneError.removeClass("error failure").text("");
            },
            incorrect = function (data) {
                $phoneError.addClass("error failure").text(data);
            },
            failure = function () {
                $phoneError.addClass("error failure").text("服务器遇到错误,请联系客服或稍后再试!");
            };
        verifyHandler.right({
            isShowLoaded: false,
            phone: null,
            correct: correct,
            incorrect: incorrect,
            failure: failure
        });
    });
});
