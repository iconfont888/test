/**
 * Created by Lorry on 2017/6/5.
 */

/** 我的账户-下拉弹出框-刷新用户账户余额 */
var dropdown_click_times = 0,
    dropdown_load_credit = function () {
        dropdown_click_times += 1;
        if ((dropdown_click_times % 2) == 1) {
            excute_load_credit(function (_data) {
                drow_modle_pane(_data);
            });
        }
    },
    excute_load_credit = function (callback) {
        $.request({
            url: "/api/balance"
        }).done(function (res) {
            if (res && res.successful == true) {
                //刷新用户余额
                var _data = res.data;
                if (undefined != callback) {
                    callback(_data);
                }
            } else {
                lib.log(res.data);
            }
        });
    },
    drow_modle_pane = function (_data) {
        if (_data) {
            if (_data.totalBalance !== undefined)
                $('.total-balance-js, .eid_total_credit').text(window.utils.amountFormatter(_data.totalBalance));

            if (_data.localBalance !== undefined)
                $('#eid_local_credit').text(window.utils.amountFormatter(_data.localBalance));
            if (_data.gameBalance !== undefined)
                $('#eid_game_credit').text(window.utils.amountFormatter(_data.gameBalance));
        }
    },
    drow_commom_pane = function (_data) {
        var balance = (_data && _data.totalBalance) ? window.utils.amountFormatter(_data.totalBalance) : "0.00";
        $('#eid_c_total_credit').text(' ¥' +balance);
    },
    async_load_credit = function () {
        $('#eid_c_total_credit').text('加载中...');
        excute_load_credit(function (_data) {
            drow_commom_pane(_data);
        });
    };

function refreshCredit() {
    // console.log($('.navbar .dropdown-menu'))
    // if($('.navbar #dropdown-credit+.dropdown-menu').is(':hidden')){
    //     $('.navbar #dropdown-credit+.dropdown-menu').show();
    // }
    $('.total-balance-js').html('<img src="/assets/images/vip/loading.gif" />');
    $('.eid_total_credit').text('加载中...');
    $('#eid_local_credit').text('加载中...');
    $('#eid_game_credit').text('加载中...');
    excute_load_credit(function (_data) {
        drow_modle_pane(_data);
    });
}
// $(document).ready(function(){
//     alert(6666)
// })
$(function () {

	// 点击 刷新额度 按钮
    setTimeout(function(){
            $('#refresh-credit').on('click', function () {
            refreshCredit();
        });
        $('#dropdown-credit').off('click').on('click', function () {
            setTimeout(function(){
                refreshCredit();
            },200)
            
            //refresh_rt_start_level();
        });
        $('#refresh_total_credit').on('click', function () {
            async_load_credit();
        });
    },1000)

});