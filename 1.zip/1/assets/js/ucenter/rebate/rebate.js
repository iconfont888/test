/**
 * Created by Lorry on 2017/6/6.
 */
$(document).ready(function () {
    loadData();
    // 等级动画
    $('.rebate-settle-submit').click(function () {
        //setDisable($(this));
        loadingEffect();
        postSubmit();
    });
    var currentDate = new Date(pn.sys_now);
    var timesStamp = currentDate.getTime();
    var currenDay = currentDate.getDay();
    var dates = [];
    for (var i = 0; i < 7; i++) {
        if(i===0){
            var beginTime=new Date(timesStamp + 24 * 60 * 60 * 1000 * (i - (currenDay + 6) % 7)).toLocaleDateString().replace(/\//g, '-');
        }
        if(i===6){
            var endTime=new Date(timesStamp + 24 * 60 * 60 * 1000 * (i - (currenDay + 6) % 7)).toLocaleDateString().replace(/\//g, '-');
        }
    }
    $(".tip").html(" 周期(北京时间 " + beginTime + " 00:00:00" + " - " + endTime + " 23:59:59 ) " +
        "  <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;单个游戏类型的洗码佣金达到10元即可随时结算");

});

function timestampToTime(timestamp) {
    var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
    Y = date.getFullYear() + '-';
    M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
    h = date.getHours() + ':';
    m = date.getMinutes() + ':';
    s = date.getSeconds();
    return Y + M + D;
}

function levelAnimation(money) {
    var $wrap = $('.level-line');
    var $line = $wrap.find('.pbcf');
    var $line2 = $wrap.find('.pbpd');
    var $line3 = $wrap.find('.pbdd');
    var width = $wrap.width();
    var alpha = 217;
    var _width = 0;
    var n = 0;
    var st = $('.st');
    var sa = $('.sa');
    var aa = $('.aa');
    var amount = $('.ac');
    var money_week = parseInt(money, 10);
    money = parseInt(money, 10);
    amount.text(utils.amountFormatter(money_week));
    if (money < 100000) {
        _width = money / 100000 * alpha;
    } else if (money >= 100000 && money < 500000) {
        _width = (money - 100000) / 400000 * alpha;
        n = 1;
    } else if (money >= 500000 && money < 1000000) {
        _width = (money - 500000) / 500000 * alpha;
        n = 2;
    } else if (money >= 1000000 && money < 3000000) {
        _width = (money - 1000000) / 2000000 * alpha;
        n = 3;
    } else if (money >= 3000000 && money < 6000000) {
        _width = (money - 3000000) / 3000000 * alpha;
        n = 4;
    } else if (money >= 6000000) {
        n = 5;
    }

    if (parseInt(pn.userLevel) === 1) {
        st.text('一星级');
        sa.text('二星级');
        if (money_week > 100000) {
            aa.text(0);
        } else {
            aa.text(utils.amountFormatter(100000 - money_week));
        }
        $('.vp2').addClass('active');
        $('.vp2').append("<div class='noti'>下一级别</div>");
    } else if (parseInt(pn.userLevel) === 2) {
        $('.vp1').hide();
        st.text('二星级');
        sa.text('三星级');
        if (money_week > 500000) {
            aa.text(0);
        } else {
            aa.text(utils.amountFormatter(500000 - money_week));
        }
        $('.vp3').addClass('active');
        $('.vp3').append("<div class='noti'>下一级别</div>");
    } else if (parseInt(pn.userLevel) === 3) {
        $('.vp1').hide();
        $('.vp2').hide();
        st.text('三星级');
        sa.text('VIP 4');
        if (money_week > 1000000) {
            aa.text(0);
        } else {
            aa.text(utils.amountFormatter(1000000 - money_week));
        }
        $('.vp4').addClass('active');
        $('.vp4').append("<div class='noti'>下一级别</div>");
    } else if (parseInt(pn.userLevel) === 4) {
        $('.vp1').hide();
        $('.vp2').hide();
        $('.vp3').hide();
        st.text('VIP 4');
        sa.text('VIP 5');
        if (money_week > 3000000) {
            aa.text(0);
        } else {
            aa.text(utils.amountFormatter(3000000 - money_week));
        }
        $('.vp5').addClass('active');
        $('.vp5').append("<div class='noti'>下一级别</div>");
    } else if (parseInt(pn.userLevel) === 5) {
        $('.vp1').hide();
        $('.vp2').hide();
        $('.vp3').hide();
        $('.vp4').hide();
        st.text('VIP 5');
        sa.text('VIP 6');
        if (money_week > 6000000) {
            aa.text(0);
        } else {
            aa.text(utils.amountFormatter(6000000 - money_week));
        }
        $('.vp6').addClass('active');
        $('.vp6').append("<div class='noti'>下一级别</div>");
    } else if (parseInt(pn.userLevel) >= 6) {
        $('.pbc').hide();
        $('.vp7').hide();
        $('.p-notice').hide();
        _width = 216;
    }

    var m = 0;
    var anim = function () {
        $line.animate({
            'width': _width + alpha * m
        }, 300, 'linear', function () {
            if (m < n) {
                m++;
                anim(m);
            } else {
                $line.animate({
                    'width': _width + alpha * m
                }, 'slow');
            }
        });
        $line2.animate({
            'left': _width + 15 + alpha * m
        }, {
            duration: 300,
            easing: 'linear',
            step: function (now, fx) {
                var pos = $line2.position();
                var data = pos.left;
                // console.log(data);
                if (data >= 200) {
                    $('.pbpd-pbb').fadeOut();
                    if (data >= 200) {
                        $('.pbcf-pd').fadeIn();
                    }
                }
            }

        });
        var nwidth = _width + alpha * n;
        $line3.animate({
            'left': _width + 15 + alpha * m
        }, {
            duration: 300,
            easing: 'linear',
            step: function (now, fx) {

                var pos = $line2.position();

                var data = pos.left;
                if (screen.width >= 2560) {
                    if (data >= 1140) {
                        $line3.stop();
                        var pos1 = nwidth;
                        var pos2 = $line3.position().left + 10;
                        var mleft = pos1 - 814;
                        $line3.find('.arrow').animate({
                            'left': mleft + 110
                        }, {
                            duration: 380,
                            easing: 'linear',
                            step: function (now, fx) {
                                var posi = $line3.find('.arrow').position();
                                var dt = posi.left;
                                if (dt >= 400) {
                                    $line3.find('.arrow').stop();
                                }
                            }
                        });
                    }
                } else {
                    if (data >= 860) {
                        $line3.stop();
                        var pos1 = nwidth;
                        var pos2 = $line3.position().left + 10;
                        var mleft = pos1 - pos2;
                        $line3.find('.arrow').animate({
                            'left': mleft + 95
                        }, {
                            duration: 320,
                            easing: 'linear',
                            step: function (now, fx) {
                                var posi = $line3.find('.arrow').position();
                                var dt = posi.left;
                                if (dt >= 310) {
                                    $line3.find('.arrow').stop();
                                }
                            }
                        });
                    }
                }
            }
        });
    }
    anim(m);
};
var loadingEffect = function () {
        $('.rebate-games').parents(".u-rebate").loading({logo: false});
    },
    hidEffect = function () {
        $('.rebate-games').parents(".u-rebate").parent().loading('close');
    },
    postSubmit = function () {
        $.request({
            type: 'PUT',
            url: "/api/rebate"
        }).done(function(res){
            if (res.successful) {
                //刷新用户余额
                var _data = res.data.resultList;
                hidEffect();
                var count = 0;
                var htmls = [];
                $.each(_data, function (index, item) {
                    if (item.data == "洗码状态必须为启用") {
                        item.data = "提交失败，请联系客服！";
                    }

                    var game_kind = $('tbody.rebate-games tr td.gameKing-name').eq(index).attr('game');
                    var data=item.data.substring(0,5)==="赢得洗码："?item.data:"赢得洗码："+item.data;
                    var html = '<li><label>【<span>' + game_kind + '</span>】</label>'+ data + '</li>';
                    htmls.push(html);
                    if (item.successful === false) {
                        count++;
                    }
                });
                if (count === 6) {
                    $("#alter").text("很抱歉");
                }
                var modal = $('#modal-onload');
                modal.find('.modal-body').find('ul').html(htmls);
                modal.modal('show');
                modal.on("hide.bs.modal", function () {
                    location.reload();
                });
            } else {
                //新增洗码禁用
                if(res.code === 8823){
                    hidEffect();
                    var modal2 = $('#modal-onload').addClass("modal-onload2");
                    modal2.find(".modal-content .modal-header h4").text("很抱歉");
                    modal2.find(".modal-content .modal-body .text-wrap").html('<p>提交一键洗码失败，请联系客服</p>');
                    modal2.modal('show');
                    modal2.on("hide.bs.modal", function () {
                        location.reload();
                    });
                }else{
                    hidEffect();
					failure(res.message);
                }
            }
        }).fail(function(msg){
            lib.log(msg);
        });
    },
    loading_pane,
    loadData = function () {
        loadingEffect();
        $.request({
            url: "/api/rebate",
            success: function (res) {
                var weekBetAmount = 0;
                if (res.successful && true == res.successful) {
                    var data = res.data.rebateInfo;
                    var _html = [];

                    for (var a = 0; a < data.length; a++) {
                        var item = data[a];

                        _html.push('<tr>');
                        switch (item.gameKind) {
                            case '3':
                                _html.push('<td class="gameKing-name" game=\"真人游戏\"><span>真人游戏');
                                break;
                            case '5':
                                _html.push('<td class="gameKing-name" game=\"电子游戏\"><span>电子游戏');
                                break;
                            case '8':
                                _html.push('<td class="gameKing-name" game=\"捕&nbsp;鱼&nbsp;王\"><span>捕鱼王');
                                break;
                            case '1':
                                _html.push('<td class="gameKing-name" game="体育电竞"><span>体育电竞');
                                break;
                            case '2':
                                _html.push('<td class="gameKing-name" game=\"现&nbsp;场&nbsp;厅\"><span>现场厅');
                                break;
                            case '12':
                                _html.push('<td class="gameKing-name" game=\"彩票游戏\"><span>彩票游戏');
                                break;
                        }

                        _html.push('<em>(洗码比例');
                        _html.push(null == item['rate'] ? '0.00' : item['rate']);
                        _html.push('%)');
                        _html.push('</em></span>');

                        _html.push('</td>');
                        _html.push('<td class="money">');
                        if (null !== item['amount']) {
                            if (parseFloat(item['amount']) < 0) {
                                _html.push("--");
                            } else {
                                _html.push(parseFloat(item['amount']).toFixed(2));
                            }
                        } else {
                            _html.push("--");
                        }

                        _html.push('</td>');

                        _html.push('<td class="money">');
                        if (null !== item['turnoverAmount']) {
                            if (parseFloat(item['turnoverAmount']) < 0) {
                                _html.push("--");
                            } else {
                                _html.push(parseFloat(item['turnoverAmount']).toFixed(2));
                            }
                        } else {
                            _html.push("--");
                        }

                        _html.push('</td>');
                        _html.push('<td class="money">');
                        if (null !== item['totalTurnoverAmount']) {
                            if (parseFloat(item['totalTurnoverAmount']) < 0) {
                                _html.push("--");
                            } else {
                                weekBetAmount = weekBetAmount + parseFloat(item['totalTurnoverAmount']);
                                _html.push(parseFloat(item['totalTurnoverAmount']).toFixed(2));
                            }
                        } else {
                            _html.push("--");
                        }
                        _html.push('</td>');
                        _html.push('</tr>');
                    }
                    $('.rebate-games').append(_html.join(''));
                } else {
                    failure(res.message);
                }
                hidEffect();
                if (parseInt(pn.userLevel) >= 6 || parseInt(pn.userLevel) === 0) {
                    $('.pbc').hide();
                    $('.vp7').hide();
                    $('.p-notice').hide();
                } else {
                    levelAnimation(weekBetAmount.toFixed(2));
                }
            },
            error: function(xhr,textStatus,err){
				console.log("error: " + err);
			}
        });
    };

//会员日跳转指定tab页
$(function () {
    var urlparameter = location.search;
    if (/tab-4/.test(urlparameter)) {
        $(".u-transaction .nav-tabs li ").find('a[href="#tab-4"]').trigger("click");
    } else {
        $(".u-transaction .nav-tabs li ").find('a[href="#tab-1"]').trigger("click");
    }

    var min = utils.getQueryString("min");
    if (min){
        $.getScript(webConf.cdn_url + "/assets/js/pay/paymin.js");
    }
})

$('.btn-orange').click(function () {
    if ($("#alter").text() === '很抱歉') {
        location.href = "";
    } else {
        location.href = "/ucenter/transaction/view?selectTab=washCode";
    }
});

