/**
 * Created by Barden on 2017/6/9.
 */
/**
 * Created by Davy on 2017/6/8.
 */
function findCSURL(userid, loginname, level, terminal) {
    var enterurl = encodeURIComponent(window.location.href);
    var timestamp = jQuery.now();
    var url = '';

    if (!lib.hasValue(userid)) {
        userid = timestamp;
    }
    if (!lib.hasValue(loginname)) {
        loginname = '游客';
    }
    if (!lib.hasValue(level)) {
        level = '0';
    }
    var hashcode = ''; //加密过后的值
    var name = ''; //姓名=用户名(星级)
    var grade = level; //星级
    var memo = ''; //备注信息
    var skillId = 9;  // 0星级会员组9 普通客服组2 VIP客服组 3
    if (lib.hasValue(level)) {
        if (parseInt(level) >= 0) {
            name = loginname + '（' + '星级:' + level + '）';
        } else {
            name = loginname + '（' + '黑名单:' + level + '）';
        }

        if(parseInt(level) > 0 && parseInt(level) <= 4) {
            skillId = 2;
        } else if (parseInt(level) >= 5) {
            skillId = 3;
        }
    }
    //完成加密
    hashcode = $.md5(encodeURIComponent(userid + loginname + grade + name + memo + timestamp + encryptkey).toLocaleUpperCase()).toLocaleUpperCase();
    var infovalue = encodeURIComponent("userId=" + userid + "&loginname=" + loginname + "&grade=" + grade + "&name=" + name + "&memo=" + memo + "&hashCode=" + hashcode + "&timestamp=" + timestamp);

    var companyID = 0;
    var configID = 0;
    //如果登入并且等级大于等于5 , 跳转到VIP客服 .
    // if (loginname != "游客" && level >= 5) {
    //     // companyID = vipMemberCompanyID;
    //     // configID = vipMemberConfigID;
    //     companyID = ordinaryMemberCompanyID;
    //     configID = ordinaryMemberConfigID;
    // }else{
    //     //否则跳转到普通客服.
    //     companyID = ordinaryMemberCompanyID;
    //     configID = ordinaryMemberConfigID;
    // }
    //change by yancy since 2018/04/28 begin
    //如果已登陆，且是在VIP站登陆的或者星级大于5的，则使用VIP客服
    /*if (loginname != "游客" && (terminal == 'VIP' || level >= 5)) {
        companyID = vipMemberCompanyID;
        configID = vipMemberConfigID;
    }else{*/
        companyID = ordinaryMemberCompanyID;
        configID = ordinaryMemberConfigID;
    /*}*/
    //change by yancy since 2018/04/28 end


    url = rooturl + '?companyID=' + companyID + '&configID=' + configID + '&skillId=' + skillId + '&enterurl=' + enterurl + '&info=' + infovalue + '&timestamp=' + timestamp;
    return url;
}

function _cs() {
    openWindow(window.cs_target, 850, 550);
}

function openWindow(url, width, height) {
    var hasScroll;
    if (window.screen.width == 800 && window.screen.height == 600) {
        hasScroll = "yes";
    } else {
        hasScroll = "no";
    }
    var lOffset = $(window).width() ? ($(window).width() - width) / 2 : 0;
    var tOffset = $(window).height() ? ($(window).height() - height) / 2 : 0;
    var param = "height=" + height + ", width=" + width + ",left=" + lOffset + ",top=" + tOffset + ", scrollbars= " + hasScroll + ",resizable=yes,toolbar=no,directories=no,menubar=no,locationbar=no,personalbar=no,statusbar=no";
    window.open(url, "_cs", param);
}

//在线客服
var encryptkey = "ag123456789";
var rooturl = "https://ag-customer-service.com/chat/chatClient/chatbox.jsp";
var ordinaryMemberCompanyID = "8989";
var ordinaryMemberConfigID = "3";
var vipMemberCompanyID = "9002";
var vipMemberConfigID = "7";
window.cs_target = findCSURL(pn.userId, pn.userName, pn.userLevel, pn.terminal);
$(function () {
    $("body").on("click", ".as-cs,.as-cs-js", function (t) {
        var node = $(this);
        if (node.is(".as-cs-js") || node.is(".as-cs")) {
            openWindow(window.cs_target, 850, 550);
        }
    });
});
