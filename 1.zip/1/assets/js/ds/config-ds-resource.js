//PC主站埋点配置
var DS_CONFIG_JSON = [
    {
        "location": "AG8主页|左方导航",
        "locationName": "首页",
        "code": "AG8001",
        "label": "首页",
        "url": ""
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "AG国际厅",
        "code": "AG8002",
        "label": "AG国际厅",
        "url": "/game/play/agin"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "AG旗舰厅",
        "code": "AG8003",
        "label": "AG旗舰厅",
        "url": "/game/play/agq"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "AG刮刮彩",
        "code": "AG8004",
        "label": "AG刮刮彩",
        "url": "/game/play/scg"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "AG赌场厅",
        "code": "AG8005",
        "label": "AG赌场厅",
        "url": "/game/show/agtel"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "AG棋牌厅",
        "code": "AG8006",
        "label": "AG棋牌厅",
        "url": "/game/show/agchess"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "电子游戏",
        "code": "AG8007",
        "label": "电子游戏",
        "url": "AG8007"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "体育投注",
        "code": "AG8008",
        "label": "体育投注",
        "url": "/sports/sabah"
    },
    {
        "location": "AG8主页|左方导航",
        "locationName": "最新优惠",
        "code": "AG8009",
        "label": "最新优惠",
        "url": "/promotion"
    },
    {
        "location": "AG8主页|左方导航 ",
        "locationName": "手机投注",
        "code": "AG8010",
        "label": "手机投注",
        "url": "/publicity/download"
    },
    {
        "location": "AG8主页|左上导航",
        "locationName": "亚游风采",
        "code": "AG8011",
        "label": "亚游风采",
        "url": ""//无法埋页面
    },
    {
        "location": "AG8主页|左上导航",
        "locationName": "亚游论坛",
        "code": "AG8012",
        "label": "亚游论坛",
        "url": "/bbs"
    },
    {
        "location": "AG8主页|左上导航",
        "locationName": "推荐好友",
        "code": "AG8013",
        "label": "推荐好友",
        "url": "/publicity/recommend"
    },
    {
        "location": "AG8主页|顶部广告",
        "locationName": "顶部广告",
        "code": "AG8014",
        "label": "顶部广告",
        "url": "AG8014"
    },
    {
        "location": "AG8主页|右上导航",
        "locationName": "快速登录",
        "code": "AG8015",
        "label": "快速登录",
        "url": "AG8015"
    },
    {
        "location": "AG8主页|右上导航",
        "locationName": "快速注册",
        "code": "AG8016",
        "label": "快速注册",
        "url": "AG8016"
    },
    {
        "location": "AG8主页|右上导航",
        "locationName": "免费试玩",
        "code": "AG8017",
        "label": "免费试玩",
        "url": "AG8017"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "快速登录",
        "code": "AG8018",
        "label": "快速登录",
        "url": "#quick-login"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "动态密码登录",
        "code": "AG8019",
        "label": "动态密码登录",
        "url": "#phone-login"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "登录",
        "code": "AG8020",
        "label": "登录",
        "url": "AG8020"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "忘记密码",
        "code": "AG8021",
        "label": "忘记密码",
        "url": "AG8021"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "在此注册",
        "code": "AG8022",
        "label": "在此注册",
        "url": "AG8022"
    },
    {
        "location": "AG8主页|快速登录弹窗页面",
        "locationName": "关闭",
        "code": "AG8023",
        "label": "关闭",
        "url": "AG8023"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "快速注册",
        "code": "AG8024",
        "label": "快速注册",
        "url": "#quick-register"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "普通注册",
        "code": "AG8025",
        "label": "普通注册",
        "url": "#basic-register"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "快速注册界面-注册",
        "code": "AG8026",
        "label": "快速注册界面-注册",
        "url": "AG8026"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "普通注册界面-注册",
        "code": "AG8027",
        "label": "普通注册界面-注册",
        "url": "AG8027"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "注册送刮刮卡",
        "code": "AG8028",
        "label": "注册送刮刮卡",
        "url": "AG8028"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "在此登录",
        "code": "AG8029",
        "label": "在此登录",
        "url": "AG8029"
    },
    {
        "location": "AG8主页|快速注册弹窗页面",
        "locationName": "关闭",
        "code": "AG8030",
        "label": "关闭",
        "url": "AG8030"
    },
    {
        "location": "AG8主页|右侧导航",
        "locationName": "新手教程",
        "code": "AG8031",
        "label": "新手教程",
        "url": "/publicity/tutorials"
    },
    {
        "location": "AG8主页|右侧导航",
        "locationName": "在线客服",
        "code": "AG8032",
        "label": "在线客服",
        "url": "AG8032"
    },
    {
        "location": "AG8主页|右侧导航",
        "locationName": "加速登录器",
        "code": "AG8033",
        "label": "加速登录器",
        "url": "/tools/accelerator"
    },
    {
        "location": "AG8主页|底部",
        "locationName": "关于AG亚游",
        "code": "AG8034",
        "label": "关于AG亚游",
        "url": "/publicity/aboutus"
    },
    {
        "location": "AG8主页|底部",
        "locationName": "游戏规则",
        "code": "AG8035",
        "label": "游戏规则",
        "url": "/publicity/gamerule"
    },
    {
        "location": "AG8主页|底部",
        "locationName": "开牌结果验证",
        "code": "AG8036",
        "label": "开牌结果验证",
        "url": "/publicity/verification"
    },
    {
        "location": "AG8主页|底部",
        "locationName": "博彩牌照",
        "code": "AG8037",
        "label": "博彩牌照",
        "url": "/publicity/aboutus#license"
    },
    {
        "location": "AG8主页|底部",
        "locationName": "工具下载",
        "code": "AG8038",
        "label": "工具下载",
        "url": "/publicity/aboutus#tools"
    },
    {
        "location": "AG8主页|中侧",
        "locationName": "主轮播图",
        "code": "AG8039",
        "label": "主轮播图",
        "url": "AG8039"
    },
    {
        "location": "AG8主页|中下侧",
        "locationName": "轮播图一",
        "code": "AG8040",
        "label": "轮播图一",
        "url": "AG8040"
    },
    {
        "location": "AG8主页|中下侧",
        "locationName": "轮播图二",
        "code": "AG8041",
        "label": "轮播图二",
        "url": "AG8041"
    },
    {
        "location": "AG8主页|中下侧",
        "locationName": "轮播图三",
        "code": "AG8042",
        "label": "轮播图三",
        "url": "AG8042"
    },
    {
        "location": "AG8主页|中下侧",
        "locationName": "轮播图四",
        "code": "AG8043",
        "label": "轮播图四",
        "url": "AG8043"
    },
    {
        "location": "AG8主页|中下侧",
        "locationName": "轮播图五",
        "code": "AG8044",
        "label": "轮播图五",
        "url": "AG8044"
    },
    {
        "location": "AG8主页|右上导航（登录后）",
        "locationName": "消息",
        "code": "AG8045",
        "label": "消息",
        "url": "/ucenter/letters"
    },
    {
        "location": "AG8主页|右上导航（登录后）",
        "locationName": "我的账户",
        "code": "AG8046",
        "label": "我的账户",
        "url": "/ucenter/account"
    },
    {
        "location": "AG8主页|右上导航（登录后）",
        "locationName": "游戏大厅",
        "code": "AG8047",
        "label": "游戏大厅",
        "url": "/game/show/lobby"
    },
    {
        "location": "AG8主页|右上导航（登录后）",
        "locationName": "充值",
        "code": "AG8048",
        "label": "充值",
        "url": "/ucenter/pay/payIndex"
    },
    {
        "location": "AG8主页|右上导航（登录后）",
        "locationName": "提现",
        "code": "AG8049",
        "label": "提现",
        "url": "/ucenter/withdraw/withdrawIndex"
    },
    {
        "location": "AG8主页|游戏大厅（登录后）",
        "locationName": "AG旗舰厅",
        "code": "AG8050",
        "label": "AG旗舰厅",
        "url": "/game/play/agq"
    },
    {
        "location": "AG8主页|游戏大厅（登录后）",
        "locationName": "AG国际厅",
        "code": "AG8051",
        "label": "AG国际厅",
        "url": "/game/play/agin",
        "url2": "/game/show/agin"
    },
    {
        "location": "AG8主页|游戏大厅（登录后）",
        "locationName": "AG捕鱼王",
        "code": "AG8052",
        "label": "AG捕鱼王",
        "url": "/fishing"
    },
    {
        "location": "AG8主页|游戏大厅",
        "locationName": "AG亚游电游",
        "code": "AG8053",
        "label": "AG亚游电游",
        "url": "AG8053"
    },
    {
        "location": "AG8主页|游戏大厅（登录后）",
        "locationName": "AG刮刮彩",
        "code": "AG8054",
        "label": "AG刮刮彩",
        "url": "/game/play/scg"
    },
    {
        "location": "AG8主页|游戏大厅（登录后）",
        "locationName": "沙巴体育",
        "code": "AG8055",
        "label": "沙巴体育",
        "url": "/sports/sabah"
    },
    {
        "location": "充值|在线支付",
        "locationName": "在线支付",
        "code": "AG8056",
        "label": "在线支付",
        "url": "/ucenter/pay/payIndex#tab-1"
    },
    {
        "location": "充值|在线支付",
        "locationName": "在线支付-网银在线支付",
        "code": "AG8057",
        "label": "网银在线支付",
        "url": "AG8057"
    },
    {
        "location": "充值|在线支付",
        "locationName": "在线支付-银联快捷支付",
        "code": "AG8058",
        "label": "银联快捷支付",
        "url": "AG8058"
    },
    {
        "location": "充值|在线支付",
        "locationName": "在线支付-下一步",
        "code": "AG8059",
        "label": "下一步",
        "url": "AG8059"
    },
    {
        "location": "充值|比特币支付",
        "locationName": "比特币支付",
        "code": "AG8060",
        "label": "比特币支付",
        "url": "/ucenter/pay/payIndex#tab-6"
    },
    {
        "location": "充值|比特币支付",
        "locationName": "比特币支付-下一步",
        "code": "AG8061",
        "label": "下一步",
        "url": "AG8061"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付",
        "code": "AG8062",
        "label": "扫码支付",
        "url": "/ucenter/pay/payIndex#tab-2"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-超级支付宝",
        "code": "AG8063",
        "label": "超级支付宝",
        "url": "AG8063"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-微信",
        "code": "AG8064",
        "label": "微信",
        "url": "AG8064"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-支付宝",
        "code": "AG8065",
        "label": "支付宝",
        "url": "AG8065"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-QQ",
        "code": "AG8066",
        "label": "QQ",
        "url": "AG8066"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-银联",
        "code": "AG8067",
        "label": "银联",
        "url": "AG8067"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-京东",
        "code": "AG8068",
        "label": "京东",
        "url": "AG8068"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-下一步",
        "code": "AG8069",
        "label": "下一步",
        "url": "AG8069"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账",
        "code": "AG8070",
        "label": "银行卡转账",
        "url": "/ucenter/pay/payIndex#tab-3"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账-网银",
        "code": "AG8071",
        "label": "网银",
        "url": "AG8071"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账-支付宝",
        "code": "AG8072",
        "label": "支付宝",
        "url": "AG8072"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账-手机银行",
        "code": "AG8073",
        "label": "手机银行",
        "url": "AG8073"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账-微信支付",
        "code": "AG8074",
        "label": "微信支付",
        "url": "AG8074"
    },
    {
        "location": "充值|银行卡转账",
        "locationName": "银行卡转账-下一步",
        "code": "AG8075",
        "label": "下一步",
        "url": "AG8075"
    },
    {
        "location": "充值|快充",
        "locationName": "快充",
        "code": "AG8076",
        "label": "快充",
        "url": "/ucenter/pay/payIndex#tab-4"
    },
    {
        "location": "充值|快充",
        "locationName": "快充-下一步",
        "code": "AG8077",
        "label": "下一步",
        "url": "AG8077"
    },
    {
        "location": "充值|扫码支付",
        "locationName": "扫码支付-云闪付",
        "code": "AG8078",
        "label": "云闪付",
        "url": "AG8078"
    },
]