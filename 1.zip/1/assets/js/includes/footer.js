/***
 * 底部引入共通JS
 */
// dynamicLoading.js(webConf.cdn_url + "/assets/js/includes/includes.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/es6-sham.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/wow.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/bootstrap/bootstrap.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/countdown/jquery.countdown.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/loading/jquery.loading.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/carousel.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/jquery/jquery.easing.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/jquery/jquery.marquee.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/validate/jquery.validate.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/cookie/jquery.cookie.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/safety/jquery.md5.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/constants/constants.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/validatorFrom.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/includes/sticky.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/lib/lib.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/jquery.mission.helper.js?ver=" + webConf.ver);   //我的任务
dynamicLoading.js(webConf.cdn_url + "/assets/js/crypto-js.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/jquery/jquery.placeholder.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/qr/jquery.qrcode.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/qr/qrcode.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/qr/utf.js");

/*大数据埋点*/
dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/fingerprint.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/config-ds-resource.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/ds.js?ver=" + webConf.ver);


dynamicLoading.js(webConf.cdn_url + "/assets/js/main.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/custom/associated/associated.login.helper.js?ver=" + webConf.ver);  //登录互通
dynamicLoading.js(webConf.cdn_url + "/assets/js/plugins/cookie/cookie.helper.js?ver=" + webConf.ver);  //获取用户等级
dynamicLoading.js(webConf.cdn_url + "/assets/js/custom/helper/jquery.cms.helper.js?ver=" + webConf.ver);  //cms 公共js
dynamicLoading.js(webConf.cdn_url + "/assets/js/ucenter/ucenterCommon.js?ver=" + webConf.ver); //获取用户余额
// dynamicLoading.js(webConf.cdn_url + "/assets/js/home/index_cms.js?ver=" + webConf.ver); //首页CMS配置
dynamicLoading.js(webConf.cdn_url + "/assets/js/home/headImage.js?ver=" + webConf.ver); //头部CMS广告配置
dynamicLoading.js(webConf.cdn_url + "/assets/js/base/agcs.js?ver=" + webConf.ver); //联系客服弹窗
// dynamicLoading.js(webConf.cdn_url + "/assets/js/login/login.js?ver=" + webConf.ver);
// dynamicLoading.js(webConf.cdn_url + "/assets/js/register.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/kapcha/kaptcha.js?ver=" + webConf.ver);

/*站内信*/
dynamicLoading.js(webConf.cdn_url + "/assets/js/webSocket/stomp.min.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/webSocket/sockjs.min.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/webSocket/webMessage.js?ver=" + webConf.ver);
/*大数据埋点*/
// dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/fingerprint2.js");
// dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/config-ds-resource.js");
// dynamicLoading.js(webConf.cdn_url + "/assets/js/ds/ds.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/webSocket/tipMessage.js?ver=" + webConf.ver);

dynamicLoading.js(webConf.cdn_url + "/assets/js/publicity/sticky.js?ver=" + webConf.ver);
if(pn.egameJsHost.indexOf(location.protocol) < 0 ) {
    if(location.protocol == "https:") {
        pn.egameJsHost = pn.egameJsHost.replace("http:", "https:");
    }else {
        pn.egameJsHost = pn.egameJsHost.replace("https:", "http:");
    }
}
//dynamicLoading.js(pn.egameJsHost + pn.egameJsUrl + "games.js");

//
// (function () {
//     //  登录后加载的JS
//     var _IGNORES = ["/index.html", "/login.html", "/forgot.html", "/service/online_service.html", "/maintenance"];
//     var _temps = [];
//     for (var item in _IGNORES) {
//         var _value = _IGNORES[item], _index = location.pathname.indexOf(_value);
//         if (_index >= 0) {
//             _temps.push(_value);
//         }
//     }
//     if (!(_temps && _temps.length)) {
//         dynamicLoading.js(webConf.cdn_url + "/assets/js/message.js");
//     }
// })();
//
(function () {
    try {
        if (/88ag6\.com$/.test(location.hostname)) {
            dynamicLoading.js("//s19.cnzz.com/z_stat.php?id=1272561237&web_id=1272561237");
        }
    } catch (e) {
    }
})();


