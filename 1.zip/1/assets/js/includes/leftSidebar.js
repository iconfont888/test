//  生成左侧导航栏
$(function () {
    //  生成logo
    function createLogo(data) {
        if(data.length == 0){
            return null;
        }
        return '<a href="/" style="background: url('+data.maxImageUrl+') center no-repeat"' +
            'class="logo" data-tongji-attr="_trackEvent,AG8,主站,首页,首页"></a>';
    }

    //  生成扫一扫
    function createQrWrap(){
        var qrHtml ='<div class="qr-image">'
            +'<div id="img_qr"></div>'
            +'<div class="scanner"><img src="/assets/images/others/global/line.png" width="127px"></div>'
            +'</div>'
            +'<p>扫一扫 下载手机亚游</p>';

        $(".qr-wrap.leftsidbar").empty().append(qrHtml);

        $.request({
            url: "/api/app/downloadUrl"
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                utils.storage.setItem('downloadDic',JSON.stringify({'host':data.host,'appAgDownload':data.appAgDownload,'mobledowlond':data.mobledowlond,'appAgqjHref':data.appAgqjHref,'appAgin':data.appAgin,'appFish':data.appFish}));
                if(AG_INIT.isLogin()){
                    AG_INIT.resetParam("moblefrend",data.moblefrend);
                    AG_INIT.resetParam("host",data.host);
                }
                //获取二维码生成的跳转地址
                var appAgDownload = data.appAgDownload+'?domain='+location.hostname;
                var isCnyTheme = $('.wrapper').hasClass('cny-theme');
                //生成二维码
                $('#img_qr').qrcode({
                    ecLevel: 'H',
                    render    : "canvas",
                    text    : appAgDownload,
                    width : "120",               //二维码的宽度
                    height : "120",              //二维码的高度
                    background : isCnyTheme ? "#b73119" : "#ffffff",       //二维码的后景色
                    foreground : "#000000",        //二维码的前景色
                    src: '/assets/images/home/new_icon.png'             //二维码中间的图片
                });
            }else{
                logConsole(response.message);
            }
        }).fail(function(e){
            logConsole(e);
        });
    }
    //  生成sidebarInner
    function createSidebarInnner(data){
        if(data.length == 0){
            return null;
        }
        var html = [];
        var w = $(window).width();
        w = w > 1920 ? 1920 : w;
        w = w - 310;
        for(var index = 0;index<data.length;index++){
            var dataItem = data[index];
            var cls = index < data.length / 2 ? 'left' : '';
            if(data.length < 9 && index === 0) {
                cls += ' show-home';
            }
            if(data.length < 9 && index === 3) {
                cls += ' no-right-border';
            } else if(index === 4) {
                cls += ' no-right-border';
            }
            var retHtml = createHtml(dataItem, cls, w/8);
            html.push(retHtml);
        }
        return html.join("");
    }
    
    //  生成 sidebar 对象集合
    var grepSidebar = function (data) {
        var _logo = [];
        var _qrWrap = [];
        var sidebarInner = [];
        $.each(data, function (index, item) {
            if(item.rank >= 101021000&&item.rank < 101022000){
                var $logo = {
                    index: item.rank,
                    defaultAction:item.defaultAction,
                    maxImageUrl:item.maxImageHttpUrl,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime
                };
                _logo.push($logo);
            }else if(item.rank >= 101022000 && item.rank < 101023000){
                var textDescription = item["textDescription"].split("#");
                var description = textDescription[0],dataSidebar = textDescription[1],tongji = textDescription[2];
                var $sidebarInner = {
                    index: item.rank,
                    defaultAction:item.defaultAction,
                    minImageAction:item.minImageAction,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime,
                    "minImageHttpUrl": item.minImageHttpUrl,
                    "maxImageHttpUrl": item.maxImageHttpUrl,
                    "hotIconUrl": item.hotIconHttpUrl,
                    "dataSidebar":dataSidebar,
                    "description": description,
                    "jsonObj" : item.jsonObj,
                    "target": item.targetType,
                    tongji:tongji
                };
                sidebarInner.push($sidebarInner);
            }else if(item.rank >= 101023000 && item.rank < 101030000){
                var $qrWrap = {
                    index: item.rank,
                    defaultAction:item.defaultAction,
                    maxImageUrl:item.maxImageHttpUrl,
                    "description": item["textDescription"],
                    "beginTime": item.beginTime,
                    "endTime": item.endTime
                };
                _qrWrap.push($qrWrap);
            }
        });
        _logo = resort(grepGame(_logo, [function (n) {
            if(n.endTime){
                if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                    return true;
                }
                return false;
            }else {
                return n.beginTime < pn.sys_now;
            }
        }]), "index");
        _qrWrap = resort(grepGame(_qrWrap, [function (n) {
            if(n.endTime){
                if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                    return true;
                }
                return false;
            }else {
                return n.beginTime < pn.sys_now;
            }
        }]), "index");
        sidebarInner = resort(grepGame(sidebarInner, [function (n) {
            if(n.endTime){
                if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                    return true;
                }
                return false;
            }else {
                return n.beginTime < pn.sys_now;
            }
        }]), "index");
        return {
            logo:_logo[0],
            qrWrap:_qrWrap[0],
            sidebarInner:sidebarInner
        }
    };

    function createHtml(data, cls, w){
        var beginTime = data["beginTime"],
            defaultAction = data["defaultAction"],
            minImageAction=data["minImageAction"],
            hotIcon = data["hotIconUrl"],
            maxImageHttpUrl = data["maxImageHttpUrl"],
            minImageHttpUrl = data["minImageHttpUrl"],
            endTime = data["endTime"],
            targetType = data["target"],
            description = data["description"],
            dataSidebar = data["dataSidebar"],
            tip = data["tip"],
            tongji = data["tongji"];
        var strForDS = utils.getDsCodeAttr(data['jsonObj']);
        var html = '';
        if($('body').hasClass('horizontal') || $('body').hasClass('activity')) {
            html = '<li data-sidebar="' + dataSidebar +'" class="'+ cls +'" style="width: '+ Math.floor(w) +'px">';
        } else {
            html = '<li data-sidebar="' + dataSidebar +'" class="'+ cls +'">';
        }
        
        if(dataSidebar == 'agin' || dataSidebar == 'agq' || dataSidebar == 'fishing'){
            if(pn.userLevel>=2){
                html += '<a href="'+minImageAction+'" ' + strForDS +
                    'style="background-image:url('+minImageHttpUrl+');" ' +
                    'target="_blank" data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
            }else{
                html += '<a href="'+defaultAction+'" ' + strForDS +
                    'style="background-image:url('+minImageHttpUrl+');" ' +
                    'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
            }

        }else{
            if(pn.userLevel>=2){
                html += '<a href="'+minImageAction+'" ' + strForDS +
                    'style="background-image:url('+minImageHttpUrl+');" ' +
                    'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
            }else{
                html += '<a href="'+defaultAction+'" ' + strForDS +
                    'style="background-image:url('+minImageHttpUrl+');" ' +
                    'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
            }

        }
        
        html += description ;
        if(hotIcon){
            html += '<img src="'+hotIcon+'" class="more" >'
        }
        html += '</a></li>';
        return html;
    }

    //  生成侧边栏
    function createSidebar(data) {
        if(data === undefined) {
            return false;
        }
        var $sidebar=$(".sidebar");
        if(null == data || data == ""){
            $sidebar.find("ul").html(createDefaultSidebarInner());
            $("#logo").html(createDefaultLogo());
            return;
        }
        var data = grepSidebar(data);
        var logoHtml,sidebarInnnerHtml;
        try {
            logoHtml = createLogo(data.logo);
        }catch (exception){
            logoHtml = createDefaultLogo();
        }
        try {
            sidebarInnnerHtml = createSidebarInnner(data.sidebarInner);
            // 判断是否是IE浏览器
            if(BrowserType()) {
                if (location.href.indexOf('#reload') === -1) {
                    location.href = location.href + "#reload";
                    location.reload();
                }
            }
        }catch (exception){
            sidebarInnnerHtml = createDefaultSidebarInner();
        }

        if(null != sidebarInnnerHtml){
            $sidebar.find("ul").html(sidebarInnnerHtml);
        }else{
            $sidebar.find("ul").html(createDefaultSidebarInner());
        }
        if(null != logoHtml){
            $sidebar.find("#logo").html(logoHtml);
        }else{
            $sidebar.find("#logo").html(createDefaultLogo());
        }

        // 添加激活状态
        $('.sidebar ul li').each(function(i, el) {
            var $el = $(el);
            if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
                $el.addClass('active');
                $el.siblings('li').removeClass('active');
            }
        });
        if (location.href.indexOf('/activity/') !== -1) {
            var $el = $("div.sidebar > ul > li[data-sidebar='promotion']");
            $el.addClass('active');
            $el.siblings('li').removeClass('active');
        }

        createQrWrap();
    }

    function createDefaultSidebar(){
        $(".sidebar").find("ul").html(createDefaultSidebarInner());
        $("#logo").html(createDefaultLogo());
    }

    function createDefaultLogo() {
        /*return '<a href="/" class="logo" data-tongji-attr="_trackEvent,AG8,主站,首页,首页"></a>';*/
        return "";
    }
    function createDefaultSidebarInner(){
        /*
         return '<li data-sidebar="home_index"><a href="/" class="home active" data-tongji-attr="_trackEvent,AG8,主站,首页,首页">首 页</a></li>' +
         '<li data-sidebar="home_agq"><a href="/game/show/agq" class="flagship" data-tongji-attr="_trackEvent,AG8,主站,旗舰厅,旗舰厅">AG旗舰厅<img src="'+pn.staticurl+'/static/images/others/sidebar/more_icon.png" class="more"></a></li>' +
         '<li data-sidebar="home_agin"><a href="/game/show/agin" class="international" data-tongji-attr="_trackEvent,AG8,主站,国际厅,国际厅">AG国际厅</a></li>' +
         '<li data-sidebar="home_agtel"><a href="/game/show/agtel" class="tel" data-tongji-attr="_trackEvent,AG8,主站,现场厅,现场厅">AG现场厅</a></li>' +
         '<li data-sidebar="home_egame"><a href="/website/redirect?url=/" target="_playEgame" class="casino" data-tongji-attr="_trackEvent,AG8,主站,电游,电游">电子游戏</a></li>' +
         '<li><a href="/website/redirect?url=/fishing" target="_playEgame" class="fishing" data-tongji-attr="_trackEvent,AG8,主站,捕鱼王,捕鱼王">AG捕鱼王</a></li>' +
         '<li data-sidebar="home_sport"><a href="/game/try/shababsports" class="sports" data-tongji-attr="_trackEvent,AG8,主站,体育,体育">体育投注</a></li>' +
         '<li data-sidebar="home_promotion"><a href="/promotion" class="promotions" data-tongji-attr="_trackEvent,AG8,主站,最新优惠,最新优惠">最新优惠</a></li>' +
         '<li data-sidebar="home_mobile"><a href="/publicity/download" class="mobile" data-tongji-attr="_trackEvent,AG8,主站,手机投注,手机投注">手机投注</a></li>';
         */
        return "";
    }


    //  左侧导航栏
    if($(".sidebar").length){
        if (typeof cmsHelper != "undefined") {
            var d_cms_cache = utils.storage.getItem('cms_' + CMS_MODEL.sidebar);
            if(d_cms_cache != null) {
                createSidebar(JSON.parse(d_cms_cache))
            }
            cmsHelper.getScriptResult(CMS_MODEL.sidebar)
                .done(createSidebar)
                .fail(cms_failure)
                .fail(createDefaultSidebar);
        }
    }
});