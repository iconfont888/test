$(document).ready(function() {
    // Get Started
    var loadHeader = function(name) {
        $('.' + name).load('/includes/'+ name +'.html', function() {
            //===================================================网站头部样式控制
            // setTimeout(function () {
            //清除头部多个id控制台报错的日志
            // console.clear();
            if (pn.userName) {
                $("#nodataloginflag").remove();
                $(".header-user-name").html(pn.userName);
                $("#yesdateloginflag").show();
                $('.navbar-after').show();
                $('.navbar-before').remove();
                //是否试玩用户
                if (pn.userType == "0") {
                    $('#zhengqianuser').remove();
                    $('#congzhitixian').remove();
                    $('.navbar-after .gamelobby .dropdown-container').remove();
                    $("#header-balance").remove();
                } else {
                    $('#congzhitixian').show();
                    $('#shiwangyonghu').remove();
                }
                //vip用户
                if (pn.userLevel < 4) {
                    $('#vipkehu').remove();
                }
                var USER_LEVEL = ['新会员','一星级','二星级','三星级','VIP4','VIP5','VIP6','VIP7'];
                if(pn.userType =="0"){
                    $(".header-user-level").addClass("level-0");
                    $(".header-user-level").html("试玩号");
                }else{
                    $(".header-user-level").addClass("level-"+pn.userLevel);
                    $(".header-user-level").html(USER_LEVEL[pn.userLevel]);
                    $("#crown").addClass("crown-" + pn.userLevel);
                }
                if (pn.beforeLoginDate){
                    $(".header-before-login-date").html("最近登录时间："+pn.beforeLoginDate);
                    //VIP页面登录时间
                    $(".header-before-login-date-2").html("最近登录时间：<br />"+pn.beforeLoginDate);
                }else {
                    $(".header-before-login-date-2").html("无记录");
                }

                //设置头部游戏大厅链接
                $("#fishing_url").attr("href", "/game/dygame/fishing/");//"/website/redirect?url="+pn.eGameUrl+"/fishing"
                $("#game_url").attr("href", "/game/dygame/");//"/website/redirect?url="+pn.eGameUrl
                $("#agstar_url").attr("href","/game/iframe/index.html?egames=1&gameCode=agstar&gameName=asstar&g=as&platType=AS&language=zh&trial=false");//"/website/redirect?url="+pn.eGameUrl+"/game/play/agstar"

                // 侧边栏 安全退出 提示
                $('.btn-logout').on('click',function () {
                    //  标记, 不再自动授权登录
                    nonLoginHelper.setLogoutMark();
                    //   清除缓存
                    AG_INIT.clear();
                    $.request({
                        url: "/api/sync/logout"
                    }).done(function () {
                        location.href = "/login";
                    }).fail(function(e){
                        logConsole(e);
                    });
                });
            } else {
                $("#yesdataloginflag").remove();
                $('.navbar-after').remove();
                $('.navbar-before').show();
            }

            utils.getImageCode("/api/captcha?site=10&type=login",$('img.code-login'));
            utils.getImageCode("/api/captcha?site=10&type=register",$('img.code-register'));
            utils.getImageCode("/api/captcha?site=10&type=trial",$('img.code-trial'));
            $("input[name=inlineRadioOptions]").on('change', function() {
                $(this).parents('.form-group').next().toggleClass('hide', parseInt($(this).val(), 10));
            });
        });
    };
    // 普通 header   体育相关 header2
    if((location.href.indexOf('/sports/') != -1 || location.href.indexOf('/game/dygame/') != '-1') && location.href.indexOf('?login') == -1)  {
        $('.header').attr('class', 'header3 header2');
        loadHeader('header3');
        var headSports='<link href="/assets/css/pages/header_sports.css" rel="stylesheet">';
        $('head').append(headSports);
        $('.sidebar').remove();
        $('.u-wrap').css({
            'margin-left': 0,
            'padding': '80px 30px 15px 10px'
        });
        $('.u-modal-center').removeClass('u-modal-center');
        $('.main-container').css('margin-left','0px');
    } else {
        loadHeader('header');
    }


    $('.sidebar').load('/includes/sidebar.html', function() {
        $('.sidebar ul li').each(function(i, el) {
            var $el = $(el);
            if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
                $el.addClass('active');
                $el.siblings('li').removeClass('active');
            }
        });
        if (location.href.indexOf('/activity/') !== -1) {
            var $el = $('.sidebar ul li a.promotions').parent();
            $el.addClass('active');
            $el.siblings('li').removeClass('active');
        }
        var winwidth = $(window).width();
        var winheight = $(window).height();
        $(window).on('scroll', function() {
            if( winwidth <= 1366 && winheight <= 768) {
                var sTop = document.body.scrollTop || document.documentElement.scrollTop;
                $('.sidebar').toggleClass('fixed', sTop > 175);
            }
            else {

                $('.sidebar').addClass('fixedsm');
            }
        });
    });

    //加载左侧菜单导航
    $('.sticky').load('/includes/sticky.html');
    // //加载底部
    $('.footer').load('/includes/footer.html',function () {
        //底部电游链接
        $("#egame_url").attr("href","/website/redirect?url="+pn.eGameUrl);
    });
    if ($('.u-menu').length > 0) {
        $('.u-menu').load('/includes/u_menu.html', function() {
            // keep u-menu and u-main same height
            // $('.u-menu, .u-main').height(Math.max($('.u-menu').height(), $('.u-main').height()));
            $('.u-menu dd').each(function(i, el) {
                var $el = $(el);
                if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
                    $el.addClass('active');
                    $el.siblings('dt').addClass('active');
                }
            });
            if (location.href.indexOf('/verify/phone') !== -1) {
                $('.u-menu dd a[href="/ucenter/acount/"]').parent('dd').addClass('active');
            }

            if ($('.header2').length > 0) {
                $('.umenu-wrap a').each(function(i, el) {
                    $(el).attr('href', $(el).attr('href') + '?sport');
                });
            }
        });
    }
    if ($('.v-menu').length > 0) {
        $('.v-menu').load('/includes/v_menu.html', function() {
            $('.v-menu dd').each(function(i, el) {
                var $el = $(el);
                if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
                    $el.addClass('active');
                    $el.siblings('dt').addClass('active');
                }
            });
        });
    }

    $('.u-letter .btn-select-all').on('click', function() {
        var flag = $(this).data('checked');
        $('.u-letter .list-group input[type=checkbox]').prop('checked', !flag).text(flag ? '全选' : '取消全选');
        $(this).data('checked', !flag).text(flag ? '全选' : '取消全选');
    });

    $('.u-letter .btn-select-all').on('click', function() {
        var flag = $(this).data('checked');
        $('.u-letter .list-group input[type=checkbox]').prop('checked', !flag).text(flag ? '全选' : '取消全选');
        $(this).data()
    })

    $('.u-letter .btn-del').on('click', function() {
        $('.u-letter .list-group input:checked').parent('li').remove();
    });
    $('.u-letter .btn-cancel').on('click', function() {
        $('.u-letter .btn-edit').trigger('click');
    });

    // 触发免费试玩
    $('.showdemo').click(function() {
        $('.btn-tryplay').dropdown('toggle').parent().addClass('is-active');
        $('body').addClass('is-active');
        return false;
    });

    // 修复bootstrapde的tab切换页面跳顶bug
    $('.nav-tabs a').on('shown.bs.tab', function(e) {
        // 更新地址栏
        var sTop = document.body.scrollTop || document.documentElement.scrollTop;
        window.location.hash = e.target.hash;
        $('html, body').scrollTop(sTop);
    });
});



// 统一laoding样式及调用
$.fn.loading = function() {
    var $this = $(this);
    // var screenWidth = screen.width;
    // console.log($this, 11110)
    if ($this.length <= 0) {
        return false;
    }
    var _width = $this.outerWidth();
    var _height = $this.outerHeight();
    var _offset = $this.offset();
    // if(screenWidth >= 3840){
    //     _width = _width * 2;
    //     _height = _height * 2;
    // }else if( screenWidth >= 2880 ) {
    //     _width = _width * 1.5;
    //     _height = _height * 1.5;
    // }else if( screenWidth >= 2560 ) {
    //     _width = _width * 1.33333;
    //     _height = _height * 1.33333;
    // }else if( screenWidth >= 2440 ) {
    //     _width = _width * 1.271;
    //     _height = _height * 1.271;
    // }else if( screenWidth >= 2048 ) {
    //     _width = _width * 1.067;
    //     _height = _height * 1.067;
    // }
    var el = '<div class="loading-mask"></div>';
    $('.loading-mask').remove();

    $('body').append(el);
    $('.loading-mask').css({
        'width': _width,
        'height': _height,
        'top': _offset.top,
        'left': _offset.left
    });
    if (_height < 150) {
        $('.loading-mask').addClass('small');
    }
    if ($(this)[0].nodeName === 'BODY') {
        $('.loading-mask').css({
            'position': 'fixed',
            'z-index': '9999'
        })
    }
};


// countDown(10, function() { cosole.log('tick') }, function() { console.log('done') });
window.countDown = function(time, fn1, fn2) {
    var timer = 'timer_' + (new Date()).getTime();
    window[timer] = setInterval(function() {
        time -= 1;
        if(time >= 0) {
            fn1(time);
        } else {
            clearInterval(window[timer]);
            fn2();
        }
    }, 1000);
};

$.loading = function() {
    if (arguments.length > 0 && arguments[0] === false) {
        $('.loading-mask').remove();
        return false;
    }
    $('body').loading();
};
// $('.u-main').loading();
// $.loading();
// $.loading(false);  关闭loading


function placeholder() {
    var ie8 = false;
    if (ie8 == false) {
        // any code here will not be executed by IE 8
        // Released under MIT license: http://www.opensource.org/licenses/mit-license.php

        $('[placeholder]').focus(function() {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function() {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur().parents('form').submit(function() {
            $(this).find('[placeholder]').each(function() {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                }
            })
        });
    }
}
$(document).ready(function(){
    document.title = 'AG亚游集团--真人游戏第一品牌';
})