    // Get Started
    // 定义春节主题函数
    var initCnyTheme = function() {
        var now = (new Date()).getTime();
        var specifiedDate = 1550592000000;  // '2019-2-20 00:00:01';
        var dateStart = 1550160000000;  // '2019-2-15 00:00:00';

        if(now > specifiedDate) {
            $('.wrapper').removeClass('cny-theme'); /*future*/
        } else {
            $('.wrapper').addClass('cny-theme'); /*present*/
            if(now > dateStart && now < specifiedDate) {
                $('.wrapper .home-wrap').addClass('yuanxiao');
            }
        }
    }
    var loadHeader = function(name) {
        $('.' + name).load('/includes/'+ name +'.html?ver=' + webConf.ver, function() {
            var _register_flag = utils.storage.getItem("register_flag");
            if(_register_flag && _register_flag =="true"){
                $("#fast-reg-but").attr("data-target","#regModal3")
            }
            $(".captchaWrap").remove();
            $(".kaptcha").removeClass("success warning arrow_box").find(".tip_icon").removeClass("success warning shake_img");
            $(".kaptcha").find(".tip_text").text("点此进行验证");
            // 安装春节样式
            // initCnyTheme();
            //===================================================网站头部样式控制
            // setTimeout(function () {
            //清除头部多个id控制台报错的日志
            // console.clear();
            if (pn.userName) {
                $("#nodataloginflag").remove();
                $(".header-user-name").html(pn.userName);
                $("#yesdateloginflag").show();
                $('.navbar-after').show();
                $('.navbar-before').remove();
                //是否试玩用户
                if (pn.userType == "0") {
                    $('#vipkehu').remove();
                    $('#zhengqianuser').remove();
                    $('#congzhitixian').remove();
                    $('.navbar-after .gamelobby').css('display', 'inline-block');
                    $('.navbar-after .gamelobby .dropdown-container').remove();
                    $("#header-balance").remove();
                    $("a.btn.btn-custom.btn-menu-trigger").attr("href","/register/trial/basic/success/");
                } else {
                    $('#congzhitixian').show();
                    $('#shiwangyonghu').remove();
                }
                //针对非VIP用户（0-3星级）显示我的特权btn
                if(pn.userLevel === 0 || pn.userLevel === 1 || pn.userLevel === 2 || pn.userLevel === 3){
                    $('#vipkehu').find('a').attr('href','/activity/promote/')
                };
                var USER_LEVEL = ['新会员','一星级','二星级','三星级','VIP4','VIP5','VIP6','VIP7'];
                if(pn.userType =="0"){
                    $(".header-user-level").addClass("level-0");
                    $(".header-user-level").html("试玩号");
                }else{
                    $(".header-user-level").addClass("level-"+pn.userLevel);
                    $(".header-user-level").html(USER_LEVEL[pn.userLevel]);
                    $("#crown").addClass("crown-" + pn.userLevel);
                }
                if (pn.beforeLoginDate){
                    $(".header-before-login-date").html("最近登录时间："+pn.beforeLoginDate);
                    //VIP页面登录时间
                    $(".header-before-login-date-2").html("最近登录时间：<br />"+pn.beforeLoginDate);
                }else {
                    $(".header-before-login-date-2").html("无记录");
                }

                //设置头部游戏大厅链接
                
                $("#game_url").attr("href", "/game/dygame/");//"/website/redirect?url="+pn.eGameUrl
                if(pn.userType == 0) {
                    $("#agstar_url").attr("href","/game/iframe/index.html?egames=1&gameCode=agstar&platType=AS&gameName=asstar&g=as&language=zh&trial=true");
                    $("#fishing_url").attr("href", "/game/iframe/index.html?egames=1&g=ag&gameCode=6&gameName=Fish&platForm=AG&trial=true");
                } else {
                    $("#agstar_url").attr("href","/game/iframe/index.html?egames=1&gameCode=agstar&platType=AS&gameName=asstar&g=as&language=zh&trial=false");
                    $("#fishing_url").attr("href", "/game/iframe/index.html?egames=1&g=ag&gameCode=6&gameName=Fish&platForm=AG&trial=false");
                }

                // 侧边栏 安全退出 提示
                $('.btn-logout').on('click',function () {
                    //  标记, 不再自动授权登录
                    nonLoginHelper.setLogoutMark();
                    //   清除缓存
                    AG_INIT.clear();
                    $.request({
                        async:false,
                        url: "/api/sync/logout"
                    }).done(function () {
                        location.href = "/index.html?login";
                    }).fail(function(e){
                        logConsole(e);
                    });
                });
                //获取用户余额
                $.getScript(webConf.cdn_url + "/assets/js/ucenter/ucenterCommon.js");
            } else {
                $("#yesdataloginflag").remove();
                $('.navbar-after').remove();
                $('.navbar-before').show();
            }

            $("input[name=inlineRadioOptions]").on('change', function() {
                $(this).parents('.form-group').next().toggleClass('hide', parseInt($(this).val(), 10));
            });

            $.getScript(webConf.cdn_url + "/assets/js/login/login.js?ver=" + webConf.ver);
            $.getScript(webConf.cdn_url + "/assets/js/register.js?ver=" + webConf.ver);

            //修改新页面弹出框遮罩问题，加载完头部绑定去除遮罩事件
            var $login_btn = $("#quick-login-btn"), $register_btn = $("#fast-reg-but, .regBtn");
            $login_btn.add($register_btn).add($("#try-reg-but")).parent().on("show.bs.modal", function () {
                $('body').addClass('is-active');
                $(this).addClass('is-active');
                $(".modal-backdrop.in").remove();
            }).on("hidden.bs.modal", function (e) {
                $(e.target).find("form input[name='redirect']").val("");
                $('body').removeClass('is-active');
                $(this).removeClass('is-active');
                $(".modal-backdrop.in").remove();
            }).on("show.bs.modal",function(){
                $($(this).attr("data-target")).css("overflow","hidden");
                $(".modal-backdrop.in").remove();
            }).on("shown.bs.modal", function (e) {
                $(e.target).css('overflow',"hidden");
                $(".modal-backdrop.in").remove();
            });
            $register_btn.add($("#try-reg-but")).parent().on("show.bs.modal", function () {
                if(!pn.registerVerificationType){
                    $.request({
                        url: "/api/register/verify/type",
                    }).done(function (response) {
                        if (response.successful) {
                            var data = response.data;
                            var smsCodeType = data.smsCodeType;
                            if(smsCodeType && smsCodeType == 1){
                                utils.storage.setItem("register_flag","true");
                                return;
                            }
                            utils.storage.removeItem("register_flag");
                            pn.registerVerificationType = data.registerVerificationType;
                            switch (pn.registerVerificationType) {
                                case 2 :
                                    $(".kaptcha").hide();
                                    $(".kaptcha").next(".verification-group-js").show();
                                    utils.getImageCode("/api/captcha?site=10&type=register&_d=" + (1 - new Date()),$("#quickRegisterForm").find(".verification-group-js img"));
                                    break;
                                case 3 :
                                    $(".kaptcha").show();
                                    $(".kaptcha").next(".verification-group-js").hide();
                                    break;
                                default:
                                    $(".kaptcha").hide().next(".register-captcha").hide();//自动化测试去除验证码
                            }
                        }else{
                            logConsole(response.message);
                        }
                    }).fail(function(e){
                        logConsole(e);
                    });
                }else if(pn.registerVerificationType == 2 ){
                    utils.getImageCode("/api/captcha?site=10&type=register&_d=" + (1 - new Date()),$("#quickRegisterForm").find(".verification-group-js img"));
                }
            });
        });
    };
    loadHeader('header');

    //  生成左侧导航栏
    var renderSidebar = function () {
        //  生成logo
        function createLogo(data) {
            if(data.length == 0){
                return null;
            }
            return '<a href="/" style="background: url('+data.maxImageUrl+') center no-repeat"' +
                'class="logo" data-tongji-attr="_trackEvent,AG8,主站,首页,首页"></a>';
        }

        //  生成扫一扫
        function createQrWrap(){
            var qrHtml ='<div class="qr-image">'
                +'<div id="img_qr"></div>'
                +'<div class="scanner"><img src="/assets/images/others/global/line.png" width="127px"></div>'
                +'</div>'
                +'<p>扫一扫 下载手机亚游</p>';

            $(".qr-wrap.leftsidbar").empty().append(qrHtml);

            $.request({
                url: "/api/app/downloadUrl"
            }).done(function (response) {
                if (response.successful) {
                    var data = response.data;
                    utils.storage.setItem('downloadDic',JSON.stringify({'host':data.host,'appAgDownload':data.appAgDownload,'mobledowlond':data.mobledowlond,'appAgqjHref':data.appAgqjHref,'appAgin':data.appAgin,'appFish':data.appFish}));
                    if(AG_INIT.isLogin()){
                        AG_INIT.resetParam("moblefrend",data.moblefrend);
                        AG_INIT.resetParam("host",data.host);
                    }
                    //获取二维码生成的跳转地址
                    var appAgDownload = data.appAgDownload+'?domain='+location.hostname;
                    var isCnyTheme = $('.wrapper').hasClass('cny-theme');
                    //生成二维码
                    $('#img_qr').qrcode({
                        ecLevel: 'H',
                        render    : "canvas",
                        text    : appAgDownload,
                        width : "120",               //二维码的宽度
                        height : "120",              //二维码的高度
                        background : isCnyTheme ? "#b73119" : "#ffffff",       //二维码的后景色
                        foreground : "#000000",        //二维码的前景色
                        src: '/assets/images/home/new_icon.png'             //二维码中间的图片
                    });
                }else{
                    logConsole(response.message);
                }
            }).fail(function(e){
                logConsole(e);
            });
        }
        //  生成sidebarInner
        function createSidebarInnner(data){
            if(data.length == 0){
                return null;
            }
            var html = [];
            var w = $(window).width();
            w = w > 1920 ? 1920 : w;
            w = w - 310;
            for(var index = 0;index<data.length;index++){
                var dataItem = data[index];
                var cls = index < data.length / 2 ? 'left' : '';
                if(data.length < 9 && index === 0) {
                    cls += ' show-home';
                }
                if(data.length < 9 && index === 3) {
                    cls += ' no-right-border';
                } else if(index === 4) {
                    cls += ' no-right-border';
                }
                var retHtml = createHtml(dataItem, cls, w/8);
                html.push(retHtml);
            }
            return html.join("");
        }
        
        //  生成 sidebar 对象集合
        var grepSidebar = function (data) {
            var _logo = [];
            var _qrWrap = [];
            var sidebarInner = [];
            $.each(data, function (index, item) {
                if(item.rank >= 101021000&&item.rank < 101022000){
                    var $logo = {
                        index: item.rank,
                        defaultAction:item.defaultAction,
                        maxImageUrl:item.maxImageHttpUrl,
                        "beginTime": item.beginTime,
                        "endTime": item.endTime
                    };
                    _logo.push($logo);
                }else if(item.rank >= 101022000 && item.rank < 101023000){
                    var textDescription = item["textDescription"].split("#");
                    var description = textDescription[0],dataSidebar = textDescription[1],tongji = textDescription[2];
                    var $sidebarInner = {
                        index: item.rank,
                        defaultAction:item.defaultAction,
                        minImageAction:item.minImageAction,
                        "beginTime": item.beginTime,
                        "endTime": item.endTime,
                        "minImageHttpUrl": item.minImageHttpUrl,
                        "maxImageHttpUrl": item.maxImageHttpUrl,
                        "hotIconUrl": item.hotIconHttpUrl,
                        "dataSidebar":dataSidebar,
                        "description": description,
                        "jsonObj" : item.jsonObj,
                        "target": item.targetType,
                        tongji:tongji
                    };
                    sidebarInner.push($sidebarInner);
                }else if(item.rank >= 101023000 && item.rank < 101030000){
                    var $qrWrap = {
                        index: item.rank,
                        defaultAction:item.defaultAction,
                        maxImageUrl:item.maxImageHttpUrl,
                        "description": item["textDescription"],
                        "beginTime": item.beginTime,
                        "endTime": item.endTime
                    };
                    _qrWrap.push($qrWrap);
                }
            });
            _logo = resort(grepGame(_logo, [function (n) {
                if(n.endTime){
                    if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                        return true;
                    }
                    return false;
                }else {
                    return n.beginTime < pn.sys_now;
                }
            }]), "index");
            _qrWrap = resort(grepGame(_qrWrap, [function (n) {
                if(n.endTime){
                    if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                        return true;
                    }
                    return false;
                }else {
                    return n.beginTime < pn.sys_now;
                }
            }]), "index");
            sidebarInner = resort(grepGame(sidebarInner, [function (n) {
                if(n.endTime){
                    if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                        return true;
                    }
                    return false;
                }else {
                    return n.beginTime < pn.sys_now;
                }
            }]), "index");
            return {
                logo:_logo[0],
                qrWrap:_qrWrap[0],
                sidebarInner:sidebarInner
            }
        };

        function createHtml(data, cls, w){
            var beginTime = data["beginTime"],
                defaultAction = data["defaultAction"],
                minImageAction=data["minImageAction"],
                hotIcon = data["hotIconUrl"],
                maxImageHttpUrl = data["maxImageHttpUrl"],
                minImageHttpUrl = data["minImageHttpUrl"],
                endTime = data["endTime"],
                targetType = data["target"],
                description = data["description"],
                dataSidebar = data["dataSidebar"],
                tip = data["tip"],
                tongji = data["tongji"];
            var strForDS = utils.getDsCodeAttr(data['jsonObj']);
            var html = '';
            if($('body').hasClass('horizontal') || $('body').hasClass('activity')) {
                html = '<li data-sidebar="' + dataSidebar +'" class="'+ cls +'" style="width: '+ Math.floor(w) +'px">';
            } else {
                html = '<li data-sidebar="' + dataSidebar +'" class="'+ cls +'">';
            }
            
            if(dataSidebar == 'agin' || dataSidebar == 'agq' || dataSidebar == 'fishing'){
                if(pn.userLevel>=2){
                    html += '<a href="'+minImageAction+'" ' + strForDS +
                        'style="background-image:url('+minImageHttpUrl+');" ' +
                        'target="_blank" data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
                }else{
                    html += '<a href="'+defaultAction+'" ' + strForDS +
                        'style="background-image:url('+minImageHttpUrl+');" ' +
                        'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
                }

            }else{
                if(pn.userLevel>=2){
                    html += '<a href="'+minImageAction+'" ' + strForDS +
                        'style="background-image:url('+minImageHttpUrl+');" ' +
                        'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
                }else{
                    html += '<a href="'+defaultAction+'" ' + strForDS +
                        'style="background-image:url('+minImageHttpUrl+');" ' +
                        'data-tongji-attr="_trackEvent,AG8,主站,'+tongji+','+tongji+'">';
                }

            }
            
            html += description ;
            if(hotIcon){
                html += '<img src="'+hotIcon+'" class="more" >'
            }
            html += '</a></li>';
            return html;
        }

        //  生成侧边栏
        function createSidebar(data) {
            if(data === undefined) {
                return false;
            }
            var $sidebar=$(".sidebar");
            if(null == data || data == ""){
                $sidebar.find("ul").html(createDefaultSidebarInner());
                $("#logo").html(createDefaultLogo());
                return;
            }
            var data = grepSidebar(data);
            var logoHtml,sidebarInnnerHtml;
            try {
                logoHtml = createLogo(data.logo);
            }catch (exception){
                logoHtml = createDefaultLogo();
            }
            try {
                sidebarInnnerHtml = createSidebarInnner(data.sidebarInner);
                // 判断是否是IE浏览器
                if(BrowserType()) {
                    if (location.href.indexOf('#reload') === -1) {
                        location.href = location.href + "#reload";
                        location.reload();
                    }
                }
            }catch (exception){
                sidebarInnnerHtml = createDefaultSidebarInner();
            }

            if(null != sidebarInnnerHtml){
                $sidebar.find("ul").html(sidebarInnnerHtml);
            }else{
                $sidebar.find("ul").html(createDefaultSidebarInner());
            }
            if(null != logoHtml){
                $sidebar.find("#logo").html(logoHtml);
            }else{
                $sidebar.find("#logo").html(createDefaultLogo());
            }

            // 添加激活状态
            $('.sidebar ul li').each(function(i, el) {
                var $el = $(el);
                if (location.href.indexOf($el.find('a').attr('href')) !== -1) {
                    $el.addClass('active');
                    $el.siblings('li').removeClass('active');
                }
            });
            if (location.href.indexOf('/activity/') !== -1) {
                var $el = $("div.sidebar > ul > li[data-sidebar='promotion']");
                $el.addClass('active');
                $el.siblings('li').removeClass('active');
            }

            createQrWrap();
        }

        function createDefaultSidebar(){
            $(".sidebar").find("ul").html(createDefaultSidebarInner());
            $("#logo").html(createDefaultLogo());
        }

        function createDefaultLogo() {
            /*return '<a href="/" class="logo" data-tongji-attr="_trackEvent,AG8,主站,首页,首页"></a>';*/
            return "";
        }
        function createDefaultSidebarInner(){
            /*
            return '<li data-sidebar="home_index"><a href="/" class="home active" data-tongji-attr="_trackEvent,AG8,主站,首页,首页">首 页</a></li>' +
            '<li data-sidebar="home_agq"><a href="/game/show/agq" class="flagship" data-tongji-attr="_trackEvent,AG8,主站,旗舰厅,旗舰厅">AG旗舰厅<img src="'+pn.staticurl+'/static/images/others/sidebar/more_icon.png" class="more"></a></li>' +
            '<li data-sidebar="home_agin"><a href="/game/show/agin" class="international" data-tongji-attr="_trackEvent,AG8,主站,国际厅,国际厅">AG国际厅</a></li>' +
            '<li data-sidebar="home_agtel"><a href="/game/show/agtel" class="tel" data-tongji-attr="_trackEvent,AG8,主站,现场厅,现场厅">AG现场厅</a></li>' +
            '<li data-sidebar="home_egame"><a href="/website/redirect?url=/" target="_playEgame" class="casino" data-tongji-attr="_trackEvent,AG8,主站,电游,电游">电子游戏</a></li>' +
            '<li><a href="/website/redirect?url=/fishing" target="_playEgame" class="fishing" data-tongji-attr="_trackEvent,AG8,主站,捕鱼王,捕鱼王">AG捕鱼王</a></li>' +
            '<li data-sidebar="home_sport"><a href="/game/try/shababsports" class="sports" data-tongji-attr="_trackEvent,AG8,主站,体育,体育">体育投注</a></li>' +
            '<li data-sidebar="home_promotion"><a href="/promotion" class="promotions" data-tongji-attr="_trackEvent,AG8,主站,最新优惠,最新优惠">最新优惠</a></li>' +
            '<li data-sidebar="home_mobile"><a href="/publicity/download" class="mobile" data-tongji-attr="_trackEvent,AG8,主站,手机投注,手机投注">手机投注</a></li>';
            */
            return "";
        }


        //  左侧导航栏
        if($(".sidebar").length){
            if (typeof cmsHelper != "undefined") {
                var d_cms_cache = utils.storage.getItem('cms_' + CMS_MODEL.sidebar);
                if(d_cms_cache != null) {
                    createSidebar(JSON.parse(d_cms_cache))
                }
                cmsHelper.getScriptResult(CMS_MODEL.sidebar)
                    .done(createSidebar)
                    .fail(cms_failure)
                    .fail(createDefaultSidebar);
            }
        }
    };
    var elSidebar = '<div id="logo"></div><ul class="sidebarInner"></ul><div class="qr-wrap leftsidbar"></div>';
    $('.sidebar').html(elSidebar).promise().done(function() {
        var winwidth = $(window).width();
        var winheight = $(window).height();
        $(window).on('scroll', function() {
            if( winwidth <= 1366 && winheight <= 768) {
                var sTop = document.body.scrollTop || document.documentElement.scrollTop;
                $('.sidebar').toggleClass('fixed', sTop > 175);
            }
            else {
                $('.sidebar').addClass('fixedsm');
            }
        });
    });

    //加载左侧菜单导航
    $('.sticky').load('/includes/sticky.html?ver=' + webConf.ver,function(){
        //在线客服点击
        $('.a-img-sticky').on('click', function() {
            //当在3840*2560下展示时,在线客服点击无效果,
            //原因是pop-up-left1有了margin-left值,然后通过设置margin-right值企图将它向左挤出时,
            //由于margin的left已经是最大值,无论设置多少的right值,都无法实现效果.
            //所以此处动态设置right值,以此兼容各种left值.
            var marginLeft = $('.pop-up-left1').css("margin-left");
            var marginRight = $('.pop-up-left1').css("margin-right");
            marginLeft = parseFloat(marginLeft.replace("px", ""));
            marginRight = parseFloat(marginRight.replace("px", ""));
            if (marginLeft > 0) {
                if (marginRight > 0) {
                    marginLeft = marginLeft + 165;//这里写165是因为在线客服向左展示的区域就是165px
                } else {
                    marginLeft = marginLeft - 165;//这里写165是因为在线客服向左展示的区域就是165px
                }
            }
            $('.pop-up-left1').css("margin-left", marginLeft + "px");
            //添加或删除to_righ to_left
            $('.pop-up-left1').toggleClass('to_righ to_left');
            $('.chat-cont2').css("display", "block");
            $('.ag-sticky-left').fadeToggle();
        });
    });
    
    //加载底部
    $('.footer').load('/includes/footer.html?ver=' + webConf.ver, function () {
        //底部电游链接
        $("#egame_url").attr("href", "/game/dygame/");//"/website/redirect?url="+pn.eGameUrl
        $('.footer .year').html(new Date().getFullYear());
    });
    if ($('.u-menu').length > 0) {
        $('.u-menu').load('/includes/u_menu.html?ver=' + webConf.ver, function() {
            // keep u-menu and u-main same height
            // $('.u-menu, .u-main').height(Math.max($('.u-menu').height(), $('.u-main').height()));
            $('.u-menu dd').each(function(i, el) {
                var $el = $(el);
                if (location.href.indexOf($el.find('a').attr('href')) !== -1 || location.href.indexOf($el.find('a').attr('data-href')) !== -1) {
                    $el.addClass('active');
                    $el.siblings('dt').addClass('active');
                }
            });
            if (location.href.indexOf('/verify/phone') !== -1) {
                $('.u-menu dd a[href="/ucenter/account"]').parent('dd').addClass('active');
            }

            if ($('.header2').length > 0) {
                $('.umenu-wrap a').each(function(i, el) {
                    $(el).attr('href', $(el).attr('href') + '?sport');
                });
            }

            $(".my-task").on("click",function(e){
                var $this = $(e.currentTarget);
                if($this.find("a:has('.badge_2')").length){
                    var type = "";
                    if($this.hasClass("newcomer-dd")){
                        type = "NEWCOMER"
                    }
                    if($this.hasClass("daily-dd")){
                        type = "DAILY"
                    }
                    if($this.hasClass("achieve-dd")){
                        type = "ACHIEVE"
                    }
                    $.request({
                        type:"PUT",
                        url:"/api/mission/updateViewStatus",
                        data:{
                            missionType:type
                        },
                        async: false
                    }).done(function(res){
                        if(res.successful){
                            $this.find("em").remove();
                        }
                    }).fail(function(e){
                        logConsole(e);
                    });
                }
                location.href = $this.find("a").data("href");
            })
        });
    }
    if ($('.v-menu').length > 0) {
        $('.v-menu').load('/includes/v_menu.html?ver=' + webConf.ver, function() {
            $('.v-menu dd').each(function(i, el) {
                var $el = $(el);
                if (location.href.indexOf($el.find('a').attr('href')) !== -1 || location.href.indexOf($el.find('a').attr('data-href')) !== -1) {
                    $el.addClass('active');
                    $el.siblings('dt').addClass('active');
                }
            });
        });
    }

    $('.u-letter .btn-select-all').on('click', function() {
        var flag = $(this).data('checked');
        $('.u-letter .list-group input[type=checkbox]').prop('checked', !flag).text(flag ? '全选' : '取消全选');
        $(this).data('checked', !flag).text(flag ? '全选' : '取消全选');
    });

    $('.u-letter .btn-select-all').on('click', function() {
        var flag = $(this).data('checked');
        $('.u-letter .list-group input[type=checkbox]').prop('checked', !flag).text(flag ? '全选' : '取消全选');
        $(this).data()
    })

    $('.u-letter .btn-del').on('click', function() {
        $('.u-letter .list-group input:checked').parent('li').remove();
    });
    $('.u-letter .btn-cancel').on('click', function() {
        $('.u-letter .btn-edit').trigger('click');
    });

    // 触发免费试玩
    $('.showdemo').click(function() {
        $('.btn-tryplay').dropdown('toggle').parent().addClass('is-active');
        $('body').addClass('is-active');
        return false;
    });

    // 修复bootstrapde的tab切换页面跳顶bug
    $('.nav-tabs a').on('shown.bs.tab', function(e) {
        // 更新地址栏
        var sTop = document.body.scrollTop || document.documentElement.scrollTop;
        window.location.hash = e.target.hash;
        $('html, body').scrollTop(sTop);
    });



// 统一laoding样式及调用
$.fn.loading = function() {
    var $this = $(this);
    if ($this.length <= 0) {
        return false;
    }
    var _width = $this.outerWidth();
    var _height = $this.outerHeight();
    var _offset = $this.offset();
    var el = '<div class="loading-mask"></div>';
    $('.loading-mask').remove();

    $('body').append(el);
    $('.loading-mask').css({
        'width': _width,
        'height': _height,
        'top': _offset.top,
        'left': _offset.left
    });
    if (_height < 150) {
        $('.loading-mask').addClass('small');
    }
    if ($(this)[0].nodeName === 'BODY') {
        $('.loading-mask').css({
            'position': 'fixed',
            'z-index': '9999'
        })
    }
};


// countDown(10, function() { cosole.log('tick') }, function() { console.log('done') });
window.countDown = function(time, fn1, fn2) {
    var timer = 'timer_' + (new Date()).getTime();
    window[timer] = setInterval(function() {
        time -= 1;
        if(time >= 0) {
            fn1(time);
        } else {
            clearInterval(window[timer]);
            fn2();
        }
    }, 1000);
};

$.loading = function() {
    if (arguments.length > 0 && arguments[0] === false) {
        $('.loading-mask').remove();
        return false;
    }
    $('body').loading();
};
// $('.u-main').loading();
// $.loading();
// $.loading(false);  关闭loading


function placeholder() {
    var ie8 = false;
    if (ie8 == false) {
        // any code here will not be executed by IE 8
        // Released under MIT license: http://www.opensource.org/licenses/mit-license.php

        $('[placeholder]').focus(function() {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function() {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur().parents('form').submit(function() {
            $(this).find('[placeholder]').each(function() {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                }
            })
        });
    }
}