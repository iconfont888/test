$(document).ready(function() {
    //电话回拨点击
    var bindClickEventInterval = setInterval(function(){
        if($('.icon-inside4').length){
            $('.icon-inside4').click(function(){
                console.log('dianhua');
                var $loginPopUp4 = $(".login-pop-up4");
        
                $loginPopUp4.removeClass('is-open');
                $loginPopUp4.first().addClass('is-open');
        
                getCustomerReceptionist();
            });
            clearInterval(bindClickEventInterval);
        }
    },300)
    

    //主站电话回拨生成分机号
    function getCustomerReceptionist(){
        $.request({
            url: '/api/service'
        }).done(function (response) {
            if(response.successful){
                $("#callBack").html(createSticky(response.data));
                //点击弹开窗口时刷新一遍验证码
                utils.getImageCode('/api/captcha?site=10&type=service800&_d=' + (new Date() - 1),$('.login-pop-up4 span.input-group-addon.captcha img'));
                bind();
            }else{
                $("#callBack").html(creatDefaultSticky());
                //点击弹开窗口时刷新一遍验证码
                utils.getImageCode('/api/captcha?site=10&type=service800&_d=' + (new Date() - 1),$('.login-pop-up4 span.input-group-addon.captcha img'));
                bind();
            }
        }).fail(function(e){
            logConsole(e);
        });
    }
});

function createSticky(data){
    var gender = data.gender;
    var html = '';
    html += '<div class="left">';
    if(data.receptionistStatus == 1){
        if(gender == 1){
            html += '<img src="/assets/images/others/sticky/online-m.png" />';
        }else{
            html += '<img src="/assets/images/others/sticky/online-f.png" />';
        }
    }else{
        if(gender == 1){
            html += '<img src="/assets/images/others/sticky/offline-m.png" />';
        }else{
            html += '<img src="/assets/images/others/sticky/offline-f.png" />';
        }
    }

    html += '<dl>';
    if(data.receptionistStatus == 1){
        html += '<dt>'+data.receptionistNickname+'<span class="online">[在线]</span></dt>';
    }else{
        html += '<dt>'+data.receptionistNickname+'<span class="offline">[离线]</span></dt>';
    }
    html += '<dd>VIP客户经理</dd>';
    html += '</dl>';
    html += '</div>';
    html += '<form id="phoneCallBackForm" class="form-inline">';
    if(data.receptionistStatus == 1){
        html += '<p class="title">专属客户经理为您致电服务</p>';
    }else{
        html += '<p class="title">24小时电话客服为您致电服务</p>';
    }
    html += '<div class="form-group">';
    html += '<input type="text" id="callBackPhoneNo" name="callBackPhoneNo" maxlength="11" class="form-control" placeholder="请输入您的手机号码">';
    html += '</div>';
    html += '<div class="form-group form-group-2 verification-group-js">';
    html += '<div class="input-group">';
    html += '<input type="text" id="callBackCapthca" name="callBackCapthca" maxlength="4" class="form-control vali-code" placeholder="请输入验证码">';
    html += '<span class="input-group-addon captcha"><img data-type="service800" src="/api/captcha?site=10&type=service800" alt="captcha"></span>';
    html += '</div>';
    html += '</div>';
    if (data.receptionistStatus == 1) {
        html += '<a class="btn btn-add-contact-tab1 btn-add-contact-tab2 call-back-btn"><i class="i-call"></i>经理回拨</a>';
    } else {
        html += '<a class="btn btn-add-contact-tab1 call-back-btn">客服回拨</a>';
    }
    html += '</form>';
    html += '<img src="/assets/images/others/sticky/fubao-close.png" class="login4-close-popup close-btn">';
    return html;
}

function creatDefaultSticky() {
    var html = '';
    html += '<div class="left"><img src="/assets/images/others/sticky/3mins_add_1.png" class="three-mins" /></div>';
    html += '<form  id="phoneCallBackForm" class="form-inline">';
    html += '<p class="title">24小时电话客服为您致电服务</p>';
    html += '<div id="phoneCallBackForm" class="form-group">';
    html += '<input type="text" id="callBackPhoneNo" name="callBackPhoneNo" maxlength="11" class="form-control" placeholder="请输入您的手机号码">';
    html += '</div>';
    html += '<div class="form-group form-group-2 verification-group-js">';
    html += '<div class="input-group">';
    html += '<input type="text" id="callBackCapthca" name="callBackCapthca" maxlength="4" class="form-control vali-code" placeholder="请输入验证码">';
    html += '<span class="input-group-addon captcha"><img data-type="service800" src="/api/captcha?site=10&type=service800" alt="captcha"></span>';
    html += '</div>';
    html += '</div>';
    html += '<a class="btn btn-add-contact-tab1 call-back-btn">客服回拨</a>';
    html += '</form>';
    html += '<img src="/assets/images/others/sticky/fubao-close-1.png" class="login4-close-popup close-btn">';
    return html;
}

function doCallBackPhone() {
    if(!$("#phoneCallBackForm").validate().form()){
        return;
    }

    var callBackPhoneNo = $("#callBackPhoneNo").val();
    var callBackCapthca = $("#callBackCapthca").val();
    var $loginPopUp4 = $(".login-pop-up4");
    $loginPopUp4.loading({'glass': false});

    $.request({
        type: 'POST',
        url: "/api/service/call/phone",
        data: {"phoneNo": callBackPhoneNo, "captcha": callBackCapthca}
    }).done(function (response) {
        if(response.successful){
            $loginPopUp4.loading('close');
            if (response.data) {
                $("#callBackMsg").html(response.data);
            }
            $loginPopUp4.first().removeClass('is-open');
            $loginPopUp4.last().addClass('is-open');
        }else {
            switch (response.code) {
                case 7511:
                case 7512:
                case 500:
                    layer.alert("电话回拨失败，请稍后重试或联系客服!", {title: ' '});
                    break;
                default:
                    layer.alert(response.message, {title: ' '});
                    break;
            }
            $loginPopUp4.loading('close');

        }
        utils.getImageCode('/api/captcha?site=10&type=service800&_d=' + (new Date() - 1),$('.login-pop-up4 span.input-group-addon.captcha img'));
    }).fail(function(e){
        logConsole(e);
    });
}

function bind(){
    $('.call-back-btn').click(function(){
        doCallBackPhone();
    });
    $('.login4-close-popup').click(function(){
        $('.login-pop-up4').removeClass('is-open');
    });
    //增加校验
    $("#phoneCallBackForm").validate({
        rules: {
            callBackPhoneNo: {
                required: true,
                regex: /^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$/
            },
            callBackCapthca: {
                required: true,
                digits: true,
                rangelength: [4, 4]
            }
        },
        messages: {
            callBackPhoneNo: {
                required: "请输入您的联系电话",
                regex: "请输入11位有效手机号码"
            },
            callBackCapthca: {
                required: "请输入验证码",
                digits: "您输入的验证码不正确",
                rangelength: "您输入的验证码不正确"
            }
        },
        onkeyup: false,
        onclick: false,
        onfocusout: false,
        showErrors: function (errorMap, errorList) {
            if (errorList.length > 0) {
                if (errorMap.callBackPhoneNo !== undefined) {
	                if(constants.INTERNET_PHONE_REGEX.test($("#callBackPhoneNo").val())) {
		                layer.open({
			                title: ' ',
			                content: '无效号码，属于网络运营商',
			                btn: ['确定'],
			                yes: function (index, layero) {
				                layer.close(index);
			                }
		                })
	                } else {
		                layer.open({
			                title: ' ',
			                content: errorMap.callBackPhoneNo,
			                btn: ['确定'],
			                yes: function (index, layero) {
				                layer.close(index);
			                }
		                })
	                }
                } else {
                    layer.open({
                        title: ' ',
                        content: errorMap.callBackCapthca,
                        btn: ['确定'],
                        yes: function (index, layero) {
                            layer.close(index);
                        }
                    });
                }
            }
        }
    });
}