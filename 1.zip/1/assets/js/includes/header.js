/*
* 全局过滤配置
* 线上环境请将cdn_url的值改为cdn地址
* 线上环境请将NB_env更改为 production
*/
var webConf = {
    ver: 1,
    cdn_url: '',
    NB_env: "uat",
    NB_FAST_BET: {
        theme: 3,
        lockTheme: true,
        oddsType: 1,
        backUrl: '',
        iconUrl: '',
        gameType: [1, 14, 26, 45],
        fontSize: { team: [{ min: 0, max: 13, size: '17px' }, { min: 13, max: 15, size: '15px' }, { min: 15, max: 99, size: '17px' }] },
        amountList: [50, 100, 200, 300, 500]
    }
};


/***
 * 引入头部文件, 参数
 */
/**
 * 动态加载CSS和JS文件
 */
var dynamicLoading = {
    meta: function () {
        document.write('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">');
    }, css: function (path) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required!');
        }
        document.write('<link rel="stylesheet" type="text/css" href="' + path + '">');
    }, js: function (path, charset) {
        if (!path || path.length === 0) {
            throw new Error('argument "path" is required!');
        }
        document.write('<script charset="' + (charset ? charset : "utf-8") + '" src="' + path + '"></script>');
    }
};
//加载网站标题
document.write('<title>AG亚游集团--真人游戏第一品牌</title>');
//加载icon
document.write('<link rel="icon" type="image/x-icon" href="/assets/images/home/favicon.ico">');
//  CSS
dynamicLoading.css(webConf.cdn_url + "/assets/css/bootstrap.min.css");
dynamicLoading.css(webConf.cdn_url + "/assets/css/font-awesome.min.css");
dynamicLoading.css(webConf.cdn_url + "/assets/css/main.css?ver=" + webConf.ver);
dynamicLoading.css(webConf.cdn_url + "/assets/css/animate.css");
dynamicLoading.css(webConf.cdn_url + "/assets/css/custom/custom_main.css?ver=" + webConf.ver);
dynamicLoading.css(webConf.cdn_url + "/assets/js/plugins/loading/jquery.loading.css");
dynamicLoading.css(webConf.cdn_url + "/assets/js/kapcha/kaptcha.css?ver=" + webConf.ver);

//ie9兼容js
document.write('<!--[if lt IE 9]>');
dynamicLoading.js(webConf.cdn_url + "/assets/libs/html5shiv.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/respond.min.js");
document.write('<![endif]-->');
//jquery js
dynamicLoading.js(webConf.cdn_url + "/assets/libs/jquery/jquery-1.11.3.min.js");
dynamicLoading.js(webConf.cdn_url + "/assets/libs/layer/layer.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/kapcha/jquery.base64.js");
dynamicLoading.js(webConf.cdn_url + "/assets/js/utils.js?ver=" + webConf.ver);
dynamicLoading.js(webConf.cdn_url + "/assets/js/base.js?ver=" + webConf.ver);

var _hmt = _hmt || [];
(function () {
    if (location.hostname === 'localhost' || /^\d+\.\d+\.\d+\.\d+$/.test(location.hostname)) {
        return;
    }
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?452136c8900570104b1742296327ee25";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();