/***
 * CMS 工具类
 * <p>author: sabo
 * <p>date: 2018/11/14
 * <p>time: 14:06
 */

var CMS_CONFIG = typeof cms_config !== "undefined" ? cms_config : "";
var CMS_MODEL = {
    base: "base",
    newPlayerBanner : "newPlayerBanner" ,
    ordinaryMemberBanner : "ordinaryMemberBanner" ,
    vipMemberBanner : "vipMemberBanner" ,
    sidebar: "sidebar",//首页-左侧导航
    headerImage: 'headerImage',//顶部图片
    newPlayerHeaderImage : "newPlayerHeaderImage" ,
    ordinaryMemberHeaderImage : "ordinaryMemberHeaderImage" ,
    vipMemberHeaderImage : "vipMemberHeaderImage" ,
    promotionTab: "promotionTab",//最新优惠-列表
    promotionBack: "promotionBack",//最新优惠-背景
    promotionSidebar: "promotionSidebar",//嵌套菜单-热门优惠
    agin: "agin",//主站国际厅轮播图
    agq: "agq",//主站旗舰厅轮播图
    newWorld: "newWorld",//主站新世界厅轮播图
    openwindow:"openwindow",//主站首页弹窗
    withdrawAdImage : "withdrawAdImage" , //主站提现广告图
    rebateAdImage : "rebateAdImage" , //主站洗码广告图
    basicCompleteAdImage : "basicCompleteAdImage" , //主站注册成功广告图
    promotionVipSidebar:"promotionVipSidebar",//嵌套菜单-vip热门优惠
    headerPopularize:"headerPopularize",//vip站头部亚游风采 亚游论坛
    movie:"movie",//VIP站电影门票
    giftBanner:"giftBanner", // 佳节礼品轮播
    giftPicList:"giftPicList", // 佳节礼品节日图片列表
    slideshow:"slideshow",//游戏大厅-电投厅
    discountsTab:"discountsTab",//vip站优惠列表
    homepageBanar:"homepageBanar",//VIP站首页轮播图登录前
    cinematicket:"cinematicket",//VIP票务演出
    viphomepageBanar:"viphomepageBanar",//VIP站首页轮播图登录后
    vipWithdrawAdImage : "vipWithdrawAdImage" , //VIP站提现广告图
    vipRebateAdImage : "vipRebateAdImage" , //VIP站洗码广告图
    profitBanner:"profitBanner",//赌神排行榜广告图
    fish:"fish",
    NBtoggle:"NBtoggle",
    ticket1788:"ticket1788"
};
jQuery.cachedScript = function (url, options) {
    options = $.extend(options || {}, {
        dataType: "script",
        cache: true,
        url: url
    });
    return jQuery.ajax(options);
};
var CMSHelper = function () {
    var _helper = this;
    var _ID = {
        base: "base",
        newPlayerBanner : "010107" ,
        ordinaryMemberBanner : "010108" ,
        vipMemberBanner : "010109" ,
        sidebar: '010102',
        newPlayerHeaderImage : "010110" ,
        ordinaryMemberHeaderImage : "010111" ,
        vipMemberHeaderImage : "010112" ,
        promotionTab: '010151',
        promotionBack: '010152',
        promotionSidebar: '010153',
        agin:'010118',
        agq:'010119',
        newWorld:'010120',
        openwindow:'010330',
        withdrawAdImage : '010302' ,
        rebateAdImage : '010303' ,
        basicCompleteAdImage : '010304' ,
        promotionVipSidebar:'040401',
        headerPopularize:'040402',
        movie:"040403",
        slideshow:"040405",
        discountsTab:"040406",
        homepageBanar:"040407",
        cinematicket:"040410",
        viphomepageBanar:"040408",
        vipWithdrawAdImage : "040501" ,
        vipRebateAdImage : "040502" ,
        profitBanner: "020126",
        fish:"010131",
        NBtoggle:"000000",
        ticket1788:"050100",
        giftBanner:"010210",
        giftPicList:"010211"
    };

    this.getScriptResult = function (modal , userLevel) {
        var _deferred = $.Deferred();
        $.request({
            url: "/api/cms/page/templates",
            data:{moduleCodes:_ID[modal]}
        }).done(function (res) {
            if(res.successful){
                var data=res.data;
                var _cms_id = 'cms_' + modal;
                var cms_cache = utils.storage.getItem(_cms_id);
                
                if (data && data.length > 0) {
                    for(var k = 0 ; k < data.length ; k++){
                        if(data[k].beginTime){
                            data[k].beginTime = new Date (data[k].beginTime.replace(/-/g,'/')).getTime()
                        }
                        if(data[k].endTime){
                            data[k].endTime = new Date (data[k].endTime.replace(/-/g,'/')).getTime();
                        }
                    }
                    if(userLevel){
                        var userLevelStr;

                        var timestamp;
                        if(typeof _now === "number"){
                            timestamp = _now;
                        }else{
                            timestamp = new Date().getTime();
                        }

                        var beginTime , endTime;
                        var betweenTime = false;
                        var noEndTime = false;
                        for(var i = 0 ; i < data.length ; i++){
                            beginTime = data[i].beginTime;
                            endTime = data[i].endTime;
                            betweenTime = beginTime != "" && endTime != "" && timestamp >= beginTime && timestamp <= endTime;
                            noEndTime = beginTime != "" && endTime == "" && timestamp >= beginTime;

                            //此处判断原因 :
                            //因为优惠活动列表需要根据优惠时间进行分类成<即将开始><火热进行中><已结束>
                            //所以优惠活动列表需要直接跳过时间判断
                            //主站优惠活动列表
                            if(modal === "promotionTab"){
                                betweenTime = true;
                            }
                            //VIP站优惠活动列表
                            if(modal === "discountsTab"){
                                betweenTime = true;
                            }

                            //弹窗有自己的白名单,时间和用户星级判断 , 所以直接跳过此处的星级和时间判断
                            if(modal === "openwindow"){
                                continue;
                            }
                            if(modal === "openwindowmoblie"){
                                continue;
                            }

                            if(betweenTime || noEndTime){
                                userLevelStr = data[i].userLevelStr;
                                //未选择用户等级
                                if(userLevelStr === undefined || userLevelStr === null || userLevelStr === ""){
                                    continue;
                                }
                                //当前用户等级在CMS配置中
                                if(userLevelStr.indexOf(userLevel) > -1){
                                    continue;
                                }
                            }
                            data.splice(i , 1);
                            i--;
                        }

                        //排序
                        var temp = 0;
                        for(var i = 0 ; i < data.length - 1 ; i++){
                            for(var j = 0 ; j < data.length - i - 1 ; j++){
                                if(data[j].rank >= data[j+1].rank){
                                    temp = data[j].rank;
                                    data[j].rank = data[j + 1].rank;
                                    data[j+1].rank = temp;
                                }
                            }
                        }
                    }

                    if(modal === 'sidebar' || modal === 'newPlayerBanner' || modal === 'ordinaryMemberBanner' || modal === 'vipMemberBanner') {
                        var pre_cache = JSON.stringify(data);
                        if(pre_cache !== cms_cache) {
                            _deferred.resolve(data);
                            utils.storage.setItem(_cms_id, pre_cache);
                        } else {
                            _deferred.resolve();
                        }
                    } else {
                        _deferred.resolve(data);
                    }
                } else {
                    _deferred.reject(modal);
                }
            }else{
                _deferred.reject(modal);
            }
        }).fail(function(e){
            logConsole(e);
        });
        
        return _deferred.promise();
    };
};
window.cmsHelper = new CMSHelper();

function cms_failure(data) {
    logConsole("Get CMS(" + data + ") configuration is abnormal.");
}
