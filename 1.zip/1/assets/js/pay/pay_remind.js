var BANK_CARD_NUMBER_CHANGE_MSG = "旧卡已更换，转账时请勿转入旧卡，以免造成您的资金损失！";
var FIRST_TIME_BQ_MSG = "每次使用银行卡转账前，须先到网站获取/确认卡号信息，以免造成您的资金损失！";
var HAVE_CARD_MSG = "旧卡已停用，转账时请勿转入旧卡，以免造成您的资金损失！";
var CLEAR_BANK_CARD_HISTORY_MSG = "亲，记得定期清理网银收款银行列表中的旧卡信息，以免误转入旧卡造成您的资金损失！";
function checkBankCardNumberChange() {
    $.request({
        url: '/api/pay/remind/bank',
        type: 'POST',
        dataType: 'JSON',
        cache: false,
        headers: {
            "X-Website-Code":"MAIN_PC"
        }
    }).done(function (data) {
        if (data.successful) {
            var change = data.data;
            if (change) {
                //弹窗提醒
                layerForPayRemind(BANK_CARD_NUMBER_CHANGE_MSG);
                //发送站内信和短信
                letterAndSMS("BANK_CARD_NUMBER_CHANGE");
            }
        }
    }).fail(function(e){
        logConsole(e);
    }).always(function () {
        clearBankCardHistory();
    });
}
function checkFirstTimeBQ() {
    $.request({
        url: '/api/pay/remind/first',
        type: 'POST',
        dataType: 'JSON',
        cache: false,
        headers: {
            "X-Website-Code":"MAIN_PC"
        }
    }).done(function (res) {
        if (res.successful && res.data) {
            //弹窗提醒
            layerForPayRemind(FIRST_TIME_BQ_MSG);
            //发送短信
            letterAndSMS("FIRST_TIME_BQ");
        }
    }).fail(function(e){
        logConsole(e);
    });
}
function checkHaveCard(haveCard) {
    var data = {};
    data["haveCard"] = haveCard;
    $.request({
        url: '/api/pay/remind/card',
        type: 'POST',
        data: data
    }).done(function (res) {
        if (res.successful && res.data) {
            //弹窗提醒
            layerForPayRemind(HAVE_CARD_MSG);
        }
    }).fail(function(e){
        logConsole(e);
    });
}
function clearBankCardHistory() {
    $.request({
        url: '/api/pay/remind/history',
        type: 'POST',
        dataType: 'JSON',
        cache: false,
        headers: {
            "X-Website-Code":"MAIN_PC"
        }
    }).done(function (data) {
        if (data.successful && data.data) {
            //弹窗提醒
            layerForPayRemind(CLEAR_BANK_CARD_HISTORY_MSG);
            //短信
            letterAndSMS("CLEAR_BANK_CARD_HISTORY");
        }
    }).fail(function(e){
        logConsole(e);
    });
}
function layerForPayRemind(msg) {
    layer.open({
        title: " ",
        content: msg,
        btn: ['我知道了'],
        yes: function (index) {
            layer.close(index);
        }
    });
}
function letterAndSMS(type) {
    var data = {};
    data['type'] = type;
    $.request({
        url: '/api/pay/remind/letter-sms',
        type: 'POST',
        data: data,
        dataType: 'JSON',
        cache: false,
        headers: {
            "X-Website-Code":"MAIN_PC"
        }
    }).done(function (data) {

    }).fail(function(e){
        logConsole(e);
    });
}
