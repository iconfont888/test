var $wrapper = $("body .wrapper");
$("body>.footer").hide();
$wrapper.find(">.header,>.sidebar,>.sticky,.u-menu").hide();
$wrapper.find(".main-container").css({"padding": "0", "margin-left": "0"});
$wrapper.find(">.footer").hide();