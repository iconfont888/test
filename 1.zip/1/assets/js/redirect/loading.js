$(document).ready(function () {

    var params = window.location.href.split("=");
    var url = "";
    var scheme = "";
    var redirectUrl = "";
    if (params.length > 2) {
        url = params[2];
        scheme = params[2].split("&")[0];
    } else {
        url = params[1];
    }
    $.request({
        url: "/api/website/redirect",
        async:false,
        data: {url: url, scheme: scheme}
    }).done(function (response) {
        if (response.successful) {
            var url = response.data;
            if(url){
                //解密游戏链接
                url = decodeURIComponent(url);
            }else {
                return;
            }
            window.location.href = url;
            redirectUrl = url;
        }
    }).fail(function(e){
        logConsole(e);
    });

    // variables
    var $text = $('.text'),
        $textval = $text.html(),
        i = 4,
        logo1 = $('.ag8'),
        logo2 = $('.ag86');
    logo2.fadeOut();
    // animation for the logo and the text buffers
    setInterval(function () {
        i--;
        var $finalstring = $textval.slice(0, -i);
        $text.html($finalstring);
        if (i == 0) {
            $text.html($textval);
            i = 4;
            logo1.fadeToggle();
            logo2.fadeToggle();
        }
    }, 500);

    var screenw = $(window).width(),
        elarges = screenw * 1.5;
    // screen swap
    setTimeout(function () {
        // change for the site container
        $('.main-container').animate({
            width: elarges,
            height: elarges,
            top: '-65%',
            left: '-25%'
        }, 500, function () {
            if (redirectUrl) {
                window.location.href = redirectUrl;
            } else {
                window.location.href = '/';
            }
        });
    }, 3000)
});