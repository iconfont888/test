var __games__ = {

    AGIN: [{
        img: '/assets/images/maintenance/fig_1.jpg',
        gameUrl: '/game/play/agin',
        text: "最好牌路  实时推荐",
        name: "AG国际厅"
    }],
    AGQJ: [{
        img: '/assets/images/maintenance/fig_2.jpg',
        gameUrl: '/game/play/agq?gameType=NN',
        text: "业界首创  6张牌先发",
        name: "AG旗舰厅"
    }],
    XIN: [{
        img: '/assets/images/maintenance/fig_5.jpg',
        gameUrl: '/game/iframe/index.html?egames=1&g=ag&gameCode=6&gameName=Fish&platForm=AG&trial=false',
        text: "首创渔场，一起坐庄",
        name: "AG捕鱼王"
    }],
    PT: [{
        img: '/assets/images/maintenance/fig_6.jpg',
        gameUrl: '/game/iframe/index.html?egames=1&gameCode=ct&gameName=Captain%27s%20Treasure&g=pt&language=en&trial=false&platType=PT',
        text: "0.09元一局，玩到天黑不是问题",
        name: "PT船长的宝藏"
    }],
    YOPLAY: [{
        img: '/assets/images/maintenance/fig_7.jpg',
        gameUrl: '/game/iframe/index.html?egames=1&gameCode=YP810&gameName=ForestDance-Mutiplayer&g=yoplay&language=zh&trial=false&platType=YOPLAY',
        text: "多人聊天互动，欢乐赢钱不孤单",
        name: "YOPLAY森林舞会多人版"
    }],
    AGSBLB: [{
        img: '/assets/images/maintenance/fig_8.jpg',
        gameUrl: '/game/iframe/index.html?egames=1&gameCode=501&gameName=Fruit%20Slot&g=ag&language=zh&trial=false&platType=AGIN',
        text: "追忆原汁原味的经典街机",
        name: "AG 水果拉霸"
    }]

};
var _video = [], _slot = [];

$(document).ready(function () {
    /*游戏维护时间提示*/
    $.request({
        url: "/api/game/upgrade?gameName=" + utils.getQueryString("gameName")
    }).done(function (response) {
        if(response.successful){
            //显示维护时间
            if(response.data != ''){
                $("div.construction").html("<h2>游戏大厅维护中</h2>" + response.data);
            } else{
                $("div.construction").html("<h2>游戏大厅维护中</h2>");
            }
        }else{
            logConsole(response.message);
        }
    }).fail(function(e){
        logConsole(e);
    });

    /*AG真人游戏随机显示*/
    $.request({
        url: "/api/game/gameList"
    }).done(function (response) {
        var sorts = response.data;
        if (sorts.indexOf("AGIN") >= 0) {
            _video = _video.concat(__games__["AGIN"]);
            _slot = _slot.concat(__games__["YOPLAY"]);
            _slot = _slot.concat(__games__["XIN"]);
            _slot = _slot.concat(__games__["AGSBLB"]);
        }
        if (sorts.indexOf("AGQJ") >= 0 || sorts.indexOf("AG(AGQJ)") >= 0) {
            _video = _video.concat(__games__["AGQJ"]);
        }
        if (sorts.indexOf("PT") >= 0) {
            _slot = _slot.concat(__games__["PT"]);
        }

        var $gameList = $(".unit-wrap"),
            $videoGame = $gameList.find("li.video-game-js"),
            $slotGame = $gameList.find("li.slot-game-js");
        if (_video.length) {
            var videoRandom = Math.floor(Math.random() * _video.length);//3
            var video = _video[videoRandom];
            $videoGame.find('.name-js').text(video.name);
            $videoGame.find('.text-js').text(video.text);
            $videoGame.find('img').attr('src', video.img);
            $videoGame.find('a').attr('href', video.gameUrl);
        } else {
            $videoGame.remove();
        }
        if (_slot.length) {
            var slotRandom = Math.floor(Math.random() * _slot.length);//3
            var slot = _slot[slotRandom];
            $slotGame.find('.name-js').html(slot.name);
            $slotGame.find('.text-js').html(slot.text);
            $slotGame.find('img').attr('src', slot.img);
            $slotGame.find('a').attr('href', slot.gameUrl);
        } else {
            $slotGame.remove();
        }
    }).fail(function(e){
        logConsole(e);
    });

    var hk1 = "+852-3841-5777",
        hk2 = "+852-3008-3777";

    if(pn.hongKong1==="true" && pn.hongKong2==="false"){
        $(".phone-num").html("<em>香港热线(0.49元/分)</em><br>" + hk1);
    }else if(pn.hongKong2==="true" && pn.hongKong1==="false"){
        $(".phone-num").html("<em>香港热线(0.49元/分)</em><br>" + hk2);
    }else if(pn.hongKong1==="true" && pn.hongKong2==="true"){
        $(".phone-num").html("<em>香港热线(0.49元/分2)</em><br>" + hk1 + "<br>" + hk2);
    }
});