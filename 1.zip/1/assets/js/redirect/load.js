$(document).ready(function () {
    // Get Started
    var $proress = $('.proress-bar');
    $proress.width('75%');
    $('.proress-num').prop('Counter', 0).animate({
        Counter: 75
    }, {
        duration: 600,
        easing: 'swing',
        step: function (now) {
            $('.proress-num').text(Math.ceil(now) + '%');
        }
    });
    var loadUrl = decodeURIComponent(location.search).substring(1);
    $.request({
        type: 'POST',
        url: loadUrl
    }).done(function (response) {
        $proress.stop();
        if (response.successful) {
            var data = response.data;
            if (data.url === "exception") {
                location.replace("/game/game_upgrade.html?gameName=" + (utils.getQueryString("platType") == null ? loadUrl.split("/")[3] : utils.getQueryString("platType"))) +  '&_=' + (new Date()).getTime();
                return;
            }
            switch (data.plat || "") {
                case "PT":
                    PT(data);
                    break;
                case "PNG":
                    var url = data.url;
                    location.replace(url.replace("/js?", "/PlayMobile?") + "&lobby=" + location.href.replace(/(^.*?\/\/.*?\/).*/, "$1") + "egames");
                    break;
                case "AG":
                    var gameUrl = data.url;
                    if (data.gameCode || data.videoID) {
                        var search = $("<a href='" + gameUrl + "'></a>")[0].search;
                        var params = {};
                        if (data.gameCode) {
                            params["gameType"] = data.gameCode;
                        }
                        if (data.videoID) {
                            params["videoID"] = data.videoID;
                        }
                        gameUrl = gameUrl + (search ? "&" : "?") + $.param(params);
                    }
                    location.replace(gameUrl);
                    break;
                case "SCG":
                    var scgUrl = data.url;
                    var cardId = $("<a href='" + loadUrl + "'></a>")[0].search;
                    var cardParam = (cardId.substring(1) && "&" + cardId.substring(1)) || "";
                    location.replace(scgUrl + cardParam + "&dm=" + document.location.origin + "&payuri=/ucenter/pay/u_deposit.html&gameuri=/index.html");
                    break;
                case "AGIN":
                default:
                    location.replace(data.url);
                    break;
            }
        } else {
            if (response.code == 5005) {
                location.replace("/game_upgrade.html?gameName=" + (utils.getQueryString("platType") == null ? loadUrl.split("/")[3] : utils.getQueryString("platType")) + '&_=' + (new Date()).getTime());
                return;
            }
            $(".game-loading").hide();
            $(".game-error").find(".text-js").text(response.message).end().removeClass("hide");
        }
    }).fail(function(e){
        logConsole(e);
    });

    function PT(res) {
        $.getScript(res.url, function () {
            var mobiledomain = "ld176888.com";
            var systemidvar = "424";

            function logout(allSessions, realMode) {
                iapiLogout(allSessions, realMode);
            }

            function launchMobileClient(temptoken) {
                var base_url = location.href.substring(0, location.href.lastIndexOf('/') + 1);
                base_url = base_url.substring(0, base_url.lastIndexOf('/'));
                base_url = base_url.substring(0, base_url.lastIndexOf('/') + 1);
                var game_url = 'http://hub.' + mobiledomain + '/igaming/' + '?gameId=' + res.gameCode +
                    '&real=1' +
                    '&username=' + res.loginName +
                    '&lang=zh-cn&tempToken=' + temptoken +
                    '&lobby=' + base_url + 'egames#pt' +
                    '&support=' + base_url + '' +
                    '&logout=' + base_url + 'logout' +
                    '&deposit=' + base_url + 'personal/deposit';

                location.replace(game_url);
            }

            function calloutGetTemporaryAuthenticationToken(response) {
                if (response.errorCode && response.errorCode != 6) {
                    alert(response.playerMessage + " Error code: " + response.errorCode);
                }
                else {
                    iapiRequestTemporaryToken(1, systemidvar, "GamePlay");
                }
            }

            function gettest(response) {
                launchMobileClient(response.sessionToken.sessionToken);
            }

            function calloutLogout(response) {
                if (response.errorCode) {
                    alert("Logout failed, " + response.errorCode);
                }
                else {
                    alert("Logout OK");
                }
            }

            function login(realMode, loginName, gameKey) {
                iapiSetClientPlatform("mobile&deliveryPlatform=HTML5");
                iapiLogin(loginName, gameKey, realMode, "zh-cn");
            }

            iapiSetCallout('Login', calloutGetTemporaryAuthenticationToken);
            iapiSetCallout('GetTemporaryAuthenticationToken', gettest);
            iapiSetCallout('Logout', calloutLogout);
            login(1, res.loginName, res.key);
        });
    }

    $(".retry-js").on("click", function () {
        location.reload();
    })
});