
// 游戏类型
var GAME_TYPE = {
    BAC:{type:"BAC", name:"百家乐",table:"tab-card"},
    CBAC:{type:"CBAC", name:"VIP百家乐",table:"tab-card"},
    TBAC:{type:"TBAC", name:"竞咪百家乐",table:"tab-card"},
    LINK:{type:"LINK", name:"连环百家乐",table:"tab-card"},
    DT:{type:"DT", name:"龙虎",table:"tab-card"},
    SHB:{type:"SHB", name:"骰宝",table:"tab-dice"},
    LBAC:{type:"LBAC", name:"LED竞咪百家乐",table:"tab-card"},
    BBAC:{type:"BBAC", name:"龙宝百家乐",table:"tab-card"},
    SBAC:{type:"SBAC", name:"保险百家乐",table:"tab-card"},
    // TEB:{type:"TEB", name:"二八杠",table:"tab-card"},//暂不展示
    NN:{type:"NN", name:"牛牛",table:"tab-game"},
    BJ:{type:"BJ", name:"21点",table:"tab-card"},
    ZJH:{type:"ZJH", name:"炸金花",table:"tab-card"},
    ROU:{type:"ROU",name:"轮盘",table:"tab-num"}
};

// 图片名称
var CARD_TYPE = {
    1:"card_c1",
    2:"card_c2",
    3:"card_c3",
    4:"card_c4",
    5:"card_c5",
    6:"card_c6",
    7:"card_c7",
    8:"card_c8",
    9:"card_c9",
    10:"card_c10",
    11:"card_c11",
    12:"card_c12",
    13:"card_c13",
    17:"card_d1",
    18:"card_d2",
    19:"card_d3",
    20:"card_d4",
    21:"card_d5",
    22:"card_d6",
    23:"card_d7",
    24:"card_d8",
    25:"card_d9",
    26:"card_d10",
    27:"card_d11",
    28:"card_d12",
    29:"card_d13",
    33:"card_sp1",
    34:"card_sp2",
    35:"card_sp3",
    36:"card_sp4",
    37:"card_sp5",
    38:"card_sp6",
    39:"card_sp7",
    40:"card_sp8",
    41:"card_sp9",
    42:"card_sp10",
    43:"card_sp11",
    44:"card_sp12",
    45:"card_sp13",
    49:"card_h1",
    50:"card_h2",
    51:"card_h3",
    52:"card_h4",
    53:"card_h5",
    54:"card_h6",
    55:"card_h7",
    56:"card_h8",
    57:"card_h9",
    58:"card_h10",
    59:"card_h11",
    60:"card_h12",
    61:"card_h13"
};

function showSources(checked){
    var status = $(checked).attr("data-status");
    if (status == "init") {
        $(".final").hide();
    } else {
        $(".final").show();
    }
}

// 查询游戏结果
$(function () {
    //刷新验证码
    var $captcha = $("#captcha");
    utils.getImageCode('/api/captcha?type=trial&_d=' + (new Date() - 1),$captcha);

    // 绑定查询事件
    $captcha.find("input").on("propertychange keypress",function(event){
        if (event.keyCode == "13") {
            $(".btn-check").trigger("click");
        }
    });
    // 问号提示
    $(".icon-check").hover(function () {
        $(this).next().removeClass("hide");
    }, function () {
        $(this).next().addClass("hide");
    });

    $(".btn-check").on("click",function () {
        _hmt.push(['_trackEvent', 'AG8', '开牌结果验证', '立即查询', '立即查询']);
        getGameResult();
    });
    function getGameResult() {
        $(".verification-wrap .tab-content").find(".active").removeClass("active");
        var gameCode = $("#gameCode").find("input").val();
        var captcha = $("#captcha").find("input").val();
        gameCode = gameCode.replace(/\s/g,"");
        if (gameCode == null || gameCode === "") {
            layer.alert("请输入游戏局号！", {title: " "});
            return;
        }
        if (captcha == null || captcha === "") {
            layer.alert("请输入验证码！", {title: " "});
            return;
        }
        $(".download-wrap").show();

        $.request({
            type: 'POST',
            url:"/api/publicity/game/result",
            data:{ gameCode: gameCode, captcha: captcha}
        }).done(function (response) {
            if (response.successful && response.data) {
                createHtml(response.data.data)
            } else {
                failure(response.message);
            }
        }).fail(function(e){
            logConsole(e);
        }).always(function () {
            $(".download-wrap").hide();
            // 更换验证码
            var $captcha = $("#captcha");
            utils.getImageCode('/api/captcha?type=trial&_d=' + (new Date() - 1),$captcha.find("img"));

            $captcha.find("input").val("");
            // 显示原始牌事件
            if ($("#inlineRadio1")) {
                $("#inlineRadio1").on("click",function () {
                    showSources(this);
                });
                $("#inlineRadio2").on("click",function () {
                    showSources(this);
                });
            }
        });
    }

    // 获取牌url
    function getPorkImgUrl(data){
        // if(pn.terminal === "VIP"){
        //     return pn.staticurl + "/vipstatic/images/vip/verification/" + CARD_TYPE[data] + ".png";
        // }
        return "/assets/images/verification/" + CARD_TYPE[data] + ".png";
    }

    function createHtml(data){
        var tableId = "";
        var leftHtml = "",rightHtml = "";
        switch (data.gameType) {
            case GAME_TYPE.SBAC.type:
                tableId = GAME_TYPE.SBAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.BBAC.type:
                tableId = GAME_TYPE.BBAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.LBAC.type:
                tableId = GAME_TYPE.LBAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.BAC.type:
                tableId = GAME_TYPE.BAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.CBAC.type:
                tableId = GAME_TYPE.CBAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.TBAC.type:
                tableId = GAME_TYPE.TBAC.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.LINK.type:
                tableId = GAME_TYPE.LINK.table;
                leftHtml = getBACLeftHtml(data);
                rightHtml = getBACRightHtml(data);
                break;
            case GAME_TYPE.BJ.type:
                tableId = GAME_TYPE.BJ.table;
                leftHtml = createBJLeftHtml(data);
                rightHtml = createBJRightHtml(data);
                break;
            case GAME_TYPE.DT.type :
                tableId = GAME_TYPE.DT.table;
                leftHtml = createDTLeftHtml(data);
                rightHtml = createDTRightHtml(data);
                break;
            case GAME_TYPE.NN.type:
                tableId = GAME_TYPE.NN.table;
                leftHtml = createNNLeftHtml(data);
                rightHtml = createNNRightHtml(data);
                break;
            case GAME_TYPE.ROU.type:
                tableId = GAME_TYPE.ROU.table;
                leftHtml = createROULeftHtml(data);
                rightHtml = createROURightHtml(data);
                break;
            case GAME_TYPE.SHB.type:
                tableId = GAME_TYPE.SHB.table;
                leftHtml = createSHBLeftHtml(data);
                rightHtml = createSHBRightHtml(data);
                break;
            case GAME_TYPE.ZJH.type:
                tableId = GAME_TYPE.ZJH.table;
                leftHtml = getZJHLeftHtml(data);
                rightHtml = getZJHRightHtml(data);
                break;
            default:
                break;
        }
        if (tableId !== "" && leftHtml !== "" && rightHtml !== "") {
            var $table = $("#" + tableId);
            $table.find(".row > .left-col").html(leftHtml);
            $table.find(".row > .right-col").html(rightHtml);
            $table.addClass("active");
        } else {
            layer.alert("不支持此类型游戏查询", {title: " "});
        }
    }

    // 生成炸金花左html
    function getZJHLeftHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩",
            bankerPoint = data.bankerPoint,
            playerPoint = data.playerPoint;

        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>庄家: ' + bankerPoint + ' 点;' +
            '   <ul>' +
            '      <li>闲家: ' + playerPoint + '点;</li>' +
            '   </ul>' +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成炸金花右html
    function getZJHRightHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var cards = cardList.split(";");
        var bankerCardList = cards[0].split(" "),playerCardList = cards[1].split(" ");
        var bankerCardsHtml = "",playerCardsHtml = "";
        for(var i = 0;i < bankerCardList.length;i++){
            var url = getPorkImgUrl(bankerCardList[i]);
            bankerCardsHtml += '<img src="' + url + '" alt="">';
        }
        for(var i = 0;i < playerCardList.length;i++){
            var url = getPorkImgUrl(playerCardList[i]);
            playerCardsHtml += '<img src="' + url + '" alt="">';
        }
        var html =
            '<h4>游戏局号: ' + gameCode +'    游戏类型: ' + gameName + '</h4>' +
            '<ul>' +
            '   <li><span>庄家：</span>' + bankerCardsHtml + '</li>' +
            '   <li><span>闲家：</span>' + playerCardsHtml + '</li>' +
            '</ul>';
        return html;
    }

    // 生成骰宝左html
    function createSHBLeftHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            cardList = data.cardList,
            flag = data.flag == 0 ? "新游戏":"已派彩";

        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>'+cardList+' </li>'+
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成骰宝右html
    function createSHBRightHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var dices = cardList.split(",");
        var html =
            '<h4>游戏局号: ' + gameCode +  '    游戏类型: ' + gameName + '</h4>' +
            '<div class="dice-wrap"> ';
        var dicesHtml = [];
        for (var index = 0;index < dices.length;index ++) {
            var diceHtml = "";
            var second = index * 0.2;
            if (index == 0) {
                diceHtml = '<span class="dice dice-' + dices[index] + ' animated bounceIn"></span>';
            } else {
                diceHtml = '<span class="dice dice-' + dices[index] + ' animated bounceIn" style="animation-delay: ' + second + 's"></span>';
            }
            dicesHtml.push(diceHtml);
        }
        html += dicesHtml.join("") + '</div>';
        return html;
    }

    // 生成轮盘左html
    function createROULeftHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩",
            card = data.cardList;
        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>' + card +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成轮盘右html
    function createROURightHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var html = '<h4>游戏局号: ' + gameCode + '    游戏类型: ' + gameName + '</h4>' +
            '<span class="num animated bounceIn">' + cardList + '</span>';
        return html;
    }

    // 生成牛牛左html
    function createNNLeftHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            bankerPoint = data.bankerPoint,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩";
        var playerPointSources = data.playerPoint;
        var playerPointArray = playerPointSources.split("|");

        // 生成闲点数html
        var playerHtml = [];
        for(var index = 0; index < playerPointArray.length; index ++){
            var playerResult = playerPointArray[index];
            var point = playerResult.charAt(0);
            var playerId = index + 1;
            playerHtml.push('<li>闲 ' + playerId + ': ' + point + '点;</li>')
        }
        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>庄家: ' + bankerPoint + ' 点;' +
            '   <ul>' +
            playerHtml.join("") +
            '   </ul>' +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成牛牛右html
    function createNNRightHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            bankerPoint = data.bankerPoint,
            cardList = data.cardList;
        var cardArray = cardList.split(";");
        var headCard = cardArray[0];
        var bankerCardArray = cardArray[1];
        var playersCardArray = cardArray.slice(2);
        var bankerCards = bankerCardArray.split(" ");
        var playerPointSources = data.playerPoint;
        var playerPointArray = playerPointSources.split("|");
        // 生成头牌html
        var headHtml = '<li><span>头牌：</span><img src="' + getPorkImgUrl(headCard) + '" alt=""></li>';

        // 生成庄html
        var bankerHmtl = '<div class="card-wrap"> ' + '   <span>庄：</span> ';
        for(var index = 0;index<bankerCards.length;index++){
            bankerHmtl += '<img src="' + getPorkImgUrl(bankerCards[index]) + '" alt="">';
        }
        bankerHmtl += '<span>牛' + bankerPoint + '</span> ' +
            '</div>';

        // 生成玩家html
        var playersHtml = [];
        for (var index = 0;index < playersCardArray.length;index++) {
            var playerPoint = playerPointArray[index];
            var playerId = index + 1;
            var playerCards = playersCardArray[index];
            var cardArray = playerCards.split(" ");
            var playerHtml =
                '<div class="card-wrap"><span>闲'+ playerId + '：</span> ';
            for (var i = 0;i< cardArray.length;i++) {
                playerHtml += '<img src="'+ getPorkImgUrl(cardArray[i]) + '" alt="">'
            }
            playerHtml += '<span>牛' + playerPoint.charAt(0) + '</span> ' +
                '</div>';
            playersHtml.push(playerHtml);
        }
        var rightHtml = '<li class="even">' + bankerHmtl + playersHtml.join("") + '</li>';
        var html = '<h4>游戏局号: ' + gameCode + '    游戏类型: ' + gameName + '</h4>';
        html += '<ul>' + headHtml + rightHtml + '</ul>';
        return html;
    }

    // 生成龙虎左html
    function createDTLeftHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩",
            dragonPoint = data.dragonPoint,
            tigerPoint = data.tigerPoint;

        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>龙点: ' + dragonPoint + ' 点;  ' +
            '   <ul>      ' +
            '       <li>虎点: ' + tigerPoint + '点;</li>   ' +
            '   </ul>' +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生产龙虎右html
    function createDTRightHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var cards = cardList.split(";");
        var dragonCard = cards[0],tigerCard = cards[1];
        var dragonCardHtml = '<img src="' + getPorkImgUrl(dragonCard) + '" alt="">';
        var tigerCardHtml = '<img src="' + getPorkImgUrl(tigerCard) + '" alt="">';
        var html =
            '<h4>游戏局号: ' + gameCode +'    游戏类型: ' + gameName + '</h4>' +
            '<ul>' +
            '   <li><span>龙：</span>' + dragonCardHtml + '</li>' +
            '   <li class="even"><span>虎：</span>' + tigerCardHtml + '</li>' +
            '</ul>';
        return html;
    }

    // 生成21点左html
    function createBJLeftHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩",
            bankerPointSource = data.bankerPoint,
            playerPoints = data.playerPoint;
        var playerPointSource = playerPoints.split(";");
        var bankerPoint = bankerPointSource.split(",");
        var _bankerPoint = bankerPoint[2];
        var playersPoint = [];
        for (var index = 0;index < playerPointSource.length;index ++) {
            var playerPointList = playerPointSource[index].split(",");
            var playerPoint = "";
            if (playerPointList.length > 1) {
                playerPoint = Math.max(playerPointList[3],playerPointList[4]);
            } else {
                playerPoint = 0;
            }
            playersPoint.push(playerPoint);
        }
        // 生成玩家点数html
        var playersPointHtml = [];
        for (var index = 0; index < playersPoint.length;index ++) {
            var playerId = index + 1;
            if (playersPoint[index] != "0") {
                var playerPointHmtl = '<li>玩家' + playerId + ': ' + playersPoint[index] + '点;</li>';
                playersPointHtml.push(playerPointHmtl);
            }
        }
        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>庄家: ' + _bankerPoint + ' 点;' +
            '   <ul>' + playersPointHtml.join("") +
            '   </ul>' +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成21点右html
    function createBJRightHtml(data) {
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var playerCards = cardList.split(";");
        var playerInfos = [];

        // 生成卡牌结果数组
        for(var index = 0;index < playerCards.length;index++){
            var cardInfo = playerCards[index];
            var info = cardInfo.split(":");
            var palyerSource = info[0],cards = info[1];
            var player = "";
            var _cards;

            // 玩家分牌情况
            if (cards && cards.indexOf(",") > 0) {
                var cardList = cards.split(",");
                _cards = [];
                $.each(cardList,function (index,item) {
                    _cards.push(item.split(" "));
                })
            } else {
                _cards = cards == undefined ? "" : cards.split(" ");
            }
            // _cards = $.map(_cards,function(index,item){return index.split(",")});
            if (palyerSource == "B") {
                player = "庄家";
            } else {
                var playIndex = palyerSource.charAt(1) ? palyerSource.charAt(1): index ;
                player = "玩家" + playIndex;
            }
            if (cards) {
                var playerInfo = {
                    player:player,
                    cards:_cards
                };
                playerInfos.push(playerInfo);
            }
        }

        // 生成卡牌html
        var cardsHtml  = [];
        for (var index = 0;index < playerInfos.length;index++) {
            var playerInfo = playerInfos[index];
            var player = playerInfo.player,cards = playerInfo.cards;
            var _cardHtml = [];
            for (var i = 0;i < cards.length;i++) {
                var card = cards[i];
                if (typeof card === "object") {
                    for (var j = 0;j < card.length;j++) {
                        var init = j == 0 ? "init" : "final";
                        var __cardHtml = '<img src="' + getPorkImgUrl(card[j]) +'" class="' + init + '" alt="">';
                        _cardHtml.push(__cardHtml);
                    }
                } else {
                    var init = '';
                    if (index < 1 && i < 1) {
                        init = "init";
                    } else if (index > 0 && i < 2) {
                        init = "init";
                    } else {
                        init = "final";
                    }
                    var __cardHtml = '<img src="' + getPorkImgUrl(cards[i]) +'" class="' + init + '" alt="">';
                    _cardHtml.push(__cardHtml);
                }
            }

            var cardHtml = '<li><span>'+ player + '：</span>' +
                _cardHtml.join("") +
                '</li>';
            cardsHtml.push(cardHtml);
        }
        var html =
            '<h4>游戏局号: ' + gameCode + '    游戏类型: ' + gameName + '</h4>' +
            '   <div class="text-center">' +
            '   <label class="radio-inline">' +
            '       <input type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" data-status="init" data-type="BJ"> 初始卡牌结果 ' +
            '   </label> ' +
            '   <label class="radio-inline">' +
            '       <input type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" data-status="final" data-type="BJ" checked=""> 最终卡牌结果 ' +
            '   </label>' +
            '</div>' +
            '<ul>' + cardsHtml.join("") + '</ul>';
        return html;
    }

    // 生成百家乐左html
    function getBACLeftHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            tableCode = data.tableCode || data.videoId,
            beginTime = data.beginTime,
            endTime = data.closeTime,
            flag = data.flag == 0 ? "新游戏":"已派彩",
            bankerPoint = data.bankerPoint,
            playerPoint = data.playerPoint;

        var html =
            '<ul>' +
            '   <li><span>桌枱号：</span>' + gameName + tableCode + '</li>' +
            '   <li><span>游戏类型：</span>' + gameName + '</li>' +
            '   <li><span>开始时间：</span>' + beginTime + '</li>' +
            '   <li><span>结束时间：</span>' + endTime + '</li>' +
            '   <li><span>游戏结果：</span>庄家: ' + bankerPoint + ' 点;' +
            '   <ul>' +
            '      <li>闲家: ' + playerPoint + '点;</li>' +
            '   </ul>' +
            '   <li><span>状态：</span>' + flag + '</li>' +
            '</ul>'+
            '<span class="stamp"></span>';
        return html;
    }

    // 生成百家乐右html
    function getBACRightHtml(data){
        var gameName = GAME_TYPE[data.gameType].name,
            gameCode = data.gmCode,
            cardList = data.cardList;
        var cards = cardList.split(";");
        var bankerCardList = cards[1].split(" "),playerCardList = cards[0].split(" ");
        var bankerCardsHtml = "",playerCardsHtml = "";
        for(var i = 0;i < bankerCardList.length;i++){
            var url = getPorkImgUrl(bankerCardList[i]);
            var init = i < 2 ? "init" : "final";
            bankerCardsHtml += '<img src="' + url + '" class="' + init + '" alt="">';
        }
        for(var i = 0;i < playerCardList.length;i++){
            var url = getPorkImgUrl(playerCardList[i]);
            var init = i < 2 ? "init" : "final";
            playerCardsHtml += '<img src="' + url + '" class="' + init + '" alt="">';
        }
        var html =
            '<h4>游戏局号: ' + gameCode +'    游戏类型: ' + gameName + '</h4>' +
            '<ul>' +
            '   <li><span>庄家：</span>' + bankerCardsHtml + '</li>' +
            '   <li class="even"><span>闲家：</span>' + playerCardsHtml + '</li>' +
            '</ul>';
        return html;
    }
});
