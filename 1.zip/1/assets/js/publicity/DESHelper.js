//加密
function encryptByDES(str){
    var keyHex = CryptoJS.enc.Utf8.parse(pn.DES_KEY);
    var encrypted = CryptoJS.DES.encrypt(
        str ,
        keyHex ,
        {
            mode : CryptoJS.mode.ECB ,
            padding : CryptoJS.pad.Pkcs7
        }
    );
    return encodeURIComponent(encrypted.toString());
}
//解密
function decryptByDES(str){
    var keyHex = CryptoJS.enc.Utf8.parse(pn.DES_KEY);
    var decrypted = CryptoJS.DES.decrypt(
        {
            ciphertext : CryptoJS.enc.Base64.parse(str)
        } ,
        keyHex ,
        {
            mode : CryptoJS.mode.ECB ,
            padding : CryptoJS.pad.Pkcs7
        }
    );
    return decrypted.toString(CryptoJS.enc.Utf8);
}