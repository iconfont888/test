function myFunctionTutorials() {
    _hmt.push(['_trackEvent', 'AG8', '主站', '新手教程', '新手教程']);
    window.open('/publicity/tutorials', '', "toolbar=no,scrollbars=no,resizable=1,top=100,left=100,width=1040,height=600");

}

$('#listNum').hover(
    function () {
        $('#listNum > span').addClass('list-num');
    }, function () {
        $('#listNum > span').removeClass('list-num');
    }
);