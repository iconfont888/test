$(function () {
    //app动态获取文件大小
    // $.request({
    //     url: "/api/app/size",
    // }).done(function (response) {
    //     if (response.successful) {
    //         data = response.data;
    //         $('.mobile-wrap').empty();
    //         $('.mobile-wrap').append("<span><i class='icon-apple'></i>文件大小：" +  data.android + "</span>");
    //         $('.mobile-wrap').append("<span><i class='icon-android'></i>文件大小：" +  data.ios + "</span>");
    //         $('.mobile-wrap').append("<h4>手机亚游</h4><h6>隐私更安全,赢钱更随意</h6>");
    //     }
    // }).fail(function(e){
    //     logConsole(e);
    // });

    bindClick();
    $(".download-mode-1").text("手机浏览器输入网址："+location.host);
    $('.moblie-qr').css({"background": "url('/download/qr/moblie?host=" + encodeURIComponent(location.href.replace(/(^.*?\/\/.*?\/).*/, "$1")) + "') 50% 10% no-repeat"})

    var downloadDic = JSON.parse(utils.storage.getItem("downloadDic"));
    if(downloadDic){
        buildQrCode(downloadDic);
    }else{
        //生成手机亚游APP二维码
        $.request({
            url: "/api/app/downloadUrl"
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                utils.storage.setItem('downloadDic',JSON.stringify({'host':data.host,'appAgDownload':data.appAgDownload,'mobledowlond':data.mobledowlond,'appAgqjHref':data.appAgqjHref,'appAgin':data.appAgin,'appFish':data.appFish}));
                buildQrCode(data);
            }else{
                logConsole(response.message);
            }
        }).fail(function (e) {
            logConsole(e);
        });
    }

});

function buildQrCode(data){
    //获取二维码生成的跳转地址
    var appAgDownload = data.appAgDownload+'?domain='+location.hostname;
    //生成手机亚游APP二维码
    $('#ag-app .canvas').qrcode({
        ecLevel: 'H',
        render    : "canvas",
        text    : appAgDownload,
        width : "134",               //二维码的宽度
        height : "142",              //二维码的高度
        background : "#ffffff",       //二维码的后景色
        foreground : "#000000",        //二维码的前景色
        src: '/assets/images/home/new_icon.png'             //二维码中间的图片
    });

    //获取二维码生成的跳转地址
    var host = data.mobledowlond+'?url='+data.host;
    //生成手机网页版二维码
    $('#webmobile-qr .canvas').qrcode({
        ecLevel: 'H',
        render    : "canvas",
        text    : host,
        width : "160",               //二维码的宽度
        height : "170",              //二维码的高度
        background : "#ffffff",       //二维码的后景色
        foreground : "#000000",        //二维码的前景色
        src: '/assets/images/home/qr_logo.png'             //二维码中间的图片
    });

    //获取二维码生成的跳转地址
    var appAgqjHref = data.appAgqjHref;
    //生成旗舰厅二维码
    $('#agq .canvas').qrcode({
        ecLevel: 'H',
        render    : "canvas",
        text    : appAgqjHref,
        width : "160",               //二维码的宽度
        height : "170",              //二维码的高度
        background : "#ffffff",       //二维码的后景色
        foreground : "#000000",        //二维码的前景色
        src: '/assets/images/home/qr_logo.png'             //二维码中间的图片
    });

    //获取二维码生成的跳转地址
    var appAgin = data.appAgin;
    //生成国际厅二维码
    $('#agin .canvas').qrcode({
        ecLevel: 'H',
        render    : "canvas",
        text    : appAgin,
        width : "160",               //二维码的宽度
        height : "170",              //二维码的高度
        background : "#ffffff",       //二维码的后景色
        foreground : "#000000",        //二维码的前景色
        src: '/assets/images/home/ag.png'             //二维码中间的图片
    });

    //获取二维码生成的跳转地址
    var appFish = data.appFish;
    //生成捕鱼王二维码
    $('#fish .canvas').qrcode({
        ecLevel: 'H',
        render    : "canvas",
        text    : appFish,
        width : "160",               //二维码的宽度
        height : "170",              //二维码的高度
        background : "#ffffff",       //二维码的后景色
        foreground : "#000000",        //二维码的前景色
        src: '/assets/images/home/fish.png'             //二维码中间的图片
    });
}
function bindClick() {
    $('.ag-mobile-wrap .btn-send-submit').each(function (i, item) {
        $(item).bind('click', function () {
            var tabName = $('li.active a[aria-expanded="true"]').attr('href');
            var phone = $(tabName + " input[name='phone']").val();            
            var type = tabName.substring(1);
            if (!(/^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$/.test(phone))) {
                layer.alert("请输入正确的手机号码", {title: " "});
                return;
            }
            $.request({
                type: 'POST',
                url: '/api/publicity/sendalink',
                encrypt: true,
                data: {
                    'type': type,
                    'phone': phone
                },
                success: function (response) {
                    var data = response.data || response.message;
                    if (response.successful) {
                        layer.alert(data, {title: " "});
                        countdown(item);
                    } else {
                        layer.alert(data, {title: " "});
                    }
                },
                error: function(xhr,textStatus,err){
                    console.log("error: " + err);
                }
            });
        });
    })
}

function countdown(item) {
    $(item).unbind('click');
    $(item).attr('style', 'background-color: #8e8783');
    var currenttime = new Date().getTime();
    var csecond = 300;
    UpdateTime();
    var counter = setInterval(UpdateTime, 500);

    function UpdateTime() {
        var cTime = new Date().getTime();
        var diff = cTime - currenttime;
        var seconds = csecond - Math.floor(diff / 1000);
        var count = seconds < 10 ? "0" + seconds : seconds;
        if (seconds >= 0) {
            $(item).text("发送(" + count + ")");
        } else {
            $(item).text("发送");
            $(item).attr('style', 'background-color: #b85c2e');

            bindClick();

            clearInterval(counter);
        }
    }
}



































