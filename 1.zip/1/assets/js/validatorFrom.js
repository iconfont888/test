function ValidatorFrom($from, options) {
    var t = this;
    this.status = false;
    this.validation = {};
    var default_event = "blur";
    this.settings = {
        event: default_event,
        submit: function () {
        },
        validationCallBack: function (valid, key, $node) {
            if (valid === undefined) {
                valid = true;
            }
            $node.parents('.form-group').removeClass('success error');
            $node.parents('.form-group').addClass(valid ? 'success' : 'error');
        },
        validationFunction: {},
        getVerify: function (result) {
            var type = $.type(result);
            if (type === "object") {
                return result["successful"];
            }
            return result;
        },
        checkNode: null
    };
    $.extend(this.settings, options);

    function validationCallBack(valid, $node) {
        $.each(valid, function (key, value) {
            if ($.type(t.settings.validationCallBack) === 'function') {
                t.settings.validationCallBack(value, key, $node);
            } else {
                t.settings.validationCallBack[key](value, key, $node);
            }
        });
    }

    this.isSuccess = function () {
        var keys = $.map(this.settings.validationFunction, function (value, key) {
            return key;
        });

        function call(fuc, $node) {
            return $.when(fuc.call(t, ($node))).then(function (res) {
                var o = {};
                o[$node.attr("name")] = res;
                validationCallBack(o, $node);
                if (t.settings.getVerify(res)) {
                    var len = keys.length;
                    for (var i = 0; i < len; i++) {
                        var name = keys.splice(0, 1)[0],
                            _$node = $from.find("*[name='" + name + "']");
                        var isResult = true;
                        if (t.settings.checkNode && _$node.length) {
                            isResult = t.settings.checkNode(_$node);
                        } else {
                            isResult = _$node.filter(":visible").length;
                        }
                        if (isResult) {
                            break;
                        }
                    }
                    if (isResult && _$node.length) {
                        return call(t.settings.validationFunction[name], _$node);
                    }
                }
                return $.when(res);
            })
        }

        if (keys.length) {
            var len = keys.length;
            for (var i = 0; i < len; i++) {
                var name = keys.splice(0, 1)[0],
                    _$node = $from.find("*[name='" + name + "']");
                var isResult = true;
                if (t.settings.checkNode && _$node.length) {
                    isResult = t.settings.checkNode(_$node);
                } else {
                    isResult = _$node.filter(":visible").length;
                }
                if (isResult) {
                    break;
                }
            }
            if (isResult && _$node.length) {
                return call(t.settings.validationFunction[name], _$node);
            }
        }
        return $.when(true);
    };

    this.validation = function (name) {
        var _$node = $from.find("*[name='" + name + "']"), res = true;
        if (this.settings.checkNode) {
            res = this.settings.checkNode(_$node);
        } else {
            res = _$node.filter(":visible").length;
        }
        if (res) {
            return $.when(this.settings.validationFunction[name].call(t, (_$node)))
                .done(function (res) {
                    var o = {};
                    o[name] = res;
                    validationCallBack(o, _$node);
                    return $.when(res);
                })
        }
        return $.when(true);

    };
    $.each(t.settings.validationFunction, function (key, value) {
        var event;
        if ($.type(t.settings.event) === "string") {
            event = t.settings.event;
        } else {
            event = t.settings.event[key];
        }
        if (!event) {
            event = default_event;
        }
        $from.find("*[name='" + key + "']")
            .on(event, function (e) {
                var $this = $(this);
                $.when(value.call(t, $this)).done(function (result) {
                    var o = {};
                    o[key] = result;
                    validationCallBack(o, $this);
                })
            });
    });
    $from.on("submit", function (e) {
        e.preventDefault();
        if ($from.hasClass("ongoing-js")) {
            return;
        }
        $from.addClass("ongoing-js");

        t.isSuccess().done(function (res) {
            if (t.settings.getVerify(res)) {
                $from.trigger("ag.submit");
                if ($.type(t.settings.submit) === "function") {
                    t.settings.submit(t, $from);
                }
            }
        }).always(function () {
            $from.removeClass("ongoing-js");
        });
    });
}