function CreateMDUtil() {
    var util = new Object();
    util.init = function () {
        this.addEvt('click', this.btnClick);
        this.pageLoadForBigDataPV();
    }

    util.TYPE_BTN = 1;
    util.TYPE_PAGE = 2;

    //通过按钮单击事件进行埋点
    util.btnClick = function (e) {
        var attr = util.needSend(e);

        if (attr === null) {
            return;
        }

        var data = util.getUserCfg();

        //域名
        if (document) {
            data.domain = document.domain || '';
        }

        //得到PV埋点配置
        var pv_cfg = util.getPVCfgByCode(attr['data-code'].value);
        data['code'] = pv_cfg['code'];
        data['location'] = pv_cfg['location'];
        data['locationName'] = pv_cfg['locationName'];
        data['label'] = pv_cfg['label'];

        //事件时间
        data['occurTime'] = Date.parse(new Date());

        //埋点类型
        data['type'] = this.TYPE_BTN;

        //用户类型
        data['userType'] = util.getUserType();

        util.setDeviceInfo(data);

        util.send(data);
    }

    //通过URL访问的页面加载进行埋点
    util.pageLoadForBigDataPV = function () {
        if (!document.referrer) {
            return;
        }

        var uri = window.location.pathname + window.location.search + window.location.hash;

        //获取PV埋点配置
        var pv_cfg = this.getPVCfgByURI(uri);

        //判断URI是否是需要进行埋点的
        if (pv_cfg) {
            var data = this.getUserCfg();

            //域名
            if (document) {
                data.domain = document.domain || '';
            }

            data['code'] = pv_cfg['code'];
            data['location'] = pv_cfg['location'];
            data['locationName'] = pv_cfg['locationName'];
            data['label'] = pv_cfg['label'];

            //埋点类型
            data['type'] = this.TYPE_PAGE;

            //用户类型
            data['userType'] = this.getUserType(data['userType']);

            this.setDeviceInfo(data);

            this.send(data);
        }
    }

    util.setDeviceInfo = function (data) {
        data['deviceOs'] = this.deviceOs;
        data['deviceBrand'] = this.deviceBrand;
        data['deviceModel'] = this.deviceModel;
    }

    util.needSend = function (e) {
        //获取事件源
        e = e || window.event;
        var src = e.srcElement || e.target;
        //获取事件源的属性
        attr = src.attributes;
        //如果没有data-code属性说明不是我们需要埋点的按钮
        if (!attr['data-code']) {
            return null;
        }
        return attr;
    }

    //发送数据
    util.send = function (data) {
        var query = [];
        for (var k in data) {
            query.push(k + '=' + encodeURIComponent(data[k]));
        }

        //删除无用数据
        for (var i = 0; i < query.length; i++) {
            if (query[i].indexOf("url") !== -1) {
                query.splice(i, 1);
            }
        }

        try {
            var img = new Image();
            var rand = '_click_' + Math.floor(2147483648 * Math.random()).toString(36);
            window[rand] = img;
            img.onload = img.onerror = img.onabort = function () {
                img.onload = img.onerror = img.onabort = null;
                img = window[rand] = null;
            };
            // img.src = url + '?' + query.join('&');
            console.log(query);
        } catch (e) {
        }
    };

    //获取用户配置数据
    util.getUserCfg = function () {
        var data = {};
        //解析_maq配置
        if (_maq) {
            for (var i in _maq) {
                //_maq      : 相当于map
                //_maq[i][0]: 相当于key
                //_maq[i][1]: 相当于value
                switch (_maq[i][0]) {
                    case 'serverURL':
                        data.url = _maq[i][1];
                        break;
                    case 'userId':
                        data.userId = _maq[i][1];
                        break;
                    case 'userName':
                        data.userName = _maq[i][1];
                        break;
                    case 'sysCode':
                        data.sysCode = _maq[i][1];
                        break;
                    case 'productId':
                        data.productId = _maq[i][1];
                        break;
                    case 'site':
                        data.site = _maq[i][1];
                        break;
                    case 'star':
                        data.star = _maq[i][1];
                        break;
                    case 'userType':
                        data.userType = util.getUserType(_maq[i][1]);
                        break;
                    case 'occurTime':
                        data.occurTime = _maq[i][1];
                        break;
                    default:
                        break;
                }
            }
        }
        return data;
    }

    //绑定事件
    util.addEvt = function (event, funcName) {
        if (document.addEventListener) {
            document.addEventListener(event, funcName);
        } else {
            document.attachEvent('on' + event, funcName);
        }
    }

    //用户类型
    util.getUserType = function (ut) {
        if (ut === '') {
            return 1;
        }
        if (ut === '0') {
            return 2;
        }
        if (ut === '1') {
            return 3;
        }
        return '';
    }

    util.getPVCfgByCode = function (code) {
        return this.getPVCfgByKey("code", code);
    }

    util.getPVCfgByURI = function (uri) {
        return this.getPVCfgByKey("url", uri);
    }

    util.getPVCfgByKey = function (key, value) {
        var cfg = generatePVConfig();
        for (var i = 0; i < cfg.length; i++) {
            if (cfg[i][key] === value) {
                return cfg[i];
            }
        }
    }

    util.deviceOs = function () {
        return this.isAndroid() || this.isIOS() || this.isWindowsPhone() || this.isPC();
    }
    util.deviceBrand = function () {
        return "deviceBrand";
    }
    util.deviceModel = function () {
        return "deviceModel";
    }
    util.isPC = function () {
        return !util.isMobile() ? "mobile" : "pc";
    }
    util.isMobile = function () {
        return this.isAndroid() || this.isIPhone() || this.isWindowsPhone() || this.isIPad();
    }
    util.isAndroid = function () {
        return navigator.userAgent.toLowerCase().match(/android/i) != null ? "android" : "";
    }
    util.isIOS = function () {
        return this.isIPad() || this.isIPhone() ? "ios" : "";
    }
    util.isWindowsPhone = function () {
        return navigator.userAgent.toLowerCase().match(/windows phone/) != null ? "windows phone" : "";
    }
    util.isIPad = function () {
        return navigator.userAgent.toLowerCase().match(/ipad/i) != null ? "ipad" : "";
    }
    util.isIPod = function () {
        return navigator.userAgent.toLowerCase().match(/ipod/i) != null ? "ipod" : "";
    }
    util.isIPhone = function () {
        return navigator.userAgent.toLowerCase().match(/iphone/i) != null || util.isIPod() ? "iphone" : "";
    }
    util.isBrowser = function () {
        return this.isChrome() || this.isFirefox() || this.isOpera() || this.isSafari() || this.isIE();
    }
    util.isChrome = function () {
        return navigator.userAgent.toLowerCase().match(/chrome/i) != null ? "chrome" : "";
    }
    util.isFirefox = function () {
        return navigator.userAgent.toLowerCase().match(/firefox/i) != null ? "firefox" : "";
    }
    util.isOpera = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/opera/i) != null || ua.match(/opr\//i) != null ? "opera" : "";
    }
    util.isSafari = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/safari/i) != null ? "safari" : "";
    }
    util.isIE = function () {
        return this.isIE6() || this.isIE7() || this.isIE8() || this.isIE9() || this.isIE10() || this.isIE11();
    }
    util.isIE11 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/trident\/7/) != null && ua.match(/rv:11/) != null ? "ie11" : "";
    }
    util.isIE10 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/msie 10/i) != null && !util.isOpera() ? "ie10" : "";
    }
    util.isIE9 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/msie 9/i) != null && !this.isOpera() ? "ie9" : "";
    }
    util.isIE8 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/msie 8/i) != null && !this.isOpera() ? "ie8" : "";
    }
    util.isIE7 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/msie 7/i) != null && !this.isOpera() ? "ie7" : "";
    }
    util.isIE6 = function () {
        var ua = navigator.userAgent.toLowerCase();
        return ua.match(/msie 6/i) != null && !this.isOpera() ? "ie6" : "";
    }

    function generatePVConfig(){
        var cfg = new Array();
        cfg.push({'location': 'AG8主页|左方导航', 'locationName': '首页', 'code': 'AG8001', 'label': '首页', 'url': ''});
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': 'AG国际厅',
            'code': 'AG8002',
            'label': 'AG国际厅',
            'url': '/game/show/agq'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': 'AG旗舰厅',
            'code': 'AG8003',
            'label': 'AG旗舰厅',
            'url': '/game/show/agin'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': 'AG刮刮彩',
            'code': 'AG8004',
            'label': 'AG刮刮彩',
            'url': 'game/play/scg'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': 'AG赌场厅',
            'code': 'AG8005',
            'label': 'AG赌场厅',
            'url': '/game/show/agtel'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': 'AG棋牌厅',
            'code': 'AG8006',
            'label': 'AG棋牌厅',
            'url': '/game/show/agchess'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': '电子游戏',
            'code': 'AG8007',
            'label': '电子游戏',
            'url': '/website/redirect?scheme=https&url=/'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': '体育投注',
            'code': 'AG8008',
            'label': '体育投注',
            'url': '/game/try/shababsports'
        });
        cfg.push({
            'location': 'AG8主页|左方导航',
            'locationName': '最新优惠',
            'code': 'AG8009',
            'label': '最新优惠',
            'url': '/promotion'
        });
        cfg.push({
            'location': 'AG8主页|左方导航 ',
            'locationName': '手机投注',
            'code': 'AG8010',
            'label': '手机投注',
            'url': '/publicity/download'
        });

        cfg.push({
            'location': 'AG8主页|左上导航',
            'locationName': '亚游风采',
            'code': 'AG8011',
            'label': '亚游风采',
            'url': 'AG8011'
        });
        cfg.push({
            'location': 'AG8主页|左上导航',
            'locationName': '亚游论坛',
            'code': 'AG8012',
            'label': '亚游论坛',
            'url': '/bbs'
        });
        cfg.push({
            'location': 'AG8主页|左上导航',
            'locationName': '推荐好友',
            'code': 'AG8013',
            'label': '推荐好友',
            'url': '/publicity/recommend'
        });

        cfg.push({
            'location': 'AG8主页|顶部广告',
            'locationName': '顶部广告',
            'code': 'AG8014',
            'label': '顶部广告',
            'url': 'AG8014'
        });

        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '快速登录',
            'code': 'AG8015',
            'label': '快速登录',
            'url': 'AG8015'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '快速注册',
            'code': 'AG8016',
            'label': '快速注册',
            'url': 'AG8016'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '免费试玩',
            'code': 'AG8017',
            'label': '免费试玩',
            'url': 'AG8017'
        });

        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '快速登录',
            'code': 'AG8018',
            'label': '快速登录',
            'url': '/login#quick-login'
        });
        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '动态密码登录',
            'code': 'AG8019',
            'label': '动态密码登录',
            'url': '/login#phone-login'
        });
        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '登录',
            'code': 'AG8020',
            'label': '登录',
            'url': 'AG8020'
        });
        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '忘记密码',
            'code': 'AG8021',
            'label': '忘记密码',
            'url': 'AG8021'
        });
        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '在此注册',
            'code': 'AG8022',
            'label': '在此注册',
            'url': 'AG8022'
        });
        cfg.push({
            'location': 'AG8主页|快速登录弹窗页面',
            'locationName': '关闭',
            'code': 'AG8023',
            'label': '关闭',
            'url': 'AG8023'
        });

        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '快速注册',
            'code': 'AG8024',
            'label': '快速注册',
            'url': '/register#quick-register'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '普通注册',
            'code': 'AG8025',
            'label': '普通注册',
            'url': '/register#basic-register'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '快速注册界面-注册',
            'code': 'AG8026',
            'label': '快速注册界面-注册',
            'url': 'AG8026'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '普通注册界面-注册',
            'code': 'AG8027',
            'label': '普通注册界面-注册',
            'url': 'AG8027'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '注册送刮刮卡',
            'code': 'AG8028',
            'label': '注册送刮刮卡',
            'url': 'AG8028'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '在此登录',
            'code': 'AG8029',
            'label': '在此登录',
            'url': 'AG8029'
        });
        cfg.push({
            'location': 'AG8主页|快速注册弹窗页面',
            'locationName': '关闭',
            'code': 'AG8030',
            'label': '关闭',
            'url': 'AG8030'
        });

        cfg.push({
            'location': 'AG8主页|右侧导航',
            'locationName': '新手教程',
            'code': 'AG8031',
            'label': '新手教程',
            'url': '/publicity/tutorials'
        });
        cfg.push({
            'location': 'AG8主页|右侧导航',
            'locationName': '在线客服',
            'code': 'AG8032',
            'label': '在线客服',
            'url': 'AG8032'
        });
        cfg.push({
            'location': 'AG8主页|右侧导航',
            'locationName': '加速登录器',
            'code': 'AG8033',
            'label': '加速登录器',
            'url': '/tools/accelerator'
        });

        cfg.push({
            'location': 'AG8主页|底部',
            'locationName': '关于AG亚游',
            'code': 'AG8034',
            'label': '关于AG亚游',
            'url': '/publicity/aboutus'
        });
        cfg.push({
            'location': 'AG8主页|底部',
            'locationName': '游戏规则',
            'code': 'AG8035',
            'label': '游戏规则',
            'url': '/publicity/gamerule'
        });
        cfg.push({
            'location': 'AG8主页|底部',
            'locationName': '开牌结果验证',
            'code': 'AG8036',
            'label': '开牌结果验证',
            'url': '/publicity/verification'
        });
        cfg.push({
            'location': 'AG8主页|底部',
            'locationName': '博彩牌照',
            'code': 'AG8037',
            'label': '博彩牌照',
            'url': '/publicity/aboutus/license'
        });
        cfg.push({
            'location': 'AG8主页|底部',
            'locationName': '工具下载',
            'code': 'AG8038',
            'label': '工具下载',
            'url': '/publicity/aboutus/tool'
        });

        cfg.push({
            'location': 'AG8主页|中侧',
            'locationName': '主轮播图',
            'code': 'AG8039',
            'label': '主轮播图',
            'url': 'AG8039'
        });

        cfg.push({
            'location': 'AG8主页|中下侧',
            'locationName': '轮播图一',
            'code': 'AG8040',
            'label': '轮播图一',
            'url': 'AG8040'
        });
        cfg.push({
            'location': 'AG8主页|中下侧',
            'locationName': '轮播图二',
            'code': 'AG8041',
            'label': '轮播图二',
            'url': 'AG8041'
        });
        cfg.push({
            'location': 'AG8主页|中下侧',
            'locationName': '轮播图三',
            'code': 'AG8042',
            'label': '轮播图三',
            'url': 'AG8042'
        });
        cfg.push({
            'location': 'AG8主页|中下侧',
            'locationName': '轮播图四',
            'code': 'AG8043',
            'label': '轮播图四',
            'url': 'AG8043'
        });
        cfg.push({
            'location': 'AG8主页|中下侧',
            'locationName': '轮播图五',
            'code': 'AG8044',
            'label': '轮播图五',
            'url': 'AG8044'
        });

        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '消息',
            'code': 'AG8045',
            'label': '消息',
            'url': '/ucenter/letters'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '我的账户',
            'code': 'AG8046',
            'label': '我的账户',
            'url': '/ucenter/account'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '游戏大厅',
            'code': 'AG8047',
            'label': '游戏大厅',
            'url': '/game/show/lobby'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '充值',
            'code': 'AG8048',
            'label': '充值',
            'url': '/ucenter/pay/payIndex'
        });
        cfg.push({
            'location': 'AG8主页|右上导航',
            'locationName': '提现',
            'code': 'AG8049',
            'label': '提现',
            'url': '/ucenter/withdraw/withdrawIndex'
        });

        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'AG旗舰厅',
            'code': 'AG8050',
            'label': 'AG旗舰厅',
            'url': '/game/play/agin'
        });
        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'AG国际厅',
            'code': 'AG8051',
            'label': 'AG国际厅',
            'url': '/game/play/agq'
        });
        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'AG捕鱼王',
            'code': 'AG8052',
            'label': 'AG捕鱼王',
            'url': 'AG8052'
        });
        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'AG亚游电游',
            'code': 'AG8053',
            'label': 'AG亚游电游',
            'url': 'AG8053'
        });
        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'AG刮刮彩',
            'code': 'AG8054',
            'label': 'AG刮刮彩',
            'url': '/game/play/scg'
        });
        cfg.push({
            'location': 'AG8主页|游戏大厅',
            'locationName': 'NB体育',
            'code': 'AG8055',
            'label': 'NB体育',
            'url': '/game/show/sport'
        });

        cfg.push({
            'location': '充值|在线支付',
            'locationName': '在线支付',
            'code': 'AG8056',
            'label': '在线支付',
            'url': '/ucenter/pay/payIndex#tab-1'
        });
        cfg.push({
            'location': '充值|在线支付',
            'locationName': '在线支付-网银在线支付',
            'code': 'AG8057',
            'label': '网银在线支付',
            'url': 'AG8057'
        });
        cfg.push({
            'location': '充值|在线支付',
            'locationName': '在线支付-银联快捷支付',
            'code': 'AG8058',
            'label': '银联快捷支付',
            'url': 'AG8058'
        });
        cfg.push({
            'location': '充值|在线支付',
            'locationName': '在线支付-下一步',
            'code': 'AG8059',
            'label': '下一步',
            'url': 'AG8059'
        });

        cfg.push({
            'location': '充值|比特币支付',
            'locationName': '比特币支付',
            'code': 'AG8060',
            'label': '比特币支付',
            'url': '/ucenter/pay/payIndex#tab-6'
        });
        cfg.push({
            'location': '充值|比特币支付',
            'locationName': '比特币支付-下一步',
            'code': 'AG8061',
            'label': '下一步',
            'url': 'AG8061'
        });

        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付',
            'code': 'AG8062',
            'label': '扫码支付',
            'url': '/ucenter/pay/payIndex#tab-2'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-超级支付宝',
            'code': 'AG8063',
            'label': '超级支付宝',
            'url': 'AG8063'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-微信',
            'code': 'AG8064',
            'label': '微信',
            'url': 'AG8064'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-支付宝',
            'code': 'AG8065',
            'label': '支付宝',
            'url': 'AG8065'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-QQ',
            'code': 'AG8066',
            'label': 'QQ',
            'url': 'AG8066'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-银联',
            'code': 'AG8067',
            'label': '银联',
            'url': 'AG8067'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-京东',
            'code': 'AG8068',
            'label': '京东',
            'url': 'AG8068'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-下一步',
            'code': 'AG8069',
            'label': '下一步',
            'url': 'AG8069'
        });

        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账',
            'code': 'AG8070',
            'label': '银行卡转账',
            'url': '/ucenter/pay/payIndex#tab-3'
        });
        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账-网银',
            'code': 'AG8071',
            'label': '网银',
            'url': 'AG8071'
        });
        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账-支付宝',
            'code': 'AG8072',
            'label': '支付宝',
            'url': 'AG8072'
        });
        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账-手机银行',
            'code': 'AG8073',
            'label': '手机银行',
            'url': 'AG8073'
        });
        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账-微信支付',
            'code': 'AG8074',
            'label': '微信支付',
            'url': 'AG8074'
        });
        cfg.push({
            'location': '充值|银行卡转账',
            'locationName': '银行卡转账-下一步',
            'code': 'AG8075',
            'label': '下一步',
            'url': 'AG8075'
        });
        cfg.push({
            'location': '充值|快充',
            'locationName': '快充',
            'code': 'AG8076',
            'label': '快充',
            'url': '/ucenter/pay/payIndex#tab-4'
        });
        cfg.push({
            'location': '充值|快充',
            'locationName': '快充-下一步',
            'code': 'AG8077',
            'label': '下一步',
            'url': 'AG8077'
        });
        cfg.push({
            'location': '充值|扫码支付',
            'locationName': '扫码支付-云闪付',
            'code': 'AG8078',
            'label': '云闪付',
            'url': 'AG8078'
        });
        return cfg;
    }

    return util;
}
