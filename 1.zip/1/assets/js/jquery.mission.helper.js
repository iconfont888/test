/***
 *
 * 我的任务
 *
 */
var paths = window.location.pathname.split("/");
var missionType = paths.pop() || paths.pop();
var availableHelper;
var missionHelper;
$(function() {
    var _usable = ["newcomer", "daily", "achieve", "ucenter", "acount", "letters"];
    if ($.inArray(missionType, _usable) < 0) {
        missionType = paths[1];
    }
    var $umenu = $(".umenu-wrap"),
        $uempty = $(".u-empty"),
        $umission = $(".u-mission");
    if (pn.userType && pn.userType == "1" && $umenu) {
        availableHelper = new AvailableHelper();
        var _available = availableHelper.get();
        if ($.inArray(missionType, _usable) >= 0) {
            if ($.inArray(missionType, _usable) >= 3 && _available && (new Date().getTime() - _available.now <= 2 * 60 * 1000)) {
                setTimeout(function() {
                    generateBadge(_available.hasOwnProperty("availables") ? _available.availables : null);
                }, 10);
            } else {
                missionHelper = new MissionHelper();
                if ($.inArray(missionType, _usable) > 2) {
                    missionHelper.init();
                }
            }
        } else {
            if (_available && _available.hasOwnProperty("availables")) {
                //  生成可领取任务'new'标志
                setTimeout(function() {
                    generateBadge(_available.availables || null);
                }, 10);
            }
        }
    }

    function MissionHelper() {
        var countL = 0;
        var _mission = [];
        var _progresses = [];
        //  生成任务列表数据
        var progressHtml = function($missionLi, mission) {
            var _progress = grepGame(_progresses, [function(c) {
                return c.id === mission.id;
            }]) || [];
            var progress = _progress.length ? _progress[0].progress : [];
            var result = progress && progress.length;
            if (!!result) {
                var html = [];
                //通关夺重金活动特殊处理
                if (mission.bigType != 1) {
                    $.each(progress, function(index, item) {
                        var aHtml;
                        var classA = item.pass ? "complete" : "undone pointer-link";
                        var picPass = item.pass ? "checked" : "cross";
                        if (item.linkUrl && item.linkType) {
                            // noinspection RegExpRedundantEscape
                            var classB = item.pass ? "" : "underline";
                            var main = pn.terminal === "VIP" ?
                                (/PC_MAIN_VIP\[(.*?)\]/.exec(item.linkUrl)) :
                                (/PC_MAIN\[(.*?)\]/.exec(item.linkUrl));
                            var url = (main && main.length) ? main[1] : "";
                            if (item.code === "bankFlag") {
                                url += "?redirect=/ucenter/mission/newcomer";
                            }
                            var classOrHref = (item.pass ? "" : url);

                            if (item.linkType === "INTERNAL") {
                                classA += classOrHref ? "" : " undefined";
                                aHtml = "<p class='markers " + picPass + "'><a data-tongji-attr='_trackEvent,AG8," + mission.name + "," + item.text + "," + item.text + "' data-toggle='modal' data-name='" + mission.name + "' class='" + classA + " " + classB + " " + classOrHref + "'>" + item.text + "</a></p>";
                            } else {
                                var href = classOrHref ? ('href="' + classOrHref + '"') : "";
                                aHtml = '<p class="markers ' + picPass + '"><a data-tongji-attr="_trackEvent,AG8,' + mission.name + ',' + item.text + ',' + item.text + '" ' + href + ' class="' + classA + ' ' + classB + ' undefined">' + item.text + '</a></p>';
                            }
                        } else {
                            aHtml = '<p class="markers ' + picPass + '"><a data-tongji-attr="_trackEvent,AG8,' + mission.name + ',' + item.text + ',' + item.text + '" class="undefined" style="text-decoration: none;color: #ac6e20;">' + item.text + '</a></p>';
                        }
                        html.push(aHtml);
                    });
                    if (html.join(" ").indexOf('cross') <= -1) {
                        $('li[data-id="' + mission.id + '"]').find('.btn-receive-award').removeClass('btn4 gradiento1');
                        $('li[data-id="' + mission.id + '"]').find('.btn-receive-award').addClass('btn3 gradiento');
                    }
                    $missionLi.show().find(".u-premise-condition").html(html.join(" "));
                } else {
                    var totalPayAmount = 0;
                    var envParticipateAmount = 0;
                    if (_progress[0].property != null) {
                        totalPayAmount = _progress[0].property.system_totalPayAmount ? _progress[0].property.system_totalPayAmount : 0;
                        envParticipateAmount = _progress[0].property.system_env_participate_amount ? _progress[0].property.system_env_participate_amount : 0;
                    }
                    var tempHmtl = '<p><span class="count">' + envParticipateAmount + '</span>/' + totalPayAmount + '</p>';
                    html.push(tempHmtl);
                    $missionLi.show().find(".progressbar p").html(html.join(" "));
                    var tempWidth = 0;
                    if (totalPayAmount != 0) {
                        tempWidth = envParticipateAmount / totalPayAmount * 100;

                        if (envParticipateAmount >= totalPayAmount) {
                            $('li[data-id="' + mission.id + '"]').find('.btn-receive-award').removeClass('btn4 gradiento1');
                            $('li[data-id="' + mission.id + '"]').find('.btn-receive-award').addClass('btn3 gradiento');
                        }
                    }


                    $('li[data-id="' + mission.id + '"]').find('.progressbar .progressb').css("width", tempWidth + "%");
                }
            } else {
                //  删除无进度的任务
                $missionLi.remove();
            }

            //  更新可领取任务缓存中数目
            availableHelper.update({ type: missionType, id: mission.id, status: !!result });
        };
        var generateProgress = function($missionLi, mission) {
            progressHtml($missionLi, mission);
        };
        var generateHtml = function(index, length, status, mission) {
            if (!mission && !mission.length) {
                return;
            }
            //倒计时文字描述
            var statusRemark = "距离结束";
            if (status === "going") {
                statusRemark = "距离开始";
            }
            var imageUrl;
            if (mission.actLogo) {
                imageUrl = pn.activeUrl + mission.actLogo;
            } else {
                var imageName = 'p_hongbao';
                if (mission.activityType === 'DEPOSIT') {
                    imageName = 'p_deposit';
                } else if (mission.activityType === 'BET') {
                    imageName = 'p_betting';
                } else if (mission.activityType === 'REGISTER') {
                    imageName = 'p_reg';
                }
                var path = pn.terminal === "VIP" ? "vip" : "";
                imageUrl = '/' + path + 'static/images/user/apply_promo/' + imageName + '.jpg';
            }
            var rules = "";
            if (status === "ongoing") {
                rules = '<div class="countdowncontainer" data-begin="' + mission.actBeginTime + '" data-end="' + mission.actEndTime + '">' +
                    '     <p>' +
                    statusRemark + ' <i>0</i>天 <i>00</i>:<i>00</i>:<i>00</i></p>' +
                    '</div>';
            }
            var ruleDetail = mission.ruleDetail || "暂无数据";

            var icoClass = isLoginTime(mission.actEndTime) ? "" : "countdown";

            var html =
                ' <li data-id="' + mission.actId + '" class="col-2 ' + icoClass + '" style="display: none;">' +
                '<div class="col col-chest"><div  class="chestcc">' +
                '<h2               class="pink">' + (mission.bonusDescribe || "") + '</h2>';
            if (mission.taskDescribe.length > 30) {
                html += '<p class="p">' + (mission.taskDescribe || "").substring(0, 25) + '...</p>';
            } else {
                html += '<p>' + (mission.taskDescribe || "") + '</p>';
            }
            html += '<div style="background-size: initial;"><image src="' + imageUrl + '"/></div>' +
                rules +
                '</div></div>' +
                '<div class="col col-info">';

            if (mission.bigType == 1) {
                html += '<div class="info"><h3 class="orange">' + mission.actName + '</h3>' +
                    '<div class="info-title">' +
                    '<span>'+
                    '<label>完成进度</label>'+
                    '</span>'+
                    '</div>'+
                    '<div class="date"><div class="progressbar"><div class="progressb">' +
                    '<div class="progression"></div></div>' +
                    '<p><span class="count">50000</span>/100000</p>' +
                    '</div>' +
                    '</div>' +
                    '<div class="separator"></div>' +
                    '</div>' +
                    '<a class="btn btn-receive-award btn4 gradiento1" data-tongji-attr="_trackEvent,AG8,' + mission.actName + ',领取奖励,领取奖励" >领取奖励</a>'
            } else if (mission.bigType == 2) {
                var level = pn.userLevel;
                html += '<div class="info"><h3 class="pink">' + mission.actName + '</h3>' +
                    '<div class="info-title">' +
                    '<span>'+
                    '<label>完成进度</label>'+
                    '</span>'+
                    '</div>'+
                    '<div class="star-ratings">' +
                    '<div class="ratings">' +
                    '<p class="label">当   前：</p><p class="stars">'
                for (var i = 0; i < level; i++) {
                    html += '<i></i>'
                }
                html += '</p>' +
                    '</div>' +
                    '<div class="ratings">' +
                    '<p class="label">下一级：</p><p class="stars">'
                for (var i = 0; i <= level; i++) {
                    html += '<i></i>'
                }
                html += '</p>' +
                    '</div>' +
                    '</div>' +
                    '<div class="separator"></div>' +
                    '<a class="btn btn2 bgsilver">自动派发</a>'
            } else if (mission.bigType == 3) {
                html += '<div class="info">' +
                    ' <h3 class="pink">周年礼金</h3>' +
                    '<div class="info-title">' +
                    '<span>'+
                    '<label>完成进度</label>'+
                    '</span>'+
                    '</div>'+
                    ' <div class="date">' +
                    '<p>距离周年日还差： </p>' +
                    '<p class="dates count-time"><span class="grad">0</span><span class="grad">0</span>月<span' +
                    ' class="grad">0</span><span class="grad">0</span>日</p>' +
                    '</div>' +
                    '<div class="separator"></div>' +
                    '</div>' +
                    '<a id="getMoneyYear" class="btn btn3 gradient" src="javascript:;">领取奖励</a>'
                vipTimer();
            } else if (mission.bigType == 4) {
                html += '<div class="info">' +
                    '<h3 class="pink">' + mission.actName + '</h3>' +
                    '<div class="info-title">' +
                    '<span>'+
                    '<label>完成进度</label>'+
                    '</span>'+
                    '</div>'+
                    '<div class="date">' +
                    '<p>成功推荐人数：</p>' +
                    '<p class="referrals">0<span>人</span></p>' +
                    '</div>' +
                    '<div class="separator"></div>' +
                    '<a class="btn btn2 bgsilver">自动派发</a></div>'
                getTotalValidCustomers();
            } else {
                html += '<div class="info"><h3 class="pink">' + mission.actName + '</h3>' +
                    '<div class="info-title">' +
                    '<span>'+
                    '<label>完成进度</label>'+
                    '</span>'+
                    '</div>'+
                    '<div class="date u-premise-condition">' +
                    '加载中...' +
                    '</div>' +
                    '<div class="separator"></div></div>' +
                    '<a class="btn btn-receive-award btn4 gradiento1" data-tongji-attr="_trackEvent,AG8,' + mission.actName + ',领取奖励,领取奖励">领取奖励</a>';
            }
            var loginTimeStr = isLoginTime(mission.actEndTime) ? "长期有效" : "限时";
            html += '<a class="link" href="#modal-rules" data-toggle="modal">更多细则' +
                '<div class="rule-content" style="display: none;">' + ruleDetail + '</div></a>' +
                '</div><p class="note">' + loginTimeStr + '</p>' +
                '</li>';
            var $li = $(html);
            $(".u-task-list .palebg").append($li);

            $(".list-col-0[data-name='" + mission.actName + "'] img").error(function() {
                $(this).parent().html(mission.actName).css({ 'padding-top': '5px', 'color': '#b98d56' });
            });
            //启用过期时钟
            if (index === length - 1) {
                (new Timer).init();
            }
            //加载进度
            generateProgress($li, { id: mission.actId, name: mission.actName, bigType: mission.bigType });
        };

        //是否长期有效判断
        var isLoginTime = function(endTime) {
            var formatTime = function(i) {
                return (i < 10 ? "0" + i : i) + " ";
            };

            var space, now = new Date();

            space = __AG_DATE_.compare(endTime, now);

            var days = formatTime(Math.floor(space / 1000 / 60 / 60 / 24));
            if (days >= 30) {
                return true;
            } else {
                return false;
            }
        };

        var generateList = function() {
            var configs = grepGame(_mission, [function(n) {
                return n.taskType === missionType.toUpperCase();
            }]) || [];
            if (configs && configs.length) {
                //正在开始的任务
                var ongoings = grepGame(configs, [function(n) {
                    return isBeforeToNow(n.actBeginTime) && !isBeforeToNow(n.actEndTime);
                }]);
                //过期的的任务
                var expireds = grepGame(configs, [function(n) {
                    return isBeforeToNow(n.actEndTime);
                }]);
                //即将开始的任务
                var goings = grepGame(configs, [function(n) {
                    return !isBeforeToNow(n.actBeginTime);
                }]);
                $.each({ ongoing: ongoings, expired: expireds, going: goings }, function(status, mission) {
                    var _s = status;
                    var _length = mission.length;
                    $.each(mission, function(index, item) {
                        generateHtml(index, _length, _s, item);
                    });
                });

            } else {
                $umission.hide();
                $uempty.show();
            }
        };

        var loadEndProgress = function() {
            var newcomers = grepGame(_progresses, [function(n) {
                return n.type === "NEWCOMER";
            }]) || [];
            var dailies = grepGame(_progresses, [function(n) {
                return n.type === "DAILY";
            }]) || [];
            var achieves = grepGame(_progresses, [function(n) {
                return n.type === "ACHIEVE";
            }]) || [];

            //  设置各类任务可领取任务标识数据
            var newcomerStatus = $.map(newcomers, function(item) {
                return {
                    "id": item.id,
                    "status": item.isInterim || !!(item.progress && item.progress.length)
                };
            });
            var dailyStatus = $.map(dailies, function(item) {
                return {
                    "id": item.id,
                    "status": item.isInterim || !!(item.progress && item.progress.length)
                };
            });
            var achieveStatus = $.map(achieves, function(item) {
                return {
                    "id": item.id,
                    "status": item.isInterim || !!(item.progress && item.progress.length)
                };
            });

            //  存入缓存中
            var available = {
                newcomer: newcomerStatus,
                daily: dailyStatus,
                achieve: achieveStatus
            };
            //  将当前可以参与活动的数量存入本地
            availableHelper.set(available);

            //  生成可领取任务'new'标志
            generateBadge(available);

            if ($.inArray(missionType, _usable) >= 0) {
                generateList();
            }
        };
        var ajaxProgress = function(mission) {
            return $.request({
                url: "/api/mission/progress/" + mission.id
            }).done(function(response) {
                if(response.successful){
                    // noinspection JSUnresolvedVariable
                    var data = response.data,
                        progress = data.qualificationList;
                    _progresses.push({
                        id: mission.id,
                        type: mission.type,
                        name: mission.name,
                        isInterim: false,
                        progress: progress,
                        property: data.property
                    });
                }else{

                }
            }).fail(function(e) {
                logConsole(e);
            });
        };
        var getProgresses = function(configs) {
            _mission = configs || [];
            if (_mission && _mission.length) {
                countL = _mission.length;
                return $.map(_mission, function(item) {
                    return ajaxProgress({
                        id: item.actId,
                        type: item.taskType,
                        name: item.actName
                    });
                });
            } else {
                return { getProgressesFailure: true };
            }
        };
        var getConfigs = function() {
            return $.request({
                url: "/api/mission/configs"
            }).done(function(response) {
                var data = response.data;
                if (response.successful && _VALID.isNormal(data)) {
                    var greps = [];
                    greps.push(function(n) {
                        // noinspection JSUnresolvedVariable
                        var customerLevels = n.customerLevels,
                            ruleOperator = n.ruleOperator;
                        if (_VALID.isNormal(customerLevels)) {
                            return ruleOperator === 'exclude' ?
                                customerLevels.indexOf(pn.userLevel) === -1 :
                                customerLevels.indexOf(pn.userLevel) !== -1;
                        }
                        return true;
                    });
                    greps.push(function(n) {
                        // noinspection JSUnresolvedVariable
                        return isBeforeToNow(n.actBeginTime) && !isBeforeToNow(n.actEndTime);
                    });
                    response.configs = grepGame(data, greps);
                    return response;
                }
                return response;
            }).fail(function(e) {
                logConsole(e);
            });
        };
        this.init = function() {
            return getConfigs()
                .then(function (response) {
                    if (response.successful) {
                        return $.when.apply(null, getProgresses(response.configs));
                    }
                    return { getConfigFailure: true };
                })
                .then(function(response) {
                    if (response && response.getConfigFailure || response && response.getProgressesFailure) {
                        $umission.hide();
                        $uempty.show();
                        availableHelper.clear();
                    } else {
                        loadEndProgress();
                    }
                });
        };
    }

    //  可领取任务缓存到localStorage, 读取,设置,更新
    function AvailableHelper() {
        var missionKey = "mission_new_count_" + pn.terminal.toLowerCase() + ":" + pn.userName;
        var _helper = this;
        _helper.set = function(availables) {
            localStorage.setItem(missionKey,
                JSON.stringify({
                    now: new Date().getTime(),
                    availables: availables
                }));
        };
        _helper.get = function() {
            return JSON.parse(localStorage.getItem(missionKey));
        };
        //  更新 localStorage 状态, 以及当 availables 中可领取状态都为false时, 显示任务列表为空的页面"任务正在路上"
        _helper.update = function(mission) {
            var missionType = mission.type;
            var availables = _helper.get().availables;
            var contain = false;
            $.each(availables[missionType], function(index, item) {
                if (item.id === mission.id) {
                    contain = true;
                    item.status = mission.status;
                }
            });
            if (!contain) {
                availables[missionType].push({ id: mission.id, status: mission.status });
            }
            localStorage.setItem(missionKey,
                JSON.stringify({
                    now: new Date().getTime(),
                    availables: availables
                }));
            var available = grepGame(availables[missionType], [function(n) {
                return n.status === true;
            }]);
            if (!available || !available.length) {
                $umission.hide();
                $uempty.show();
            }
        };
        _helper.clear = function() {
            localStorage.removeItem(missionKey);
        };
    }

    //  生成NEW标志
    function generateBadge(availables) {
        if (!availables) {
            return;
        }
        $.request({
            url: "/api/mission/checkContainsNew",
            data: {
                missionType: [1, 2, 3]
            },
            traditional: true,
            async: false
        }).done(function(res) {
            if (res.successful) {
                var newInterval = setInterval(function(){
                    if($('.umenu-wrap').length){
                        var isNewcomerNew = !!$("dl>.newcomer-dd a:has('.badge_2')").length;
                        var isDailyNew = !!$("dl>.daily-dd a:has('.badge_2')").length;
                        var isAchieveNew = !!$("dl>.achieve-dd a:has('.badge_2')").length;
                        var newcomerNew = $.grep(res.data, function(item) {
                            return item.missionType == "NEWCOMER";
                        })[0].containsNew;
                        var dailyNew = $.grep(res.data, function(item) {
                            return item.missionType == "DAILY";
                        })[0].containsNew;
                        var achieveNew = $.grep(res.data, function(item) {
                            return item.missionType == "ACHIEVE"
                        })[0].containsNew;
                        if (!isNewcomerNew && newcomerNew) {
                            $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.newcomer-dd a"));
                        }
                        if (!isDailyNew && dailyNew) {
                            $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.daily-dd a"));
                        }
                        if (!isAchieveNew && achieveNew) {
                            $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.achieve-dd a"));
                        }
                        clearInterval(newInterval);
                    }
                },300);
            }
        }).fail(function(e) {
            logConsole(e);
        });
        return;
        // var newcomerNew = [], dailyNew = [], achieveNew = [];
        // if (!isNewcomerNew) {
        //     if (availables.hasOwnProperty("newcomer")) {
        //         newcomerNew = grepGame(availables.newcomer, [function (n) {
        //             return n.status === true;
        //         }]);
        //     }
        //     if (newcomerNew && newcomerNew.length) {
        //         $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.newcomer-dd a"));
        //     }
        // }
        // if (!isDailyNew) {
        //     if (availables.hasOwnProperty("daily")) {
        //         dailyNew = grepGame(availables.daily, [function (n) {
        //             return n.status === true;
        //         }]);
        //     }
        //     if (dailyNew && dailyNew.length) {
        //         $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.daily-dd a"));
        //     }
        // }
        // if (!isAchieveNew) {
        //     if (availables.hasOwnProperty("achieve")) {
        //         achieveNew = grepGame(availables.achieve, [function (n) {
        //             return n.status === true;
        //         }]);
        //     }
        //     if (achieveNew && achieveNew.length) {
        //         $('<em class="badge_2"><small>new</small></em>').appendTo($("dl>.achieve-dd a"));
        //     }
        // }
    }
});

function Timer() {
    var formatTime = function(i) {
        return (i < 10 ? "0" + i : i) + " ";
    };
    var generator = function($current, countdown) {
        var begin = $current.data('begin');
        var end = $current.data('end');
        var space, now = new Date();

        var missionBegin = false;
        //任务未开始
        if (!__AG_DATE_.isBefore(begin, now)) {
            missionBegin = true;
            space = __AG_DATE_.compare(begin, now);
            //任务正在进行中
        } else if (__AG_DATE_.isBefore(begin, now) && !__AG_DATE_.isBefore(end, now)) {
            space = __AG_DATE_.compare(end, now);
        } else {
            window.clearInterval(countdown);
            //  结束时间在当前时间之前, 活动已结束
            return;
        }
        var days = formatTime(Math.floor(space / 1000 / 60 / 60 / 24));
        if (days < 30 || missionBegin) {
            var hours = formatTime(Math.floor(space / 1000 / 60 / 60 % 24));
            var minutes = formatTime(Math.floor(space / 1000 / 60 % 60));
            var seconds = formatTime(Math.floor(space / 1000 % 60));
            var time = (days + hours + minutes + seconds).split(" ");
            $current.find("i").each(function(index, item) {
                $(item).text(time[index]);
            });
            $current.show();
        } else {
            window.clearInterval(countdown);
            $current.hide();
        }

    };
    this.init = function() {
        $('.countdowncontainer').each(function() {
            var $current = $(this);
            var countdown = window.setInterval(function() {
                generator($current, countdown);
            }, 1000);
        });
    };
}

//VIP会员周年日倒计时
function vipTimer() {
    $.request({
        url: "/api/anniversary/countDownInfo"
    }).done(function(r) {
        if (r.data === "PROVIDER_ERROR") {
            providerError();
            return;
        }
        var nowDate = new Date().getTime();
        var anniversaryDate = new Date(r.data).getTime();
        if (r.data === null) {
            if (nowDate > anniversaryDate) {
                $('.count-time').html(dealWithCountTime(anniversaryDate + 31536000000));
            } else {
                $('.count-time').html(dealWithCountTime(anniversaryDate));
            }
        } else {
            var anniversaryDeadline = new Date(r.data);
            if (nowDate < anniversaryDate) {
                $('.count-time').html(dealWithCountTime(anniversaryDate));
            } else if (nowDate >= anniversaryDate && nowDate <= anniversaryDeadline) {
                if (r.data.received) {
                    anniversaryDate = anniversaryDate + 31536000000;
                    $('.count-time').html(dealWithCountTime(anniversaryDate));
                } else {
                    $('.count-time span').eq(0).html("00");
                    $('.count-time span').eq(1).html("00");
                    $('.count-time span').eq(2).html("00");
                }
            } else if (nowDate > anniversaryDeadline) {
                anniversaryDate = anniversaryDate + 31536000000;
                $('.count-time').html(dealWithCountTime(anniversaryDate));
            }
        }
    }).fail(function(e) {
        logConsole(e);
    });
};

function providerError() {
    layer.open({
        title: '',
        yes: function(index) {
            layer.close(index);
        },
        content: "服务器遇到错误,请联系客服或稍后再试!"
    });
}
// dealWithCountTime2();
function dealWithCountTime2(endTime2) {
    var formatTime = function(i) {
        return (i < 10 ? "0" + i : (i + ""));
    };

    var endTime = new Date(endTime2);
    var now = new Date();

    if (endTime.getTime() < now.getTime()) {
        return;
    }
    var monthX = getIntervalMonth(now, endTime);
    var month = 0;
    var day = 0;
    var hour = 0;
    //计算月
    for (var i = 0; i < monthX; i++) {
        endTime.setUTCMonth(endTime.getUTCMonth() - 1);
        if (endTime.getTime() > now.getTime()) {
            month = month + 1;
        } else {
            endTime.setUTCMonth(endTime.getUTCMonth() + 1);
            break;
        }
    }
    var space = endTime.getTime() - now.getTime();
    //计算天
    day = space / (1000 * 60 * 60 * 24);
    //计算时
    hour = space / 1000 / 60 / 60 % 24;

    month = formatTime(Math.floor(month));
    day = formatTime(Math.ceil(day));
    hour = formatTime(Math.floor(hour));

    var result = "";
    result = result + (month > 9 ? "<span class='grad'>1</span><span" +
        " class='grad'>" + month % 10 + "</span>月" : "<span class='grad'>0</span><span class='grad'>" + month % 10 + "</span>月");
    result = result + (day > 9 ? "<span class='grad'>" + Math.floor(day / 10 % 10) + "</span><span" +
        " class='grad'>" + day % 10 + "</span>天" : "<span class='grad'>0</span><span class='grad'>" + day % 10 + "</span>天");
    return result;
}

function formatDate(date) {
    var y = date.getFullYear();
    var M = date.getMonth() + 1;
    var d = date.getDate();
    var h = date.getHours();
    var m = date.getMinutes();
    var s = date.getSeconds();
    console.log(y + "-" + M + "-" + d + " " + h + ":" + m + ":" + s);
}

function getIntervalMonth(date1, date2) {
    var month1 = date1.getMonth();
    var month2 = date2.getMonth();
    return (date2.getFullYear() * 12 + month2) - (date1.getFullYear() * 12 + month1);
}

function dealWithCountTime(endTime) {

    return dealWithCountTime2(endTime);
}
$("body").on('click', "#getMoneyYear", function() {
    window.location.href = "/privilege/anniversary";
});

function getTotalValidCustomers() {
    $.request({
        url: "/api/friends"
    }).done(function(r) {
        if (r.successful) {
            $(".u-task .u-task-list .grid-row ul .col-2 .col.col-info .date .referrals").html(" " + r.data.totalValidCustomers + "<span>人</span>")
        } else {
            $(".u-task .u-task-list .grid-row ul .col-2 .col.col-info .date .referrals").html("0<span>人</span>")
        }
    }).fail(function(e) {
        logConsole(e);
    });
}