function ad_getCookie(a) {
    for (var b = a + "=", c = document.cookie.split(";"), d = 0; d < c.length; d++) {
        for (var e = c[d];
            " " == e.charAt(0);) e = e.substring(1, e.length);
        if (0 == e.indexOf(b)) return e.substring(b.length, e.length)
    }
    return null
}
function ad_setCookieToMidnight(a,b){
    var c=new Date;
    c.setHours(23),c.setMinutes(59),c.setSeconds(59);
    var d="; expires="+c.toGMTString();
    document.cookie=a+"="+b+d+"; path=/"
}


function cubead(o){
    var _o =o;
    _o.cubeid = _o.adc+_o.adn;
    _o.adplay = false;
    _o.todayid = _o.cubeid + 'Today'

    _o.count = ad_getCookie(_o.cubeid);
    null==_o.count&&(_o.count=0),_o.count++;
    ad_setCookieToMidnight(_o.cubeid, _o.count);

    _o.openbtn = document.getElementById("cubead_openbtn");
    _o.quitbtn = document.getElementById("cubead_quitbtn");
    _o.wrapper = document.getElementById("cubead_wrapper");


    //檢查 圖片是否全數loaded
    var imgLoad = imagesLoaded('#cubead_content');

    //這個 on always 之後可以不要留
    imgLoad.on('always', function() {
        console.log( imgLoad.images.length + ' images loaded' );
        // detect which image is broken
        for ( var i = 0, len = imgLoad.images.length; i < len; i++ ) {
            var image = imgLoad.images[i];
            var result = image.isLoaded ? 'loaded' : 'broken';
            console.log( 'image is ' + result + ' for ' + image.img.src );
        }
    });

    imgLoad.on( 'done', function( instance ) {
        //console.log('DONE  - all images have been successfully loaded');
        //初始化 cubead
        initcube(_o);
    });

}

function initcube(o){
    var _o =o;
    _o.cube = new Cute.Slider();
    _o.cube.setup("cubead_content", "cubead_container");
    _o.cube.pause();

    var d = new Date();
    var today = d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate();
    var _today = localStorage.getItem(_o.todayid);

    if(_today === null || _today !== today) {
        setTimeout(function() {
            showCubeAD();
        }, 1500);
    }

    // if (_o.count < 3) {
    //     _o.openbtn.style.display = "none";
    //     setTimeout(function() {
    //         showCubeAD();
    //     }, 1000);
    // } else {
    //     _o.openbtn.style.display = "block";
    // }

    //展開廣告按鈕
    _o.openbtn.onclick = function(event) {
        showCubeAD();
    }

    _o.quitbtn.onclick = function(event) {
        hideCubeAD();
    }

    //顯示瘋狂3D
    function showCubeAD() {
        _o.adplay = true;
        _o.wrapper.style.top = "0px";
        _o.openbtn.style.display = "none";
        document.body.style.overflow = 'hidden';
        _o.cube.api.gotoSlide(1, true);
    }

    function hideCubeAD() {
        _o.cube.api.gotoSlide(0, true);
    }

    changeend = function(event) {
        var _idx = event.target.getCurrentSlideIndex();

        _o.quitbtn.style.display = "block";
        if (_idx == 1) {
            _o.cube.play();
        }
        if (_idx == 0 && _o.adplay == true) {
            _o.adplay = false;
            _o.wrapper.style.top = "-2000px";
            _o.openbtn.style.display = "block";
            _o.quitbtn.style.display = "none";
            document.body.style.overflow = '';
            _o.cube.pause();

            // 动画特效结束
            localStorage.setItem(_o.todayid, today);
        };
    }

    changestr = function(event) {
        _o.quitbtn.style.display = "none";
    }

    _o.cube.api.addEventListener(Cute.SliderEvent.CHANGE_END, changeend, this);
    _o.cube.api.addEventListener(Cute.SliderEvent.CHANGE_START, changestr, this);
}
