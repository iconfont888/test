/**
 * 头部广告CMS 配置
 */

//  生成顶部图片
$(function () {
    if ($("#headImg")) {
        cmsHelper.getScriptResult(generateHeaderImageCMSDataKey(), pn.userLevel ? pn.userLevel + "" : "1")
            .done(createHeaderImage)
            .fail(cms_failure)
            .fail(createDefaultHeaderImage);
    }

    function generateHeaderImageCMSDataKey() {
        if (pn.cmsDataKey == "NEW_PLAYER") {
            return "newPlayerHeaderImage";
        } else if (pn.cmsDataKey == "ORDINARY_MEMBER") {
            return "ordinaryMemberHeaderImage";
        } else if (pn.cmsDataKey == "VIP_MEMBER") {
            return "vipMemberHeaderImage";
        }
        return "";
    }

    function createDefaultHeaderImage() {
        var html = createDefaultHeaderImageHtml();
        $("#headImg").html(html);
    }

    var endTimeCount;

    //生成图片对象
    function createHeaderImageObject(data) {
        if (!data) {
            return null;
        }
        var headerImageList = [];
        $.each(data, function (index, item) {
            var headerImage = {
                "index": item.rank,
                "beginTime": item.beginTime,
                "endTime": item.endTime,
                "minUrl": item.defaultAction || item.maxImageAction,
                "minImageHttpUrl": item.minImageHttpUrl,
                "target": item.targetType,
                "templateType": item.templateType,
                "textDescription": item["textDescription"],
                "jsonObj": item["jsonObj"]
            };
            headerImageList.push(headerImage);
        });
        var headerImageListSort = resort(grepGame(headerImageList, [function (n) {
            return (n.beginTime - pn.sys_now) <= 0 && (n.endTime - pn.sys_now) >= 0;
        }]), "index");
        return headerImageListSort[0];
    }

    function createHeaderImage(data) {
        if(data === undefined) {
            return false;
        }
        var html;
        if (null == data || "" == data) {
            html = createDefaultHeaderImageHtml();
            $("#headImg").html(html);
            return;
        }
        var headerImageObject = createHeaderImageObject(data);
        if (headerImageObject) {
            html = createHeaderImageHtml(headerImageObject);
            $("#headImg").html(html);
            if (headerImageObject["textDescription"] === "1") {
                setInterval(countTime, 1000);
            }
        }
    }

    function createHeaderImageHtml(data) {
        var html = '';
        var textDescription = data["textDescription"];
        if (textDescription === '1') {
            html = createCountHeaderImageHtml(data);
        } else {
            html = createNoCountHeaderImageHtml(data);
        }
        return html;
    }

    function createCountHeaderImageHtml(data) {
        console.log(data);
        var minUrl = data["minImageAction"],
            minImageHttpUrl = data["minImageHttpUrl"],
            target = data["target"],
            beginTime = data["beginTime"],
            endTime = data["endTime"],
            target = data["target"];
        var codeDs = window.utils && utils.getDsCodeAttr(data["jsonObj"]);
        endTimeCount = endTime;
        var textDescription = data["textDescription"];
        var html = '';
        if (target === "a") {
            html += '<a ' + codeDs + ' href="' + minUrl + '" data-tongji-attr="_trackEvent,AG8,主站,顶部广告,顶部广告">';
        } else {
            html += '<a ' + codeDs + ' href="' + minUrl + '" target="_blank" data-tongji-attr="_trackEvent,AG8,主站,顶部广告,顶部广告">';
        }
        html += '<div class="count">';
        html += '<div class="xin-wrap" style="cursor:pointer;background: url(' + minImageHttpUrl + ');" id="timer">';
        html += '<ul><li id="timer1"></li><li id="timer2"></li><li class="text">天</li>' +
            '<li id="timer3"></li><li id="timer3"></li><li class="text">:</li>' +
            '<li id="timer5"></li><li id="timer6"></li><li class="text">:</li>' +
            '<li id="timer7"></li><li id="timer8"></li></ul>';
        html += '</div></div></a>';
        return html;
    }

    function createNoCountHeaderImageHtml(data) {
        
        var minUrl = data["minUrl"],
            minImageHttpUrl = data["minImageHttpUrl"],
            target = data["target"];
        var html = '';
        var codeDs = window.utils && utils.getDsCodeAttr(data["jsonObj"]);
        if (target === "a") {
            html += '<a ' + codeDs + ' href="' + minUrl + '" data-tongji-attr="_trackEvent,AG8,主站,顶部广告,顶部广告">';
        } else {
            html += '<a ' + codeDs + ' href="' + minUrl + '" target="_blank" data-tongji-attr="_trackEvent,AG8,主站,顶部广告,顶部广告">';
        }
        html += '<img src="' + minImageHttpUrl + '"></a>';
        return html;
    }

    function createDefaultHeaderImageHtml() {
        /*return '<div class="game-fish">' +
            '<a href="/website/redirect?scheme=http:url=/fishing" target="_blank" data-tongji-attr="_trackEvent,AG8,主站,顶部广告,顶部广告">' +
            '<img src="'+pn.staticurl+'/static/images/others/header/fishking.gif"></a></div>';*/
        return "";
    }

    function countTime() {
        var total = endTimeCount - pn.sys_now;
        if (total > 0) {
            var d = parseInt(total / 1000 / 60 / 60 / 24);//计算剩余的天数
            var h = parseInt(total / 1000 / 60 / 60 % 24);//计算剩余的小时数
            var m = parseInt(total / 1000 / 60 % 60);//计算剩余的分钟数
            var s = parseInt(total / 1000 % 60);//计算剩余的秒数
            d = checkTimehead(d);
            h = checkTimehead(h);
            m = checkTimehead(m);
            s = checkTimehead(s);
            var _time = (d + h + m + s).split("");
            $(".xin-wrap>ul>li[id]").each(function (index, item) {
                $(item).text(_time[index]);
            });
        } else {
            window.location.reload();
        }
        pn.sys_now = pn.sys_now + 1000;
    }

    function failure(data) {
        logConsole("Get CMS(" + data + ") configuration is abnormal.");
    }

    function checkTimehead(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i + "";
    }
});