/**
 * Created by Barden on 2017/6/1.
 */
$(function () {
    $("div.carousel.slide").on("slide.bs.carousel", function (e) {
        var target = e.relatedTarget, imgNode = $("img", target), src = imgNode.src;
        imgNode.each(function (index, item) {
            if (!item.src) {
                $(item).attr("src", $(item).data("src"));
            }
        });
    });

    if (lib.hasParam('kickout')) {
        var kickoutMsg = $("#kickoutMsg").val();
        $('.header-overlay').click();
        layer.open({
            title: ' ',
            content: kickoutMsg + '(点击联系<a class="as-cs" style="cursor:pointer">【在线客服】</a>)',
            btn: ['确定'],
            closeBtn: 0,
            yes: function (index, layero) {
                //todo 这地方有一个问题，layer弹窗貌似和本地的有影响，直接暴力解决
                window.location.href = '/login?redirect=' + location.pathname;
            }
        });
    }
});

$(function () {
    function buildPrePopFirst() {
        return '    <div class="pop-up-wrap">' +
            '        <div class="pop-up pop-up-1 is-showing">' +
            '          <div class="pop-up-header">' +
            '            <span class="envelope-btn-close"></span>' +
            '            <p>尊敬的AG亚游会员，欢迎回来！<em>' + _red_envelope.first.title + '</em></p>' +
            '          </div>' +
            '          <div class="pop-up-body">' +
            '            <div class="envelope-wrap">' +
            '              <a href="javascript:;" class="btn-link btn-link1"><img src="/assets/images/others/ad_banner/btn-text.png" alt=""></a>' +
            '            </div>' +
            '          </div>' +
            '          <div class="pop-up-footer">' + _red_envelope.tips + '</div>' +
            '        </div>' +
            '</div> ';
    }

    function buildPrePopNext(success, option) {
        var message;
        if (success) {
            message = option.flag === 2 ? "领取成功！您的礼金已经添加到账！" : "领取成功！请您联系客服审核！";
            return '<div class="pop-up pop-up-2">'
                + '     <div class="pop-up-header">'
                + '         <span class="envelope-btn-close"></span>'
                + '         <p>'
                + '             <em>' + _red_envelope.second.amount + '元</em>' + message
                + '         </p>'
                + '     </div>'
                + '     <div class="pop-up-body">'
                + '         <div class="envelope-wrap is-open">'
                + '             ' + _red_envelope.second.content + _red_envelope.second.button
                + '         </div>'
                + '     </div>'
                + '     <div class="pop-up-footer" style="color: #333">'
                + '             ' + _red_envelope.tips
                + '     </div>'
                + '</div>';
        }
        message = option ? option.replace("联系客服", "<a href='#' class='as-cs'>联系客服</a>") : "";
        return '<div class="pop-up pop-up-2">'
            + '     <div class="pop-up-header">'
            + '         <span class="envelope-btn-close"></span>'
            + '         <p>'
            + '             <em>领取失败</em>' + message
            + '         </p>'
            + '     </div>'
            + '     <div class="pop-up-body">'
            + '         <div class="envelope-wrap is-open"></div>'
            + '     </div>'
            + '     <div class="pop-up-footer" style="color: #333">'
            + '             ' + _red_envelope.tips
            + '     </div>'
            + '</div>';
    }

    function handlePreClick(option, $this) {
        $this.find(">.pop-up-1").loading();
        //noinspection JSUnresolvedFunction
        $.request({
            url: "/api/promotion/pre",
            type: "post",
            data: {"requestId": option.id}
        }).done(function (response) {
            $this.find(">.pop-up-1").removeClass("is-showing").addClass("animate-out");
            var data = response.data;
            //noinspection JSUnresolvedVariable
            if (response.successful) {
                $this.append(buildPrePopNext(true, {flag: data.flag}));
            } else {
                $this.append(buildPrePopNext(false, data));
            }
            $this.find(">.pop-up-2").addClass("animate-in");

        }).always(function () {
            $this.loading('close');
        });
    }

    //查询是否有预审优惠,如果有,出现弹窗提示用户领取
    function prePromotion() {
        if (pn.userName && pn.userType == "1") {
            //noinspection JSUnresolvedFunction
            $.request({
                url: "/api/promotion/pre"
            }).done(function (response) {
                //noinspection JSUnresolvedVariable
                if (response.successful) {
                    var data = response.data;
                    //noinspection JSUnresolvedVariable
                    setRedEnvelope(data);
                    var $this = $(buildPrePopFirst());
                    $this.show();
                    $($this).one("click", ".btn-link.btn-link1", function () {
                        handlePreClick(data, $this);
                    }).on("click", ".envelope-btn-close", function () {
                        $this.remove();
                    }).appendTo($("body>.wrapper"));
                }else{
                    logConsole(response.message);
                }
            }).fail(function(e){
                logConsole(e);
            });
        }
    }

    var hb_name_move = "_ADS_MOVE_ONCE_BANNER";
    var isVerified = _Cookie_.get(hb_name_move);
    var ad = $('.third-phase-wrap.is-animating');
    if (!isVerified) {
       ad.addClass('active')
        $('.third-phase-wrap.is-animating .btn-close').click(function () {
            ad.fadeOut();
            //查询是否有预审优惠,如果有,出现弹窗提示用户领取
            prePromotion();
        });
        _Cookie_.set(hb_name_move, "We are a family", 1);
    } else {
        ad.fadeOut();
    }

    prePromotion();
    /* 新人注册弹窗 */
    if(localStorage.getItem('register_key')){
        localStorage.removeItem('register_key');
        if(pn.userName){
            $('.ads-wrap.memberday-ads-js').show();
        }
                    $('.ads-wrap.memberday-ads-js .btn-close').on('click', function () {
            $('.ads-wrap.memberday-ads-js').fadeOut();
                    });
    }
    if (pn.userName && pn.userType >= 1) {
        $.request({
            url: "/api/lottery-ticket/first-price"
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                // if(!data)
                if (data && data.hasOwnProperty('actType')){
                    var actType = data.actType;
                    //期号
                    var openPeriods = data.actId;
                    var key = "promo_maserati_user_"+actType+openPeriods;
                    var val = "PROMO-MASERATI-user-"+actType+openPeriods;
                    if (localStorage.getItem(key) != val) {
                        // 弹出层（周奖）
                        var className = actType == 1 ? 'super_pirze' :'';
                        var ad = $('#threeAndOne');
                        //根据期号设置中奖图片
                        ad.find('h2').html(data.luckyPrize);
                        ad.find('.ads-container').addClass(className);
                        ad.fadeIn();
                        $('#threeAndOne').find(".close").on("click", function () {
                            $('#threeAndOne').fadeOut();
                        });
                        $('#threeAndOne .submits').on('click', function(){
                            $('#threeAndOne').fadeOut();
                        });
                        //缓存当前当前期号和中奖类型
                        localStorage.setItem(key, val);
                    }
                }
            }
        }).fail(function(e){
            logConsole(e);
        });
    }

});

/*根据注册星级展示充值按钮icon*/
$(function () {
	if(pn.userType =="1"){
        $.request({
            url: "/api/newly/register",
            type: "POST"
        }).done(function (response) {
            if (response.successful) {
            var _data = response.data;
                if(localStorage.getItem("key")==="MODAL-NEW-MAMBER"){
                   return false;
                }else if(_data.firstDeposit && !_data.promotionRecord){
                    $(".modal-new-mamber").show();
                    $('.modal-new-mamber .btn-close').on('click', function () {
                        $('.modal-new-mamber').fadeOut();
                    });
                    localStorage.setItem("key","MODAL-NEW-MAMBER");
                }
            }
        }).fail(function(e){
            logConsole(e);
        });
    }
});

/*首存优惠到期提醒-消息弹窗*/
$(function () {
    if(!pn.userName) {
        return;
    }
    if(localStorage.getItem("first_deposit_pop")==="FIRST-DEPOSIT-POP") {
        return false;
    }else{
        var cliW = document.documentElement.clientWidth || document.body.clientWidth, width_height = [];
        if (Math.floor(cliW) >= 1920) {
            width_height = ['670px', '566px'];
        } else if (Math.floor(cliW) <= 1360) {
            width_height = ['490px', '414px'];
        }else if (Math.floor(cliW) > 1360 && Math.floor(cliW) <= 1600) {
            width_height = ['540px', '460px'];
        } else {
            width_height = ['600px', '510px'];
        }
        $.request({
            url: "/api/first/deposit",
            type: "post",
        }).done(function (response) {
            if (response.successful) {
                var _data = response.data;
                if(!_data.firstDeposit){
                    layer.open({
                        skin: 'first-save',
                        title: ' ',
                        btn: false,
                        area: ['756px', '470px'],
                        content: '<div class="text-content"><a href="/ucenter/mission/newcomer" class="use_now"></a></div>'
                    });
                    localStorage.setItem("first_deposit_pop","FIRST-DEPOSIT-POP");
                }
            }
        }).fail(function(e){
            logConsole(e);
        });
    }
});

// 已登录
if(AG_INIT.isLogin() && pn.userType === 1) {
	// 弹出层（QG刮刮卡）
    $.request({
        url: "/api/game/scg/showScgTip"
    }).done(function (res) {
        var code = res.code;
        var data = res.data;
        if(code === 200) {
            if(localStorage.getItem("times") !== "one" && data.needShowTip) {
                var cont = '<p>尊敬的AG亚游会员，欢迎回来！<br /><strong>恭喜您获得<em>' + data.total + '</em>张刮刮彩！</strong></p>';
                cont += '<a href="/game/play/scg/" target="_blank" class="button">立即领取</a>';
                cont += data.expirationTime != null ? '<p class="tip">温馨提醒：本刮刮卡将于' + data.expirationTime + '失效</p>' : '';
                var index_1 = layer.open({
                    skin: 'layer-ggk',
                    title: false,
                    btn: "",
                    content: cont,
                    success: function () {
                        localStorage.setItem("times", "one");
                        $("a.button").click(function () {
                            layer.close(index_1);
                        })
                    }
                })
            }
        } else if(code === 5001) {
            AG_INIT.clear();
            layer.open({
                title: ' ',
                className: 'icon-no',
                content: res.message,
                btn: ['确定'],
                btnActive: 0,
                yes: function () {
                    top.window.location = "/login?redirect=" + document.location.href;
                }
            });
        } else {
            var index_2 = layer.open({
                title: ' ',
                className: 'icon-no',
                content: res.message,
                btn: ['确定'],
                btnActive: 0,
                yes: function () {
                    layer.close(index_2);
                }
            });
        }
    }).fail(function(e){
        if(e.status==401){
            return;
        }
        logConsole(e);
    });
}