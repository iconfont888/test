var TWEEN = TWEEN ||
function() {
  var d, h, c, g, e = 60,
    b = false,
    a = [],
    f;
  return {
    setFPS: function(a) {
      e = a || 60
    },
    start: function(a) {
      arguments.length != 0 && this.setFPS(a);
      c = setInterval(this.update, 1e3 / e)
    },
    stop: function() {
      clearInterval(c)
    },
    setAutostart: function(a) {
      b = a;
      b && !c && this.start()
    },
    add: function(d) {
      a.push(d);
      b && !c && this.start()
    },
    getAll: function() {
      return a
    },
    removeAll: function() {
      a = []
    },
    remove: function(b) {
      d = a.indexOf(b);
      d !== -1 && a.splice(d, 1)
    },
    update: function(d) {
      var c = 0,
        e = d || Date.now();
      while (c < a.length) if (a[c].update(e)) c++;
      else a.splice(c, 1);
      f == 0 && b == true && this.stop()
    }
  }
}();
TWEEN.Tween = function(l) {
  var a = l,
    j = {},
    e = {},
    h = {},
    k = 1e3,
    f = 0,
    g = null,
    i = TWEEN.Easing.Linear.EaseNone,
    d = null,
    c = null,
    b = null;
  this.to = function(c, d) {
    if (d !== null) k = d;
    for (var b in c) {
      if (a[b] === null) continue;
      h[b] = c[b]
    }
    return this
  };
  this.start = function(c) {
    TWEEN.add(this);
    g = c ? c + f : Date.now() + f;
    for (var b in h) {
      if (a[b] === null) continue;
      j[b] = a[b];
      e[b] = h[b] - a[b]
    }
    return this
  };
  this.stop = function() {
    TWEEN.remove(this);
    return this
  };
  this.delay = function(a) {
    f = a;
    return this
  };
  this.easing = function(a) {
    i = a;
    return this
  };
  this.chain = function(a) {
    d = a
  };
  this.onUpdate = function(a) {
    c = a;
    return this
  };
  this.onComplete = function(a) {
    b = a;
    return this
  };
  this.update = function(m) {
    var h, f, l;
    if (m < g) return true;
    f = (m - g) / k;
    f = f > 1 ? 1 : f;
    l = i(f);
    for (h in e) a[h] = j[h] + e[h] * l;
    c !== null && c.call(a, l);
    if (f == 1) {
      b !== null && b.call(a);
      d !== null && d.start();
      return false
    }
    return true
  }
};
TWEEN.Easing = {
  Linear: {},
  Quadratic: {},
  Cubic: {},
  Quartic: {},
  Quintic: {},
  Sinusoidal: {},
  Exponential: {},
  Circular: {},
  Elastic: {},
  Back: {},
  Bounce: {}
};
TWEEN.Easing.Linear.EaseNone = function(a) {
  return a
};
TWEEN.Easing.Quadratic.EaseIn = function(a) {
  return a * a
};
TWEEN.Easing.Quadratic.EaseOut = function(a) {
  return -a * (a - 2)
};
TWEEN.Easing.Quadratic.EaseInOut = function(a) {
  return (a *= 2) < 1 ? .5 * a * a : -.5 * (--a * (a - 2) - 1)
};
TWEEN.Easing.Cubic.EaseIn = function(a) {
  return a * a * a
};
TWEEN.Easing.Cubic.EaseOut = function(a) {
  return --a * a * a + 1
};
TWEEN.Easing.Cubic.EaseInOut = function(a) {
  return (a *= 2) < 1 ? .5 * a * a * a : .5 * ((a -= 2) * a * a + 2)
};
TWEEN.Easing.Quartic.EaseIn = function(a) {
  return a * a * a * a
};
TWEEN.Easing.Quartic.EaseOut = function(a) {
  return -(--a * a * a * a - 1)
};
TWEEN.Easing.Quartic.EaseInOut = function(a) {
  return (a *= 2) < 1 ? .5 * a * a * a * a : -.5 * ((a -= 2) * a * a * a - 2)
};
TWEEN.Easing.Quintic.EaseIn = function(a) {
  return a * a * a * a * a
};
TWEEN.Easing.Quintic.EaseOut = function(a) {
  return (a = a - 1) * a * a * a * a + 1
};
TWEEN.Easing.Quintic.EaseInOut = function(a) {
  return (a *= 2) < 1 ? .5 * a * a * a * a * a : .5 * ((a -= 2) * a * a * a * a + 2)
};
TWEEN.Easing.Sinusoidal.EaseIn = function(a) {
  return -Math.cos(a * Math.PI / 2) + 1
};
TWEEN.Easing.Sinusoidal.EaseOut = function(a) {
  return Math.sin(a * Math.PI / 2)
};
TWEEN.Easing.Sinusoidal.EaseInOut = function(a) {
  return -.5 * (Math.cos(Math.PI * a) - 1)
};
TWEEN.Easing.Exponential.EaseIn = function(a) {
  return a == 0 ? 0 : Math.pow(2, 10 * (a - 1))
};
TWEEN.Easing.Exponential.EaseOut = function(a) {
  return a == 1 ? 1 : -Math.pow(2, -10 * a) + 1
};
TWEEN.Easing.Exponential.EaseInOut = function(a) {
  return a == 0 ? 0 : a == 1 ? 1 : (a *= 2) < 1 ? .5 * Math.pow(2, 10 * (a - 1)) : .5 * (-Math.pow(2, -10 * (a - 1)) + 2)
};
TWEEN.Easing.Circular.EaseIn = function(a) {
  return -(Math.sqrt(1 - a * a) - 1)
};
TWEEN.Easing.Circular.EaseOut = function(a) {
  return Math.sqrt(1 - --a * a)
};
TWEEN.Easing.Circular.EaseInOut = function(a) {
  return (a /= .5) < 1 ? -.5 * (Math.sqrt(1 - a * a) - 1) : .5 * (Math.sqrt(1 - (a -= 2) * a) + 1)
};
TWEEN.Easing.Elastic.EaseIn = function(c) {
  var d, a = .1,
    b = .4;
  if (c == 0) return 0;
  if (c == 1) return 1;
  if (!b) b = .3;
  if (!a || a < 1) {
    a = 1;
    d = b / 4
  } else d = b / (2 * Math.PI) * Math.asin(1 / a);
  return -(a * Math.pow(2, 10 * (c -= 1)) * Math.sin((c - d) * (2 * Math.PI) / b))
};
TWEEN.Easing.Elastic.EaseOut = function(c) {
  var d, a = .1,
    b = .4;
  if (c == 0) return 0;
  if (c == 1) return 1;
  if (!b) b = .3;
  if (!a || a < 1) {
    a = 1;
    d = b / 4
  } else d = b / (2 * Math.PI) * Math.asin(1 / a);
  return a * Math.pow(2, -10 * c) * Math.sin((c - d) * (2 * Math.PI) / b) + 1
};
TWEEN.Easing.Elastic.EaseInOut = function(a) {
  var d, b = .1,
    c = .4;
  if (a == 0) return 0;
  if (a == 1) return 1;
  if (!c) c = .3;
  if (!b || b < 1) {
    b = 1;
    d = c / 4
  } else d = c / (2 * Math.PI) * Math.asin(1 / b);
  return (a *= 2) < 1 ? -.5 * (b * Math.pow(2, 10 * (a -= 1)) * Math.sin((a - d) * (2 * Math.PI) / c)) : b * Math.pow(2, -10 * (a -= 1)) * Math.sin((a - d) * (2 * Math.PI) / c) * .5 + 1
};
TWEEN.Easing.Back.EaseIn = function(a) {
  var b = 1.70158;
  return a * a * ((b + 1) * a - b)
};
TWEEN.Easing.Back.EaseOut = function(a) {
  var b = 1.70158;
  return (a = a - 1) * a * ((b + 1) * a + b) + 1
};
TWEEN.Easing.Back.EaseInOut = function(a) {
  var b = 1.70158 * 1.525;
  return (a *= 2) < 1 ? .5 * (a * a * ((b + 1) * a - b)) : .5 * ((a -= 2) * a * ((b + 1) * a + b) + 2)
};
TWEEN.Easing.Bounce.EaseIn = function(a) {
  return 1 - TWEEN.Easing.Bounce.EaseOut(1 - a)
};
TWEEN.Easing.Bounce.EaseOut = function(a) {
  return (a /= 1) < 1 / 2.75 ? 7.5625 * a * a : a < 2 / 2.75 ? 7.5625 * (a -= 1.5 / 2.75) * a + .75 : a < 2.5 / 2.75 ? 7.5625 * (a -= 2.25 / 2.75) * a + .9375 : 7.5625 * (a -= 2.625 / 2.75) * a + .984375
};
TWEEN.Easing.Bounce.EaseInOut = function(a) {
  return a < .5 ? TWEEN.Easing.Bounce.EaseIn(a * 2) * .5 : TWEEN.Easing.Bounce.EaseOut(a * 2 - 1) * .5 + .5
};
window.Aroma = {
  version: 2,
  author: "Averta group"
};
Aroma.Engine = function(a) {
  this._tweenList = [];
  this._view = a;
  this._view.engine = this;
  this.startEff = function() {
    this._effect.prepare();
    this._part_duration = this._duration / (this._selector.getCount() - (1 - this._overlapping) * (this._selector.getCount() - 1));
    this._part_delay = this._part_duration * this._overlapping;
    for (var e = [], c, b, h = 0, n = 0, f = [], j, g = null, i = 0, m = this._selector.getCount(); i < m; ++i) {
      e = this._selector.getPieceList();
      for (var d = 0, k = e.length; d < k; ++d) {
        f = this._effect.getToData();
        j = this._effect.getFromData();
        for (var a = 0, l = f.length; a < l; ++a) {
          b = CloneObject.clone(f[a].options);
          if (a == 0) if (b.delay == null) b.delay = this._part_delay + h + this._startDelay;
          else b.delay += this._part_delay + h + this._startDelay;
          this.applyFromProperties(e[d], j);
          c = (new TWEEN.Tween(e[d].proxy)).delay(b.delay * 1e3 || 0).to(f[a].to, this._part_duration * f[a].time * 1e3).easing(b.ease || TWEEN.Easing.Linear.EaseNone).onUpdate(e[d].proxyUpdate);
          a == 0 && c.start();
          g != null && g.chain(c);
          g = c;
          if (d + 1 == k && i + 1 == m && a + 1 == l) c.onComplete(this.effComp);
          this._tweenList.push(c)
        }
        g = null
      }
      h += this._part_delay
    }
    this._view.sort && this._view.sortParts();
    this._view.prepare()
  };
  this.applyFromProperties = function(a, b) {
    for (var c in b) a.proxy[c] = b[c];
    a.proxyUpdate.call(a.proxy)
  };
  this.effComp = function() {
    this.piece.view.engine.onComplete && this.piece.view.engine.onComplete.listener.call(this.piece.view.engine.onComplete.ref)
  }
};
Aroma.Engine.prototype.start = function(d, c, b, a, e) {
  this._selector = c;
  this._effect = d;
  this._duration = b;
  this._overlapping = a || .5;
  this._startDelay = e || 0;
  this._selector.setup(this._effect, this._view);
  this.startEff()
};
Aroma.Engine.prototype.reset = function() {
  this._selector = null;
  this._effect = null;
  this._duration = 0;
  this._overlapping = 0;
  this._startDelay = 0;
  this._tweenList = []
};
Aroma.Engine.prototype.removeTweens = function() {
  for (var a = 0, b = this._tweenList.length; a < b; a++) {
    TWEEN.remove(this._tweenList[a]);
    this._tweenList[a] = null
  }
};
Aroma.Engine.prototype.getView = function() {
  return this._view
};
Aroma.AbstractView = function(b, a) {
  this.sort = false;
  this.col = a;
  this.row = b;
  this.part_width = 0;
  this.part_height = 0;
  this._pieceList = [];
  this.width = 0;
  this.height = 0;
  this.vpWidth = 0;
  this.vpHeight = 0;
  this.needRendering = false;
  this.extra_part_width = 0, this.extra_part_height = 0;
  this.posToID = function(a, b) {
    return b * this.col + a
  };
  this.getPieceBounds = function(b, c) {
    var a = {
      width: 0,
      height: 0,
      x: 0,
      y: 0
    };
    if (this.extra_part_width == 0) {
      a.x = b * this.part_width;
      a.width = this.part_width
    } else {
      a.width = b > this.extra_part_width ? this.part_width : this.part_width + 1;
      a.x = b > this.extra_part_width ? (this.part_width + 1) * this.extra_part_width + (b - this.extra_part_width) * this.part_width : (this.part_width + 1) * b
    }
    if (this.extra_part_height == 0) {
      a.y = c * this.part_height;
      a.height = this.part_height
    } else {
      a.height = c > this.extra_part_height ? this.part_height : this.part_height + 1;
      a.y = c > this.extra_part_height ? (this.part_height + 1) * this.extra_part_height + (c - this.extra_part_height) * this.part_height : (this.part_height + 1) * c
    }
    return a
  };
  this.swapchildren_col = function(b, c) {
    for (var a = 0, e = (c - b) / 2; a < e; ++a) {
      var d = this._pieceList[b + a];
      this._pieceList[b + a] = this._pieceList[c - a];
      this._pieceList[c - a] = d
    }
  };
  this.swapchildren_row = function(b) {
    for (var a = 0, c = b.length; a < c / 2; ++a) {
      var d = this._pieceList[b[a]];
      this._pieceList[b[a]] = this._pieceList[b[c - a - 1]];
      this._pieceList[b[c - a - 1]] = d
    }
  };
  this.sortInCols = function() {
    if (this.col == 1) return;
    for (var b = Math.floor(this.col >> 1), c = this._pieceList.length, a = b; a < c; a += this.col) this.swapchildren_col(a, a + (this.col - b) - 1)
  };
  this.sortInRows = function() {
    if (this.row == 1) return;
    for (var d = Math.floor(this.row >> 1), a = [], b = 0; b < this.col; ++b) {
      for (var c = 0; c < this.row - d; ++c) a.push(d * this.col + b + c * this.col);
      this.swapchildren_row(a);
      a = []
    }
  }
};
Aroma.AbstractView.prototype.getCount = function() {
  return this.row * this.col
};
Aroma.AbstractView.prototype.prepare = function() {};
Aroma.AbstractView.prototype.setSize = function(b, a) {
  this.part_height = Math.floor(a / this.row);
  this.extra_part_height = a % this.row;
  this.part_width = Math.floor(b / this.col);
  this.extra_part_width = b % this.col;
  this.width = b;
  this.height = a
};
Aroma.AbstractView.prototype.setViewPortSize = function(b, a) {
  this.vpWidth = b;
  this.vpHeight = a
};
Aroma.AbstractView.prototype.dispose = function() {
  for (var a = 0, b = this._pieceList.length; a < b; ++a) {
    this._pieceList[a] && this._pieceList[a].dispose();
    this._pieceList[a] = null
  }
  this._pieceList = []
};
Aroma.AbstractView.prototype.sortParts = function() {
  this.sortInCols();
  this.sortInRows()
};
window.CloneObject = window.ConcatObject || {};
CloneObject.clone = function(a) {
  if (a == null) return {};
  var b = {};
  for (var c in a) b[c] = a[c];
  return b
};
ConcatObject = {};
ConcatObject.concat = function(c, a) {
  for (var b in a) c[b] = a[b];
  return c
};
window.setOpacity = function(a, b) {
  a.style.filter = "alpha(opacity=" + b + ")";
  a.style.opacity = b * .01;
  a.style.MozOpacity = b * .01;
  a.style.KhtmlOpacity = b * .01;
  a.style.MSOpacity = b * .01
};
Aroma.AbstractSelector = function() {
  this.selectNum = 1
};
Aroma.AbstractSelector.prototype.getCount = function() {
  return Math.floor(this.view.getCount() / this.selectNum)
};
Aroma.AbstractSelector.prototype.setup = function(a, b) {
  this.effect = a;
  this.view = b;
  a.selector = this;
  a.view = b
};
Aroma.AbstractSelector.prototype.reset = function() {};
Aroma.SerialSelector = function(c, b, a) {
  this.row = 0;
  this.col = 0;
  this.row_len = 0;
  this.col_len = 0;
  this.selectNum = a || 1;
  this.zigzag = b;
  this.dir = c || "tlr";
  this.convertPoint = function(b, a) {
    switch (this.dir) {
    case "tlr":
      return {
        row: b,
        col: a
      };
      break;
    case "tld":
      return {
        row: a,
        col: b
      };
      break;
    case "trl":
      return {
        row: b,
        col: this.col_len - a - 1
      };
      break;
    case "trd":
      return {
        row: a,
        col: this.row_len - b - 1
      };
      break;
    case "brl":
      return {
        row: this.row_len - b - 1,
        col: this.col_len - a - 1
      };
      break;
    case "bru":
      return {
        row: this.col_len - a - 1,
        col: this.row_len - b - 1
      };
      break;
    case "blr":
      return {
        row: row_len - b - 1,
        col: a
      };
      break;
    case "blu":
      return {
        row: this.col_len - a - 1,
        col: b
      }
    }
    return {
      row: b,
      col: a
    }
  }
};
Aroma.SerialSelector.prototype = new Aroma.AbstractSelector;
Aroma.SerialSelector.prototype.constructor = Aroma.SerialSelector;
Aroma.SerialSelector.prototype.getPieceList = function() {
  var b = [],
    a = {};
  if (this.dir.charAt(2) == "u" || this.dir.charAt(2) == "d") {
    this.col_len = this.view.row;
    this.row_len = this.view.col
  } else {
    this.col_len = this.view.col;
    this.row_len = this.view.row
  }
  for (var c = 0; c < this.selectNum; c++) {
    a = this.convertPoint(this.row, this.zigzag && this.row % 2 != 0 ? this.col_len - this.col - 1 : this.col);
    b.push(this.view.getPieceAt(a.col, a.row, this.effect));
    this.col++;
    if (this.col == this.col_len) {
      this.col = 0;
      this.row++
    }
  }
  return b
};
Aroma.SerialSelector.prototype.reset = function() {
  this.row = 0;
  this.col = 0
};
Aroma.DiagonalSelector = function(f, h) {
  this.selectNum = h || 1;
  this.startPoint = f || "tl";
  var b = 0,
    a = 0,
    d = 0,
    g = 0,
    e = 0,
    c = true;
  this.getList = function() {
    for (var g = [], f = 0; f < this.selectNum; f++) {
      switch (this.startPoint) {
      case "tl":
        if (c) c = false;
        else if (a != 0 && b != this.view.row - 1) {
          a--;
          b++
        } else {
          a = ++d;
          if (a > this.view.col - 1) {
            b = ++e;
            a = this.view.col - 1
          } else b = 0
        }
        break;
      case "tr":
        if (c) {
          c = false;
          a = this.view.col - 1
        } else if (a != this.view.col - 1 && b != this.view.row - 1) {
          a++;
          b++
        } else {
          a = this.view.col - 1 - ++d;
          if (a < 0) {
            b = ++e;
            a = 0
          } else b = 0
        }
        break;
      case "bl":
        if (c) {
          c = false;
          b = this.view.row - 1
        } else if (a != 0 && b != 0) {
          a--;
          b--
        } else {
          a = ++d;
          if (a > this.view.col - 1) {
            b = this.view.row - 1 - ++e;
            a = this.view.col - 1
          } else b = this.view.row - 1
        }
        break;
      case "br":
        if (c) {
          c = false;
          b = this.view.row - 1;
          a = this.view.col - 1
        } else if (a != this.view.col - 1 && b != 0) {
          a++;
          b--
        } else {
          a = this.view.col - 1 - ++d;
          if (a < 0) {
            b = this.view.row - 1 - ++e;
            a = 0
          } else b = this.view.row - 1
        }
      }
      g[f] = this.view.getPieceAt(a, b, this.effect)
    }
    return g
  };
  this._reset = function() {
    b = 0, a = 0, d = 0, g = 0, e = 0, c = true
  }
};
Aroma.DiagonalSelector.prototype = new Aroma.AbstractSelector;
Aroma.DiagonalSelector.prototype.constructor = Aroma.DiagonalSelector;
Aroma.DiagonalSelector.TOP_LEFT = "tl";
Aroma.DiagonalSelector.BOTTOM_LEFT = "bl";
Aroma.DiagonalSelector.TOP_RIGHT = "tr";
Aroma.DiagonalSelector.BOTTOM_RIGHT = "br";
Aroma.DiagonalSelector.prototype.getPieceList = function() {
  return this.getList()
};
Aroma.DiagonalSelector.prototype.reset = function() {
  return this._reset()
};
Aroma.RandSelector = function(a) {
  this.selectNum = a || 1;
  this.id_rand_list = [];
  this.shuffle = function(a) {
    var b = Math.floor(Math.random() * a.length),
      c = a[b];
    a.splice(b, 1);
    return c
  }
};
Aroma.RandSelector.prototype = new Aroma.AbstractSelector;
Aroma.RandSelector.prototype.constructor = Aroma.RandSelector;
Aroma.RandSelector.prototype.setup = function(c, b) {
  Aroma.AbstractSelector.prototype.setup.call(this, c, b);
  for (var a = 0, d = b.col * b.row; a < d; ++a) this.id_rand_list[a] = a
};
Aroma.RandSelector.prototype.getPieceList = function() {
  for (var c = [], a = 0, b = 0; b < this.selectNum; ++b) {
    a = this.shuffle(this.id_rand_list);
    c[b] = this.view.getPieceAt(Math.floor(a / this.view.row), a % this.view.row, this.effect)
  }
  return c
};
Aroma.Piece = function() {
  this.col = 0;
  this.row = 0;
  this.bounds = {};
  this.origin_x = 0;
  this.origin_y = 0;
  this.origin_z = 0;
  this.options = {}
};
Aroma.Effect = function() {
  this.pieceOptions = {};
  this.isStatic = false
};
Aroma.Effect.prototype.addFrame = function(b, c, a) {
  this.data.push({
    time: b,
    to: c,
    options: a
  })
};
Aroma.Effect.prototype.getToData = function() {
  if (this.data != null && this.isStatic) return this.data;
  this.data = [];
  this.getTo();
  return this.data
};
Aroma.Effect.prototype.getFromData = function() {
  if (this.fromData != null && this.isStatic) return this.fromData;
  else if (this.isStatic) {
    this.fromData = this.getFrom();
    return this.fromData
  } else return this.getFrom()
};
Aroma.Effect.prototype.prepare = function() {};
Aroma.Effect.prototype.getPieceOptions = function() {
  return this.pieceOptions
};

function UAParser(c) {
  var a = c || window.navigator.userAgent,
    b = function(j) {
      for (var c, g, a, d, f = 1; f < arguments.length; f += 2) {
        var i = arguments[f],
          b = arguments[f + 1],
          h = false;
        for (g = 0; g < i.length; g++) {
          var e = i[g].exec(j);
          if ( !! e) {
            c = {};
            d = 1;
            for (a = 0; a < b.length; a++) if (typeof b[a] === "object" && b[a].length === 2) {
              c[b[a][0]] = b[a][1];
              d -= 1
            } else if (typeof b[a] === "object" && b[a].length === 3) c[b[a][0]] = !! e[a + d] ? e[a + d].replace(b[a][1], b[a][2]) : undefined;
            else c[b[a]] = !! e[a + d] ? e[a + d] : undefined;
            h = true;
            break
          }
        }
        if (!h) {
          c = {};
          for (a in b) if (b.hasOwnProperty(a)) if (typeof b[a] == "object") c[b[a][0]] = undefined;
          else c[b[a]] = undefined
        } else return c
      }
      return c
    },
    d = {
      os: {
        win: function(b, a) {
          switch (a.toLowerCase()) {
          case "nt 5.0":
            return "2000";
          case "nt 5.1":
          case "nt 5.2":
            return "XP";
          case "nt 6.0":
            return "Vista";
          case "nt 6.1":
            return "7";
          case "nt 6.2":
            return "8";
          default:
            return a
          }
        }
      }
    };
  this.getBrowser = function(c) {
    return b(c || a, [/(kindle)\/((\d+)?[\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine)[\/\s]?((\d+)?[\w\.]+)/i, /(opera\smini)\/((\d+)?[\w\.-]+)/i, /(opera\smobi)\/((\d+)?[\w\.-]+)/i, /(opera).*\/((\d+)?[\w\.]+)/i, /(avant\sbrowser|iemobile|slimbrowser)[\/\s]?((\d+)?[\w\.]*)/i, /ms(ie)\s((\d+)?[\w\.]+)/i, /(chromium|flock|rockmelt|midori|epiphany)\/((\d+)?[\w\.]+)/i, /(chrome|omniweb|arora|dolfin)\/((\d+)?[\w\.]+)/i], ["name", "version", "major"], [/android.+crmo\/((\d+)?[\w\.]+)/i], [
      ["name", "Chrome"], "version", "major"], [/(mobile\ssafari|safari|konqueror)\/((\d+)?[\w\.]+)/i, /(applewebkit|khtml)\/((\d+)?[\w\.]+)/i, /(iceweasel|camino|fennec|maemo|minimo)[\/\s]?((\d+)?[\w\.\+]+)/i, /(firefox|seamonkey|netscape|navigator|k-meleon|icecat|iceape)\/((\d+)?[\w\.]+)/i, /(mozilla)\/([\w\.]+).+rv\:.+gecko\/\d+/i, /(lynx|dillo|icab)[\/\s]?((\d+)?[\w\.]+)/i], ["name", "version", "major"])
  };
  this.getEngine = function(c) {
    return b(c || a, [/(presto)\/([\w\.]+)/i, /([aple]*webkit|trident)\/([\w\.]+)/i, /(khtml)\/([\w\.]+)/i], ["name", "version"], [/rv\:([\w\.]+).*(gecko)/i], ["version", "name"])
  };
  this.getOS = function(c) {
    return b(c || a, [/(windows\sphone\sos|windows)\s+([\w\.\s]+)*/i], ["name", ["version", /(nt\s[\d\.]+)/gi, d.os.win]], [/(blackberry).+version\/([\w\.]+)/i, /(android|symbianos|symbos|webos|palm\os|qnx|bada|rim\stablet\sos)[\/\s-]?([\w\.]+)*/i, /(nintendo|playstation)\s([wids3portable]+)/i, /(mint)[\/\s\(]?(\w+)*/i, /(joli|[kxln]?ubuntu|debian|[open]*suse|gentoo|arch|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk)[\/\s-]?([\w\.-]+)*/i, /(gnu|linux)\s?([\w\.]+)*/i], ["name", "version"], [/cros\s([\w\.\s]+)/i], [
      ["name", "Chromium OS"], "version"], [/sunos\s?([\w\.\s]+)*/i], [
      ["name", "Solaris"], "version"], [/\s(\w*bsd|dragonfly)\s?([\w\.]+)*/i], ["name", "version"], [/(ip[honead]+).*os\s*([\w]+)*\slike\smac/i], [
      ["name", /.+/g, "iOS"],
      ["version", /_/g, "."]
    ], [/(mac\sos)\sx\s([\w\s\.]+)/i], ["name", ["version", /_/g, "."]], [/(macintosh|unix|minix|beos)[\/\s]?()*/i], ["name", "version"])
  };
  this.getDevice = function(c) {
    return b(c || a, [/\((ip[honead]+|playbook);/i, /(blackberry)[\s-]?(\w+)/i, /(blackberry|benq|nokia|palm(?=\-)|sonyericsson)[\s-]?([\w-]+)*/i, /(hp)\s([\w\s]+)/i, /(hp).+(touchpad)/i, /(kindle)\/([\w\.]+)/i, /(lg)[e;\s-]+(\w+)*/i, /(nintendo|playstation)\s([wids3portable]+)/i], ["name", "version"], [/(htc)[;_\s-]+([\w\s]+(?=\))|[\w]+)*/i, /(zte)-([\w]+)*/i], ["name", ["version", /_/g, " "]], [/\s(milestone|mz601|droid[2x]?|xoom)[globa\s]*\sbuild\//i, /mot[\s-]?(\w+)*/i], [
      ["name", "Motorola"], "version"], [/(s[cgp]h-\w+|gt-\w+|galaxy\snexus)/i, /sam[sung]*[\s-]*(\w+-?[\w-]*)*/i, /sec-(sgh\w+)/i], [
      ["name", "Samsung"], "version"], [/sie-(\w+)*/i], [
      ["name", "Siemens"], "version"])
  };
  this.setUA = function(b) {
    a = b || a;
    return this.result = {
      browser: this.getBrowser(),
      engine: this.getEngine(),
      os: this.getOS(),
      device: this.getDevice()
    }
  };
  this.setUA(a)
}
window.Cute = {
  version: 1,
  name: "Cute Slider",
  author: "Averta group"
};
Cute.Effect1 = function(a) {
  Aroma.Effect.prototype.constructor.call(this);
  a = a || {};
  this.ease = a.ease || TWEEN.Easing.Linear;
  this.isStatic = true
};
Cute.Effect1.prototype = new Aroma.Effect;
Cute.Effect1.prototype.constructor = Cute.Effect1;
Cute.Effect1.prototype.getToVars = function() {
  this.addFrame(1, {
    opacity: 100
  }, {
    ease: this.ease.EaseOut
  })
};
Cute.Effect1.prototype.getFromVars = function() {
  return {
    opacity: 0,
    slide: 100
  }
};
Cute.Effect1.prototype.prepare = function() {
  this.getFrom = this.getFrom || this.getFromVars;
  this.getTo = this.getTo || this.getToVars
};
Cute.Effect2 = function(a) {
  Aroma.Effect.prototype.constructor.call(this);
  a = a || {};
  this.pieceOptions.dir = a.dir || "r";
  this.pieceOptions.push = a.push;
  this.ease = a.ease || TWEEN.Easing.Linear;
  this.fade = a.fade;
  this.isStatic = true
};
Cute.Effect2.prototype = new Aroma.Effect;
Cute.Effect2.prototype.constructor = Cute.Effect2;
Cute.Effect2.prototype.getToVars = function() {
  this.addFrame(1, this.fade ? {
    opacity: 100,
    slide: 100
  } : {
    slide: 100
  }, {
    ease: this.ease.EaseOut
  })
};
Cute.Effect2.prototype.getFromVars = function() {
  return this.fade ? {
    opacity: 0,
    slide: 0
  } : {
    slide: 0
  }
};
Cute.Effect2.prototype.prepare = function() {
  this.getFrom = this.getFrom || this.getFromVars;
  this.getTo = this.getTo || this.getToVars
};
Cute.Effect3 = function(a) {
  Cute.Effect2.prototype.constructor.call(this, a);
  this.dir_name_arr = ["r", "l", "t", "b"]
};
Cute.Effect3.prototype = new Cute.Effect2;
Cute.Effect3.prototype.constructor = Cute.Effect3;
Cute.Effect3.prototype.getPieceOptions = function() {
  this.pieceOptions.dir = this.dir_name_arr[Math.round(parseInt(Math.random() * 3))];
  return this.pieceOptions
};
Cute.Effect4 = function(a) {
  Cute.Effect3.prototype.constructor.call(this, a);
  this.counter = 0;
  this.rotation_dir = a.dir || "vertical"
};
Cute.Effect4.prototype = new Cute.Effect3;
Cute.Effect4.prototype.constructor = Cute.Effect4;
Cute.Effect4.prototype.getPieceOptions = function() {
  this.pieceOptions.dir = this.dir_name_arr[(this.counter++ % 2 ? 0 : 1) + (this.rotation_dir == "vertical" ? 2 : 0)];
  return this.pieceOptions
};
Cute.Effect5 = function(a) {
  Aroma.Effect.prototype.constructor.call(this);
  a = a || {};
  this.side = a.side || "r";
  this.zmove = a.zmove || 0;
  this.rotation_axis = "y";
  this.rotation_dir = 1;
  this.xspace = a.xspace || 0;
  this.yspace = a.yspace || 0;
  this.stack = a.stack || false;
  this.balance = a.blance || .5;
  this.ease = a.ease || TWEEN.Easing.Linear;
  this.isStatic = false
};
Cute.Effect5.prototype = new Aroma.Effect;
Cute.Effect5.prototype.constructor = Cute.Effect5;
Cute.Effect5.prototype.createFrames = function(c, a) {
  if (!this.stack) {
    c.z = this.zmove;
    a.z = 0;
    c.x = (this.piece.col - Math.floor(this.view.col * .5)) * this.xspace;
    c.y = (this.piece.row - Math.floor(this.view.row * .5)) * this.yspace;
    a.y = a.x = 0;
    this.addFrame(.5, a, {
      ease: this.ease.EaseOut
    })
  } else {
    var b = {};
    b.x = (this.piece.col - Math.floor(this.view.col * .5)) * this.xspace;
    b.y = (this.piece.row - Math.floor(this.view.row * .5)) * this.yspace;
    b.z = this.zmove;
    this.addFrame(this.balance * .5, b, {
      ease: this.ease.EaseInOut
    });
    this.addFrame(1 - this.balance, a, {
      ease: this.ease.EaseInOut
    });
    this.addFrame(this.balance * .5, {
      z: 0,
      x: 0,
      y: 0
    }, {
      ease: this.ease.EaseInOut
    })
  }
};
Cute.Effect5.prototype.getToVars = function() {
  var a = {},
    b = {};
  if (this.rotation_axis == "y") {
    a.rotationY = 45 * this.rotation_dir;
    b.rotationY = 90 * this.rotation_dir
  } else {
    a.rotationX = 45 * this.rotation_dir;
    b.rotationX = 90 * this.rotation_dir
  }
  this.createFrames(a, b)
};
Cute.Effect5.prototype.getFromVars = function() {
  return {}
};
Cute.Effect5.prototype.checkSidePos = function() {
  switch (this.side) {
  case "r":
    this.pieceOptions.newImageLocation = this.piece.side_dic.right;
    this.pieceOptions.depth = this.piece.bounds.width;
    this.rotation_axis = "y";
    this.rotation_dir = 1;
    break;
  case "l":
    this.pieceOptions.newImageLocation = this.piece.side_dic.left;
    this.pieceOptions.depth = this.piece.bounds.width;
    this.rotation_axis = "y";
    this.rotation_dir = -1;
    break;
  case "t":
    this.pieceOptions.newImageLocation = this.piece.side_dic.top;
    this.pieceOptions.depth = this.piece.bounds.height;
    this.rotation_axis = "x";
    this.rotation_dir = 1;
    break;
  case "b":
    this.pieceOptions.newImageLocation = this.piece.side_dic.bottom;
    this.pieceOptions.depth = this.piece.bounds.height;
    this.rotation_axis = "x";
    this.rotation_dir = -1
  }
};
Cute.Effect5.prototype.prepare = function() {
  this.getFrom = this.getFrom || this.getFromVars;
  this.getTo = this.getTo || this.getToVars
};
Cute.Effect5.prototype.getPieceOptions = function() {
  this.checkSidePos();
  return this.pieceOptions
};
Cute.Effect6 = function(a) {
  Cute.Effect5.prototype.constructor.call(this, a);
  this.slide_name_arr = ["l", "r", "b", "t"]
};
Cute.Effect6.prototype = new Cute.Effect5;
Cute.Effect6.prototype.constructor = Cute.Effect6;
Cute.Effect6.prototype.getPieceOptions = function() {
  this.side = this.slide_name_arr[Math.round(parseInt(Math.random() * 3))];
  this.checkSidePos();
  return this.pieceOptions
};
Cute.Effect7 = function(a) {
  Cute.Effect6.prototype.constructor.call(this, a);
  this.counter = 0;
  this._move = a.dir || "vertical"
};
Cute.Effect7.prototype = new Cute.Effect6;
Cute.Effect7.prototype.constructor = Cute.Effect7;
Cute.Effect7.prototype.getPieceOptions = function() {
  this.side = this.slide_name_arr[(this.counter++ % 2 ? 0 : 1) + (this._move == "vertical" ? 2 : 0)];
  this.checkSidePos();
  return this.pieceOptions
};
Cute.Effect8 = function(a) {
  a = a || {};
  Cute.Effect5.prototype.constructor.call(this, a);
  this.sideColor = a.sidecolor || 0;
  this.depth = a.depth || -1;
  this.dir = a.dir || "u";
  this.rotation_axis = "x";
  this.rotation_dir = 1
};
Cute.Effect8.prototype = new Cute.Effect5;
Cute.Effect8.prototype.constructor = Cute.Effect8;
Cute.Effect8.prototype.getToVars = function() {
  var a = {},
    b = {};
  if (this.rotation_axis == "y") {
    a.rotationY = 90 * this.rotation_dir;
    b.rotationY = 180 * this.rotation_dir
  } else {
    a.rotationX = 90 * this.rotation_dir;
    b.rotationX = 180 * this.rotation_dir
  }
  this.createFrames(a, b)
};
Cute.Effect8.prototype.updateConfig = function() {
  this.pieceOptions.sideColor = this.sideColor;
  this.pieceOptions.depth = this.depth <= 0 ? this.dir == "u" || this.dir == "d" ? this.piece.bounds.height : this.piece.bounds.width : this.depth;
  this.rotation_axis = this.dir == "u" || this.dir == "d" ? "x" : "y";
  this.rotation_dir = this.dir == "u" || this.dir == "r" ? 1 : -1;
  this.pieceOptions.flipX = this.pieceOptions.flipY = this.dir == "u" || this.dir == "d"
};
Cute.Effect8.prototype.getPieceOptions = function() {
  this.updateConfig();
  return this.pieceOptions
};
Cute.Effect9 = function(a) {
  Cute.Effect8.prototype.constructor.call(this, a);
  this.dir_name_arr = ["l", "r", "u", "d"]
};
Cute.Effect9.prototype = new Cute.Effect8;
Cute.Effect9.prototype.constructor = Cute.Effect9;
Cute.Effect9.prototype.getPieceOptions = function() {
  this.dir = this.dir_name_arr[Math.round(parseInt(Math.random() * 3))];
  this.updateConfig();
  return this.pieceOptions
};
Cute.Effect10 = function(a) {
  Cute.Effect9.prototype.constructor.call(this, a);
  this.counter = 0;
  this._move = a.dir || "vertical"
};
Cute.Effect10.prototype = new Cute.Effect9;
Cute.Effect10.prototype.constructor = Cute.Effect10;
Cute.Effect10.prototype.getPieceOptions = function() {
  this.dir = this.dir_name_arr[(this.counter++ % 2 ? 0 : 1) + (this._move == "vertical" ? 2 : 0)];
  this.updateConfig();
  return this.pieceOptions
};
Cute.Effect11 = function(a) {
  Cute.Effect8.call(this, a);
  a = a || {};
  this.rotation_x = 0;
  this.rotation_y = 0;
  this.dir = a.dir || "tr";
  this.pieceOptions.flipX = this.pieceOptions.flipY = true
};
Cute.Effect11.prototype = new Cute.Effect8;
Cute.Effect11.prototype.constructor = Cute.Effect11;
Cute.Effect11.prototype.getToVars = function() {
  var a = {},
    b = {};
  if (this.rotation_x != 0) {
    a.rotationX = 90 * this.rotation_x;
    b.rotationX = 180 * this.rotation_x
  }
  if (this.rotation_y != 0) {
    a.rotationY = 180 * this.rotation_y;
    b.rotationY = 360 * this.rotation_y
  }
  this.createFrames(a, b)
};
Cute.Effect11.prototype.updateConfig = function() {
  this.pieceOptions.sideColor = this.sideColor;
  this.pieceOptions.depth = this.depth <= 0 ? 10 : this.depth;
  switch (this.dir.charAt(0)) {
  case "t":
    this.rotation_x = -1;
    break;
  case "b":
    this.rotation_x = 1
  }
  switch (this.dir.charAt(1)) {
  case "r":
    this.rotation_y = -1;
    break;
  case "l":
    this.rotation_y = 1
  }
};
Cute.Effect12 = function(a) {
  Cute.Effect11.prototype.constructor.call(this, a);
  this.dir_name_arr = ["tl", "tr", "bl", "br"]
};
Cute.Effect12.prototype = new Cute.Effect11;
Cute.Effect12.prototype.constructor = Cute.Effect12;
Cute.Effect12.prototype.getPieceOptions = function() {
  this.dir = this.dir_name_arr[Math.round(parseInt(Math.random() * 3))];
  this.updateConfig();
  return this.pieceOptions
};
(function() {
  window.resizeListeners = [];
  if (window.addEventListener) window.addEventListener("resize", a);
  else window.attachEvent && window.attachEvent("onresize", a);

  function a() {
    for (var a = 0, b = window.resizeListeners.length; a < b; ++a) window.resizeListeners[a].listener.call(window.resizeListeners[a].ref)
  }
  window.addResizeListener = function(a, b) {
    window.resizeListeners.push({
      listener: a,
      ref: b
    })
  };
  window.removeResizeListener = function(b, c) {
    for (var a = 0; a < window.resizeListeners.length; ++a) window.resizeListeners[a].listener == b && window.resizeListeners[a].ref == c && window.resizeListeners.splice(a, 1)
  }
})();
Averta = {};
Averta.Timer = function(b, a) {
  this.delay = b;
  this.currentCount = 0;
  this.paused = false;
  this.onTimer = null;
  this.refrence = null;
  a && this.start()
};
Averta.Timer.prototype = {
  constructor: Averta.Timer,
  start: function() {
    this.paused = false;
    this.lastTime = Date.now()
  },
  stop: function() {
    this.paused = true
  },
  reset: function() {
    this.currentCount = 0;
    this.paused = true;
    this.lastTime = Date.now()
  },
  update: function() {
    if (this.paused || Date.now() - this.lastTime < this.delay) return;
    this.currentCount++;
    this.lastTime = Date.now();
    this.onTimer && this.onTimer.call(this.refrence, this.getTime())
  },
  getTime: function() {
    return this.delay * this.currentCount
  }
};
for (var lastTime = 0, vendors = ["ms", "moz", "webkit", "o"], x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
  window.requestAnimationFrame = window[vendors[x] + "RequestAnimationFrame"];
  window.cancelAnimationFrame = window[vendors[x] + "CancelAnimationFrame"] || window[vendors[x] + "CancelRequestAnimationFrame"]
}
if (!window.requestAnimationFrame) window.requestAnimationFrame = function(c) {
  var b = (new Date).getTime(),
    a = Math.max(0, 16 - (b - lastTime)),
    d = window.setTimeout(function() {
      c(b + a)
    }, a);
  lastTime = b + a;
  return d
};
if (!window.cancelAnimationFrame) window.cancelAnimationFrame = function(a) {
  clearTimeout(a)
};
Cute.Ticker = Cute.Ticker || {
  list: [],
  __stoped: true,
  add: function(a, b) {
    Cute.Ticker.list.push([a, b]);
    return Cute.Ticker.list.length
  },
  remove: function(b, c) {
    for (var a = 0, d = Cute.Ticker.list.length; a < d; ++a) Cute.Ticker.list[a] && Cute.Ticker.list[a][0] == b && Cute.Ticker.list[a][1] == c && Cute.Ticker.list.splice(a, 1)
  },
  start: function() {
    if (!Cute.Ticker.__stoped) return;
    Cute.Ticker.__stoped = false;
    Cute.Ticker.__tick()
  },
  stop: function() {
    Cute.Ticker.__stoped = true
  },
  __tick: function() {
    if (Cute.Ticker.__stoped) return;
    for (var a = 0; a < Cute.Ticker.list.length; ++a) Cute.Ticker.list[a][0].call(Cute.Ticker.list[a][1]);
    requestAnimationFrame(Cute.Ticker.__tick)
  }
};
Cute.FallBack = function() {};
Cute.FallBack.CANVAS = "canvas";
Cute.FallBack.CSS3D = "css3d";
Cute.FallBack.DOM2D = "dom2d";
Cute.FallBack.ua = (new UAParser).result;
Cute.FallBack.prototype = {
  force: null,
  __result: null,
  getType: function() {
    if (this.__result) return this.__result;
    if (this.force) {
      switch (this.force.toLowerCase()) {
      case "2d":
        this.__result = Cute.FallBack.DOM2D;
        break;
      case "canvas":
        this.__result = Cute.FallBack.CANVAS;
        break;
      case "css":
        this.__result = Cute.FallBack.CSS3D
      }
      if (this.__result) return this.__result
    }
    var c = Cute.FallBack.ua,
      a = Cute.FallBack.DOM2D,
      e = c.os.name.toLowerCase(),
      d = false;
    if (c.browser.name != undefined) {
      var b = c.browser.name.toLowerCase()
    } else {
      var b = 'ie'
    }
    switch (e) {
    case "windows":
    case "mac os":
    case "linux":
    case "ubuntu":
      if (b == "chrome" || b == "safari" || b == "chromium" || c.engine.name == "AppleWebKit") a = Cute.FallBack.CSS3D;
      else if (b == "ie" && parseInt(c.browser.major) >= 9 || b == "firefox" || b == "opera" || c.browser.name == undefined) a = Cute.FallBack.CANVAS;
      break;
    case "ios":
      a = Cute.FallBack.CSS3D;
      break;
    case "android":
      if (parseInt(c.os.version.charAt(0)) >= 4) a = Cute.FallBack.CSS3D;
      break;
    case "windows phone os":
      a = Cute.FallBack.DOM2D;
      break;
    default:
      d = true
    }
    if (window.Modernizr) if (a == Cute.FallBack.CANVAS && !Modernizr.canvas) a = Cute.FallBack.DOM2D;
    else if (a == Cute.FallBack.CSS3D && !Modernizr.csstransforms3d) a = Cute.FallBack.DOM2D;
    else if (d) if (Modernizr.csstransforms3d) a = Cute.FallBack.CSS3D;
    else if (Modernizr.canvas) a = Cute.FallBack.CANVAS;
    this.__result = a;
    return a
  }
};
Cute.FallBack.isIE = Cute.FallBack.ua.browser.name == "IE";
Cute.FallBack.isIE7 = Cute.FallBack.isIE && Cute.FallBack.ua.browser.major == 7;
Cute.FallBack.isIE8 = Cute.FallBack.isIE && Cute.FallBack.ua.browser.major == 8;
Cute.FallBack.isMobileDevice = Cute.FallBack.ua.os.name.toLowerCase() == "android" || Cute.FallBack.ua.os.name.toLowerCase() == "ios" || Cute.FallBack.ua.os.name.toLowerCase() == "windows phone os", function() {
  if (Cute.FallBack.ua.browser.name == "IE" && parseInt(Cute.FallBack.ua.browser.major) < 9) {
    Date.now = function() {
      return (new Date).getTime()
    };
    Array.prototype.indexOf = function(b) {
      for (var a = 0, c = this.length; a < c; ++a) if (this[a] == b) return a;
      return -1
    }
  }
}();
Cute.ModuleLoader = function(a) {
  this.fallBack = a
};
Cute.ModuleLoader.loadedModules = {
  css3d: false,
  canvas: false,
  dom2d: false
};
Cute.ModuleLoader.dom2d_files = ["./assets/js/home/cube2.js"];
Cute.ModuleLoader.canvas_files = ["./assets/js/home/cube3.js"];
Cute.ModuleLoader.css3d_files = ["./assets/js/home/cube4.js"];
Cute.ModuleLoader.prototype = {
  onComplete: null,
  loadModule: function() {
    var b = this.fallBack.getType();
    if (Cute.ModuleLoader.loadedModules[b]) {
      if (this.onComplete) {
        Cute.ModuleLoader.loadedModules[b] = true;
        this.onComplete.listener.call(this.onComplete.ref)
      }
      return
    }
    var a = [];
    switch (b) {
    case Cute.FallBack.CSS3D:
      a = Cute.ModuleLoader.css3d_files;
      break;
    case Cute.FallBack.CANVAS:
      a = Cute.ModuleLoader.canvas_files;
      break;
    case Cute.FallBack.DOM2D:
      a = Cute.ModuleLoader.dom2d_files
    }
    var c = this;
    yepnope({
      load: a,
      complete: function() {
        if (c.onComplete) {
          Cute.ModuleLoader.loadedModules[b] = true;
          c.onComplete.listener.call(c.onComplete.ref)
        }
      }
    })
  }
};
window.Averta = window.Averta || {};
Averta.EventDispatcher = function() {
  this.listeners = {}
};
Averta.EventDispatcher.extend = function(c) {
  var b = new Averta.EventDispatcher;
  for (var a in b) if (a != "constructor") c[a] = Averta.EventDispatcher.prototype[a]
};
Averta.EventDispatcher.prototype = {
  constructor: Averta.EventDispatcher,
  addEventListener: function(a, b, c) {
    if (!this.listeners[a]) this.listeners[a] = [];
    this.listeners[a].push({
      listener: b,
      ref: c
    })
  },
  removeEventListener: function(a, c, d) {
    if (this.listener[a.type]) {
      for (var b = 0, e = this.listeners[a].length; b < e; ++b) c == this.listeners[a][b].listener && d == this.listeners[a][b].ref && this.listeners[a].splice(b);
      if (this.listeners[a].length == 0) delete this.listeners[a]
    }
  },
  dispatchEvent: function(a) {
    a.target = this;
    if (this.listeners[a.type]) for (var b = 0, c = this.listeners[a.type].length; b < c; ++b) this.listeners[a.type][b].listener.call(this.listeners[a.type][b].ref, a)
  }
};
Cute.SliderEvent = function(a) {
  this.type = a
};
Cute.SliderEvent.CHANGE_START = "changeStart";
Cute.SliderEvent.CHANGE_END = "changeEnd";
Cute.SliderEvent.WATING = "wating";
Cute.SliderEvent.AUTOPLAY_CHANGE = "autoplayChange";
Cute.SliderEvent.CHANGE_NEXT_SLIDE = "changeNextSlide";
Cute.SliderEvent.WATING_FOR_NEXT = "watingForNextSlide";
window.Averta = window.Averta || {};
Averta.ScrollContainer = function(b, a) {
  this.element = b;
  this.scrollStartPosY = 0;
  this.scrollStartPosX = 0;
  this.content = a;
  this.lastX = 0;
  this.lastY = 0;
  this.moved = false;
  this.isTouch = function() {
    try {
      document.createEvent("TouchEvent");
      return true
    } catch (a) {
      return false
    }
  }
};
Averta.ScrollContainer.prototype = {
  constrcutor: Averta.ScrollContainer,
  setup: function() {
    if (Cute.FallBack.isIE8 || Cute.FallBack.isIE7) return;
    var a = this,
      b = this.isTouch();

    function c(c) {
      if (b) {
        a.scrollStartPosX = c.touches[0].pageX;
        a.scrollStartPosY = c.touches[0].pageY
      } else {
        a.scrollStartPosX = c.clientX;
        a.scrollStartPosY = c.clientY
      }
      a.mouseDown = true;
      a.moved = false;
      window.addEventListener && c.preventDefault()
    }
    function d(c) {
      if (!a.mouseDown) return;
      if (b) {
        var d = c.touches[0].pageX,
          e = c.touches[0].pageY;
        a.move(d - a.scrollStartPosX + a.lastX, e - a.scrollStartPosY + a.lastY);
        a.scrollStartPosX = d;
        a.scrollStartPosY = e
      } else {
        a.move(c.clientX - a.scrollStartPosX + a.lastX, c.clientY - a.scrollStartPosY + a.lastY);
        a.scrollStartPosX = c.clientX;
        a.scrollStartPosY = c.clientY
      }
      window.addEventListener && c.preventDefault()
    }
    function e(c) {
      if (!a.mouseDown) return;
      a.mouseDown = false;
      window.addEventListener && c.preventDefault();
      if (b) {
        document.removeEventListener("touchend", a.element, false);
        return
      }
      if (document.detachEvent) document.detachEvent("onmousemove", a.element);
      else document.removeEventListener("mousemove", a.element, false)
    }
    if (b) {
      this.element.addEventListener("touchstart", c);
      this.element.addEventListener("touchmove", d);
      return
    }
    if (window.addEventListener) {
      this.element.addEventListener("mousedown", c, false);
      document.addEventListener("mousemove", d, false);
      document.addEventListener("mouseup", e, false);
      return
    }
    this.element.attachEvent("onmousedown", c, false);
    document.attachEvent("onmousemove", d, false);
    document.attachEvent("onmouseup", e, false)
  },
  move: function(a, b) {
    this.moved = true;
    this.element.scrollTop = -b;
    this.element.scrollLeft = -a;
    this.lastX = -this.element.scrollLeft;
    this.lastY = -this.element.scrollTop
  },
  translate: function(a, b) {
    this.move(this.lastX + (a || 0), this.lastY + (b || 0))
  }
};
Cute.ItemList = function(e) {
  this.frame = document.createElement("div");
  this.frame.className = "il-frame";
  this.content = document.createElement("div");
  this.content.className = "il-content";
  this.type = "vertical";
  this.items = [];
  this.sc = new Averta.ScrollContainer(this.frame, this.content);
  var a = this,
    c = 0,
    b = false,
    d = this.sc.isTouch();
  this.__scrollnext = function(e) {
    b = true;
    c = 2;
    Cute.Ticker.add(a.__scrolling, a);
    d && e.preventDefault()
  };
  this.__scrollprev = function(e) {
    b = true;
    c = -2;
    Cute.Ticker.add(a.__scrolling, a);
    d && e.preventDefault()
  };
  this.__stopscroll = function(c) {
    if (!b) return;
    b = false;
    Cute.Ticker.remove(a.__scrolling, a);
    a.sc.moved = false;
    d && c.preventDefault()
  };
  this.__scrolling = function() {
    if (a.type == "vertical") a.sc.translate(0, c);
    else a.sc.translate(-c, 0)
  };
  this.upleft = document.createElement("div");
  this.upleft.onmousedown = this.__scrollprev;
  this.downright = document.createElement("div");
  this.downright.onmousedown = this.__scrollnext;
  document.onmouseup = this.__stopscroll;
  if (d) {
    this.upleft.addEventListener("touchstart", this.__scrollprev, false);
    this.downright.addEventListener("touchstart", this.__scrollnext, false);
    document.addEventListener("touchend", this.__stopscroll, false)
  }
  e.appendChild(this.frame);
  e.appendChild(this.downright);
  e.appendChild(this.upleft);
  this.frame.appendChild(this.content);
  this.addItem = function(a) {
    this.content.appendChild(a);
    this.items.push(a)
  }
};
Cute.Slide = function(a) {
  this.src = "";
  this.delay = 0;
  this.slider = a;
  this.ready = false;
  this._index = 0;
  this.autoPlay = true;
  this.pluginData = {};
  this.opacity = 100;
  this.domElement = document.createElement("div");
  this.domElement.style.width = "100%";
  this.domElement.style.height = "auto";
  this.domElement.style.overflow = "hidden";
  this.domElement.style.position = "absolute";
  this.domElement.style.zIndex = "1"
};
Cute.Slide.prototype = {
  constructor: Cute.Slide,
  loadContent: function() {
    if (this.src != null) {
      this.image = new Image;
      this.image.slide = this;
      this.image.onload = this.contentLoaded;
      this.image.src = this.src;
      this.image.style.width = "100%";
      this.image.style.height = "auto"
    } else {
      this.ready = true;
      this.onReady.listener.call(this.onReady.ref)
    }
  },
  killLoading: function() {
    this.image.onload = null
  },
  addContent: function(a) {
    this.domElement.appendChild(a);
    this.image = a;
    this.image.style.width = "100%";
    this.image.style.height = "auto";
    this.ready = true;
    this.onReady && this.onReady.listener.call(this.onReady.ref);
    this.prepareToShow();
    this.showIsDone()
  },
  showIsDone: function() {},
  hideIsDone: function() {},
  prepareToShow: function() {},
  prepareToHide: function() {},
  contentLoaded: function() {
    this.slide.domElement.appendChild(this);
    this.slide.ready = true;
    this.slide.onReady && this.slide.onReady.listener.call(this.slide.onReady.ref)
  },
  opacityUpdate: function() {
    setOpacity(this.domElement, this.opacity)
  }
};
Cute.SlideManager = function() {
  Averta.EventDispatcher.prototype.constructor.call(this);
  this.width = 0;
  this.height = 0;
  this._timer = new Averta.Timer(100);
  this._slideList = [];
  this._currentSlideIndex = 0;
  this._delayProgress = 0;
  this._autoPlay = true;
  this._status = "";
  this.domElement = document.createElement("div");
  this.domElement.style.position = "relative";
  this._timer.onTimer = this.onTimer;
  this._timer.refrence = this
};
Cute.SlideManager.prototype = {
  constructor: Cute.SlideManager,
  startTimer: function() {
    if (!this._autoPlay) return false;
    this._timer.start();
    return true
  },
  skipTimer: function() {
    this._timer.reset();
    this._delayProgress = 100;
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.WATING))
  },
  onTimer: function() {
    if (this._timer.getTime() >= this._currentSlide.delay * 1e3) {
      this._timer.stop();
      if (this._nextSlide.ready) this.showSlide(this._nextSlide);
      else this.waitForNext()
    }
    this._delayProgress = this._timer.getTime() / (this._currentSlide.delay * 10);
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.WATING))
  },
  prepareTransition: function(a) {
    return this.rotator.fallBack.getType() == Cute.FallBack.DOM2D ? a.transitions2D[parseInt(Math.random() * a.transitions2D.length)] : a.transitions3D[parseInt(Math.random() * a.transitions3D.length)]
  },
  showSlide: function(b) {
    var a = this.prepareTransition(b);
    this._oldSlide = this._currentSlide;
    this._currentSlide = b;
    this._oldSlide.prepareToHide();
    b.prepareToShow();
    this._view = new this._viewClass(a.row, a.col);
    this._view.setSize(this.width, this.height);
    this._view.setViewPortSize(this.vpWidth, this.vpHeight);
    this._view.oldSource = this._oldSlide.image;
    this._view.newSource = b.image;
    this._view.setup();
    this._view.needRendering && Cute.Ticker.add(this._view.render, this._view);
    this._engine = new Aroma.Engine(this._view);
    a.selector.reset();
    this._engine.start(a.effect, a.selector, a.duration, a.overlapping, .45);
    this._engine.onComplete = {
      ref: this,
      listener: this.transitionCl
    };
    this._replaceTween = (new TWEEN.Tween(this._oldSlide)).to({
      opacity: 0
    }, 450).onUpdate(this._oldSlide.opacityUpdate).start();
    this._replaceTween.slider = this;
    this.newSlide = b;
    this._replaceTween.onComplete(function() {
      this.slider.domElement.removeChild(this.domElement)
    });
    this.domElement.appendChild(this._view.viewport);
    this._view.viewport.style.position = "absolute";
    this._view.viewport.style.zIndex = "0";
    this._view.viewport.style.marginLeft = -(this.vpWidth - this.width) / 2 + "px";
    this._view.viewport.style.marginTop = -(this.vpHeight - this.height) / 2 + "px";
    this._currentSlideIndex = b.index;
    this._timer.reset();
    this._delayProgress = 0;
    this._status = "changing";
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.WATING));
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.CHANGE_START))
  },
  transitionCl: function() {
    this._engine.reset();
    this._currentSlide.opacity = 0;
    this.domElement.appendChild(this._currentSlide.domElement);
    this._replaceTween2 = (new TWEEN.Tween(this._currentSlide)).to({
      opacity: 100
    }, 450).onUpdate(this._currentSlide.opacityUpdate);
    TWEEN.add(this._replaceTween2);
    this._replaceTween2.start();
    this._replaceTween2.onComplete(function() {
      this.slider._view.needRendering && Cute.Ticker.remove(this.slider._view.render, this.slider._view);
      TWEEN.remove(this.slider._replaceTween2);
      this.slider.domElement.removeChild(this.slider._view.viewport);
      this.slider._view.dispose();
      this.slider._view = null;
      this.slider._currentSlide.showIsDone();
      this.slider._oldSlide.hideIsDone();
      this.slider._status = "wating";
      this.slider.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.CHANGE_END))
    });
    this._engine = null;
    this.startTimer();
    this.gotoSlide(this.getNextIndex())
  },
  readyToShow: function() {
    this._delayProgress == 100 && this.showSlide(this._nextSlide)
  },
  waitForNext: function() {
    this._status = "loading";
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.WATING_FOR_NEXT))
  },
  resize: function() {
    if (this._status == "changing") {
      if (this._engine) {
        this._engine.removeTweens();
        this._engine.reset()
      }
      if (this._view) {
        this._view.needRendering && Cute.Ticker.remove(this._view.render, this._view);
        this.domElement.removeChild(this._view.viewport);
        this._view.dispose();
        this._view = null;
        this._engine = null
      }
      if (this._replaceTween2) {
        this._replaceTween2.stop();
        TWEEN.remove(this._replaceTween2)
      }!this._currentSlide.domElement.parentElement && this.domElement.appendChild(this._currentSlide.domElement);
      this._currentSlide.opacity = 100;
      this._currentSlide.opacityUpdate();
      this._currentSlide.showIsDone();
      if (this._replaceTween) {
        this._replaceTween.stop();
        TWEEN.remove(this._replaceTween)
      }!this._oldSlide.domElement.parentElement && this.domElement.appendChild(this._oldSlide.domElement);
      this._oldSlide.opacity = 0;
      this._oldSlide.opacityUpdate();
      this._oldSlide.hideIsDone();
      this._status = "wating";
      this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.CHANGE_END));
      this.startTimer();
      this.gotoSlide(this.getNextIndex())
    }
  },
  getNextIndex: function() {
    return this._currentSlideIndex + 1 == this._slideList.length ? 0 : this._currentSlideIndex + 1
  },
  getPreviousIndex: function() {
    return this._currentSlideIndex - 1 == -1 ? this._slideList.length - 1 : this._currentSlideIndex - 1
  },
  gotoSlide: function(a, b) {
    if (b) {
      this.skipTimer();
      if (this._nextSlide && this._nextSlide.index == a) {
        if (this._nextSlide.ready) this.showSlide(this._nextSlide);
        else this.waitForNext();
        return
      }
    }
    if (this._nextSlide && this._nextSlide.index == a) return;
    if (this._nextSlide) {
      this._nextSlide.killLoading();
      this._nextSlide = null
    }
    this._nextSlide = this._slideList[a];
    if (!this._nextSlide.ready) {
      b && this.waitForNext();
      this._nextSlide.onReady = {
        listener: this.readyToShow,
        ref: this
      };
      this._nextSlide.loadContent()
    } else this._delayProgress == 100 && this.showSlide(this._slideList[a]);
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.CHANGE_NEXT_SLIDE))
  },
  start: function() {
    this._currentSlide = this._slideList[this._currentSlideIndex];
    this.domElement.appendChild(this._currentSlide.domElement);
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.CHANGE_END));
    this.startTimer();
    this.gotoSlide(this.getNextIndex());
    this.vpWidth = this.vpWidth || this.width;
    this.vpHeight = this.vpHeight || this.height
  },
  next: function() {
    if (this._status == "changing") return;
    this.gotoSlide(this.getNextIndex(), true)
  },
  previous: function() {
    if (this._status == "changing") return;
    this.gotoSlide(this.getPreviousIndex(), true)
  },
  pushSlide: function(a) {
    this._slideList.push(a);
    a.index = this._slideList.length - 1;
    return this._slideList.length - 1
  },
  pause: function() {
    this._timer.stop()
  },
  play: function() {
    this._timer.start()
  },
  getTimer: function() {
    return this._timer
  },
  getSlideList: function() {
    return this._slideList
  },
  getNextSlide: function() {
    return this._nextSlide
  },
  getCurrentSlide: function() {
    return this._currentSlide
  },
  getCurrentSlideIndex: function() {
    return this._currentSlideIndex
  },
  delayProgress: function() {
    return this._delayProgress
  },
  getAutoPlay: function() {
    return this._autoPlay
  },
  setAutoPlay: function(a) {
    if (this._autoPlay == a) return;
    this._autoPlay = a;
    if (!this._autoPlay) this._timer.stop();
    else this._timer.start();
    this.dispatchEvent(new Cute.SliderEvent(Cute.SliderEvent.AUTOPLAY_CHANGE))
  }
};
Averta.EventDispatcher.extend(Cute.SlideManager.prototype);
Cute.rotatorControls = {};
Cute.AbstractControl = function(a) {
  this.config = null;
  this.slider = a;
  this.domElement = null;
  this.disable = false;
  this.name = "";
  this.config = {};
  this.opacity = 100;
  this.showTween = null
};
Cute.AbstractControl.prototype = {
  constructor: Cute.AbstractControl,
  setup: function(a) {
    this.config_ele = a;
    this.domElement.className = a.className || this.config.css_class;
    a.getAttribute("style") && this.domElement.setAttribute("style", a.getAttribute("style"));
    this.slider.addEventListener(Cute.SliderEvent.CHANGE_START, this.__effStart, this);
    this.slider.addEventListener(Cute.SliderEvent.CHANGE_END, this.__effEnd, this)
  },
  opacityUpdate: function() {
    setOpacity(this.domElement, this.opacity)
  },
  visible: function(a) {
    this.domElement.style.display = !a ? "none" : ""
  },
  show: function() {
    this.showTween && this.showTween.stop();
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 100
    }, 450).onUpdate(this.opacityUpdate).start();
    TWEEN.add(this.showTween)
  },
  hide: function() {
    this.showTween && this.showTween.stop();
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 0
    }, 450).onUpdate(this.opacityUpdate).start();
    TWEEN.add(this.showTween)
  },
  __effEnd: function() {
    this.visible(true);
    !this.config.autoHide && this.show();
    this.ap && this.slider.setAutoPlay(true)
  },
  __effStart: function() {
    this.hide()
  }
};
Cute.Next = function(a) {
  Cute.AbstractControl.prototype.constructor.call(this, a);
  this.domElement = document.createElement("div");
  this.config = {
    css_class: "br-next"
  }
};
Cute.rotatorControls.next = Cute.Next;
Cute.Next.prototype = new Cute.AbstractControl;
Cute.Next.prototype.constructor = Cute.Next;
Cute.Next.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.domElement.control = this;
  this.domElement.onclick = function() {
    this.control.slider.next()
  }
};
Cute.Next.prototype.show = function() {
  Cute.AbstractControl.prototype.show.call(this);
  this.domElement.style.cursor = "pointer"
};
Cute.Next.prototype.hide = function() {
  Cute.AbstractControl.prototype.hide.call(this);
  this.domElement.style.cursor = ""
};
Cute.Previous = function(a) {
  Cute.Next.call(this, a);
  this.config = {
    css_class: "br-previous"
  }
};
Cute.rotatorControls.previous = Cute.Previous;
Cute.Previous.prototype = new Cute.Next;
Cute.Previous.prototype.constructor = Cute.Previous;
Cute.Previous.prototype.setup = function(a) {
  Cute.Next.prototype.setup.call(this, a);
  this.domElement.onclick = function() {
    this.control.slider.previous()
  }
};
Cute.CircleTimer = function(a) {
  Cute.AbstractControl.call(this, a);
  this.domElement = document.createElement("div");
  this.lbrowser = Cute.FallBack.ua.browser.name.toLowerCase() == "ie" && parseInt(Cute.FallBack.ua.browser.major) < 9;
  if (this.lbrowser) return;
  this.config = {
    color: "#A2A2A2",
    stroke: 10,
    radius: 4,
    css_class: "br-circle-timer"
  };
  this.overpause = false;
  this.canvas = document.createElement("canvas");
  this.dot = document.createElement("div");
  this.ctx = this.canvas.getContext("2d");
  this.prog = 0;
  this.drawTween = null
};
Cute.rotatorControls.circletimer = Cute.CircleTimer;
Cute.CircleTimer.prototype = new Cute.AbstractControl;
Cute.CircleTimer.prototype.constructor = Cute.CircleTimer;
Cute.CircleTimer.prototype.setup = function(a) {
  if (this.lbrowser) return;
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.config.color = a.getAttribute("data-color") || this.config.color;
  if (a.getAttribute("data-stroke")) this.config.stroke = parseInt(a.getAttribute("data-stroke"));
  if (a.getAttribute("data-radius")) this.config.radius = parseInt(a.getAttribute("data-radius"));
  this.__w = (this.config.radius + this.config.stroke) * 2;
  this.canvas.width = this.__w;
  this.canvas.height = this.__w;
  this.canvas.className = "br-timer-stroke";
  this.canvas.style.position = "absolute";
  this.dot.className = "br-timer-dot";
  this.dot.style.position = "relative";
  this.dot.style.left = (this.__w - 10) * .5 + "px";
  this.dot.style.top = (this.__w - 12) * .5 + "px";
  this.domElement.slider = this.slider;
  this.domElement.onclick = function() {
    if (!Cute.AbstractControl.paused) {
      Cute.AbstractControl.paused = true;
      this.slider.setAutoPlay(false)
    } else {
      Cute.AbstractControl.paused = false;
      this.slider.setAutoPlay(true)
    }
  };
  this.slider.addEventListener(Cute.SliderEvent.WATING, this.update, this);
  this.domElement.appendChild(this.canvas);
  this.domElement.appendChild(this.dot)
};
Cute.CircleTimer.prototype.update = function() {
  this.drawTween && this.drawTween.stop();
  this.drawTween = (new TWEEN.Tween(this)).to({
    prog: this.slider.delayProgress() * .01
  }, 300).easing(TWEEN.Easing.Circular.EaseOut).onUpdate(this.draw).start()
};
Cute.CircleTimer.prototype.draw = function() {
  this.ctx.clearRect(0, 0, this.__w, this.__w);
  this.ctx.beginPath();
  this.ctx.arc(this.__w * .5, this.__w * .5, this.config.radius, Math.PI * 1.5, Math.PI * 1.5 + 2 * Math.PI * this.prog, false);
  this.ctx.strokeStyle = this.config.color;
  this.ctx.lineWidth = this.config.stroke;
  this.ctx.stroke()
};
Cute.CircleTimer.prototype.show = function() {
  Cute.AbstractControl.prototype.show.call(this);
  this.domElement.style.cursor = "pointer"
};
Cute.CircleTimer.prototype.hide = function() {
  Cute.AbstractControl.prototype.hide.call(this);
  this.domElement.style.cursor = ""
};
Cute.Thumb = function(b, a) {
  this.domElement = document.createElement("div");
  this.domElement.className = "br-thumb-" + a;
  this.imgCont = document.createElement("div");
  this.imgCont.className = "br-thumb-img";
  this.imgCont.style.overflow = "hidden";
  this.img = new Image;
  this.img.thumb = this;
  this.img.onload = this.thumbLoaded;
  this.img.src = b;
  this.img.style.position = "absolute";
  this.img.style.filter = "inherit";
  this.frame = document.createElement("div");
  this.frame.style.position = "absolute";
  this.frame.style.zIndex = "1";
  this.frame.className = "br-thumb-frame";
  this.frame.style.filter = "inherit";
  this.thumb_pos = 1;
  this.imgCont.appendChild(this.img);
  this.domElement.appendChild(this.imgCont);
  this.domElement.appendChild(this.frame)
};
Cute.Thumb.prototype = {
  constructor: Cute.Thumb,
  thumbLoaded: function() {
    this.thumb.imgLoaded = true;
    this.thumb.rts && this.thumb.show()
  },
  ut: function() {
    this.img.style.transform = "scale(" + this.thumb_pos + ")";
    this.img.style.webkitTransform = "scale(" + this.thumb_pos + ")";
    this.img.style.MozTransform = "scale(" + this.thumb_pos + ") rotate(0.1deg)";
    this.img.style.msTransform = "scale(" + this.thumb_pos + ")";
    this.img.style.OTransform = "scale(" + this.thumb_pos + ")"
  },
  show: function() {
    if (!this.imgLoaded) {
      this.rts = true;
      return
    }
  },
  reset: function() {
    this.rts = false;
    if (this.st) {
      this.st.stop();
      this.st = null
    }
  }
};
Cute.SlideControl = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-slidecontrol",
    thumb: true,
    thumb_align: "bottom"
  };
  this.domElement = document.createElement("div");
  this.points_ul = document.createElement("ul");
  this.points = []
};
Cute.rotatorControls.slidecontrol = Cute.SlideControl;
Cute.SlideControl.prototype = new Cute.AbstractControl;
Cute.SlideControl.prototype.constructor = Cute.SlideControl;
Cute.SlideControl.prototype.setup = function(c) {
  Cute.AbstractControl.prototype.setup.call(this, c);
  this.domElement.appendChild(this.points_ul);
  this.slider.addEventListener(Cute.SliderEvent.CHANGE_NEXT_SLIDE, this.update, this);
  this.config.thumb = c.getAttribute("data-thumb") != "false";
  this.config.thumb_align = c.getAttribute("data-thumbalign") || "bottom";
  for (var a, b = 0, d = this.slider.getSlideList().length; b < d; ++b) {
    a = new Cute.SlideControl.Point(this.slider, this.slider.getSlideList()[b], this);
    if (b == this.slider.getCurrentSlideIndex()) {
      this.selectedPoint = a;
      a.select()
    }
    a.index = b;
    this.points_ul.appendChild(a.domElement);
    this.points.push(a)
  }
};
Cute.SlideControl.prototype.update = function() {
  if (this.selectedPoint && this.slider.getCurrentSlideIndex() == this.selectedPoint.index) return;
  this.selectedPoint && this.selectedPoint.unselect();
  this.selectedPoint = this.points[this.slider.getCurrentSlideIndex()];
  this.selectedPoint.select()
};
Cute.SlideControl.prototype.show = function() {
  Cute.AbstractControl.prototype.show.call(this);
  this.disable = false;
  this.domElement.style.cursor = "pointer"
};
Cute.SlideControl.prototype.hide = function() {
  Cute.AbstractControl.prototype.hide.call(this);
  this.disable = true;
  this.domElement.style.cursor = "default"
};
Cute.SlideControl.Point = function(b, c, a) {
  this.domElement = document.createElement("li");
  this.slider = b;
  this.index = 0;
  this.domElement.point = this;
  this.sc = a;
  this.domElement.onclick = function() {
    if (this.point.sc.disable) return;
    this.point.changeSlide()
  };
  if (Cute.FallBack.ua.browser.name == "IE") this.domElement.style.filter = "inherit";
  this.selectedElement = document.createElement("span");
  this.selectedElement.className = "br-control-selected";
  this.selectOpacity = 0;
  this.uo();
  if (a.config.thumb) {
    this.thumb = new Cute.Thumb(c.thumb, a.config.thumb_align);
    this.domElement.onmouseover = function() {
      this.point.showThumb()
    };
    this.domElement.onmouseout = function() {
      this.point.hideThumb()
    };
    this.thumb_pos = 0;
    this.drawThumb();
    this.thumb.domElement.style.display = "none";
    this.domElement.appendChild(this.thumb.domElement);
    this.thumb.align = a.config.thumb_align
  }
  this.domElement.appendChild(this.selectedElement);
  this.selectTween = null
};
Cute.SlideControl.Point.prototype = {
  constructor: Cute.SlideControl.Point,
  align: "bottom",
  changeSlide: function() {
    this.slider.gotoSlide(this.index, true)
  },
  uo: function() {
    setOpacity(this.selectedElement, this.selectOpacity)
  },
  select: function() {
    this.selectTween && this.selectTween.stop();
    this.selectTween = (new TWEEN.Tween(this)).to({
      selectOpacity: 100
    }, 450).onUpdate(this.uo).start();
    TWEEN.add(this.selectTween)
  },
  unselect: function() {
    this.selectTween && this.selectTween.stop();
    this.selectTween = (new TWEEN.Tween(this)).to({
      selectOpacity: 0
    }, 450).onUpdate(this.uo).start();
    TWEEN.add(this.selectTween)
  },
  drawThumb: function() {
    setOpacity(this.thumb.domElement, this.thumb_pos);
    if (this.sc.config.thumb_align == "up") this.thumb.domElement.style.top = 10 - this.thumb.frame.offsetHeight + -this.thumb_pos * .1 + "px";
    else this.thumb.domElement.style.top = 24 + -this.thumb_pos * .1 + "px"
  },
  showThumb: function() {
    this.domElement.style.zIndex = this.slider.getSlideList().length;
    this.thumbTween && this.thumbTween.stop();
    this.thumb.show();
    this.thumb.domElement.style.display = "";
    this.thumbTween = (new TWEEN.Tween(this)).to({
      thumb_pos: 100
    }, 700).onUpdate(this.drawThumb).easing(TWEEN.Easing.Quartic.EaseOut).start()
  },
  hideThumb: function() {
    this.domElement.style.zIndex = 0;
    this.thumbTween && this.thumbTween.stop();
    this.thumb.reset();
    this.thumbTween = (new TWEEN.Tween(this)).to({
      thumb_pos: 0
    }, 250).onUpdate(this.drawThumb).start().onComplete(function() {
      this.thumb.domElement.style.display = "none"
    })
  }
};
Cute.SlideInfo = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-slideinfo",
    align: "bottom"
  };
  this.domElement = document.createElement("div");
  this.content = document.createElement("div");
  this.poition = 0
};
Cute.rotatorControls.slideinfo = Cute.SlideInfo;
Cute.SlideInfo.prototype = new Cute.AbstractControl;
Cute.SlideInfo.prototype.constructor = Cute.SlideInfo;
Cute.SlideInfo.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.domElement.style.overflow = "hidden";
  this.domElement.style.position = "absolute";
  this.domElement.style.display = "none";
  this.content.className = "br-infocontent";
  this.content.style.position = "relative";
  this.eff = a.getAttribute("data-effect") || "slide";
  this.domElement.appendChild(this.content)
};
Cute.SlideInfo.prototype.update = function() {
  if (this.data) if (this.eff == "fade") setOpacity(this.content, this.position);
  else this.content.style[this.data.align] = this.position + "px"
};
Cute.SlideInfo.prototype.show = function() {
  this.domElement.style.display = "";
  this.showTween && this.showTween.stop();
  this.data = this.slider.getCurrentSlide().pluginData.info;
  if (!this.data) {
    this.disable = true;
    this.content.className = "";
    this.content.innerHTML = "";
    return
  } else this.disable = false;
  this.content.innerHTML = this.data.text;
  this.content.className = "br-infocontent " + this.data.align + " " + this.data._class || "";
  this.domElement.style.width = this.data.align == "left" || this.data.align == "right" ? "auto" : "100%";
  this.domElement.style.height = this.data.align == "bottom" || this.data.align == "top" ? "auto" : "100%";
  this.domElement.style.left = "";
  this.domElement.style.right = "";
  this.domElement.style.bottom = "";
  this.domElement.style.top = "";
  this.content.style.left = "";
  this.content.style.right = "";
  this.content.style.bottom = "";
  this.content.style.top = "";
  if (this.eff == "slide") this.position = -(this.data.align == "bottom" || this.data.align == "top" ? this.content.offsetHeight : this.content.offsetWidth);
  else this.position = 0;
  this.domElement.style[this.data.align] = "0px";
  this.update();
  this.showTween = (new TWEEN.Tween(this)).to({
    position: this.eff == "slide" ? 0 : 100
  }, 950).easing(TWEEN.Easing.Quartic.EaseInOut).onUpdate(this.update).start();
  TWEEN.add(this.showTween)
};
Cute.SlideInfo.prototype.hide = function() {
  if (this.disable) return;
  this.showTween && this.showTween.stop();
  this.showTween = (new TWEEN.Tween(this)).to({
    position: this.eff != "slide" ? 0 : -(this.data.align == "bottom" || this.data.align == "top" ? this.content.offsetHeight : this.content.offsetWidth)
  }, 850).easing(TWEEN.Easing.Quartic.EaseInOut).onUpdate(this.update).start();
  TWEEN.add(this.showTween)
};
Cute.BarTimer = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-bar-timer"
  };
  this.domElement = document.createElement("div");
  this.prog = 0
};
Cute.rotatorControls.bartimer = Cute.BarTimer;
Cute.BarTimer.prototype = new Cute.AbstractControl;
Cute.BarTimer.prototype.constructor = Cute.BarTimer;
Cute.BarTimer.prototype.update = function() {
  this.drawTween && this.drawTween.stop();
  this.drawTween = (new TWEEN.Tween(this)).to({
    prog: this.slider.delayProgress() * .01
  }, 500).easing(TWEEN.Easing.Quartic.EaseOut).onUpdate(this.draw).start()
};
Cute.BarTimer.prototype.draw = function() {
  var a = this.prog * this.slider.width;
  this.glow.style.left = a - this.glow.offsetWidth + "px";
  this.bar.style.width = Math.max(0, a - 5) + "px"
};
Cute.BarTimer.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.slider.bartimer = this;
  this.domElement.style.width = "100%";
  this.domElement.style.overflow = "hidden";
  this.glow = document.createElement("div");
  this.glow.className = "br-timer-glow";
  this.glow.style.position = "relative";
  this.bar = document.createElement("div");
  this.bar.className = "br-timer-bar";
  this.domElement.appendChild(this.glow);
  this.domElement.appendChild(this.bar);
  this.slider.addEventListener(Cute.SliderEvent.WATING, this.update, this);
  this.draw()
};
Cute.Captions = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-captions"
  };
  this.domElement = document.createElement("div");
  this.captions = [];
  this.overpause = false
};
Cute.rotatorControls.captions = Cute.Captions;
Cute.Captions.prototype = new Cute.AbstractControl;
Cute.Captions.prototype.constructor = Cute.Captions;
Cute.Captions.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.domElement.style.width = "100%";
  this.domElement.style.height = "100%";
  this.domElement.style.position = "absolute"
};
Cute.Captions.prototype.show = function() {
  this.data = this.slider.getCurrentSlide().pluginData.captions;
  this.slide_index = this.slider.getCurrentSlideIndex();
  if (!this.captions[this.slide_index] && this.data) {
    this.captions[this.slide_index] = [];
    for (var c = this.data.getElementsByTagName("li"), b, a = 0, d = c.length; a < d; ++a) {
      b = new Cute.Caption;
      b.add(c[a].innerHTML, c[a].className);
      b.delay = Number(c[a].getAttribute("data-delay")) || 0;
      b.effect = c[a].getAttribute("data-effect") || "fade";
      this.captions[this.slide_index].push(b)
    }
  }
  if (this.data) for (var a = 0, d = this.captions[this.slide_index].length; a < d; ++a) {
    this.domElement.appendChild(this.captions[this.slide_index][a].domElement);
    this.captions[this.slide_index][a].show()
  }
};
Cute.Captions.prototype.hide = function() {
  if (this.captions[this.slide_index]) for (var a = 0, b = this.captions[this.slide_index].length; a < b; ++a) this.captions[this.slide_index][a].hide()
};
Cute.Caption = function() {
  this.domElement = document.createElement("div");
  this.content = document.createElement("div")
};
Cute.Caption.prototype = {
  constructro: Cute.Caption,
  effect: "fade",
  add: function(b, a) {
    this.content.innerHTML = b;
    this.content.className = "br-caption-content";
    this.content.style.position = "relative";
    this.domElement.className = a;
    this.domElement.style.overflow = "hidden";
    this.domElement.appendChild(this.content)
  },
  fade: function() {
    setOpacity(this.domElement, this.show_pos)
  },
  slide: function() {
    this.content.style.left = -this.domElement.offsetWidth * (1 - this.show_pos * .01) + "px"
  },
  show: function() {
    this.showTween && this.showTween.stop();
    this.show_pos = 0;
    this[this.effect]();
    this.showTween = (new TWEEN.Tween(this)).to({
      show_pos: 100
    }, 1e3).delay(this.delay).easing(TWEEN.Easing.Quartic.EaseInOut).onUpdate(this[this.effect]).delay(this.delay).start();
    TWEEN.add(this.showTween)
  },
  hide: function() {
    this.showTween && this.showTween.stop();
    this.showTween = (new TWEEN.Tween(this)).to({
      show_pos: 0
    }, 1e3).delay(this.delay).easing(TWEEN.Easing.Quartic.EaseInOut).onUpdate(this[this.effect]).onComplete(this.remove).start()
  },
  remove: function() {
    this.domElement.parentElement && this.domElement.parentElement.removeChild(this.domElement)
  }
};
Cute.VideoControl = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-video",
    width: 300,
    height: 200
  };
  this.domElement = document.createElement("div");
  this.video_ele = document.createElement("iframe");
  this.closeBtn = document.createElement("div");
  this.overPlay = document.createElement("div");
  this.videoContainer = document.createElement("div");
  this.domElement.style.position = "absolute";
  this.vopacity = 0;
  this.videoFade = function() {
    setOpacity(this.videoContainer, this.vopacity)
  }
};
Cute.rotatorControls.video = Cute.VideoControl;
Cute.VideoControl.prototype = new Cute.AbstractControl;
Cute.VideoControl.prototype.constructor = Cute.VideoControl;
Cute.VideoControl.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.video_ele.setAttribute("allowFullScreen", "");
  this.video_ele.setAttribute("frameborder", "0");
  this.overPlay.targ = this;
  this.overPlay.onclick = function() {
    this.targ.showVideo()
  };
  this.overPlay.className = "play-btn";
  this.closeBtn.targ = this;
  this.closeBtn.onclick = function() {
    this.targ.hideVideo()
  };
  this.closeBtn.className = "close-btn";
  this.videoContainer.className = "video-cont";
  this.domElement.style.width = "100%";
  this.domElement.style.height = "100%";
  this.video_ele.style.width = "100%";
  this.video_ele.style.height = "100%";
  this.video_ele.style.background = "black";
  this.domElement.appendChild(this.overPlay);
  this.domElement.appendChild(this.videoContainer);
  this.videoContainer.appendChild(this.closeBtn);
  this.videoContainer.style.display = "none";
  setOpacity(this.videoContainer, 0)
};
Cute.VideoControl.prototype.showVideo = function() {
  this.videoContainer.style.display = "";
  this.videoContainer.appendChild(this.video_ele);
  this.video_ele.className = this.data.className || this.config.css_class;
  this.video_ele.getAttribute("src") != this.data.getAttribute("href") && this.video_ele.setAttribute("src", this.data.getAttribute("href") || "about:blank");
  this.videoTween && this.videoTween.stop();
  this.videoTween = (new TWEEN.Tween(this)).to({
    vopacity: 100
  }, 400).onUpdate(this.videoFade).start();
  this.slider.rotator.pause()
};
Cute.VideoControl.prototype.hideVideo = function() {
  this.videoTween && this.videoTween.stop();
  this.videoTween = (new TWEEN.Tween(this)).to({
    vopacity: 0
  }, 400).onUpdate(this.videoFade).start();
  this.videoTween.onComplete(function() {
    this.video_ele.setAttribute("src", "about:blank");
    this.videoContainer.removeChild(this.video_ele);
    this.videoContainer.style.display = "none"
  })
};
Cute.VideoControl.prototype.show = function() {
  this.data = this.slider.getCurrentSlide().pluginData.video;
  if (!this.data) {
    this.domElement.style.display = "none";
    return
  }
  this.domElement.style.display = "";
  Cute.AbstractControl.prototype.show.call(this)
};
Cute.VideoControl.prototype.hide = function() {
  Cute.AbstractControl.prototype.hide.call(this);
  this.showTween.onComplete(function() {
    this.video_ele.parentElement && this.videoContainer.removeChild(this.video_ele);
    this.domElement.style.display = "none";
    this.videoContainer.style.display = "none";
    this.videoTween && this.videoTween.stop()
  })
};
Cute.LinkControl = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-link"
  };
  this.domElement = document.createElement("div");
  this.domElement.style.position = "absolute"
};
Cute.rotatorControls.link = Cute.LinkControl;
Cute.LinkControl.prototype = new Cute.AbstractControl;
Cute.LinkControl.prototype.constructor = Cute.LinkControl;
Cute.LinkControl.prototype.setup = function(a) {
  Cute.AbstractControl.prototype.setup.call(this, a);
  this.domElement.lc = this;
  this.domElement.style.width = "100%";
  this.domElement.style.height = "100%";
  this.domElement.style.cursor = "pointer"
};
Cute.LinkControl.prototype.gotoURL = function() {
  window.open(this.lc.link.href, this.lc.link.target || "_self")
};
Cute.LinkControl.prototype.show = function() {
  this.link = this.slider.getCurrentSlide().pluginData.link;
  if (this.link) {
    this.domElement.style.display = "";
    this.domElement.onclick = this.gotoURL
  } else {
    this.domElement.style.display = "none";
    this.domElement.onclick = null
  }
};
Cute.LinkControl.prototype.hide = function() {
  this.domElement.style.display = "none";
  this.domElement.onclick = null
};
Cute.Loading = function() {
  this.domElement = document.createElement("div");
  this.domElement.className = "br-loading";
  this.domElement.style.display = "none";
  this.animEle = document.createElement("div");
  this.animEle.className = "img";
  this.domElement.appendChild(this.animEle);
  this.opacity = 0
};
Cute.Loading.prototype = {
  constructor: Cute.Loading,
  opacityUpdate: function() {
    setOpacity(this.domElement, this.opacity)
  },
  show: function() {
    this.showTween && this.showTween.stop();
    this.domElement.style.display = "";
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 100
    }, 450).onUpdate(this.opacityUpdate).start()
  },
  hide: function() {
    this.showTween && this.showTween.stop();
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 0
    }, 450).onUpdate(this.opacityUpdate).start();
    this.domElement.style.display = "none"
  }
};
Cute.ThumbList = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-thumblist",
    type: "vertical"
  };
  this.domElement = document.createElement("div");
  this.thumbs = []
};
Cute.rotatorControls.thumblist = Cute.ThumbList;
Cute.ThumbList.prototype = new Cute.AbstractControl;
Cute.ThumbList.prototype.constructor = Cute.ThumbList;
Cute.ThumbList.prototype.setup = function(c) {
  Cute.AbstractControl.prototype.setup.call(this, c);
  this.config.type = c.getAttribute("data-dir") || "vertical";
  this.config.autohide = c.getAttribute("data-autohide") == "true";
  this.domElement.className += " " + this.config.type;
  this.list = new Cute.ItemList(this.domElement);
  this.list.type = this.config.type;
  this.list.frame.className = "br-thumblist-frame";
  this.list.content.className = "br-thumblist-content";
  this.list.downright.className = "br-thumblist-next";
  this.list.upleft.className = "br-thumblist-previous";
  this.slider.addEventListener(Cute.SliderEvent.CHANGE_NEXT_SLIDE, this.update, this);
  for (var a, b = 0, d = this.slider.getSlideList().length; b < d; ++b) {
    a = new Cute.ListThumb(this.slider.getSlideList()[b].thumb, this.slider, this);
    a.index = b;
    this.thumbs.push(a);
    this.list.addItem(a.element)
  }
  this.list.sc.setup()
};
Cute.ThumbList.prototype.update = function() {
  if (this.selectedThumb && this.slider.getCurrentSlideIndex() == this.selectedThumb.index) return;
  this.selectedThumb && this.selectedThumb.unselect();
  this.selectedThumb = this.thumbs[this.slider.getCurrentSlideIndex()];
  this.selectedThumb.select()
};
Cute.ThumbList.prototype.show = function() {
  this.config.autohide && Cute.AbstractControl.prototype.show.call(this);
  this.disable = false
};
Cute.ThumbList.prototype.hide = function() {
  this.config.autohide && Cute.AbstractControl.prototype.hide.call(this);
  this.disable = true
};
Cute.ListThumb = function(d, c, a) {
  this.img = new Image;
  this.img.src = d;
  this.element = document.createElement("div");
  this.element.className = "br-list-thumb";
  this.select_ele = document.createElement("div");
  this.select_ele.className = "br-list-thumb-select";
  this.element.appendChild(this.img);
  this.element.appendChild(this.select_ele);
  setOpacity(this.select_ele, 0);
  this.opacity = 0;
  var b = this;
  if (a.list.sc.isTouch()) this.element.addEventListener("touchend", function(d) {
    if (b.selected || a.disable || a.list.sc.moved) return;
    c.gotoSlide(b.index, true);
    d.preventDefault();
    d.stopPropagation()
  }, false);
  else this.element.onclick = function() {
    if (b.selected || a.disable || a.list.sc.moved) return;
    c.gotoSlide(b.index, true)
  }
};
Cute.ListThumb.prototype = {
  constructor: Cute.ListThumb,
  opacityUpdate: function() {
    setOpacity(this.select_ele, this.opacity)
  },
  select: function() {
    if (this.selected) return;
    this.selected = true;
    if (this.showTween) this.showTween = null;
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 100
    }, 450).onUpdate(this.opacityUpdate).start()
  },
  unselect: function() {
    if (!this.selected) return;
    this.selected = false;
    if (this.showTween) this.showTween = null;
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 0
    }, 450).onUpdate(this.opacityUpdate).start()
  }
};
Cute.InfoList = function(a) {
  Cute.AbstractControl.call(this, a);
  this.config = {
    css_class: "br-infolist",
    type: "vertical"
  };
  this.domElement = document.createElement("div");
  this.items = []
};
Cute.rotatorControls.infolist = Cute.InfoList;
Cute.InfoList.prototype = new Cute.AbstractControl;
Cute.InfoList.prototype.constructor = Cute.InfoList;
Cute.InfoList.prototype.setup = function(c) {
  Cute.AbstractControl.prototype.setup.call(this, c);
  this.config.type = c.getAttribute("data-dir") || "vertical";
  this.config.autohide = c.getAttribute("data-autohide") == "true";
  this.domElement.className += " " + this.config.type;
  this.list = new Cute.ItemList(this.domElement);
  this.list.type = this.config.type;
  this.list.frame.className = "br-infolist-frame";
  this.list.content.className = "br-infolist-content";
  this.list.downright.className = "br-infolist-next";
  this.list.upleft.className = "br-infolist-previous";
  this.slider.addEventListener(Cute.SliderEvent.CHANGE_NEXT_SLIDE, this.update, this);
  for (var a, b = 0, d = this.slider.getSlideList().length; b < d; ++b) {
    a = new Cute.ListItem(this.slider.getSlideList()[b].pluginData.info, this.slider, this);
    a.index = b;
    this.items.push(a);
    this.list.addItem(a.element)
  }
  this.list.sc.setup()
};
Cute.InfoList.prototype.update = function() {
  if (this.selectedThumb && this.slider.getCurrentSlideIndex() == this.selectedThumb.index) return;
  this.selectedThumb && this.selectedThumb.unselect();
  this.selectedThumb = this.items[this.slider.getCurrentSlideIndex()];
  this.selectedThumb.select()
};
Cute.InfoList.prototype.show = function() {
  this.config.autohide && Cute.AbstractControl.prototype.show.call(this);
  this.disable = false
};
Cute.InfoList.prototype.hide = function() {
  this.config.autohide && Cute.AbstractControl.prototype.hide.call(this);
  this.disable = true
};
Cute.ListItem = function(d, c, a) {
  this.element = document.createElement("div");
  this.element.className = "br-slist-item";
  this.select_ele = document.createElement("div");
  this.select_ele.className = "br-slist-item-select";
  this.content = document.createElement("div");
  this.content.innerHTML = d ? d.text : "";
  this.content.className = "br-slist-item-content";
  this.element.appendChild(this.select_ele);
  this.element.appendChild(this.content);
  setOpacity(this.select_ele, 0);
  this.opacity = 0;
  var b = this;
  if (a.list.sc.isTouch()) this.element.addEventListener("touchend", function(d) {
    if (b.selected || a.disable || a.list.sc.moved) return;
    c.gotoSlide(b.index, true);
    d.preventDefault();
    d.stopPropagation()
  }, false);
  else this.element.onclick = function() {
    if (b.selected || a.disable || a.list.sc.moved) return;
    c.gotoSlide(b.index, true)
  }
};
Cute.ListItem.prototype = {
  constructor: Cute.ListThumb,
  opacityUpdate: function() {
    setOpacity(this.select_ele, this.opacity)
  },
  select: function() {
    if (this.selected) return;
    this.selected = true;
    if (this.showTween) this.showTween = null;
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 100
    }, 450).onUpdate(this.opacityUpdate).start()
  },
  unselect: function() {
    if (!this.selected) return;
    this.selected = false;
    if (this.showTween) this.showTween = null;
    this.showTween = (new TWEEN.Tween(this)).to({
      opacity: 0
    }, 450).onUpdate(this.opacityUpdate).start()
  }
};
Cute.TouchNavigation = function(a, f) {
  this.isTouch = function() {
    try {
      document.createEvent("TouchEvent");
      return true
    } catch (a) {
      return false
    }
  };
  var g = this.isTouch(),
    c = false,
    d = 0,
    b = 0,
    e;
  this.__touchStart = function(a) {
    c = true;
    b = d = a.touches[0].pageX;
    e = setTimeout(function() {
      c = false
    }, 3e3);
    a.preventDefault()
  };
  this.__touchMove = function(a) {
    if (!c) return;
    b = a.touches[0].pageX;
    a.preventDefault()
  };
  this.__touchEnd = function(g) {
    if (!c) return;
    c = false;
    clearTimeout(e);
    if (b - d > a.offsetWidth / 10) f.next();
    else b - d < -a.offsetWidth / 10 && f.previous();
    d = b = 0;
    g.preventDefault()
  };
  if (g) {
    a.addEventListener("touchstart", this.__touchStart);
    a.addEventListener("touchmove", this.__touchMove);
    a.addEventListener("touchend", this.__touchEnd)
  }
};
Cute.Slider = function() {
  this.slides = [];
  this.controls = [];
  this.slideManager = new Cute.SlideManager;
  this.imgLoaded = false;
  this.mlcl = false;
  this.api = this.slideManager
};
Cute.Slider.prototype = {
  constructor: Cute.Slider,
  setup: function(d, e) {
    this.fallBack = new Cute.FallBack;
    this.element = document.getElementById(d);
    this.wrapper = document.getElementById(e);
    if (Cute.FallBack.isIE8) this.element.className += " cute-ie8";
    this.wrapper.slider = this;
    window.addResizeListener(this.__onresize, this);
    this.aspect = Number(this.element.getAttribute("data-width")) / Number(this.element.getAttribute("data-height"));
    this.__setSize();
    this.slideManager.resize();
    this.slideManager.rotator = this;
    this.controlLayer = document.createElement("div");
    this.controlLayer.style.visibility = "hidden";
    this.contentLoading = new Cute.Loading;
    this.contentLoading.domElement.className = "br-large-loading";
    this.contentLoading.show();
    this.element.appendChild(this.contentLoading.domElement);
    if (this.element.getAttribute("data-force")) this.fallBack.force = this.element.getAttribute("data-force");
    for (var b = this.element.getElementsByTagName("ul"), a = 0, f = b.length; a < f; ++a) if (b[a].getAttribute("data-type") == "slides") this.slidesElement = b[a];
    else if (b[a].getAttribute("data-type") == "controls") this.controlsElement = b[a];
    this.__createSlides();
    this.controlsElement && this.__createControls();
    this.element.appendChild(this.slideManager.domElement);
    var c = new Cute.ModuleLoader(this.fallBack);
    c.loadModule();
    c.onComplete = {
      listener: this.__onModuleReady,
      ref: this
    }
  },
  __setSize: function() {
    this.slideManager.width = this.wrapper.clientWidth;
    this.slideManager.height = this.wrapper.clientWidth / this.aspect;
    this.slideManager.vpWidth = this.slideManager.width + this.slideManager.width * .2;
    this.slideManager.vpHeight = this.slideManager.height + this.slideManager.height * .2;
    this.element.style.width = this.slideManager.width + "px";
    this.element.style.height = this.slideManager.height + "px"
  },
  __onresize: function() {
    this.__setSize();
    this.slideManager.resize()
  },
  __onModuleReady: function() {
    this.mlcl = true;
    this.imgLoaded && this.__start()
  },
  __onImgLoaded: function() {
    this.slide.addContent(this);
    this.rotator.mlcl && this.rotator.__start();
    this.rotator.imgLoaded = true;
    this.slide = null;
    this.rotator = null
  },
  __start: function() {
    var a = this.fallBack.getType();
    switch (a) {
    case Cute.FallBack.CANVAS:
      this.slideManager._viewClass = Aroma.ThreeView;
      break;
    case Cute.FallBack.CSS3D:
      this.slideManager._viewClass = Aroma.CSS3DView;
      Aroma.CSS3DCube.light = !Cute.FallBack.isMobileDevice;
      break;
    case Cute.FallBack.DOM2D:
      this.slideManager._viewClass = Aroma.DivView
    }
    this.showControls();
    this.slideManager.start();
    if (!Cute.Ticker.Tweenisadded) {
      Cute.Ticker.add(TWEEN.update, TWEEN);
      Cute.Ticker.Tweenisadded = true
    }
    Cute.Ticker.add(this.slideManager._timer.update, this.slideManager._timer);
    Cute.Ticker.start();
    this.element.removeChild(this.contentLoading.domElement)
  },
  __parseTransValues: function(d, e) {
    for (var c = [], a = d.split(" ").join().split(","), b = 0, f = a.length; b < f; b++) if (e) Transitions2D[a[b]] && c.push(Transitions2D[a[b]]);
    else Transitions3D[a[b]] && c.push(Transitions3D[a[b]]);
    a = null;
    return c
  },
  __createSlides: function() {
    var c = null,
      f = 0;
    while (this.slidesElement.children.length != 0) {
      var d = this.slidesElement.firstElementChild || this.slidesElement.children[0];
      c = new Cute.Slide(this.slideManager);
      c.dataElement = d;
      c.delay = d.getAttribute("data-delay");
      c.transitions2D = this.__parseTransValues(d.getAttribute("data-trans2d"), true);
      c.transitions3D = this.__parseTransValues(d.getAttribute("data-trans3d"), false);
      c.rotator = this;
      for (var b = d.children, a = 0, g = b.length; a < g; ++a) {
        if (b[a].nodeName === "IMG") {
          if (f == 0) {
            c.src = b[a].getAttribute("src");
            var e = new Image;
            e.slide = c;
            e.rotator = this;
            e.onload = this.__onImgLoaded;
            e.src = c.src
          } else c.src = b[a].getAttribute("data-src");
          c.thumb = b[a].getAttribute("data-thumb");
          continue
        }
        if (b[a].nodeName === "DIV" && b[a].getAttribute("data-type") == "info") {
          c.pluginData.info = {
            text: b[a].innerHTML,
            _class: b[a].className,
            align: b[a].getAttribute("data-align") || "bottom"
          };
          continue
        }
        if (b[a].nodeName === "UL" && b[a].getAttribute("data-type") == "captions") {
          c.pluginData.captions = b[a];
          continue
        }
        if (b[a].nodeName === "A" && b[a].getAttribute("data-type") == "video") {
          c.pluginData.video = b[a];
          continue
        }
        if (b[a].nodeName === "A" && b[a].getAttribute("data-type") == "link") {
          c.pluginData.link = {
            href: b[a].getAttribute("href"),
            target: b[a].getAttribute("target")
          };
          continue
        }
      }
      this.slides.push(c);
      this.slideManager.pushSlide(c);
      this.slidesElement.removeChild(d);
      f++
    }
    this.element.removeChild(this.slidesElement)
  },
  __createControls: function() {
    var d = this.controlsElement.getElementsByTagName("li"),
      a, b;
    this.element.appendChild(this.controlLayer);
    this.controlLayer.className = "br-controls";
    if (this.element.getAttribute("data-overpause") != "false" && !Cute.FallBack.isMobileDevice) {
      this.controlLayer.slideManager = this.slideManager;
      this.controlLayer.rotator = this;
      var e = function() {
          if (this.slideManager._status == "changing" || this.slideManager._status == "loading") return;
          this.slideManager.setAutoPlay(false)
        },
        f = function() {
          if (!Cute.AbstractControl.paused) {
            if (this.slideManager._status == "changing" || this.slideManager._status == "loading") {
              this.rotator.ap = true;
              return
            }
            this.rotator.ap = false;
            this.slideManager.setAutoPlay(true)
          }
        };
      this.controlLayer.onmouseover = e;
      this.controlLayer.onmouseout = f;
      this.slideManager.addEventListener(Cute.SliderEvent.CHANGE_END, this.__effEnd, this)
    }
    var h = new Cute.TouchNavigation(this.controlLayer, this.api);
    this.controlLayer.style.width = "100%";
    this.controlLayer.style.height = "100%";
    for (var c = 0, g = d.length; c < g; ++c) {
      a = d[c].getAttribute("data-type");
      if (a && Cute.rotatorControls[a]) {
        b = new Cute.rotatorControls[a](this.slideManager);
        this.controlLayer.appendChild(b.domElement);
        b.setup(d[c]);
        this.controls.push(b)
      }
    }
    this.loading = new Cute.Loading;
    this.element.appendChild(this.loading.domElement);
    this.slideManager.addEventListener(Cute.SliderEvent.WATING_FOR_NEXT, this.showLoading, this);
    this.slideManager.addEventListener(Cute.SliderEvent.CHANGE_START, this.hideLoading, this);
    this.element.removeChild(this.controlsElement)
  },
  __effEnd: function() {
    this.ap && this.slideManager.setAutoPlay(true)
  },
  showLoading: function() {
    this.lis = true;
    this.loading.show()
  },
  hideLoading: function() {
    if (this.lis) {
      this.lis = false;
      this.loading.hide()
    }
  },
  showControls: function() {
    this.contentLoading.hide();
    this.controlLayer.style.visibility = "visible"
  },
  play: function() {
    Cute.AbstractControl.paused = false;
    this.api.setAutoPlay(true)
  },
  pause: function() {
    Cute.AbstractControl.paused = true;
    this.api.setAutoPlay(false)
  }
}