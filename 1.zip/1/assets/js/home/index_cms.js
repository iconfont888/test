/***
 *
 * CMS 内容管理 (首页)
 *     1. 轮播图
 *     2. 左侧导航
 *     3. 首页广告弹窗
 */

var _visit_ip_first = false;

//  生成轮播图
$(function () {
    var $indicators = $("#carousel-home").find(".carousel-indicators"), $inner = $("#carousel-home").find(".carousel-inner");
    var codeDsArr = ["AG8040", "AG8041", "AG8042", "AG8043", "AG8044"];
    //  生成 banner 小图
    var indicatorsHtml = function (index, item) {
        var labelAttr = "";
        if(index < codeDsArr.length) {
            labelAttr = " code-ds='" + codeDsArr[index] + "' ";
        }
        var classA = index === 0 ? 'active' : '';
        var image = item.minImageHttpUrl;
        return '<li data-target="#carousel-home" ' + labelAttr + ' data-slide-to="' + index + '" class="' + classA + '">'
            + '		<img src="' + image + '">'
            + '</li>';
    };
    //  生成 banner 大图
    var innerHtml = function (index, item) {
        var classA = index === 0 ? 'active' : '';
        var dataSrc = index !== 0 ? 'data-' : '';
        if((/agweb.nbbets.com/.test(item.maxUrl)) && pn.userName!=="") {
            var href = item.maxUrl === '' ? '' : ('data-item="nbbets" href="' + item.maxUrl + '"');
        }else{
            var href = item.maxUrl === '' ? '' : ('href="' + item.maxUrl + '"');
        }
        var target = item.target ? " target='_blank'" : '';
        var imageUrl = item.maxImageHttpUrl;
        if (item.buttons) {
            var buttons = [];
            $.each(item.buttons, function (index, item) {
                var url = "", s = "";
                if (item.buttonAction === 'trial') {
                    s = "trial-gobut";
                } else if (item.buttonAction === 'register') {
                    s = "register-gobut"
                } else if (item.buttonAction === 'login') {
                    s = "login-gobut";
                } else if (item.buttonAction) {
                    if((/agweb.nbbets.com/.test(item.buttonAction)) && pn.userName!=="") {
                        url = "data-item='nbbets' href='" + item.buttonAction + "'";
                    }else{
                        url = "href='" + item.buttonAction + "'";
                    }
                }
                var classB = ((index % 2 !== 0) ? "left " : "right ") + s;
                var text = item.buttonName, target = ' target="_blank"';
                var html = '<a ' + url + target + ' class="btn btn-link ' + classB + '">' + text + '</a>';
                if (pn.userType && (s === "trial-gobut" || s === "register-gobut" || s === "login-gobut")) {
                    return;
                }
                buttons.push(html);
            });
            return '<div class="item reset_btn ' + classA + '">'
                + '    <a class="item-img" ' + href + target + '>'
                + '			<img ' + dataSrc + 'src="' + imageUrl + '">'
                + '	   </a>'
                + '    <div class="carousel-caption">' + buttons.join("") + '</div>'
                + '</div>';
        } else {
            return '<div class="item ' + classA + '">'
                + '    <a class="item-img" ' + href + target + '>'
                + '			<img ' + dataSrc + 'src="' + imageUrl + '">'
                + '	   </a>'
                + '</div>';
        }
    };
    //  生成 Banner 对象集合
    var grepBanners = function (data) {
        var banners = [];
        $.each(data, function (index, item) {
            var $banner =
                {
                    "index": item.rank,
                    "beginTime": item.beginTime,
                    "endTime": item.endTime,
                    "minUrl": item.defaultAction || item.maxImageAction,
                    "maxUrl": item.defaultAction || item.maxImageAction,
                    "minImageHttpUrl": item.minImageHttpUrl,
                    "maxImageHttpUrl": item.maxImageHttpUrl,
                    "target": item.targetType === "target" ? "target" : "",
                    "buttons": item.templateButtons,
                    "templateType": item.templateType,
                    "textDescription": item.textDecoration,
                    "jsonObj": item.jsonObj
                };
            banners.push($banner);
        });
        return resort(grepGame(banners, [function (n) {
            if(n.endTime != ""){
                return (n.beginTime - pn.sys_now) <= 0 && (n.endTime - pn.sys_now) >= 0;
            }else{
                return (n.beginTime - pn.sys_now) <= 0;
            }
        }]), "index");
    };
    //  生成的轮播图
    var generate = function (data) {
        if(data === undefined) {
            return false;
        }
        var banners = grepBanners(data);
        if (!banners) {
            return false;
        }
        var indicators = [], inners = [];
        $.each(banners, function (index, item) {
            indicators.push(indicatorsHtml(index, item));
            inners.push(innerHtml(index, item));
        });
        if (indicators.length && inners.length) {
            $indicators.empty();
            $inner.empty();
            $indicators.append(indicators.join(""));
            $inner.append(inners.join(""));
        }

        updateRedirectUrl();

        bindCarouselEvent();
    };

    function generateBannerCMSDataKey() {

        if (pn.cmsDataKey == "NEW_PLAYER") {
            return "newPlayerBanner";
        } else if (pn.cmsDataKey == "ORDINARY_MEMBER") {
            return "ordinaryMemberBanner";
        } else if (pn.cmsDataKey == "VIP_MEMBER") {
            return "vipMemberBanner";
        }
        return "NEW_PLAYER";
    }

    var bindCarouselEvent = function() {
        var $carousel = $("#carousel-home");
        $carousel.find(".carousel-inner").on("click", ".item-img", function () {
            _hmt.push(['_trackEvent', 'AG8', '主站', '主轮播图', '主轮播图']);
        });
        $carousel.find(".carousel-indicators").on("click", "li", function () {
            var len = $carousel.find(".carousel-indicators li").length;
            var _len = $(this).find("~li").length;
            _hmt.push(['_trackEvent', 'AG8', '主站', '轮播图' + (len - _len), '轮播图' + (len - _len)]);
        });
        $carousel.on('slide.bs.carousel', function (e) {
            var image = $(e.relatedTarget).find('img[data-src]');
            if(image.length > 0) {
                image.attr('src', image.data('src'))
                image.removeAttr('data-src')
            }
        });
    };

    var d_cms_cache = utils.storage.getItem('cms_' + generateBannerCMSDataKey());
    if(d_cms_cache != null) {
        generate(JSON.parse(d_cms_cache));
    }
    //  首页轮播图
    cmsHelper.getScriptResult(generateBannerCMSDataKey(), getUserLevel())
        .done(generate)
        .fail(cms_failure);
});

//cms生成首页弹窗
function open_windows(openwindows) {
    var openWin = openwindows;
    var hrefStr = "";
    if(openWin.maxUrl){
        if(openWin.maxUrl !== ""){
            hrefStr = openWin.maxUrl;
        }else{
            hrefStr = "javascript:void(0)";
        }
    }else{
        hrefStr = "javascript:void(0)";
    }

    var html = '<div class="ads-wrap memberday-ads-js memberday-ads-js-one" data-window-id="' + openwindows.id + '" style="display: none;">'
        +'  <div class="ads-container large">'
        +'    <a class="btn-close">'
        +'      <img src="'+openwindows.minImageHttpUrl+'">'
        +'    </a>'
        +'    <a href="'+hrefStr+'" class="mainad" target="' + openwindows.target + '">'
        +'       <img src="'+openwindows.maxImageHttpUrl+'" alt="">'
        +'    </a>'
        +'    <p class="subtitle"> </p>'
        +'    <div class="btn-group">'
    var buttonHtml = "";
    if (openwindows.buttons.length > 0) {
        for (var i = 0; i < openwindows.buttons.length; i++) {
            var button = openwindows.buttons[i];
            var target = openwindows.target;
            // buttonHtml += '<a href="' + button.url + '" target="' + openwindows.target + '" class="btn-item ">' + button.text + '</a>';
            buttonHtml += generateBtnHTML(button , target);
        }
    }
    html += buttonHtml;
    html +='</div>'
        +'</div>';
    return html;
}
function open_windows_two(openwindowstwo) {
    var openWin = openwindowstwo;
    var hrefStr = "";
    if(openWin.maxUrl){
        if(openWin.maxUrl !== ""){
            hrefStr = openWin.maxUrl;
        }else{
            hrefStr = "javascript:void(0)";
        }
    }else{
        hrefStr = "javascript:void(0)";
    }

    var html = '<div class="ads-wrap memberday-ads-js memberday-ads-js-two" data-window-id="' + openwindowstwo.id + '" style="display: none;">'
        +'  <div class="ads-container large">'
        +'    <a class="btn-close">'
        +'      <img src="'+openwindowstwo.minImageHttpUrl+'">'
        +'    </a>'
        +'    <a href="'+hrefStr+'" class="mainad" target="' + openwindowstwo.target + '">'
        +'       <img src="'+openwindowstwo.maxImageHttpUrl+'" alt="">'
        +'    </a>'
        +'    <p class="subtitle"></p>'
        +'    <div class="btn-group">'
    var buttonHtml = "";
    if (openwindowstwo.buttons.length > 0) {
        for (var i = 0; i < openwindowstwo.buttons.length; i++) {
            var button = openwindowstwo.buttons[i];
            var target = openwindowstwo.target;
            // buttonHtml += '<a href="' + button.url + '" target="' + openwindows.target + '" class="btn-item ">' + button.text + '</a>';
            buttonHtml += generateBtnHTML(button , target);
        }
    }
    html += buttonHtml;
    html +='</div>'
        +'</div>';
    return html;
}
function open_windows_thr(openwindowsthr) {
    var openWin = openwindowsthr;
    var hrefStr = "";
    if(openWin.maxUrl){
        if(openWin.maxUrl !== ""){
            hrefStr = openWin.maxUrl;
        }else{
            hrefStr = "javascript:void(0)";
        }
    }else{
        hrefStr = "javascript:void(0)";
    }

    var html = '<div class="ads-wrap memberday-ads-js memberday-ads-js-thr" data-window-id="' + openwindowsthr.id + '" style="display: none;">'
        +'  <div class="ads-container large">'
        +'    <a class="btn-close">'
        +'      <img src="'+openwindowsthr.minImageHttpUrl+'">'
        +'    </a>'
        +'    <a href="'+hrefStr+'" class="mainad" target="' + openwindowsthr.target + '">'
        +'       <img src="'+openwindowsthr.maxImageHttpUrl+'" alt="">'
        +'    </a>'
        +'    <p class="subtitle"></p>'
        +'    <div class="btn-group">'
    var buttonHtml = "";
    if (openwindowsthr.buttons.length > 0) {
        for (var i = 0; i < openwindowsthr.buttons.length; i++) {
            var button = openwindowsthr.buttons[i];
            var target = openwindowsthr.target;
            // buttonHtml += '<a href="' + button.url + '" target="' + openwindows.target + '" class="btn-item ">' + button.text + '</a>';
            buttonHtml += generateBtnHTML(button , target);
        }
    }
    html += buttonHtml;
    html +='</div>'
        +'</div>';
    return html;
}

function generateBtnHTML(button , target){
    var classStr = "";
    var styleStr = "";
    if(button.buttonImage){
        styleStr = ' style="background-image : url(' + button.buttonImage + ')"';
        classStr = ' class="btn-item2"';
        button.text = "";
    }else{
        styleStr = '';
        classStr = ' class="btn-item"';
    }
    return '<a href="' + button.url + '" target="' + target + '" ' + styleStr + classStr + '>' + button.text + '</a>';
}

/**
 * 校验IP是否是第一次访问
 */
function verifyIPFirstFunc(data) {
    if(!_visit_ip_first) {
        $.request({
            type : 'GET' ,
            url : "/api/cms/verifyIpFirst" ,
            async : false
        }).done(function (response) {//_visit_ip_first
            if(response && response.successful) {
                if(response.data == 0) {
                    _visit_ip_first = true;
                }
            }
        });
    }
    return _visit_ip_first;
}

function windowBanners (data) {
    // if (!pn.userName) {
    //     return;
    // }
    var html = "";
    // $.request({
    //     url: "/api/cms/window-code",
    //     async:false
    // }).done(function (response) {
    //     var showData = new Array();
    //     if (response.successful) {
    //         var res = response.data;
    //         var showTemplateIdArr = res.codeList;
    //         var inWhiteList = false;
    //         for(var i = 0 ; i < data.length ; i++){
    //             inWhiteList = false;
    //             for(var j = 0 ; j < showTemplateIdArr.length ; j++){
    //                 if(pn.userName){
    //                     if(data[i].id === showTemplateIdArr[j] && data[i].textDescription === "1"){
    //                         showData.push(data[i]);
    //                         inWhiteList = true;
    //                         break;
    //                     }
    //                 }
    //             }
    //             if(!inWhiteList && data[i].textDescription !== "1"){
    //                 var userLevel = getUserLevel();
    //                 var userLevelStr = data[i].userLevelStr;
    //                 //未选择用户等级
    //                 if(userLevelStr === undefined || userLevelStr === null || userLevelStr === ""){
    //                     showData.push(data[i]);
    //                     continue;
    //                 }
    //                 //当前用户等级在CMS配置中
    //                 if(userLevelStr.indexOf("," + userLevel + ",") > -1){
    //                     showData.push(data[i]);
    //                     continue;
    //                 }
    //             }
    //         }
    //     }
    //     if(showData){
    //         //去掉重复项
    //         var newShowData = [];
    //         for(var i = 0 ; i < showData.length ; i++){
    //             //verifyIPFirst
    //             if(showData[i].textDescription === "2") {
    //                 if(verifyIPFirstFunc() && newShowData.indexOf(showData[i]) === -1) {
    //                     newShowData.push(showData[i]);
    //                 }
    //             }else if(newShowData.indexOf(showData[i]) === -1){
    //                 newShowData.push(showData[i]);
    //             }
    //         }
    //         if(newShowData){
    //             html = windowBanner_(newShowData);
    //         }
    //     }
    // });
    html = windowBanner_(data);
    return html;
}
function windowBanner_(data){
    var openwindow = [];
    $.each(data, function (index, item) {
        var buttonList = [];
        if (item.templateButtons.length > 0) {
            $.each(item.templateButtons, function (i, t) {
                var button = {
                    text: t.buttonName,
                    url: t.buttonAction,
                    buttonImage : t.buttonImage
                }
                buttonList.push(button);
            });
        }
        var banner ={
            "id": item.id,
            "index": item.rank,
            "beginTime": item.beginTime,
            "endTime": item.endTime || 2000000000000,
            "minUrl": item.defaultAction || item.maxImageAction,
            "maxUrl": item.defaultAction || item.maxImageAction,
            "minImageHttpUrl": item.minImageHttpUrl,
            "maxImageHttpUrl": item.maxImageHttpUrl,
            "target": item.targetType === "target" ? "target" : "",
            "buttons": buttonList,
            "templateType": item.templateType,
            "information": item.textDescription,
        };
        openwindow.push(banner);
    });
    var result = resort(grepGame(openwindow , [function (n) {
        return (n.beginTime - pn.sys_now) <= 0 && (n.endTime - pn.sys_now) >= 0;
    }]) , "index");
    return result;
}
$(document).ready(function () {
    try {
        cmsHelper.getScriptResult(CMS_MODEL.openwindow,getUserLevel())
            .then(realvideopage)
            .done(function(response){      
                if(!response){
                    return;
                }
                function showDialog(dialog,nextDialog){
                    return {
                        start:function(){
                            var key=dialog.key,
                                dom=dialog.dom;
                            key += dom.data("windowId");
                            var h1 = dom.html();
                            if(!dom || h1 === undefined){
                                nextDialog.start();
                            }
                            var isVerified = _Cookie_.get(key);
                            if (!isVerified) {
                                dom.fadeIn();
                                _Cookie_.set(key, "We are a family", 365);
                                dom.on("click",'.btn-close',function(){
                                    dom.remove();
                                    if(nextDialog){
                                        nextDialog.start();
                                    }
                                });
                            }else{
                                if(nextDialog) {
                                    nextDialog.start();
                                }
                            }
                        }
                    }
                }
                var one=showDialog({key:'HOME_ADS_MOVE_ONCE_ONE','dom':$(".wrapper").find('.ads-wrap.memberday-ads-js-one')},null);
                var two= showDialog({key:'HOME_ADS_MOVE_ONCE_TWO','dom':$(".wrapper").find('.ads-wrap.memberday-ads-js-two')},one);
                var three= showDialog({key:'HOME_ADS_MOVE_ONCE_THREE','dom':$(".wrapper").find('.ads-wrap.memberday-ads-js-thr')},two);
                three.start();
            })
            .fail(cms_failure);

        function realvideopage(data) {  
            if(data === undefined) {
                return false;
            }  
            var html = windowBanners(data);
            if(null==html||!html.length){
                return false;
            }
            $.each(html , function (index , item) {
                if(item.minImageHttpUrl == ""){
                    //没有后缀，认为cms没有配置小图，使用默认的
                    item.minImageHttpUrl ='/assets/images/others/common_close.png';
                }

                if(index === 0){
                    var h = open_windows(item);
                    $('body .wrapper').append(h);
                }else if(index === 1){
                    var h = open_windows_two(item);
                    $('body .wrapper').append(h);
                }else if(index === 2){
                    var h = open_windows_thr(item);
                    $('body .wrapper').append(h);
                }
            });
            return true;
        }
    } catch (e) {
        console.log(e);
    }
});
