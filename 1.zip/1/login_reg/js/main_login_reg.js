$.ajaxSetup({cache: false});
jQuery.cachedScript = function (url, options) {
    options = $.extend(options || {}, {
        dataType: "script",
        cache: true,
        url: url
    });
    return jQuery.ajax(options);
};

var _Cookie_ = {
    set: function (key, value, expiredays) {
        var exp = expiredays * 24 * 60 * 60;
        var expire = new Date();
        expire.setTime(expire.getTime() + (expiredays || 0) * 24 * 60 * 60 * 1000);
        //  IE 下不支持 max-age
        document.cookie =
            key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; expires=" + expire.toUTCString())
            + "; domain=" + window.location.hostname + "; path=/;";
        //document.cookie = key + "=" + encodeURI(value) + ((expiredays === null) ? "" : "; max-age=" + exp) + ";";
    },
    get: function (key) {
        var arr, reg = new RegExp("(^|\\s+)" + key + "=(.*?)(;|$)");
        if (arr = document.cookie.match(reg))
            return (arr[0]);
        else
            return null;
    },
    del: function (key) {
        if (_Cookie_.get(key)) {
            var date = new Date();
            date.setTime(date.getTime() - 10000);
            //  IE 下不支持 max-age
            document.cookie = key + "=v; expires =" + date.toUTCString()
                + "; domain=" + window.location.hostname + "; path=/;";
            //document.cookie = key + "=v; max-age=0";
        }
    }
};

(function () {
    var redirect = utils.getQueryString("redirect");
    if (redirect){
        $("form input[name='redirect']").val(redirect);
        //登录的情况下直接跳到重定向地址
        if(pn.userType == "0" && redirect.indexOf("egames=1") >= 0 && redirect.indexOf("trial=true") < 0) {
            // location.href = location.origin + '/index.html?login&redirect=' + encodeURIComponent(redirect);
            history.pushState({url: '/index.html?login', title: document.title}, document.title, '/index.html?login')
        }else {
            // 改变url地址，不刷新页面
            var url = location.origin + '/index.html?login'
            //此判断只针对电游的游戏试玩
            if(redirect && redirect.indexOf("egames=1") >= 0 && redirect.indexOf("trial=true") >= 0) {
                url = location.origin + "/index.html?trial"
            }
            history.pushState({url: url, title: document.title}, document.title, url)
        }
    }
    try {
        if (games && $.isArray(games)) {
            var _js = $.grep(games, function (n, i) {
                var _id = n[_wms_key.id];
                return _id === "banner_dev" || /^wms_js_/i.test(_id);
            });
            if (_js) {
                var jsFile = _js[0],
                    name = jsFile[_wms_key.image1];
                var url = pn.gameStaticUrl + "static/__static/electronicgames/" + name + "?" + jsFile[_wms_key.popular];
                var hm = document.createElement("script");
                hm.src = url;
                var s = document.getElementsByTagName("script")[0];
                s.parentNode.insertBefore(hm, s);
            }
        }
    } catch (Error) {
    }
})();

$(document).ready(function () {
    $("#fast-reg-but").on("click" , function(){
        $("#loginModal").modal('hide');
        switch (pn.registerVerificationType) {
            case 2 :
                $(".kaptcha").hide();
                break;
            case 3 :
                $(".kaptcha").next(".register-captcha").hide();
                break;
        }
        setTimeout(function() {
            $('.modal-backdrop').remove();
        }, 200);
    });
    $("#quick-login-btn, #fast-reg-but, #try-reg-but").on("click" , function(){
        $(".captchaWrap").remove();
        $(".kaptcha").removeClass("success warning arrow_box").find(".tip_icon").removeClass("success warning shake_img");
        $(".kaptcha").find(".tip_text").text("点此进行验证");
        setTimeout(function() {
            $('.modal-backdrop').remove();
        }, 200);
    });

    $('.navbar-right .dropdown-toggle').click(function () {
        showSpeedyActive(this, true);
    });

    //  图片验证码-刷新 verification-group-js
    $(".verification-group-js img").on("click", function () {
        var type = $(this).data("type");
        utils.getImageCode("/api/captcha?site=10&type=" + type + "&_d=" + (1 - new Date()),$(this));
    });

    /**
     * 点击任意位置右上边弹出效果隐藏
     */
    $('.header-overlay').click(function () {
        $('body').toggleClass('is-active');
    });
    /**
     * 点击任意位置右上边弹出效果隐藏
     */
    $(document).on('click', '.header-wrap .dropdown-menu', function (e) {
        e.stopPropagation();
    });


    $("input[name=autoLoginName]").on('change', function () {
        $(this).parents('.form-group').next().toggleClass('hide', parseInt($(this).val(), 10));
    });

    setTimeout(function(){
        var b1 = window.lib && lib.hasParam('trial');
        var b2 = window.lib && !lib.hasParam('/register/trial/basic/success');
        if ((b1 && b2)  || window.lib && lib.hasParam('trygame')) {
            $("#try-reg-but").click();
            $("#regModal").modal('hide');
            $("#loginModal").modal('hide');
            $('body').addClass('is-active');
            setTimeout(function() {
                $('.modal-backdrop').remove();
            }, 200);
        }
    }, 400);


    //保存推荐码到cookie缓存
    var _recommend_code = window.lib && lib.getUrlParam('recommendcode');
    if (_recommend_code) {
        var expiresDate = new Date();
        expiresDate.setTime(expiresDate.getTime() + (15 * 60 * 1000));
        $.cookie(constants.recommendcode, _recommend_code, {path: '/', expires: expiresDate});
        showRecommend();
    }

    if (window.lib && lib.hasParam('register') && !lib.hasParam('trial/basic/success') || window.lib && lib.hasParam('bitcoin/preRegister')) {
        $("#fast-reg-but").click();
        setTimeout(function() {
            $('.modal-backdrop').remove();
        }, 200);
        showRecommend();
    }


    var $btnSignIn = $('.btn-sign-in'),
        $btnSignUp = $('.btn-sign-up'),
        $signInCont = $('.sign-in-wrap'),
        $loginModal = $('#loginModal'),
        $regModal = $('#regModal');

    // sign-in sign-up modal
    $('#loginModal, #regModal, #chargeModal, #tryplayModal').on('show.bs.modal', function (e) {
        $('.modal-header .nav-tabs li:eq(0) a', $(e.target)).trigger('click');
    }).on('hidden.bs.modal',function(){

    });

    $(document).on("click", '.header-wrap .modal .close', function() {
        $('body').removeClass('is-active');
    });

    $('.forget-password-wrap3').find('.btn-submit').click(function () {
        $(this).parents('.modal-content').hide();
        $('.sign-in-wrap').fadeIn('fast');
    });
    $('.btn-forget-password').click(function () {
        $(this).parents('.modal-content').hide().next().fadeIn('fast');
    });
    $btnSignIn.click(function () {
        $signInCont.show().siblings().hide();
        $signInCont.find('.nav-tabs li').removeClass('active');
        $('a[href="#quick-login"]').tab("show");
    });
    $('.go-sign-in').click(function () {
        $regModal.modal('hide');
        $loginModal.modal({
            "backdrop": false,
            "show": true
        });
        $loginModal.find('.modal-content').hide();
        $('.sign-in-wrap').fadeIn('fast').find('.nav-tabs li').removeClass('active');
        $('a[href="#quick-login"]').tab("show");
    });
    $btnSignUp.click(function () {
        $loginModal.modal('hide');
        $regModal.modal({
            "backdrop": false,
            "show": true
        });
        $regModal.find('.modal-content').hide().fadeIn('fast');
        $('a[href="#phone-login"]').parent().addClass('active').siblings().removeClass('active');
    });
    $('[data-toggle="tooltip"]').tooltip();
});

$(".verification-group-js img").on("click", function () {
    var type = $(this).data("type");
    utils.getImageCode("/api/captcha?site=10&type=" + type + "&_d=" + (1 - new Date()),$(this));
});

function showRecommend() {
    if (lib.hasValue($.cookie(constants.recommendcode))) {
        $('.recommend-group').each(function () {
            var sidebar = $(this);
            sidebar.hide();
        });
    }
}

$.loading = function () {
    if (arguments.length > 0 && arguments[0] === false) {
        $('.loading-mask').remove();
        return false;
    }
    $('body').loading();
};




