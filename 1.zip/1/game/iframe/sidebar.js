var getGameImage = function (game) {
    return pn.gameStaticUrl + "static/__static/electronicgames/" + game[_wms_key.image1];
};

function resizeFrame() {
    // var $FrameWrap = $(".iframe"), $iFrame = $FrameWrap.find("iframe");
    // if ($iFrame.length) {
    //     var clientHeight = $(window).height(),
    //         clientWidth = $(window).width();
    //     var $sidebar = $(".sidebar-wrap");
    //     if (clientHeight < 625) {
    //         $sidebar.removeClass("show").addClass("hide");
    //     } else {
    //         $sidebar.removeClass("hide").addClass("show");
    //     }
    //     if ($sidebar.length > 0 && !$sidebar.hasClass("hide") && !parseInt($sidebar.css("right"))) {
    //         clientWidth = clientWidth - 90;
    //     }

    //     $iFrame.css({
    //         "height": clientHeight + "px",
    //         "width": clientWidth + "px"
    //     });
    //     $FrameWrap.css({
    //         "height": clientHeight + "px",
    //         "padding-bottom": "0px",
    //         "width": clientWidth + "px"
    //     });
    //     // 兼容4500*3000大屏幕样式
    //     if(screen.availWidth>=4500&&screen.availWidth<5120&&screen.availHeight>=3000&&screen.availHeight<4096){
    //         // var top = parseFloat((3000-1638/2910*4404)/2).toFixed(1)+'px';
    //         $sidebar.css({"paddingTop":"260.5px","paddingBottom":"260.5px",'background-color': '#000'});
    //         $sidebar.find("ul").addClass('black');
    //     }else if(screen.availWidth>=5120&&screen.availHeight>=4096){
    //         // var top = parseFloat((4096-1870/3324.33*5024)/2).toFixed(1)+'px';
    //         $sidebar.css({"paddingTop":"635px","paddingBottom":"635px",'background-color': '#000'});
    //         $sidebar.find("ul").addClass('big_black');
    //     }
    // }
}

function openWindow(b, d, a) {
    var f;
    if (window.screen.width == 800 && window.screen.height == 600) {
        f = "yes"
    } else {
        f = "no"
    }
    var c = $(window).width() ? ($(window).width() - d) / 2 : 0;
    var e = $(window).height() ? ($(window).height() - a) / 2 : 0;
    var g = "height=" + a + ", width=" + d + ",left=" + c + ",top=" + e + ", scrollbars= " + f + ",resizable=yes,toolbar=no,directories=no,menubar=no,locationbar=no,personalbar=no,statusbar=no";
    window.open(b, "_blank", g)
}

$(document).ready(function () {
    $("div.carousel.slide").on("slide.bs.carousel", function (e) {
        var target = e.relatedTarget, imgNode = $("img", target), src = imgNode.src;
        imgNode.each(function (index, item) {
            if (!item.src) {
                $(item).attr("src", $(item).data("src"));
            }
        });
    });

    $('.sidebar-wrap').on('mouseleave', function (e) {
        $('.sidebar-wrap li').removeClass('active');
    });

    // Get Started
    $(".sidebar-wrap .btn-trigger").on("click", function (e) {
        $('.btn-trigger').toggleClass('active');
    });

    $('.sidebar-wrap li').hover(function () {
        $(this).addClass('active');
        if ($(this).find('.dropdown-content').length > 0) {
            $(this).siblings().removeClass('active');
            $('.sidebar-wrap li').addClass('no-arrow');
        }
    }, function () {
        $('.sidebar-wrap li').removeClass('active').removeClass('no-arrow');
    });

    $('.btn-open').on('click', function () {
        $('.sidebar-wrap').animate({right: '0%'}, resizeFrame);
        window.localStorage.setItem("likeCloseOpen", true);
    });

    $('.btn-close').on('click', function () {
        $('.sidebar-wrap').animate({right: '-100px'}, resizeFrame);
        $('.sidebar-wrap li').removeClass('active');
        window.localStorage.setItem("likeCloseOpen", false);
    });

    //  站内信
    var $letter = $("#letter"), $letterContent = $(".js-letter-content");

    function updateMessageCount() {
        if (pn.userType == '1') {
            $.request({
                url: "/api/letters/unread"
            }).done(function (response) {
                if(response.successful){
                    var data = response.data;
                    var noticeCount = data.notice;
                    var perferentialCount = data.perferential;
                    var count = noticeCount + perferentialCount;
                    count > 0?$letter.find(".badge").show().text(count):$letter.find(".badge").hide();
                }else{
                    logConsole(response.message);
                }
            }).fail(function(e){
                logConsole(e);
            });
        }
    }

    updateMessageCount();
    setInterval(updateMessageCount, 1000 * 120);

    function getLetter(page) {
        page = page || 1;
        $letterContent.parent().loading();
        $letterContent.attr("data-page", page);
        return $.request({
            url: "/api/letters?page_number="+page+"&page_size=1&status=ALL"
        }).done(function (response) {
            if (response.successful) {
                var $letterBadge = $(".badge.letter"), count = parseInt($letterBadge.text() || 0) - 1;
                count = count < 0 ? 0 : count;
                if (!count) {
                    $letterBadge.hide();
                }
                $letterBadge.text(count);
            }
        }).always(function () {
            $letterContent.parent().loading("close");
        });
    }
    function getText(html) {
        var reg = /(<a\s.*?>.*?<\/a>)/g;
        var result = reg.exec(html);
        var link = {}, index = 0;
        while (result && result.length) {
            var value = result[0], key = "__" + index + "__";
            link[key] = value;
            html = html.replace(value, key);
            result = reg.exec(html);
            index++
        }
        var $content = $("<div>" + html + "</div>"),text=null;
        if($content.html().indexOf("<img")>-1){
            text = $content.html().replace(/<(?!\/?img)[^<>]*>/ig,"");
        }else{
            text = $content.text();
            text = text.length > 58? text.substring(0,60)+"...":text;
        }
        $.each(link, function (index, item) {
            text = text.replace(index, item);
        });
        return text;
    }
    function ShowLetter(page) {
        return getLetter(page || 1).done(function (response) {
            var data = response.data;
            if (response.successful) {
                var totalMap = data.total;
                var notice = parseInt(totalMap["notice"]);
                var preferential = parseInt(totalMap["perferential"]);
                var total = (notice+preferential ? notice+preferential : "") || "";
                var title, content;
                $letterContent.attr("data-total", total);
                var $content = $letterContent.find("p");
                var letterId,msgType,all;
                if (total) {
                    var item = data["details"][0];
                    var contentStr = item["content"][0];
                    msgType = item["msgType"];
                    letterId = item["id"];
                    content = contentStr.replace(/\/\*[\s\S]*?\*\//g,"").replace(/<!--[\s\S]*?-->/g,"");//删除注释
                    content = getText(content);
                    title = item["title"];
                    $content.attr("data-status", item["status"]);
                    $content.attr("data-id", item["id"]);
                    $(".letter-date").text(item["createdDate"].substr(0, 16));
                } else {
                    title = "暂无消息";
                    content = "暂无消息";
                    $(".letter-date").text("");
                }
                if (total <= 1) {
                    $letterContent.find('a.left').hide();
                    $letterContent.find('a.right').hide();
                }
                $(".letter-title").html(title.length > 20 ? title.substr(0, 20) : title);
                //设置为已读
                if($letterContent.parents("li.active")){

                    //标记为已读
                    $.request({
                        type: "PUT",
                        url: '/api/letters/READ',
                        data: {
                            "ids": letterId,
                            "msgType": msgType
                        }
                    }).done(function (resoponse) {
                        if(resoponse.successful){
                            //更新未读站内信
                            updateMessageCount();
                        }
                    }).fail(function(e){
                        logConsole(e);
                    });

                }
                $content.html(content);
            }
        });
    }

    $letter.on('mouseover', function () {
        if ($(this).parent().hasClass('active')) {
            return;
        }
        var page = parseInt($letterContent.attr("data-page") || 1);
        ShowLetter(page);
    });

    $letterContent.find("a.left").on("click", function () {
        var page = parseInt($letterContent.attr("data-page") || 1);
        page = (page - 1) < 1 ? 1 : (page - 1);
        $letterContent.attr("data-page", page);
        ShowLetter(page);
    });

    $letterContent.find("a.right").on("click", function () {
        var page = parseInt($letterContent.attr("data-page") || 1),
            total = parseInt($letterContent.attr("data-total") || 1);
        page = (page + 1) > total ? total : (page + 1);
        $letterContent.attr("data-page", page);
        ShowLetter(page);
    });

    //  快速转额
    var $localCredit = $("#localCredit"),
        $gameCredit = $("#gameCredit");

    function refreshBalance() {
        return $.request({
            url: "/api/game/amount/refresh?" + (new Date() - 1),
            type: "post",
            data: {platForm: ___platForm}
        }).done(function (response) {
            if (response.successful) {
                var data = response.data;
                $localCredit.text(data[0] + "元");
                $gameCredit.text(data[1] + "元");
            }
        }).fail(function(e){
            logConsole(e);
        });
    }

    var $refreshBalance = $("#refreshBalance");
    var handleShowBalance = function () {
        if ($(this).parent().hasClass('active')) {
            return;
        }
        if ($refreshBalance.hasClass("processed")) {
            return;
        }
        $refreshBalance.addClass("processed");
        $localCredit.text("加载中...");
        $gameCredit.text("加载中...");
        refreshBalance().always(function () {
            $refreshBalance.removeClass("processed");
        });
    };
    $("#transfer").on('mouseenter', handleShowBalance);
    $refreshBalance.on("click", handleShowBalance);

    var $transferBalance = $("#transferBalance");
    $transferBalance.on("click", function () {
        if ($transferBalance.hasClass("processed")) {
            return;
        }
        $transferBalance.addClass("processed");
        $localCredit.text("转额中...");
        $gameCredit.text("转额中...");
        $.request({
            url: "/api/game/transfer?" + (new Date() - 1),
            type: "post",
            data: {platForm: ___platForm}
        }).done(function (response) {
            if (response.successful) {
                refreshBalance().always(function () {
                    $transferBalance.removeClass("processed");
                }).fail(function () {
                    $localCredit.text("转额失败,请重试");
                    $gameCredit.text("转额失败,请重试");
                    $transferBalance.removeClass("processed");
                });
            } else {
                $transferBalance.removeClass("processed");
            }
        }).fail(function(e){
            logConsole(e);
        });
    });

    //  快速充值
    $("#goPayPage").on("click", function () {
        openWindow("/ucenter/pay/payIndex/index.html?min=true", 1420, 800);
    });

    //  自助洗码
    $("#rebate").on("click", function () {
        openWindow("/ucenter/rebate/view/index.html?min=true", 1420, 800);
    });

    //  热门优惠
    var $hotdealsCarousel = $("#carousel-2");
    (function () {
        function filterHotDeals(data){
            return resort(grepGame(data, [function (n) {
                if(n.endTime){
                    if(n.beginTime < pn.sys_now && n.endTime > pn.sys_now){
                        return true;
                    }
                    return false;
                }else {
                    return n.beginTime < pn.sys_now;
                }
            }]), "rank");
        }
        // todo vip cms对接时,删除兼容以前的版本
        //if (typeof cmsHelper != "undefined") {  
            if(pn.terminal=="MAIN"){
            	$.request({
                    url:"/api/cms/promotions",
                    data:{
                        moduleCode:"010153",
                        pageNumber:"1",
                        pageSize:"20"
                    }
                }).done(createSidebar)
                .fail(function(e){
                    logConsole(e);
                });
            }else{
                $.request({
                    url:"/api/cms/promotions",
                    data:{
                        moduleCode:"040401",
                        pageNumber:"1",
                        pageSize:"20"
                    }
                })
                .done(createSidebar)
                .fail(function(e){
                    logConsole(e);
                });
            }
	    //} else {
            var hotdeals = grepGame(games, [function (n) {
                var _h = /^wms_hotdeals_/i.test(n[_wms_key.id]);
                if (!_h) {
                    return _h;
                }
                var remark = n[_wms_key.remark] || "",
                    remarks = remark.split("||");
                if (remarks.length !== 2) {
                    return false;
                }
                try {
                    var beginTime = remarks[0];
                    var endTime = remarks[1];
                    return isBeforeToNow(beginTime) && !isBeforeToNow(endTime);
                } catch (Error) {
                    return false;
                }
            }]);
            if (!hotdeals.length) {
                return;
            }
            $(".hotdeals-total").html(hotdeals.length);
            hotdeals = resort(hotdeals, _wms_key.popular);
            var html = [];
            $.each(hotdeals, function (index, item) {
                var url = item[_wms_key.bonusUrl];
                if (url) {
                    url = 'target="_blank" href="' + url + '"';
                }
                var image1 = getGameImage(item);
                var isActive = index ? "" : "active";
                var isData = index ? "data-" : "";
                html.push('<div class="item ' + isActive + '"> <a ' + url + '><img ' + isData + 'src="' + image1 + '"></a> </div>');
            });
            $hotdealsCarousel.find(".carousel-inner").html(html.join(""));
            $hotdealsCarousel.on("slide.bs.carousel", function (e) {
                var current = $(e.relatedTarget).prevAll().length + 1;
                $(".hotdeals-current").html(current);
            });

        function createSidebar(data){
            var data = data.data.list;
            var dataArry = [];
            var nowTimes = pn.sys_now ? pn.sys_now : new Date().getTime();
            for(var u=0; u<data.length; u++){                
                if(data[u].endTime){
                    var endTime = new Date (data[u].endTime.replace(/-/g,'/')).getTime();
                    if(endTime > nowTimes){
                        dataArry.push(data[u]);
                    }
                }else if(data[u].beginTime){
                    dataArry.push(data[u]);
                }
            }
            if (dataArry.length > 0) {
                createHtml(dataArry);
            }
        }
        function createHtml(hotDealsSources){
            $(".hotdeals-total").html(hotDealsSources.length);
            var html = [];
            $.each(hotDealsSources, function (index, item) {
                var target = item.targetType == "target" ? "_blank" : "";
                var url = 'target="' + target + '" href="' + item.defaultAction + '"';
                var image1 = item.maxImageHttpUrl;
                var isActive = index ? "" : "active";
                var isData = index ? "data-" : "";
                html.push('<div class="item ' + isActive + '"> <a ' + url + '><img ' + isData + 'src="' + image1 + '"></a> </div>');
            });
            $hotdealsCarousel.find(".carousel-inner").html(html.join(""));

            $hotdealsCarousel.on("slide.bs.carousel", function (e) {
                var current = $(e.relatedTarget).prevAll().length + 1;
                $(".hotdeals-current").html(current);
            });
        }
    })();

    var lastTime = 0;
    $(window).on("resize", function () {
        if (lastTime) {
            clearTimeout(lastTime);
        }
        lastTime = setTimeout(function () {
            resizeFrame();
        }, 500);
    });

    /**
     * 记录用户行为，用户下一次进入游戏后，根据上一次行为决定收起按钮是否开启。
     */
    var s = window.localStorage.getItem("likeCloseOpen");
    if (s === undefined || s === null || s === '' || s === 'true') {
        $('.sidebar-wrap').animate({right: '0%'}, resizeFrame);
    } else {
        $('.sidebar-wrap').animate({right: '-100px'}, resizeFrame);
        $('.sidebar-wrap li').removeClass('active');
        $('.btn-trigger').toggleClass('active');
    }

    $('#go-baccarat-agq-game').on('click', function () {
        //支付错误
        layer.confirm("您即将跳转AG旗舰厅,确定要跳转吗？", {
                skin: 'btn-reverse',
                title: ' ',
                btn: ['取消', '确定'] //按钮
            },
            function (index) {
                layer.close(index);
            }, function () {
                window.open("/game/play/agq", "_blank");
            });
    });
});
