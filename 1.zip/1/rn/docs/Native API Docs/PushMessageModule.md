## 消息推送
#### Native Module名称: UMPushModule
### Native接口：
---

#### 1.修改用户别名 

**接口名称：** 
- ` addAlias`
- 例:addAlias(alias,type)

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|type |是  |string |别名类型   |
|alias |是  |string | 别名    |

 **返回Promise**
```
code : 200

msg : ****
```
---
#### 2.删除用户别名 

**接口名称：** 
- ` deleteAlias`
- 例:deleteAlias(alias,type)

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|type |是  |string |别名类型   |
|alias |是  |string | 别名    |

 **返回Promise**
```
code : 200

msg : ****
```
---

#### 3.添加标签 

**接口名称：** 
- ` addTag`
- 例:addTag(tag)

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|tag |是  |string |标签名   |

 **返回Promise**
```
code : 200

msg : ****
```
---

#### 4.删除标签 

**接口名称：** 
- ` deleteTag`
- 例:deleteTag(tag)

**参数：** 

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|tag |是  |string |标签名   |

 **返回Promise**
```
code : 200

msg : ****
```
---

### Native回调监听:

#### 1.点击推送通知进入前台

**消息名称：** 
- ` NATIVEEVENT_UMENG_NOTIFICATION_CLICK`

 **返回Promise**
```
code : 200

msg : ****

data : ****
```

