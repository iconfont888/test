## 基础交互模块
#### 原生Moudle名称: AppModule
### Native接口：
#### 基础返回值类型定义:
```
所有返回值都为promise，对应基础数据结构为
{
    "code": 200,  //成功的code 为 200，其余值为失败或其他错误码
    "data": {}, //data是json字符串
	"msg":""
}
```
## 注:除code和msg外，后面所有定义的返回参数都为data里的键值对
---
#### 1.获取地理位置

**接口名称：** 
- ` getAddress`


 **返回参数说明** 
 data :{
    address : ***,
}

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|address |  string |  地理位置|

#### 2.获取轮询域名列表

**接口名称：** 
- ` getDomainLoopJsonPath`


 **返回参数说明** 
  data :{
    paths : ***,
}

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|paths |  array |  域名列表json数组|

#### 3.获取根域名

**接口名称：** 
- ` getDomainApiPath`


 **返回参数说明** 
  data :{
    domain : ***,
}


|参数名|类型|说明|
|:-----  |:-----|-----                           |
|domain |  string |  根域名|

#### 4.设置百度统计的用户(登陆后调用,仅Android端)

**接口名称：** 
- ` setBaiduUserId`

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|data |  string |  用户名|

 **返回参数说明** 

(无)

#### 5.获取App内置渠道域名

**接口名称：** 
- ` getAppChannel`


 **返回参数说明**  
data :{
    channel : ***,
}
 
|参数名|类型|说明|
|:-----  |:-----|-----                           |
|channel |  string |  渠道名|


#### 6.获取缓存大小

**接口名称：** 
- ` getCacheSize`


 **返回参数说明** 
data :{
    cacheSize : ***,
}

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|cacheSize |  String |  缓存大小|


#### 7.清除缓存

**接口名称：** 
- ` clearAppData`


 **返回参数说明** 
 data :{
    cacheSize : ***,
}

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|cacheSize |  String |  缓存大小|

#### 8.获取设备码

**接口名称：** 
- ` getDeviceId`


 **返回参数说明** 
 data :{
    deviceId : ***,
}

|参数名|类型|说明|
|:-----  |:-----|-----                           |
|deviceId |  String |  设备码|

#### 9.获取网络信息

**接口名称：** 
- ` getNetworkInfo`


 **返回参数说明** 

data :{
    networkType : ***,
    networkOperators : ***
}
|参数名|类型|说明|
|:-----  |:-----|-----                           |
|networkType |  String |  网络类型|
|networkOperators |  String |  运营商|

#### 10.获取是否jenkins打包

**接口名称：** 
- ` getIsJenkins`


 **返回参数说明** 

data :{
    isJenkins : false,
}
|参数名|类型|说明|
|:-----  |:-----|-----                           |
|isJenkins |  bool |  是否jenkins打包|

---

### 指纹识别&&刷脸识别

#### 1.是否支持指纹识别

**接口名称：** 
- ` deviceSupportTouchID`


 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           
| code |  int |  		code定义:200 支持;1.设备不支持;2.没有录入指纹;3.没有指纹识别权限 -android; 4.失败次数太多,稍后再试 -ios; |
| msg |  string |  不支持的错误描述.support为true时，该值为空字符串|

#### 2.是否支持刷脸识别

**接口名称：** 
- ` deviceSupportFaceID`

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
| code |  int |  code定义:200 支持;1.设备不支持;2.没有录入刷脸;3.没有刷脸识别权限 -android; 4.失败次数太多,稍后再试 -ios; |
| msg |  string |  不支持的错误描述.support为true时，该值为空字符串|

#### 3.调用指纹识别

**接口名称：** 
- ` useTouchID`

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
| code |  int |  code定义:200 识别成功;5.识别失败 ;6.用户取消 -ios;7.失败次数太多 -ios|
| msg |  string |  不成功的错误描述.success为true时，该值为空字符串|

#### 4.调用刷脸识别

**接口名称：** 
- ` useFaceID`

 **返回参数说明** 

|参数名|类型|说明|
|:-----  |:-----|-----                           |
| code |  int |  code定义:200 识别成功;5.识别失败 ;6.用户取消 -ios;7.失败次数太多 -ios|
| msg |  string |  不成功的错误描述.success为true时，该值为空字符串|

### App常量

APPLICATION_ID   //app包名
DEBUG            //是否开启
VERSION_CODE     //
VERSION_NAME
CODE_PUSH_TYPE
DOMAIN_API_PATH
DOMAIN_LOOP_JSON_PATH
IS_JENKINS
UMENG_ALIASTYPE