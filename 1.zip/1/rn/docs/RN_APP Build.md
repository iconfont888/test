##IOS
>RN_IOS 构建安装地址:

http://10.55.57.37:8083/jenkins/job/B79\_IOS\_RN/
>
>用户名:
>webFront
>密码:
>ag866.com
>


##Android
>RN_Android 构建安装地址:
>
>http://10.11.16.116:7002/view/APP/job/b79-tiger-mobile-main-android-rn/
>
>用户名:
>admin
>密码:
>admin




