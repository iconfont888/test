#bin/bsah - l

export LANG=en_US.UTF-8

export LANGUAGE=en_US.UTF-8

export LC_ALL=en_US.UTF-8




#产品ID
PRODUCT_ID=$2
#产品ID 获取APPNAME
if [ $PRODUCT_ID == "main" ];then
    APP_NAME="tcbs_app_rn"
    DISPLAY_NAME="亞游集團"
else if [ $PRODUCT_ID == "main" ];then
    APP_NAME="cityHero_rn"
    DISPLAY_NAME="城市英雄"
fi

#基于同一个工程,不可变部分使用该变量
BASIC_APP_NAME="tcbs_app_rn"

#证书类型 --- 企业证书 or 个人证书
CertificateType=$3


#根据证书类型 修改CodeSignType
if [ $CertificateType == "Personal" ];then
#签名证书类型
CodeSignType="New"
else
#签名证书类型
CodeSignType="Old"
fi

#codePush类型，DEV,SIT,UAT,PE
CodePushType=$4
CodePushEnv_DEV="DEV"
CodePushEnv_SIT="SIT"
CodePushEnv_UAT="UAT"
CodePushEnv_PE="PE"
if [ $PRODUCT_ID == "main" ];then
CodePushDEV_KEY="ftxWzaI_o83zhjVvWlAYtd0A2_-Daf256146-1b18-4f82-8513-204bc3986496"

CodePushSIT_KEY="CS_9J1HuiDVjoFKPTUJQorvm6Iaraf256146-1b18-4f82-8513-204bc3986496"

CodePushUAT_KEY="81FO_KLuauJTqdWoD35HrScZ-hnraf256146-1b18-4f82-8513-204bc3986496"

CodePushPE_KEY="3iZMMP3G9xnWxFy8iQw0b_ovhAD5af256146-1b18-4f82-8513-204bc3986496"
else
CodePushDEV_KEY="TO-SloawuPRj10nK7sQCIlzCZa5maf256146-1b18-4f82-8513-204bc3986496"

CodePushSIT_KEY="JHm6NY_k3BA0jBFg_cHOQeDrgsWaaf256146-1b18-4f82-8513-204bc3986496"

CodePushUAT_KEY="MC-LvicfmgR7AFqek2CNQGphTE0Caf256146-1b18-4f82-8513-204bc3986496"

CodePushPE_KEY="yus73ofCdQHWvNkpzjrc3CEs57GUaf256146-1b18-4f82-8513-204bc3986496"
fi

#IsJenkinsBuild
if [ $5 == "true" ];then
IsJenkinsBuild="YES"
else
IsJenkinsBuild="NO"
fi

#Jenkins构建号
JenkinsNumber=$6

#渠道域名
APPChannel=$7

#扩展参数字段
EXTRA_PARAMS=$8

#VERSION_CODE
VERSION_CODE=$9

#VERSION_NAME
VERSION_NAME=${10}

#LAUNCHER_SCHEME
LAUNCHER_SCHEME=${11}

#LAUNCHER_HOST
LAUNCHER_HOST=${12}

#请求域名
if [ -n "$DOMAIN_API_PATH" ]; then
DOMAIN_API_PATH=${13}
#域名轮询列表字符串
DOMAIN_LOOP_JSON_PATH=${14}
else
DOMAIN_LOOP_JSON_PATH=${13}
fi



echo "jenkins配置参数---------------"
echo "ProductID==${ProductID}"
echo "CertificateType==${CertificateType}"
echo "CodePushType==${CodePushType}"
echo "CodeSignType==${CodeSignType}"
echo "APP_NAME==${APP_NAME}"
echo "IsJenkinsBuild==${IsJenkinsBuild}"
echo "DOMAIN_API_PATH==${DOMAIN_API_PATH}"
echo "DOMAIN_LOOP_JSON_PATH==${DOMAIN_LOOP_JSON_PATH}"





#cocoapods 安装
echo "当前路径------------------：$(PWD)"
cd /Users/otis/.jenkins/workspace/B79_IOS_RN/ios
pod install --verbose --no-repo-update

#编译运行环境，历史参数，默认写死
BUILDENV="Release"

#archive文件路径
ARCHIVE_PATH="./Release-iphoneos"
#要上传的ipa文件路径
IPA_PATH="$HOME/Desktop/TCBSBuildProject/OutputIPAs/${APP_NAME}/${CodePushType}/${CertificateType}"
echo ${IPA_PATH}
#ExportOptions.plist路径
EXPORT_PLIST_PATH="$HOME/Desktop/TCBSBuildProject/ExportOptions/${APP_NAME}/${CodePushType}/${CertificateType}/ExportOptions.plist"
#本地nginx打包地址
NGINX_PATH="/usr/local/var/www/${APP_NAME}/${CodePushType}/${CertificateType}"


#根据产品ID和证书类型
#1.修改BunldId
#2.修改Provisioning Profile
#3.修改Develop_TEAM
if [ $PRODUCT_ID == "main" ];then
    if [ $CertificateType == "Personal" ];then
        sed -i 's#com.cityHero.AG8#com.otis.AG8#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#b79main_profile#hybrid_release_profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#KMSR9444AG#8NXYQ9552M#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
#        sed -i '' 's/com.cityHero.AG8/com.otis.AG8/g' ${APP_NAME}.xcodeproj/project.pbxproj
        echo "修改bundle id------------------修改bundle id = com.otis.AG8"
        echo "修改Provisioning Profile------------------修改Provisioning Profile = hybrid_release_profile"
        echo "修改DEVELOPMENT_TEAM------------------修改DEVELOPMENT_TEAM = 8NXYQ9552M"
    else
        sed -i 's#com.otis.AG8#com.cityHero.AG8#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#hybrid_release_profile#b79main_profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#8NXYQ9552M#KMSR9444AG#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        echo "修改bundle id------------------修改bundle id = com.cityHero.AG8"
        echo "修改Provisioning Profile------------------修改Provisioning Profile = b79main_profile"
        echo "修改DEVELOPMENT_TEAM------------------修改DEVELOPMENT_TEAM = KMSR9444AG"
    fi
else if [ $PRODUCT_ID == "egame" ];then
    if [ $CertificateType == "Personal" ];then
        sed -i 's#com.cityHero.AG8#com.otis.CityHero#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#com.otis.AG8#com.otis.CityHero#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#b79main_profile#CityHeroRelease_Profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#hybrid_release_profile#CityHeroRelease_Profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#KMSR9444AG#8NXYQ9552M#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        #        sed -i '' 's/com.cityHero.AG8/com.otis.AG8/g' ${APP_NAME}.xcodeproj/project.pbxproj
        echo "修改bundle id------------------修改bundle id = com.otis.CityHero"
        echo "修改Provisioning Profile------------------修改Provisioning Profile = CityHeroRelease_Profile"
        echo "修改DEVELOPMENT_TEAM------------------修改DEVELOPMENT_TEAM = 8NXYQ9552M"
    else
        sed -i 's#com.cityHero.AG8#com.otis.CityHero#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#com.otis.AG8#com.otis.CityHero#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#b79main_profile#CityHeroRelease_Profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#hybrid_release_profile#CityHeroRelease_Profile#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        sed -i 's#KMSR9444AG#8NXYQ9552M#' ${BASIC_APP_NAME}.xcodeproj/project.pbxproj
        #        sed -i '' 's/com.cityHero.AG8/com.otis.AG8/g' ${APP_NAME}.xcodeproj/project.pbxproj
        echo "修改bundle id------------------修改bundle id = com.otis.CityHero"
        echo "修改Provisioning Profile------------------修改Provisioning Profile = CityHeroRelease_Profile"
        echo "修改DEVELOPMENT_TEAM------------------修改DEVELOPMENT_TEAM = 8NXYQ9552M"
    fi
fi

echo "=================即将编译的环境====${BUILDENV}============="

echo "=================clean================="
xcodebuild clean -workspace "./${BASIC_APP_NAME}.xcworkspace" -scheme "${BASIC_APP_NAME}" -configuration "${BUILDENV}"
echo "+++++++++++++++++build+++++++++++++++++"

#cocoapods
xcodebuild -archivePath "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive" -workspace "./${BASIC_APP_NAME}.xcworkspace" -sdk iphoneos -scheme "${BASIC_APP_NAME}" -configuration "${BUILDENV}" archive

########修改Info.Plist######

#修改product_id
/usr/libexec/PlistBuddy -c "Set :APP_PRODUCT_ID ""$PRODUCT_ID" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"

#修改应用名称
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName ""$DISPLAY_NAME" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"


#CodePushDeploymentKey
if [ $CodePushType == $CodePushEnv_DEV ]; then
/usr/libexec/PlistBuddy -c "Set :CodePushDeploymentKey ""$CodePushDEV_KEY" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
elif [ $CodePushType == $CodePushEnv_SIT ]; then
/usr/libexec/PlistBuddy -c "Set :CodePushDeploymentKey ""$CodePushSIT_KEY" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
elif [ $CodePushType == $CodePushEnv_UAT ]; then
/usr/libexec/PlistBuddy -c "Set :CodePushDeploymentKey ""$CodePushUAT_KEY" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
elif [ $CodePushType == $CodePushEnv_PE ]; then
/usr/libexec/PlistBuddy -c "Set :CodePushDeploymentKey ""$CodePushPE_KEY" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi

#修改CodePushType字段
/usr/libexec/PlistBuddy -c "Set :CodePushType ""$CodePushType" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"



#请求域名 优先级高于域名轮询
if [ -n "$DOMAIN_API_PATH" ]; then
/usr/libexec/PlistBuddy -c "Set :DOMAIN_API_PATH ""$DOMAIN_API_PATH" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi


#轮询域名列表  -- 当请求域名为空 && 域名轮询列表不为空 才写入
if [ -z "$DOMAIN_API_PATH" ]; then
if [ -n "$DOMAIN_LOOP_JSON_PATH" ]; then
/usr/libexec/PlistBuddy -c "Set :DOMAIN_LOOP_JSON_PATH ""$DOMAIN_LOOP_JSON_PATH" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi
fi


#签名证书类型
if [ -n "$CodeSignType" ]; then
/usr/libexec/PlistBuddy -c "Set :CodeSignType ""$CodeSignType" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi

#是否构建来源于jenkins
if [ -n "$IsJenkinsBuild" ]; then
/usr/libexec/PlistBuddy -c "Set :isJenkinsBuild ""$IsJenkinsBuild" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi

#jenkins构建编号
if [ -n "$JenkinsNumber" ]; then
/usr/libexec/PlistBuddy -c "Set :JenkinsBuildNumber ""$JenkinsNumber" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
fi


#修改Channel
/usr/libexec/PlistBuddy -c "Set :Channel ""$APPChannel" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"

#修改额外参数
/usr/libexec/PlistBuddy -c "Set :EXTRA_PARAMS ""$EXTRA_PARAMS" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"

#修改build号
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion ""$VERSION_CODE" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"
#修改version号
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ""$VERSION_NAME" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"

#修改scheme
/usr/libexec/PlistBuddy -c "Set :CFBundleURLTypes:0:CFBundleURLSchemes:0 ""$LAUNCHER_SCHEME" "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive/Products/Applications/${BASIC_APP_NAME}.app/info.plist"



xcodebuild -exportArchive -archivePath "${ARCHIVE_PATH}/${BASIC_APP_NAME}.xcarchive" -exportPath "${IPA_PATH}" -exportOptionsPlist "${EXPORT_PLIST_PATH}" -allowProvisioningUpdates
#把本地ipa复制到nginx路径下 以供打包使用
mkdir -p "${NGINX_PATH}"
cp "${IPA_PATH}/${APP_NAME}.ipa" "${NGINX_PATH}"
#生成对应的二维码
qrencode -o /usr/local/var/www/${APP_NAME}/${CodePushType}/${CertificateType}.png "itms-services://?action=download-manifest&url=https://uatdown.ag288.com/${APP_NAME}/${CodePushType}/${CertificateType}/${APP_NAME}.plist"
