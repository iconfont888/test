//
//  Config.h
//  tcbs_app_rn
//
//  Created by Otis on 04/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#ifndef Config_h
#define Config_h



/*&************ Info.plist Key ******************/

/**
 DOMAIN_API_PATH(根域名)

 */
#define kDOMAIN_API_PATH @"DOMAIN_API_PATH"


/**
 DOMAIN_LOOP_JSON_PATH(域名轮询列表)

 */
#define kDOMAIN_LOOP_JSON_PATH @"DOMAIN_LOOP_JSON_PATH"


/**
 AppChannel(APP动态域名)
 
 */
#define kAppChannel @"Channel"

/*&******************************/


#pragma mark - 事件监听key
//注:对于RN监听事件定义和OC通知事件定义，消息名保持一致。即: sendMessage:name 和 postNotification:noti中 name isEqule noti.name.
/*&************ ReactNative 监听 native事件 定义 ******************/
/*&*********** 推送模块 ***********/
/**
 友盟初始化
 
 */
#define kNativeMethod_InitialPushMessageUtil @"NativeEvent_willInitialUmengComponent"


/**
 点击推送通知进入前台
 
 */
#define kNativeMethod_RecievePushMessage @"NATIVEEVENT_UMENG_NOTIFICATION_CLICK"

/**
 全局消息通知
 
 */
#define kNativeMethod_EventMessage @"NATIVE_EVENT_MESSAGE"



/*&******************************/


#pragma mark - 原生接口相关Key定义
/*&************ Native接口Code定义 ******************/
/*&*
 通用类型
 */
#define NativeInterfaceSuccessCode @"200"

#define NativeInterfaceFailCode @"-1"

#define NativeInterfaceErrorCode @"500" //通常是I/O错误，例如写入文件失败等。

/*&***** 不支持指纹&刷脸*****/
/**
 设备不支持识别指纹或刷脸
 */
#define BiometricsSupportFailCode_NotSupport @"1"
#define BiometricsSupportFailDescription_NotSupportTouch @"该设备不支持指纹识别"
#define BiometricsSupportFailDescription_NotSupportFace @"该设备不支持刷脸识别"

/**
 没有设置指纹或刷脸
 */
#define BiometricsSupportFailCode_UserNotSet @"2"
#define BiometricsSupportFailDescription_UserNotSetTouch @"您还没有设置开启指纹识别功能"
#define BiometricsSupportFailDescription_UserNotSetFace @"您还没有设置开启刷脸识别功能"

/**
 失败次数太多，暂时不可用
 */
#define BiometricsSupportFailCode_FailedTooMany @"4"
#define BiometricsSupportFailDescription_FailedTooMany @"验证失败次数太多，请稍后再试！"


/*&***** 指纹&刷脸验证失败*****/
/**
 验证失败
 */
#define BiometricsVertifyFailCode_Failed @"1"
#define BiometricsVertifyFailDescription_Failed @"验证失败"

/**
 用户取消
 */
#define BiometricsVertifyFailCode_Cancel @"2"
#define BiometricsVertifyFailDescription_Cancel @"用户取消"

/**
 失败次数太多
 */
#define BiometricsVertifyFailCode_FailedTooMany @"3"
#define BiometricsVertifyFailDescription_FailedTooMany @"失败次数太多"

/*&******************************/


/*&***** 获取设备信息失败*****/

/**
 设备ID获取失败
 */
#define GetDeviceIdFailedDescription @"获取设备ID失败"

/**
 设备网络获取失败
 */
#define GetDeviceNetworkTypeFailedDescription @"获取设备网络信息失败"

/**
 设备运营商获取失败
 */
#define GetDeviceNetworkOperatorsFailedDescription @"获取设备运营商获取失败"

#endif /* Config_h */
