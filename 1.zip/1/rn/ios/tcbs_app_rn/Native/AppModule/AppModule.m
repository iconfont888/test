//
//  AppModule.m
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//
#if __has_include("RCTConvert.h")
#import "RCTConvert.h"
#else
#import <React/RCTConvert.h>
#endif

#import "AppModule.h"
#import "AGLocationManager.h"
#import "AGBiometricsAuth.h"
#import "AGDeviceUtil.h"
#import <WebKit/WebKit.h>
#import <BaiduMobStat/BaiduMobStat.h>
@implementation AppModule


RCT_EXPORT_MODULE();

#pragma mark 获取定位地址
/**
 获取定位地址
 
 @param getAddress JS中调用方法名
 @param RCTPromiseResolveBlock 获取成功或失败,成功返回值为完整中文地址 ex:'菲律宾(null)马卡蒂Bel AirAyala Ave ExtAyala Ave Ext';失败见错误码
 @param RCTPromiseRejectBlock 获取异常。
 */
RCT_REMAP_METHOD(getAddress, getAddress:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *address =  [AGLocationManager getRecordLocationString];
    NSDictionary *data = @{@"address":address};
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
    resolve(result);
  });
//  [[AGLocationManager sharedInstance] getLocationSuccess:^(NSString *address) {
//    NSDictionary *data = @{@"address":address};
//    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
//    resolve(result);
//  } Failed:^(NSString *des) {
//    des = des && des.length > 0 ? des : @"";
//    NSDictionary *data = @{@"address":des};
//    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
//    resolve(result);
//  }];
}


#pragma mark 获取域名轮询列表
/**
 获取域名轮询列表
 
 @param getDomainLoopJsonPath JS中调用方法名
 @param RCTPromiseResolveBlock 获取域名轮询列表成功或失败. 成功ex: '{domain1,domain2...}';失败,返回字符串 - '未获取到DomainLoopJsonPath'
 @param RCTPromiseRejectBlock 获取异常，暂未处理。
 */
RCT_REMAP_METHOD(getDomainLoopJsonPath, getDomainLoopJsonPath:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *value = [LocalUtil getInfoPlistStringWithKey:kDOMAIN_LOOP_JSON_PATH];
    if (value && value.length > 0) {
      NSArray *domainList = [value componentsSeparatedByString:@","];
      NSDictionary *data = @{@"paths":domainList};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }else{
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:[NSArray array]];
      resolve(result);
    }
  });
}


#pragma mark 获取根域名
/**
 获取根域名
 
 @param getDomainLoopJsonPath JS中调用方法名
 @param RCTPromiseResolveBlock 获取根域名成功. ex: 'https://m.ag13874.com'
 @param RCTPromiseRejectBlock 获取根域名失败,返回字符串 - '未获取到DOMAIN_API_PATH'
 */
RCT_REMAP_METHOD(getDomainApiPath, getDomainApiPath:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *domain = [LocalUtil getInfoPlistStringWithKey:kDOMAIN_API_PATH];
    if (domain && domain.length > 0) {
      NSDictionary *data = @{@"domain":domain};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }else{
      NSDictionary *data = @{@"domain":@""};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }
  });
}


#pragma mark - 获取App内置渠道域名
/**
 获取App内置渠道域名
 
 @param RCTPromiseResolveBlock  获取App内置渠道域名成功或失败。返回值appChannel字符串
 @param RCTPromiseRejectBlock   获取App内置渠道域名异常，暂未实现
 */
RCT_REMAP_METHOD(getAppChannel, getAppChannel:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *channel = [LocalUtil getInfoPlistStringWithKey:kAppChannel];
    if (channel && channel.length > 0) {
      NSDictionary *data = @{@"channel":channel};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }else{
      NSDictionary *data = @{@"channel":@""};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }
  });
}


#pragma mark - 获取缓存大小
/**
 获取缓存大小
 
 @param RCTPromiseResolveBlock  获取缓存大小成功
 @param RCTPromiseRejectBlock   获取缓存大小异常，暂未实现。
 */
RCT_REMAP_METHOD(getCacheSize, getCacheSize:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    double value = [NSString getCacheSize];
    NSString *valueString = [NSString descriptionWithBytes:value saveNumber:1];
    NSDictionary *data = @{@"cacheSize":valueString};
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
    resolve(result);
  });
}


#pragma mark - 清除缓存
/**
 清除缓存
 
 @param RCTPromiseResolveBlock  清除缓存成功
 @param RCTPromiseRejectBlock   清除缓存异常
 */
RCT_REMAP_METHOD(clearAppData, clearAppData:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    [NSString deleteCache];
    double value = [NSString getCacheSize];
    NSString *valueString = [NSString descriptionWithBytes:value saveNumber:1];
    NSDictionary *data = @{@"cacheSize":valueString};
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
    resolve(result);
//    if (value) {
//
//    }else{
//      reject(NativeInterfaceErrorCode,@"删除本地文件发生I/O错误",nil);
//    }
  });
}



#pragma mark - 是否支持指纹识别

/**
 是否支持指纹识别
 
 @param deviceSupportTouchID JS中调用方法名
 @param RCTPromiseResolveBlock 支持指纹识别
 @param RCTPromiseRejectBlock 不支持指纹识别。多种错误码，参考宏定义。
 */
RCT_REMAP_METHOD(deviceSupportTouchID, deviceSupportTouchID:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    int code = [AGBiometricsAuth canSupportTouchID];
    NSDictionary *result = nil;
    if (code == 0) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
      
    }else{
      if (code == -7) {
        //用户没有设置
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_UserNotSet Data:nil Message:BiometricsSupportFailDescription_UserNotSetTouch];
      }else if(code == -8){
        //验证失败次数太多
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_FailedTooMany Data:nil Message:BiometricsSupportFailDescription_FailedTooMany];
      }else{
        //不支持
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_NotSupport Data:nil Message:BiometricsSupportFailDescription_NotSupportTouch];
      }
    }
    resolve(result);
  });
}


#pragma mark - 是否支持刷脸识别

/**
 是否支持刷脸识别
 
 @param deviceSupportFaceID JS中调用方法名
 @param RCTPromiseResolveBlock 支持刷脸识别
 @param RCTPromiseRejectBlock 不支持刷脸识别。多种错误码，参考宏定义。
 */
RCT_REMAP_METHOD(deviceSupportFaceID, deviceSupportFaceID:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    int code = [AGBiometricsAuth canSupportFaceID];
    NSDictionary *result = nil;
    if (code == 0) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
      
    }else{
      if (code == -7) {
        //用户没有设置
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_UserNotSet Data:nil Message:BiometricsSupportFailDescription_UserNotSetFace];
      }else if(code == -8){
        //验证失败次数太多
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_FailedTooMany Data:nil Message:BiometricsSupportFailDescription_FailedTooMany];
      }else{
        //不支持
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsSupportFailCode_NotSupport Data:nil Message:BiometricsSupportFailDescription_NotSupportFace];
      }
    }
    resolve(result);
  });
}


#pragma mark - 调用指纹识别

/**
 调用指纹识别
 
 @param useTouchID JS中调用方法名
 @param RCTPromiseResolveBlock 指纹识别成功
 @param RCTPromiseRejectBlock 指纹识别失败。多种错误码，参考宏定义。
 */
RCT_REMAP_METHOD( , useTouchID:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    [AGBiometricsAuth useTouchIDSuccess:^{
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:nil];
      resolve(result);
    } Failed:^(int failCode) {
      NSDictionary *result = nil;
      if (failCode == -2) {
        //用户取消
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_Cancel Data:nil Message:BiometricsVertifyFailDescription_Cancel];
      }else if (failCode == -8){
        //失败次数太多
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_FailedTooMany Data:nil Message:BiometricsVertifyFailDescription_FailedTooMany];
      }else{
        //识别失败
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_Failed Data:nil Message:BiometricsVertifyFailDescription_Failed];
      }
      resolve(result);
    }];
  });
}


#pragma mark - 调用刷脸识别

/**
 调用刷脸识别
 
 @param useFaceID JS中调用方法名
 @param RCTPromiseResolveBlock 刷脸识别成功
 @param RCTPromiseRejectBlock 刷脸识别失败。多种错误码，参考宏定义。
 */
RCT_REMAP_METHOD(useFaceID, useFaceID:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    [AGBiometricsAuth useFaceIDSuccess:^{
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:nil];
      resolve(result);
    } Failed:^(int failCode) {
      NSDictionary *result = nil;
      if (failCode == -2) {
        //用户取消
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_Cancel Data:nil Message:BiometricsVertifyFailDescription_Cancel];
      }else if (failCode == -8){
        //失败次数太多
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_FailedTooMany Data:nil Message:BiometricsVertifyFailDescription_FailedTooMany];
      }else{
        //识别失败
        result = [BuildJSParamUtil buildFailedDataWithCode:BiometricsVertifyFailCode_Failed Data:nil Message:BiometricsVertifyFailDescription_Failed];
      }
      resolve(result);
    }];
  });
}


#pragma mark - 获取设备ID
/**
 获取设备ID
 
 @param getDeviceId JS中调用方法名
 @param RCTPromiseResolveBlock 获取设备ID成功
 @param RCTPromiseRejectBlock 获取设备ID失败
 */
RCT_REMAP_METHOD(getDeviceId, getDeviceId:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *deviceId = [AGDeviceUtil deviceIdentify];
    if (deviceId && deviceId.length > 0) {
      NSDictionary *data = @{@"deviceId":deviceId};
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
      resolve(result);
    }else{
      reject(NativeInterfaceErrorCode,GetDeviceIdFailedDescription,nil);
    }
  });
}


#pragma mark - 获取设备网络信息
/**
 获取设备网络信息
 
 @param getDeviceId JS中调用方法名
 @param RCTPromiseResolveBlock 获取设备网络信息成功
 @param RCTPromiseRejectBlock 获取设备运营商失败
 */
RCT_REMAP_METHOD(getNetworkInfo, getNetworkInfo:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    NSString *networkType = [AGDeviceUtil getNetworkType];
    NSString *networkOperator = [AGDeviceUtil getNetworkOperators];
    if (!networkType && !networkOperator) {
      reject(NativeInterfaceErrorCode,@"获取设备网络信息异常",nil);
    }else{
      networkType = networkType ? networkType : @"";
      networkOperator = networkOperator ? networkOperator : @"";
      NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:@{@"networkType":networkType,@"networkOperators":networkOperator}];
      resolve(result);
    }
  });
}



#pragma mark - 获取签名证书类型
/**
 获取签名证书类型
 
 @param getDeviceId JS中调用方法名
 @param RCTPromiseResolveBlock 获取签名证书类型成功
 @param RCTPromiseRejectBlock 获取签名证书类型失败
 */
RCT_REMAP_METHOD(getIosSignatureType, getIosSignatureType:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    //签名类型
    NSString *codeSignTypeString = [[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CodeSignType"] isEqualToString:@"Old"] ? @"1" : @"2";
    NSDictionary *data = @{@"iosSignatureType":codeSignTypeString};
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
    resolve(result);
  });
}


#pragma mark - 是否jenkins打包
/**
 是否jenkins打包
 
 @param getDeviceId JS中调用方法名
 @param RCTPromiseResolveBlock 获取是否jenkins打包成功
 @param RCTPromiseRejectBlock 获取是否jenkins打包失败
 */
RCT_REMAP_METHOD(getIsJenkins, getIsJenkins:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  dispatch_async(dispatch_get_main_queue(), ^{
    //签名类型
    BOOL isJenkinsBuild = [[[[NSBundle mainBundle] infoDictionary] objectForKey:@"isJenkinsBuild"] boolValue];
//    NSString *isJenkins = isJenkinsBuild ? @"true" : @"false";
    NSNumber *isJenkins = @(isJenkinsBuild);
    NSDictionary *data = @{@"isJenkins":isJenkins};
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:data];
    resolve(result);
  });
}


//注意这个常量仅仅在初始化的时候导出了一次，所以即使你在运行期间改变constantToExport返回的值，也不会影响到 JavaScript 环境下所得到的结果。
- (NSDictionary *)constantsToExport{
  NSString *APPLICATION_ID = [NSString getBundleID];
  NSNumber *debug = [NSString isDebugEnv];
  NSString *VERSION_CODE = [NSString getBuildNumber];
  NSString *VERSION_NAME = [NSString getAppVersion];
  NSString *CODE_PUSH_TYPE = [NSString getCodePushType];
  NSString *DOMAIN_API_PATH = [NSString getApiPath];
  NSString *DOMAIN_LOOP_JSON_PATH = [NSString getLoopPath];
  NSNumber *isJenkins = [NSString isJenkinsBuild];
  NSString *UMENG_ALIASTYPE = [NSString getUmengAlias];
  NSString *EXTRA_PARAMS = [NSString getEXTRA_PARAMS];
  NSString *APP_PRODUCT_ID = [NSString getAPP_PRODUCT_ID];
  return @{@"APPLICATION_ID":APPLICATION_ID,@"DEBUG":debug,@"VERSION_CODE":VERSION_CODE,@"VERSION_NAME":VERSION_NAME,@"CODE_PUSH_TYPE":CODE_PUSH_TYPE,@"DOMAIN_API_PATH":DOMAIN_API_PATH,@"DOMAIN_LOOP_JSON_PATH":DOMAIN_LOOP_JSON_PATH,@"IS_JENKINS":isJenkins,@"UMENG_ALIASTYPE":UMENG_ALIASTYPE,@"APP_PRODUCT_ID":APP_PRODUCT_ID,@"EXTRA_PARAMS":EXTRA_PARAMS};
}


RCT_EXPORT_METHOD(set:(NSDictionary *)props
                  resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {
  NSString *name = [RCTConvert NSString:props[@"name"]];
  NSString *value = [RCTConvert NSString:props[@"value"]];
  NSString *domain = [RCTConvert NSString:props[@"domain"]];
  NSString *origin = [RCTConvert NSString:props[@"origin"]];
  NSString *path = [RCTConvert NSString:props[@"path"]];
  NSString *version = [RCTConvert NSString:props[@"version"]];
  NSDate *expiration = [RCTConvert NSDate:props[@"expiration"]];
  
  NSMutableDictionary *cookieProperties = [NSMutableDictionary dictionary];
  [cookieProperties setObject:name forKey:NSHTTPCookieName];
  [cookieProperties setObject:value forKey:NSHTTPCookieValue];
  [cookieProperties setObject:domain forKey:NSHTTPCookieDomain];
  [cookieProperties setObject:origin forKey:NSHTTPCookieOriginURL];
  [cookieProperties setObject:path forKey:NSHTTPCookiePath];
  [cookieProperties setObject:version forKey:NSHTTPCookieVersion];
  [cookieProperties setObject:expiration forKey:NSHTTPCookieExpires];
  
  NSHTTPCookie *cookie = [NSHTTPCookie cookieWithProperties:cookieProperties];
  
  NSLog(@"SETTING COOKIE");
  NSLog(@"%@", cookie);
  
  if (@available(iOS 11.0, *)) {
    dispatch_async(dispatch_get_main_queue(), ^(){
      WKHTTPCookieStore *cookieStore = [[WKWebsiteDataStore defaultDataStore] httpCookieStore];
      [cookieStore setCookie:cookie completionHandler:nil];
      resolve(nil);
    });
  } else {
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
    resolve(nil);
  }
}



RCT_EXPORT_METHOD(clearAll:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {
  if (@available(iOS 11.0, *)) {
    dispatch_async(dispatch_get_main_queue(), ^(){
//      WKHTTPCookieStore *cookieStore = [[WKWebsiteDataStore defaultDataStore] httpCookieStore];
//      [cookieStore getAllCookies:^(NSArray<NSHTTPCookie *> *allCookies) {
//        for(NSHTTPCookie *currentCookie in allCookies) {
//          // Uses the NSHTTPCookie directly has no effect, nor deleted the cookie nor thrown an error.
//          // Create a new cookie with the given values and delete this one do the work.
//          NSMutableDictionary<NSHTTPCookiePropertyKey, id> *cookieData =  [NSMutableDictionary dictionary];
//          [cookieData setValue:currentCookie.name forKey:NSHTTPCookieName];
//          [cookieData setValue:currentCookie.value forKey:NSHTTPCookieValue];
//          [cookieData setValue:currentCookie.domain forKey:NSHTTPCookieDomain];
//          [cookieData setValue:currentCookie.path forKey:NSHTTPCookiePath];
//
//          NSHTTPCookie *newCookie = [NSHTTPCookie cookieWithProperties:cookieData];
//          [cookieStore deleteCookie:newCookie completionHandler:^{}];
//        }
//        resolve(nil);
//      }];
      NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
      
      NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
      
      [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes
                                                 modifiedSince:dateFrom
                                             completionHandler:^{
                                               
                                             }];
    });
  }else{
    NSHTTPCookieStorage *cookieStorage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *c in cookieStorage.cookies) {
      [cookieStorage deleteCookie:c];
    }
    resolve(nil);
  }
}


#pragma mark - 百度事件统计 消息转发
RCT_REMAP_METHOD(setBaiduEvent, setBaiduEvent:(NSString *)key Value:(NSString *)value Resolve:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  [[BaiduMobStat defaultStat] logEvent:key eventLabel:value];
  dispatch_async(dispatch_get_main_queue(), ^{
    NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:nil];
    resolve(result);
  });
}
@end
