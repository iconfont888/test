//
//  BuildJSParamUtil.h
//  tcbs_app_rn
//
//  Created by Otis on 17/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

/*&* 数据结构:
 {
    code:200,
    msg:'',
    data:jsonString
 }
 */


@interface BuildJSParamUtil : NSObject

/**
 构建请求成功的数据

 @param NSString 返回的data数据为json字符串
 @return 完整对象,包含code,msg,data
 */
+ (NSDictionary *)buildSuccessDataWithData:(id)data;


/**
 构建请求失败的数据（逻辑失败，非error）
 
 @param code 错误码
 @param data data对应的字典对象
 @param msg 错误描述
 @return 完整对象,包含code,msg,data
 */
+ (NSDictionary *)buildFailedDataWithCode:(NSString *)code Data:(NSDictionary *)data Message:(NSString *)msg;

@end

