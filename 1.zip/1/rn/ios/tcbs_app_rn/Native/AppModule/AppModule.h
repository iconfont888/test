//
//  AppModule.h
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

@interface AppModule : NSObject<RCTBridgeModule>

- (NSDictionary *)constantsToExport;
@end

