//
//  BuildJSParamUtil.m
//  tcbs_app_rn
//
//  Created by Otis on 17/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "BuildJSParamUtil.h"

@implementation BuildJSParamUtil

/**
 构建请求成功的数据
 
 @param data data对应的字典对象
 @return 完整对象,包含code,msg,data
 */
+ (NSDictionary *)buildSuccessDataWithData:(id)data{
  NSString *jsonString = data ? [NSString jsonStringWithDictionary:data] : @"\"\"";
  return @{@"code":@(200),@"msg":@"",@"data":jsonString};
}



/**
 构建请求失败的数据（逻辑失败failed，非error）

 @param code 错误码
 @param data data对应的字典对象
 @param msg 错误描述
 @return 完整对象,包含code,msg,data
 */
+ (NSDictionary *)buildFailedDataWithCode:(NSString *)code Data:(NSDictionary *)data Message:(NSString *)msg{
  NSString *jsonString = data ? [NSString jsonStringWithDictionary:data] : @"";
  msg = msg ? msg : @"";
  NSNumber *codeNumber = [NSNumber numberWithInt:code.intValue];
  return @{@"code":codeNumber,@"msg":msg,@"data":jsonString};
}
@end
