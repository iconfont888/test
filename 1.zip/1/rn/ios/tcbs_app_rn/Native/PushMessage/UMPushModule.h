//
//  PushMessageUtil.h
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <React/RCTEventEmitter.h>

@interface UMPushModule :RCTEventEmitter<RCTBridgeModule>

+ (instancetype _Nonnull )sharedInstance;

/**
 程序启动初始化友盟

 @param launchOptions 系统启动项
 */
- (void)initialUMengWithLaunch:(NSDictionary *_Nullable)launchOptions;


/**
 iOS10以下使用这个方法接收通知
 
 */
- (void)didReceiveRemoteNotification:(NSDictionary *_Nonnull)userInfo;


/**
 注册远程推送设备--application回调函数

 */
- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *_Nonnull)deviceToken;

@end

