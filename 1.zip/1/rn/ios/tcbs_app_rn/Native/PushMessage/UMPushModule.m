//
//  PushMessageUtil.m
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "UMPushModule.h"
#import <UMCommon/UMCommon.h>
#import <UMPush/UMessage.h>
#import <UMCommon/UMConfigure.h>
#import <UMCommonLog/UMCommonLogHeaders.h>
#import <React/RCTBridgeModule.h>
#import <React/RCTEventDispatcher.h>
#import "Config.h"

@interface UMPushModule ()<UNUserNotificationCenterDelegate>

@end


@implementation UMPushModule
{
  bool hasListeners;
}

static UMPushModule *instance;

+ (instancetype)sharedInstance{
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    instance = [[self alloc] init];
  });
  return instance;
}

- (instancetype)init{
  if (instance != nil) {
    return instance;
  }
  if ((self =[super init])) {
    return self;
  }
  return nil;
}

- (void)sendEventWithName:(NSString *)name body:(id)body{
  if (hasListeners) {
    [super sendEventWithName:name body:body];
  }else{
    NSLog(@"%@事件没有消息订阅者，本次消息发送被阻止",name);
  }
}


/**
 程序启动初始化友盟
 
 @param launchOptions 系统启动项
 */
- (void)initialUMengWithLaunch:(NSDictionary *)launchOptions{
  //开发者需要显式的调用此函数，日志系统才能工作
  [UMCommonLogManager setUpUMCommonLogManager];
  [UMConfigure setLogEnabled:YES];
  
  [UMConfigure initWithAppkey:[NSString getUmengAppKey] channel:nil];
  
  // Push功能配置
  UMessageRegisterEntity * entity = [[UMessageRegisterEntity alloc] init];
  entity.types = UMessageAuthorizationOptionBadge|UMessageAuthorizationOptionAlert|UMessageAuthorizationOptionSound;
  if (@available(iOS 10.0, *)) {
    [UNUserNotificationCenter currentNotificationCenter].delegate=self;
  }
  [UMessage registerForRemoteNotificationsWithLaunchOptions:launchOptions Entity:entity completionHandler:^(BOOL granted, NSError * _Nullable error) {
    if (granted) {
      NSLog(@"regist upush success,deviceToken");
    }else{
      NSLog(@"regist upush failed:%@",error);
    }
  }];
  
  [UMessage openDebugMode:YES];
}

#pragma mark - 收到推送消息回调
/**
 iOS10新增：处理前台收到通知的代理方法

 */
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler API_AVAILABLE(ios(10.0)){
  NSDictionary * userInfo = notification.request.content.userInfo;
  NSLog(@"iOS10新增：处理前台收到通知的代理方法 -- %@",userInfo);
  if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
    [UMessage setAutoAlert:NO];
    //应用处于前台时的远程推送接受
    //必须加这句代码
    [UMessage didReceiveRemoteNotification:userInfo];
    [self sendNotificationToReactNative:userInfo];
  }else{
    //应用处于前台时的本地推送接受
  }
  completionHandler(UNNotificationPresentationOptionSound|UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionAlert);
}

/**
 iOS10新增：处理后台点击通知的代理方法

 */
-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler API_AVAILABLE(ios(10.0)){
  NSDictionary * userInfo = response.notification.request.content.userInfo;
  NSLog(@"iOS10新增：处理后台点击通知的代理方法 -- %@",userInfo);
  if (@available(iOS 10.0, *)) {
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
      //应用处于后台时的远程推送接受
      //必须加这句代码
      [UMessage didReceiveRemoteNotification:userInfo];
      [self sendNotificationToReactNative:userInfo];
    }else{
      //应用处于后台时的本地推送接受
    }
  } else {
    // Fallback on earlier versions
  }
}


/**
 iOS10以下使用这个方法接收通知

 */
- (void)didReceiveRemoteNotification:(NSDictionary *)userInfo
{
  [UMessage setAutoAlert:NO];
  if([[[UIDevice currentDevice] systemVersion]intValue] < 10){
    [UMessage didReceiveRemoteNotification:userInfo];
    [self sendNotificationToReactNative:userInfo];
  }
//  [self sendEventWithName:@"reciveMessage" body:userInfo];
}


/**
 注册远程推送设备--application回调函数
 
 */
- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
  NSString *token = [NSString stringWithFormat:@"%@",[[[[deviceToken description] stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                                       stringByReplacingOccurrencesOfString: @">" withString: @""]
                                                      stringByReplacingOccurrencesOfString: @" " withString: @""]];
  NSLog(@"application--didRegisterForRemoteNotificationsWithDeviceToken:%@",token);
}


/**
 给RN发送推送消息(点击进入前台) -- 包裹标准success response数据
 */
- (void)sendNotificationToReactNative:(NSDictionary *)userInfo{
  NSDictionary *result = [BuildJSParamUtil buildSuccessDataWithData:userInfo];
  [self sendEventWithName:kNativeMethod_RecievePushMessage body:result];
}


RCT_EXPORT_MODULE();
#pragma mark - ReactNative Listener
- (NSArray<NSString *> *)supportedEvents{
  return @[kNativeMethod_RecievePushMessage];
}

#pragma mark - ReactNative Method
/**
 添加推送别名
 @param type 别名类型     eg:'hybrid'
 @param alias 别名        eg:'agmarshall08' -- 会员账号
 @param resolve 设置成功
 @param reject 设置失败
 */
RCT_REMAP_METHOD(addAlias, addAliceWithAliasType:(NSString *)type Alias:(NSString *)alias Resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  [UMessage setAlias:alias type:type response:^(id  _Nullable responseObject, NSError * _Nullable error) {
    NSDictionary *result = nil;
    if (!error) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
    }else{
      result = [BuildJSParamUtil buildFailedDataWithCode:NativeInterfaceFailCode Data:nil Message:@"添加alias别名失败"];
    }
    resolve(result);
  }];
}


/**
 删除推送别名
 
 @param type 别名类型     eg:'hybrid'
 @param alias 别名        eg:'agmarshall08' -- 会员账号
 @param resolve 删除成功
 @param reject 删除失败
 */
RCT_REMAP_METHOD(deleteAlias, deleteAliceWithAliasType:(NSString *)type Alias:(NSString *)alias Resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  [UMessage removeAlias:alias type:type response:^(id  _Nullable responseObject, NSError * _Nullable error) {
    NSDictionary *result = nil;
    if (!error) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
    }else{
      result = [BuildJSParamUtil buildFailedDataWithCode:NativeInterfaceFailCode Data:nil Message:@"删除alias别名失败"];
    }
    resolve(result);
  }];
}




/**
 添加标签
 
 @param tag 标签
 @param resolve 添加成功
 @param reject 添加失败
 */
RCT_REMAP_METHOD(addTag, addTag:(NSString *)tag Resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  [UMessage addTags:tag response:^(id  _Nullable responseObject, NSInteger remain, NSError * _Nullable error) {
    NSDictionary *result = nil;
    if (!error) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
    }else{
      result = [BuildJSParamUtil buildFailedDataWithCode:NativeInterfaceFailCode Data:nil Message:@"添加Umeng标签失败"];
    }
    resolve(result);
  }];
}


/**
 删除标签
 
 @param tag 标签
 @param resolve 删除成功
 @param reject 删除失败
 */
RCT_REMAP_METHOD(deleteTag, deleteTag:(NSString *)tag Resolver:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject){
  [UMessage deleteTags:tag response:^(id  _Nullable responseObject, NSInteger remain, NSError * _Nullable error) {
    NSDictionary *result = nil;
    if (!error) {
      result = [BuildJSParamUtil buildSuccessDataWithData:nil];
    }else{
      result = [BuildJSParamUtil buildFailedDataWithCode:NativeInterfaceFailCode Data:nil Message:@"删除Umeng标签失败"];
    }
    resolve(result);
  }];
}


// 在添加第一个监听函数时触发
-(void)startObserving {
  hasListeners = YES;
  NSLog(@"----------RN开始监听");
  // Set up any upstream listeners or background tasks as necessary
}

// Will be called when this module's last listener is removed, or on dealloc.
-(void)stopObserving {
  hasListeners = NO;
  NSLog(@"----------RN结束监听");
  // Remove upstream listeners, stop unnecessary background tasks
}


@end
