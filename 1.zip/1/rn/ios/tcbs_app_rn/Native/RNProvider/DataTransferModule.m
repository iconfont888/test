//
//  DataTransferModule.m
//  tcbs_app_rn
//
//  Created by Otis on 22/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "DataTransferModule.h"

@implementation DataTransferModule
{
  BOOL hasListeners;
}

RCT_EXPORT_MODULE();

#pragma mark - reload super method
- (void)sendEventWithName:(NSString *)name body:(id)body{
  if (hasListeners) {
    NSLog(@"DataTransferModule向RN发送消息.name=%@------body=%@",name,body);
    [super sendEventWithName:name body:body];
  }
}

#pragma mark - ReactNative Listener
- (NSArray<NSString *> *)supportedEvents{
  return @[kNativeMethod_RecievePushMessage,kNativeMethod_EventMessage];
}


// 在添加第一个监听函数时触发
-(void)startObserving {
  hasListeners = YES;
  NSLog(@"----------RN开始监听");
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recieveNotification:) name:kNativeMethod_EventMessage object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recieveNotification:) name:kNativeMethod_RecievePushMessage object:nil];
  
  // Set up any upstream listeners or background tasks as necessary
}

// Will be called when this module's last listener is removed, or on dealloc.
-(void)stopObserving {
  hasListeners = NO;
  NSLog(@"----------RN结束监听");
  [[NSNotificationCenter defaultCenter] removeObserver:self name:kNativeMethod_EventMessage object:nil];
  [[NSNotificationCenter defaultCenter] removeObserver:self name:kNativeMethod_RecievePushMessage object:nil];
  // Remove upstream listeners, stop unnecessary background tasks
}

- (void)recieveNotification:(NSNotification *)notification{
  NSString *name = notification.name;
  NSDictionary *body = notification.userInfo;
  [self sendEventWithName:name body:body];
}
@end
