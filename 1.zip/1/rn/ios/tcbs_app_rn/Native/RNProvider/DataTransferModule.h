//
//  DataTransferModule.h
//  tcbs_app_rn
//
//  Created by Otis on 22/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <React/RCTEventEmitter.h>

@interface DataTransferModule : RCTEventEmitter<RCTBridgeModule>

@end
