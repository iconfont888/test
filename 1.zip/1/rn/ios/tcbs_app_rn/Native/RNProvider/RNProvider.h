//
//  RNProvider.h
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

/*&* 用于调用RN方法*/

#import <React/RCTEventEmitter.h>

@interface RNProvider : RCTEventEmitter<RCTBridgeModule>

/*&* 1.主线程调用RN方法*/
//- (void)callRNMethodInMainThread:(NSString *)methodName Body:(id)body;
/*&* 2.子线程调用RN方法*/
/*&* 1.主线程调用RN方法*/

@end

