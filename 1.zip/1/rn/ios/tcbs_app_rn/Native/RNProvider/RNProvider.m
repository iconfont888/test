//
//  RNProvider.m
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "RNProvider.h"

@implementation RNProvider

RCT_EXPORT_MODULE();

//- (void)callRNMethodInMainThread:(NSString *)methodName Body:(id)body{
//  dispatch_async(dispatch_get_main_queue(), ^{
//    [self sendEventWithName:methodName body:body];
//  });
//}

- (NSArray<NSString *> *)supportedEvents
{
  return @[@"EVENT_MESSAGE"];
}

RCT_EXPORT_METHOD(callRN){
  NSLog(@"-------------123");
  [self sendEventWithName:@"EVENT_MESSAGE" body:@"123"];
}
@end
