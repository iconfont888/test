//
//  AGLocationManager.m
//  AG8
//
//  Created by Otis on 2018/6/26.
//  Copyright © 2018年 TCBS. All rights reserved.
//
#define kLocationRecord @"kLocationRecord"

#import "AGLocationManager.h"
#import <CoreLocation/CoreLocation.h>
@interface AGLocationManager()<CLLocationManagerDelegate>

@property (copy, nonatomic) void (^getLocationSuccess)(NSString *address);
@property (copy, nonatomic) void (^getLocationFailed)(NSString *des);

@property (copy, nonatomic) NSString *currentCity;//当前城市

@property (copy, nonatomic)  CLLocationManager *locationmanager;//定位服务

@property (copy, nonatomic) NSString *strlatitude;//经度
@property (copy, nonatomic) NSString *strlongitude;//纬度

@end

@implementation AGLocationManager


+ (instancetype)sharedInstance {
    static id sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (void)getLocationSuccess:(void(^)(NSString *address))successBlock
                    Failed:(void(^)(NSString *des))failBlock{
    self.getLocationSuccess = [successBlock copy];
    self.getLocationFailed = [failBlock copy];
    //判断定位功能是否打开
    if ([CLLocationManager locationServicesEnabled]) {
        [self.locationmanager requestAlwaysAuthorization];
        self.currentCity = [NSString new];
        [self.locationmanager requestWhenInUseAuthorization];
        
        //设置寻址精度
        self.locationmanager.desiredAccuracy = kCLLocationAccuracyBest;
        self.locationmanager.distanceFilter = 5.0;
        [self.locationmanager startUpdatingLocation];
    }else {
        if (failBlock) {
            failBlock(@"定位功能没有打开！！");
        }
        NSLog(@"定位功能没有打开！！");
    }
}


+ (void)recordLocation{
  [[AGLocationManager sharedInstance] getLocationSuccess:^(NSString *address) {
    dispatch_async(dispatch_get_main_queue(), ^{
      NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
      NSString *location  = address ? [address copy] : @"";
      [userDefault setObject:location forKey:kLocationRecord];
      [userDefault synchronize];
    });
  } Failed:^(NSString *des) {
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *location  = @"获取定位失败";
    [userDefault setObject:location forKey:kLocationRecord];
    [userDefault synchronize];
  }];
}

+ (NSString *)getRecordLocationString{
  NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
  NSString *value = [userDefault objectForKey:kLocationRecord];
  return value ? value : @"";
}


#pragma mark CoreLocation delegate (定位失败)
//定位失败后调用此代理方法
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if (self.getLocationFailed) {
        self.getLocationFailed([error description]);
    }
}


#pragma mark 定位成功后则执行此代理方法
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    [self.locationmanager stopUpdatingLocation];
    //旧址
    CLLocation *currentLocation = [locations lastObject];
    CLGeocoder *geoCoder = [[CLGeocoder alloc]init];
    //打印当前的经度与纬度
    NSLog(@"%f,%f",currentLocation.coordinate.latitude,currentLocation.coordinate.longitude);
    self.strlatitude = [NSString stringWithFormat:@"%lf",currentLocation.coordinate.latitude];
    self.strlongitude = [NSString stringWithFormat:@"%lf",currentLocation.coordinate.longitude];
    
//    NSDictionary *dic = @{@"lat":self.strlatitude,@"lot":self.strlongitude};
//    NSString *json = [NSString jsonStringWithDictionary:dic];
    
  
  __weak AGLocationManager *wSelf = self;
    //反地理编码
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
      __strong AGLocationManager *sSelf = wSelf;
        if (placemarks.count > 0) {
            CLPlacemark *placeMark = placemarks[0];
            self.currentCity = placeMark.locality;
            if (!sSelf.currentCity) {
//                self.currentCity = @"无法定位当前城市";
                if (sSelf.getLocationFailed) {
                    sSelf.getLocationFailed(@"无法定位当前城市");
                }
            }else{
//                AGLocationModel *model = [[AGLocationModel alloc]init];
//                model.lat = self.strlatitude;
//                model.lot = self.strlongitude;
                NSString *address = [NSString stringWithFormat:@"%@%@%@%@%@%@",placeMark.country,placeMark.subAdministrativeArea,placeMark.locality,placeMark.subLocality,placeMark.thoroughfare,placeMark.name];
                if (sSelf.getLocationSuccess) {
                    sSelf.getLocationSuccess(address);
                }
                NSLog(@"定位地址--%@",address);
                
//                // address dictionary properties
//                @property (nonatomic, readonly, copy, nullable) NSString *name; // eg. Apple Inc.
//                @property (nonatomic, readonly, copy, nullable) NSString *thoroughfare; // street name, eg. Infinite Loop
//                @property (nonatomic, readonly, copy, nullable) NSString *subThoroughfare; // eg. 1
//                @property (nonatomic, readonly, copy, nullable) NSString *subLocality; // neighborhood, common name, eg. Mission District
//                @property (nonatomic, readonly, copy, nullable) NSString *administrativeArea; // state, eg. CA
//                @property (nonatomic, readonly, copy, nullable) NSString *subAdministrativeArea; // county, eg. Santa Clara
//                @property (nonatomic, readonly, copy, nullable) NSString *postalCode; // zip code, eg. 95014
//                @property (nonatomic, readonly, copy, nullable) NSString *ISOcountryCode; // eg. US
//                @property (nonatomic, readonly, copy, nullable) NSString *inlandWater; // eg. Lake Tahoe
//                @property (nonatomic, readonly, copy, nullable) NSString *ocean; // eg. Pacific Ocean
//                @property (nonatomic, readonly, copy, nullable) NSArray<NSString *> *areasOfInterest; // eg. Golden Gate Park
            }
            /*看需求定义一个全局变量来接收赋值*/
//            NSLog(@"----%@",[NSString stringWithFormat:@"%@-%@",placeMark.country,placeMark.locality]);
        }
    }];
    self.locationmanager.delegate = nil;
    self.locationmanager = nil;
}

- (CLLocationManager *)locationmanager{
    if (_locationmanager == nil) {
        _locationmanager = [[CLLocationManager alloc]init];
        _locationmanager.delegate = self;
    }
    return _locationmanager;
}
@end
