//
//  AGLocationManager.h
//  AG8
//
//  Created by Otis on 2018/6/26.
//  Copyright © 2018年 TCBS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGLocationManager : NSObject
+ (instancetype)sharedInstance;

- (void)getLocationSuccess:(void(^)(NSString *address))successBlock
                    Failed:(void(^)(NSString *des))failBlock;

+ (void)recordLocation;

+ (NSString *)getRecordLocationString;
@end
