//
//  LocalUtil.h
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface LocalUtil : NSObject


/**
 获取info.plist里对应值(字符串)

 @param key key值
 @return value(string)
 */
+ (NSString *)getInfoPlistStringWithKey:(NSString *)key;


@end

