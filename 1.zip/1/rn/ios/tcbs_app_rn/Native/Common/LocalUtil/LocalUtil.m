//
//  LocalUtil.m
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "LocalUtil.h"

@implementation LocalUtil

/**
 获取info.plist里对应值(字符串)
 
 @param key key值
 @return value(string)
 */
+ (NSString *)getInfoPlistStringWithKey:(NSString *)key{
  // 获取info字典
  NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"Info" ofType:@"plist"];
  NSMutableDictionary *infoDict = [NSMutableDictionary dictionaryWithContentsOfFile:bundlePath];
  NSString *value = [infoDict objectForKey:key];
  return value;
}

@end
