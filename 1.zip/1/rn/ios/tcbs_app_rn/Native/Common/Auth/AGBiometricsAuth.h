//
//  AGBiometricsAuth.h
//  tcbs_app_rn
//
//  Created by Otis on 16/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//


/*&* TouchID, FaceID 权限判断,鉴权调用*/

#import <Foundation/Foundation.h>

@interface AGBiometricsAuth : NSObject

/*&* 设备是否支持指纹识别*/
+ (int)canSupportTouchID;

/*&* 设备是否支持faceID*/
+ (int)canSupportFaceID;

/*&* 调用TouchID*/
+ (void)useTouchIDSuccess:(void(^)(void))successBlock
                   Failed:(void(^)(int failCode))failedBlock;

/*&* 调用FaceID*/
+ (void)useFaceIDSuccess:(void(^)(void))successBlock
                  Failed:(void(^)(int failCode))failedBlock;
@end
