//
//  AGBiometricsAuth.m
//  tcbs_app_rn
//
//  Created by Otis on 16/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "AGBiometricsAuth.h"
#import <LocalAuthentication/LocalAuthentication.h>

static NSString *const kTouchIDAuthReason = @"验证TouchID";
static NSString *const kFaceIDAuthReason = @"验证FaceID";

@implementation AGBiometricsAuth


/*&* 设备是否支持faceID*/
+ (int)canSupportFaceID{
  int code = 0;
  LAContext *context = [[LAContext alloc]init];
  NSError *error = nil;
  BOOL support = [context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
  if (support) {
    if (@available(iOS 11.0, *)) {
      if(context.biometryType == LABiometryTypeFaceID){
      }else{
        code = -1;
      }
    } else {
      // Fallback on earlier versions
      code = -1;
    }
  }else{
    if (error.code == -7) { //用户还没有设置faceID
      NSLog(@"无法使用FaceID -- 用户还没有设置faceID");
      code = (int)error.code;
    }else if(error.code == -8){
      NSLog(@"验证失败次数太多，请稍后再试！");
      code = (int)error.code;
    }else{
      code = -1;
      NSLog(@"无法使用FaceID -- 该设备不支持FaceID");
    }
  }
  return code;
}

//- (void)face{
//  if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_8_0) {
//    LAContext *context = [[LAContext alloc] init];
//    /**
//     需要先判断是否支持识别
//     *LAPolicyDeviceOwnerAuthentication 手机密码的验证方式
//     *LAPolicyDeviceOwnerAuthenticationWithBiometrics 指纹的验证方式，使用这种方式需要设置 context.localizedFallbackTitle = @""; 否则在验证失败时会出现点击无响应的“输入密码”按钮
//     */
//    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:nil]) {
//      /**
//       需要先判断是否支持指纹或者Face ID识别后，才能判断是什么类型的识别方式
//       */
//      NSString *localizedReason = @"指纹登录";
//      
//      if (@available(iOS 11.0, *)) {
//        if (context.biometryType == LABiometryTypeTouchID) {
//          
//        }else if (context.biometryType == LABiometryTypeFaceID){
//          localizedReason = @"Face ID登录";
//        }
//      }
//      
//      [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:localizedReason reply:^(BOOL success, NSError * _Nullable error) {
//        if (success) {
//          NSLog(@"--------识别成功");
//        }else{
//          if (error.code != 2) {
//            
//          }
//        }
//      }];
//    }
//  }else {
//    NSLog(@"你的设备不支持指纹识别");
//  }
//}

/*&* 设备是否支持指纹识别*/
+ (int)canSupportTouchID{
  int code = 0;
  LAContext *context = [[LAContext alloc]init];
  NSError *error = nil;
  if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
    if (@available(iOS 11.0, *)) {
      if(context.biometryType == LABiometryTypeTouchID){
      }else{
        code = -1;
      }
    } else {
      // Fallback on earlier versions
      code = -1;
    }
  }else{
    if (error.code == -7) { //用户还没有设置touchID
      code = (int)error.code;
    }else if(error.code == -8){ //验证失败次数太多，请稍后再试！
      code = (int)error.code;
    }else{
      code = -1;
    }
  }
  return code;
}

/*&* 调用TouchID*/
+ (void)useTouchIDSuccess:(void(^)(void))successBlock
                   Failed:(void(^)(int failCode))failedBlock{
  LAContext *context = [[LAContext alloc]init];
  //localizedFallbackTitle＝@“”,不会出现“输入密码”按钮
  context.localizedFallbackTitle = @"";
  NSError *error = nil;
  if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
    if (@available(iOS 11.0, *)) {
      if(context.biometryType == LABiometryTypeTouchID){
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:kTouchIDAuthReason reply:^(BOOL success, NSError * _Nullable useError) {
          dispatch_async(dispatch_get_main_queue(), ^{
            if (success) {
              if (successBlock) {
                successBlock();
              }
            }else{
              if (error.code == -2) { //用户取消验证
                if (failedBlock) {
                  failedBlock(-2);
                }
              }else{
                if (failedBlock) {
                  failedBlock(-1);
                }
              }
            }
          });
        }];
      }
    } else {
      // Fallback on earlier versions
    }
  }else{
    if (error.code == -7) { //用户还没有设置touchID
      failedBlock(-1);
    }else if(error.code == -8){ //验证失败次数太多
      failedBlock(-8);
    }else{
      failedBlock(-1);
    }
  }
}


//error.code  : 1.LAErrorAuthenticationFailed   身份验证失败
//
//2.LAErrorUserCancel                 用户在认证时点击取消
//
//3.LAErrorUserFallback 用户点击输入密码取消指纹验证
//
//4.LAErrorSystemCancel 身份认证被系统取消(按下Home键或电源键)
//
//5.LAErrorTouchIDNotEnrolled    用户未录入指纹
//
//6.LAErrorPasscodeNotSet 设备未设置密码
//
//7.LAErrorTouchIDNotAvailable  该设备为设置FaceID
//
//8.LAErrorTouchIDLockout   连续五次密码错误,FaceID被锁定.
//
//9.LAErrorAppCancel 用户不能控制情况下App被挂起

/*&* 调用FaceID*/
+ (void)useFaceIDSuccess:(void(^)(void))successBlock
                  Failed:(void(^)(int failCode))failedBlock{
  LAContext *context = [[LAContext alloc]init];
  //localizedFallbackTitle＝@“”,不会出现“输入密码”按钮
  //    注意context.localizedFallbackTitle = @"";如果不设置空值，则AlertView弹窗默认会有“输入密码”的选项，但是在LAPolicyDeviceOwnerAuthenticationWithBiometrics模式下点击“输入密码”不会有反应；LAPolicyDeviceOwnerAuthentication模式下点击可以唤起输入手机密码页面，页面如下，其中除了“指纹”两字是你的app名称，其他都不可定制
  context.localizedFallbackTitle = @"";
  NSError *error = nil;
  if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
    if (@available(iOS 11.0, *)) {
      if (context.biometryType == LABiometryTypeFaceID) {
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:kFaceIDAuthReason reply:^(BOOL success, NSError * _Nullable error) {
          dispatch_async(dispatch_get_main_queue(), ^{
            if (success) {
              if (successBlock) {
                successBlock();
              }
            }else{
              if (error.code == -2) { //用户取消验证
                if (failedBlock) {
                  failedBlock(-2);
                }
              }else{
                if (failedBlock) {
                  failedBlock(-1);
                }
              }
            }
          });
        }];
      }
    } else {
      // Fallback on earlier versions
    }
  }else{
    if (error.code == -7) { //用户还没有设置touchID
      failedBlock(-1);
    }else if(error.code == -8){ //验证失败次数太多
      failedBlock(-8);
    }else{
      failedBlock(-1);
    }
  }
}

@end
