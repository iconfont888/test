//
//  LogUtil.h
//  tcbs_app_rn
//
//  Created by Otis on 10/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
  LogLevel_Info = 0,
  LogLevel_Error
} LogLevel;


@interface LogUtil : NSObject

@property (assign, nonatomic) LogLevel logLevel;

@end

