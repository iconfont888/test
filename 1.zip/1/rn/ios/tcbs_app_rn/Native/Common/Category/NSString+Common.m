//
//  NSString+Common.m
//  tcbs_app_rn
//
//  Created by Otis on 17/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "NSString+Common.h"

@implementation NSString (Common)

+ (id)jsonStringWithDictionary:(id)data{
  NSError *error;
  NSData *jsonData = [NSJSONSerialization dataWithJSONObject:data options:NSJSONWritingPrettyPrinted error:&error];
  if (! jsonData) {
    return @"{}";
  } else {
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return json;
  }
}


- (NSDictionary *)jsonStringToDictionary{
  NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
  NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
  return dictionary;
}


/**
 转换字节数为描述字符串 -- KB,MB,GB...

 @param bytes 字节数
 @param saveNumber 保留小数点位数   1，2，3
 @return 描述字符串
 */
+ (NSString *)descriptionWithBytes:(double)bytes saveNumber:(int)saveNumber{
  float finalCount = .0f;
  NSString *finalUnit = nil;
  double size = bytes;
  float kNum = (float)(size/1024.0);
  if (kNum >= 1024) {
    float mNum = (float)(size/1024.0/1024.0);
    if (mNum >= 1024) {
      float gNum = (float)(size/1024.0/1024.0/1024.0);
      finalCount = gNum;
      finalUnit = @"GB";
    }else{
      finalCount = mNum;
      finalUnit = @"MB";
    }
  }else{
    finalCount = kNum;
    finalUnit = @"KB";
  }
  
  NSString *string = nil;
  
  switch (saveNumber) {
    case 0:
      string = [NSString stringWithFormat:@"%.0f%@",finalCount,finalUnit];
      break;
    case 1:
      string = [NSString stringWithFormat:@"%.1f%@",finalCount,finalUnit];
      break;
    case 2:
      string = [NSString stringWithFormat:@"%.2f%@",finalCount,finalUnit];
      break;
    case 3:
      string = [NSString stringWithFormat:@"%.3f%@",finalCount,finalUnit];
      break;
    default:
      string = [NSString stringWithFormat:@"%.2f%@",finalCount,finalUnit];
      break;
  }
  
  return string;
}





+ (double)getCacheSize{
  NSString *cachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory , NSUserDomainMask , YES) firstObject];
  return [self folderSizeAtPath :cachePath];
}

+ (double)folderSizeAtPath:(NSString *)path{
  //计算结果
  double totalSize = 0;
  
  // 1.获得文件夹管理者
  NSFileManager *mgr = [NSFileManager defaultManager];
  
  // 2.检测路径的合理性
  BOOL dir = NO;
  BOOL exits = [mgr fileExistsAtPath:path isDirectory:&dir];
  if (!exits) return 0;
  
  // 3.判断是否为文件夹
  if (dir)//文件夹, 遍历文件夹里面的所有文件
  {
    //这个方法能获得这个文件夹下面的所有子路径(直接\间接子路径),包括子文件夹下面的所有文件及文件夹
    NSArray *subPaths = [mgr subpathsAtPath:path];
    
    //遍历所有子路径
    for (NSString *subPath in subPaths)
    {
      //拼成全路径
      NSString *fullSubPath = [path stringByAppendingPathComponent:subPath];
      
      BOOL dir = NO;
      [mgr fileExistsAtPath:fullSubPath isDirectory:&dir];
      if (!dir)//子路径是个文件
      {
        NSDictionary *attrs = [mgr attributesOfItemAtPath:fullSubPath error:nil];
        totalSize += [attrs[NSFileSize] doubleValue];
      }
    }
  }
  else//文件
  {
    NSDictionary *attrs = [mgr attributesOfItemAtPath:path error:nil];
    totalSize = [attrs[NSFileSize] longValue];
  }
  return totalSize;
}

+ (BOOL)deleteCache{
  //清理结果的信息
  NSError *error = nil;//错误信息
  
  //构建需要删除的文件或文件夹的路径，这里以Documents为例
  NSString *path = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
  
  //拿到path路径的下一级目录的子文件夹
  NSArray *subPathArray = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:nil];
  
  for (NSString *subPath in subPathArray)
  {
    NSString *filePath = [path stringByAppendingPathComponent:subPath];
    //删除子文件夹
    [[NSFileManager defaultManager] removeItemAtPath:filePath error:&error];
    if (error)
    {
      return NO;
    }
  }
  
  return YES;
}



+(NSString*)getAppVersion
{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

//获取BundleID
+(NSString*) getBundleID
{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
}

//获取app的名字
+(NSString*) getAppName
{
  NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
  
  return appName;
}

//获取build号
+ (NSString *)getBuildNumber{
  NSString *app_build = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
  return app_build;
}


//获取codePushType
+ (NSString *)getCodePushType{
  NSString *codePushType = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CodePushType"];
  return codePushType;
}

//获取API_PATH
+ (NSString *)getApiPath{
  NSString *apiPath = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"DOMAIN_API_PATH"];
  return apiPath;
}

//获取轮询列表字符串
+ (NSString *)getLoopPath{
  NSString *loopPath = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"DOMAIN_LOOP_JSON_PATH"];
  return loopPath;
}

+ (NSNumber *)isJenkinsBuild{
  NSNumber *isJenkins = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"isJenkinsBuild"];
  return isJenkins;
}

//获取额外参数
+ (NSString *)getEXTRA_PARAMS{
  NSString *EXTRA_PARAMS = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"EXTRA_PARAMS"];
  return EXTRA_PARAMS;
}


+ (NSString *)getAPP_PRODUCT_ID{
  NSString *app_product_id = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"APP_PRODUCT_ID"];
  return app_product_id;
}

+ (NSString *)getUmengAppKey{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"UMENG_APPKEY"];
}

+ (NSString *)getUmengMsgSecret{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"UMENG_MESSAGE_SECRET"];
}

+ (NSString *)getUmengAlias{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"UMENG_ALIASTYPE"];
}

+ (NSString *)getBaiDuAppKey{
  return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"BaiduMobAd_STAT_ID"];
}



+ (NSNumber *)isDebugEnv{
#if DEBUG==1
  return [NSNumber numberWithBool:YES];
#else
  return [NSNumber numberWithBool:NO];
#endif
}
@end
