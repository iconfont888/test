//
//  NSString+Common.h
//  tcbs_app_rn
//
//  Created by Otis on 17/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Common)

+ (id)jsonStringWithDictionary:(id)data;

- (NSDictionary *)jsonStringToDictionary;

/**
 转换字节数为描述字符串 -- KB,MB,GB...
 
 @param bytes 字节数
 @param saveNumber 保留小数点位数   1，2，3
 @return 描述字符串
 */
+ (NSString *)descriptionWithBytes:(double)bytes saveNumber:(int)saveNumber;

+ (double)getCacheSize;

+ (BOOL)deleteCache;

+(NSString*) getAppVersion;

//获取BundleID
+(NSString*) getBundleID;

//获取app的名字
+(NSString*) getAppName;

//获取build号
+ (NSString *)getBuildNumber;

//获取codePushType
+ (NSString *)getCodePushType;

//获取API_PATH
+ (NSString *)getApiPath;

//获取轮询列表字符串
+ (NSString *)getLoopPath;

+ (NSString *)getEXTRA_PARAMS;

+ (NSNumber *)isJenkinsBuild;

+ (NSNumber *)isDebugEnv;

+ (NSString *)getAPP_PRODUCT_ID;

+ (NSString *)getUmengAppKey;
+ (NSString *)getUmengMsgSecret;
+ (NSString *)getUmengAlias;
+ (NSString *)getBaiDuAppKey;
@end

