//
//  AGDeviceUtil.m
//  tcbs_app_rn
//
//  Created by Otis on 16/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import "AGDeviceUtil.h"
#import <SAMKeychain/SAMKeychain.h>
#import <objc/runtime.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import "sys/utsname.h"
#import "Reachability.h"
#import <UIKit/UIKit.h>

/*&* key chain*/
static NSString *const KC_SERVICE_NAME = @"com.tcbs.AG8";
static NSString *const KC_DEVICE = @"Device";

@implementation AGDeviceUtil

/*&*************Device Info*********************/

/*&* 获取设备ID*/
+ (NSString *)deviceIdentify{
  return [self getDeviceID];
}

+ (NSString *)getDeviceID{
//  NSString *uuid = nil;
  NSString *uuid = [SAMKeychain passwordForService:KC_SERVICE_NAME account:KC_DEVICE];
  if (!uuid || [uuid isEqualToString:@""]) {
    CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
    uuid = (__bridge NSString *)CFUUIDCreateString(kCFAllocatorDefault, uuidRef);
    [SAMKeychain setPassword:uuid forService:KC_SERVICE_NAME account:KC_DEVICE];
  }
  return uuid;
}

/*&* 获取设备型号*/
+ (NSString *)deviceModel{
  return  [self getDeviceModel];
}
/*&* 获取设备品牌*/
+ (NSString *)deviceBrand{
  return [[UIDevice currentDevice] model];
}
/*&* 系统版本*/
+ (NSString *)systemVersion{
  NSString *sysVersion = [[UIDevice currentDevice] systemVersion];
  return sysVersion;
}

// 获取设备型号然后手动转化为对应名称
+ (NSString *)getDeviceModel

{
  // 需要
#warning 题主呕心沥血总结！！最全面！亲测！全网独此一份！！
  
  struct utsname systemInfo;
  
  uname(&systemInfo);
  
  NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
  
  //------------------------------iPhone---------------------------
  if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G";
  if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G";
  if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
  if ([platform isEqualToString:@"iPhone3,1"] ||
      [platform isEqualToString:@"iPhone3,2"] ||
      [platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
  if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S";
  if ([platform isEqualToString:@"iPhone5,1"] ||
      [platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
  if ([platform isEqualToString:@"iPhone5,3"] ||
      [platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5c";
  if ([platform isEqualToString:@"iPhone6,1"] ||
      [platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5s";
  if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6";
  if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus";
  if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6s";
  if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6s Plus";
  if ([platform isEqualToString:@"iPhone8,4"]) return @"iPhone SE";
  if ([platform isEqualToString:@"iPhone9,1"] ||
      [platform isEqualToString:@"iPhone9,3"]) return @"iPhone 7";
  if ([platform isEqualToString:@"iPhone9,2"] ||
      [platform isEqualToString:@"iPhone9,4"]) return @"iPhone 7 Plus";
  if ([platform isEqualToString:@"iPhone10,1"] ||
      [platform isEqualToString:@"iPhone10,4"]) return @"iPhone 8";
  if ([platform isEqualToString:@"iPhone10,2"] ||
      [platform isEqualToString:@"iPhone10,5"]) return @"iPhone 8 Plus";
  if ([platform isEqualToString:@"iPhone10,3"] ||
      [platform isEqualToString:@"iPhone10,6"]) return @"iPhone X";
  
  //------------------------------iPad--------------------------
  if ([platform isEqualToString:@"iPad1,1"]) return @"iPad";
  if ([platform isEqualToString:@"iPad2,1"] ||
      [platform isEqualToString:@"iPad2,2"] ||
      [platform isEqualToString:@"iPad2,3"] ||
      [platform isEqualToString:@"iPad2,4"]) return @"iPad 2";
  if ([platform isEqualToString:@"iPad3,1"] ||
      [platform isEqualToString:@"iPad3,2"] ||
      [platform isEqualToString:@"iPad3,3"]) return @"iPad 3";
  if ([platform isEqualToString:@"iPad3,4"] ||
      [platform isEqualToString:@"iPad3,5"] ||
      [platform isEqualToString:@"iPad3,6"]) return @"iPad 4";
  if ([platform isEqualToString:@"iPad4,1"] ||
      [platform isEqualToString:@"iPad4,2"] ||
      [platform isEqualToString:@"iPad4,3"]) return @"iPad Air";
  if ([platform isEqualToString:@"iPad5,3"] ||
      [platform isEqualToString:@"iPad5,4"]) return @"iPad Air 2";
  if ([platform isEqualToString:@"iPad6,3"] ||
      [platform isEqualToString:@"iPad6,4"]) return @"iPad Pro 9.7-inch";
  if ([platform isEqualToString:@"iPad6,7"] ||
      [platform isEqualToString:@"iPad6,8"]) return @"iPad Pro 12.9-inch";
  if ([platform isEqualToString:@"iPad6,11"] ||
      [platform isEqualToString:@"iPad6,12"]) return @"iPad 5";
  if ([platform isEqualToString:@"iPad7,1"] ||
      [platform isEqualToString:@"iPad7,2"]) return @"iPad Pro 12.9-inch 2";
  if ([platform isEqualToString:@"iPad7,3"] ||
      [platform isEqualToString:@"iPad7,4"]) return @"iPad Pro 10.5-inch";
  
  //------------------------------iPad Mini-----------------------
  if ([platform isEqualToString:@"iPad2,5"] ||
      [platform isEqualToString:@"iPad2,6"] ||
      [platform isEqualToString:@"iPad2,7"]) return @"iPad mini";
  if ([platform isEqualToString:@"iPad4,4"] ||
      [platform isEqualToString:@"iPad4,5"] ||
      [platform isEqualToString:@"iPad4,6"]) return @"iPad mini 2";
  if ([platform isEqualToString:@"iPad4,7"] ||
      [platform isEqualToString:@"iPad4,8"] ||
      [platform isEqualToString:@"iPad4,9"]) return @"iPad mini 3";
  if ([platform isEqualToString:@"iPad5,1"] ||
      [platform isEqualToString:@"iPad5,2"]) return @"iPad mini 4";
  
  //------------------------------iTouch------------------------
  if ([platform isEqualToString:@"iPod1,1"]) return @"iTouch";
  if ([platform isEqualToString:@"iPod2,1"]) return @"iTouch2";
  if ([platform isEqualToString:@"iPod3,1"]) return @"iTouch3";
  if ([platform isEqualToString:@"iPod4,1"]) return @"iTouch4";
  if ([platform isEqualToString:@"iPod5,1"]) return @"iTouch5";
  if ([platform isEqualToString:@"iPod7,1"]) return @"iTouch6";
  
  //------------------------------Samulitor-------------------------------------
  if ([platform isEqualToString:@"i386"] ||
      [platform isEqualToString:@"x86_64"]) return @"iPhone Simulator";
  
  return @"Unknown";
}



/* 获取对象的所有方法 */
+(NSArray *)getAllMethodsWithClass:(Class)class
{
  unsigned int methodCount =0;
  Method* methodList = class_copyMethodList(class,&methodCount);
  NSMutableArray *methodsArray = [NSMutableArray arrayWithCapacity:methodCount];
  
  for(int i=0;i<methodCount;i++)
  {
    Method temp = methodList[i];
    //        IMP imp = method_getImplementation(temp);
    //        SEL name_f = method_getName(temp);
    const char* name_s =sel_getName(method_getName(temp));
    int arguments = method_getNumberOfArguments(temp);
    const char* encoding =method_getTypeEncoding(temp);
    NSLog(@"方法名：%@,参数个数：%d,编码方式：%@",[NSString stringWithUTF8String:name_s],
          arguments,
          [NSString stringWithUTF8String:encoding]);
    [methodsArray addObject:[NSString stringWithUTF8String:name_s]];
  }
  free(methodList);
  return methodsArray;
}


/*&*************Network Info*********************/
/*&* 网络类型*/
+ (NSString *)getNetworkType{
  NSString *network = @"";
  //    if (Is_IPhoneX) {
  //        //        iPhone X
  //        network = [self iphoneAfterXGetNetwork];
  //    }else {
  //        if (IS_IPAD) {
  //            if (@available(iOS 12.0, *)) {
  //                network = [self ipadAfterIOS12GetNetwork];
  //            }else{
  //                network = [self iphoneBeforeXOrIpadBeforeIOS12GetNetWork];
  //            }
  //        }else{
  //            network = [self iphoneBeforeXOrIpadBeforeIOS12GetNetWork];
  //        }
  //    }
  //    if ([network isEqualToString:@""]) {
  //        network = @"NO DISPLAY";
  //    }
  network = [self getNetconnType];
  return network;
}


+ (NSString *)getNetconnType{
  
  NSString *netconnType = @"";
  
  Reachability *reach = [Reachability reachabilityWithHostName:@"www.apple.com"];
  
  switch ([reach currentReachabilityStatus]) {
      case NotReachable:// 没有网络
    {
      netconnType = @"no network";
    }
      break;
      
      case ReachableViaWiFi:// Wifi
    {
      netconnType = @"Wifi";
    }
      break;
      
      case ReachableViaWWAN:// 手机自带网络
    {
      // 获取手机网络类型
      CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];
      
      NSString *currentStatus = info.currentRadioAccessTechnology;
      
      if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyGPRS"]) {
        
        netconnType = @"GPRS";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyEdge"]) {
        
        //                netconnType = @"2.75G EDGE";
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyWCDMA"]){
        
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyHSDPA"]){
        
        //                netconnType = @"3.5G HSDPA";
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyHSUPA"]){
        
        //                netconnType = @"3.5G HSUPA";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMA1x"]){
        
        netconnType = @"2G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORev0"]){
        
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevA"]){
        
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyCDMAEVDORevB"]){
        
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyeHRPD"]){
        //                netconnType = @"HRPD";
        netconnType = @"3G";
      }else if ([currentStatus isEqualToString:@"CTRadioAccessTechnologyLTE"]){
        
        netconnType = @"4G";
      }
    }
      break;
      
    default:
      break;
  }
  return netconnType;
}


/*&* 第一种 如果是iphone，低于iphoneX；如果是ipad，低于ios12*/
+ (NSString *)iphoneBeforeXOrIpadBeforeIOS12GetNetWork{
  UIApplication *app = [UIApplication sharedApplication];
  id statusBar = [app valueForKeyPath:@"statusBar"];
  NSString *network = @"";
  UIView *foregroundView = [statusBar valueForKeyPath:@"foregroundView"];
  NSArray *subviews = [foregroundView subviews];
  
  for (id subview in subviews) {
    if ([subview isKindOfClass:NSClassFromString(@"UIStatusBarDataNetworkItemView")]) {
      int networkType = [[subview valueForKeyPath:@"dataNetworkType"] intValue];
      switch (networkType) {
          case 0:
          network = @"NONE";
          break;
          case 1:
          network = @"2G";
          break;
          case 2:
          network = @"3G";
          break;
          case 3:
          network = @"4G";
          break;
          case 5:
          network = @"WIFI";
          break;
        default:
          break;
      }
    }
  }
  return network;
}


/*&* 第二种 --- iphoneX类型*/
+ (NSString *)iphoneAfterXGetNetwork{
  UIApplication *app = [UIApplication sharedApplication];
  id statusBar = [app valueForKeyPath:@"statusBar"];
  NSString *network = @"";
  //        iPhone X
  id statusBarView = [statusBar valueForKeyPath:@"statusBar"];
  UIView *foregroundView = [statusBarView valueForKeyPath:@"foregroundView"];
  
  NSArray *subviews = [[foregroundView subviews][2] subviews];
  
  for (id subview in subviews) {
    if ([subview isKindOfClass:NSClassFromString(@"_UIStatusBarWifiSignalView")]) {
      network = @"WIFI";
    }else if ([subview isKindOfClass:NSClassFromString(@"_UIStatusBarStringView")]) {
      network = [subview valueForKeyPath:@"originalText"];
    }
  }
  return network;
}

/*&* 第三种 --- ipad大于IOS12版本*/
+ (NSString *)ipadAfterIOS12GetNetwork{
  UIApplication *app = [UIApplication sharedApplication];
  id statusBar = [[app valueForKey:@"statusBar"] valueForKey:@"statusBar"];
  id one = [statusBar valueForKey:@"regions"];
  id two = [one valueForKey:@"trailing"];
  NSArray *three = [two valueForKey:@"displayItems"];
  NSString *state = @"无网络";
  for (UIView *view in three) {
    //alert: iOS12.0 情况下identifier的变成了类"_UIStatusBarIdentifier"而不是NSString，所以会在调用“isEqualToString”方法时发生crash，
    //修改前
    //  NSString *identifier = [view valueForKeyPath:@"identifier"];
    //修改后
    NSString *identifier = [[view valueForKeyPath:@"identifier"] description];
    if ([identifier isEqualToString:@"_UIStatusBarWifiItem.signalStrengthDisplayIdentifier"]) {
      id item = [view valueForKeyPath:@"_item"];
      
      //alert: 这个问题和上边一样itemId是_UIStatusBarIdentifier 类型，不是string
      NSString *itemId = [[item valueForKeyPath:@"identifier"] description];
      if ([itemId isEqualToString:@"_UIStatusBarWifiItem"]) {
        state = @"WIFI";
      }
      state = @"不确定";
      
    } else if ([identifier isEqualToString:@"_UIStatusBarCellularItem.typeDisplayIdentifier"]) {
      UIView *statusBarStringView = [view valueForKeyPath:@"_view"];
      // 4G/3G/E
      state = [statusBarStringView valueForKeyPath:@"text"];
    }
    
  }
  return state;
}


/*&* 网络运营商*/
+ (NSString *)getNetworkOperators{
  CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
  CTCarrier *carrier = [telephonyInfo subscriberCellularProvider];
  NSString *currentCountry=[carrier carrierName];
  NSLog(@"[carrier isoCountryCode]==%@,[carrier allowsVOIP]=%d,[carrier mobileCountryCode=%@,[carrier mobileCountryCode]=%@",[carrier isoCountryCode],[carrier allowsVOIP],[carrier mobileCountryCode],[carrier mobileNetworkCode]);
  return currentCountry;
}

@end
