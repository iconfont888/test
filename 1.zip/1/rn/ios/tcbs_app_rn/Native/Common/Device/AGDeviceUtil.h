//
//  AGDeviceUtil.h
//  tcbs_app_rn
//
//  Created by Otis on 16/04/2019.
//  Copyright © 2019 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGDeviceUtil : NSObject

/*&*************Device Info*********************/
/*&* 获取设备ID*/
+ (NSString *)deviceIdentify;
/*&* 获取设备型号*/
+ (NSString *)deviceModel;
/*&* 获取设备品牌*/
+ (NSString *)deviceBrand;
/*&* 系统版本*/
+ (NSString *)systemVersion;

/*&*************Network Info*********************/
/*&* 网络类型*/
+ (NSString *)getNetworkType;
/*&* 网络运营商*/
+ (NSString *)getNetworkOperators;

+ (void)collectUserInfo;

@end
