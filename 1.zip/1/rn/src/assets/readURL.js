/**
 *Created by Lili 2019/4/9
 * 获取项目工程里的图片
 **/
//获取项目工程里的图片
var fs = require('fs');//引用文件系统模块
var image = require("imageinfo"); //引用imageinfo模块
const PATH = require('path');

function readFileList(path, filesList) {
    var files = fs.readdirSync(path);
    files.forEach(function (itm, index) {
        var stat = fs.statSync(path + itm);
        if (stat.isDirectory()) {
            //递归读取文件
            readFileList(path + itm + "/", filesList)
        } else {

            var obj = {};//定义一个对象存放文件的路径和名字
            obj.path = path;//路径
            obj.filename = itm//名字
            filesList.push(obj);
        }

    })

}

var getFiles = {
    //获取文件夹下的所有文件
    getFileList: function (path) {
        var filesList = [];
        readFileList(path, filesList);
        return filesList;
    },
    //获取文件夹下的所有图片
    getImageFiles: function (path) {
        var imageList = {};//定义一个对象存放文件的路径和名字
        this.getFileList(path).forEach((item) => {
            var ms = image(fs.readFileSync(item.path + item.filename));

            let p = (item.path + item.filename).replace(/\\/g, '/')
            let obj = PATH.parse(p)
            let key = obj.name.replace(/@2x|@3x/g, '')

            if (obj.ext != '.js') {
                let rel = (PATH.relative(PATH.resolve(__dirname, '../'), p))
                    .replace(/\\/g, '/')
                    .replace(/@2x|@3x/g, '')

                imageList[key] = `#require('../${rel}')#`;//路径
                console.log(rel)

            }
            // console.log(PATH.resolve(__dirname, '../common'), PATH.resolve(__dirname, '../assets'))
            ms.mimeType && (imageList)


        });
        //3. fs.writeFile  写入文件（会覆盖之前的内容）（文件不存在就创建）  utf8参数可以省略


        let geturl = __dirname + '/getURL.js'
        let txt = `/**
         查询【 "# 】 删除
         查询【 #" 】 删除
         然后复制内容到 \\tcbs-app-rn\\src\\common\\ImgURL.js 中
        **/
        export default
        `
        fs.writeFileSync(geturl, txt, 'utf8', function (error, data) {
            if (error) {
                console.log(error);
                return false;
            }
            console.log('写入成功', data);
        })

        imageList = JSON.stringify(imageList, null, 4);
        fs.appendFile(geturl, imageList, function (err) {
            if (err) throw err;

            //数据被添加到文件的尾部
            console.log('The "data to append" was appended to file!');
        });

        return imageList;

    }
};
// let p=PATH.join(__dirname,'/assets/')
let gp = __dirname + '/'

//获取文件夹下的所有图片
getFiles.getImageFiles(gp);

