import React, { Component } from 'react';
import { View, Text, TextInput,StyleSheet } from 'react-native';
import common from '../util/common';
/**
  * @author candice
  * @param startTime://开始时间  毫秒数 以服务器时间算 若不传为系统时间
  * @param endTime: // 结束时间 毫秒数
  * @param success // fn 
  * @param error // fn 
  * @param label //  string  
  * @param labelStyle //  obj 样式  
  * @param textStyle //  字体 样式  
  * @type children | 
 **/
export default class AGCountDown extends Component{
    constructor(props) {
        super(props)
        const {
            startTime = new Date().getTime(),
            endTime = ''
        } = this.props;
        this.state = {
            date: {
                day: '',
                hour: '',
                minute: '',
                sec: ''
            },
            stop: this.props.stop || false
            
        }
         this.initDate();
    };
    animate = null
    initDate(){
        // 修正 时间误差
        let nowDateTime = global.SYSTEM_NOW;
        let dateTime = nowDateTime;
        if( this.props.startTime != dateTime && dateTime > this.props.startTime){
            let curTime = dateTime - this.props.startTime;
            dateTime = this.props.startTime + curTime;
        }
        this.animate = common.countDown({
            startTime: dateTime,
            endTime: this.props.endTime,
        },({day, hour, minute, sec}) => {
            if(day === 0 && hour === 0 && minute === 0 && sec ===0 ){
                this.setState({
                    stop: true
                })
                this.props.onFinshChange && this.props.onFinshChange()
                clearInterval(this.animate)
                return;
            }
            this.state.date.day = day;
            this.state.date.hour = hour;
            this.state.date.minute = minute;
            this.state.date.sec = sec;
            this.setState({
                date: this.state.date
            })
        })
    }
    componentWillMount() {
       
    }
    componentWillUnmount(){
        // 解决内存泄漏
        clearInterval(this.animate)
    }
    componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {
        if(nextProps.stop){
            clearInterval(this.animate);
            this.setState({
                stop: nextProps.stop
            })
        }

    }

    render(){
        return(
            <View>
                {!this.state.stop &&
                    <View style={styles.containerStyle}>
                        <Text style={StyleSheet.flatten([styles.labelStyle, this.props.labelStyle])}>{this.props.label}</Text>
                        <Text style={StyleSheet.flatten([styles.textStyle, this.props.textStyle])}> {this.state.date.day} 天</Text>
                        <Text style={StyleSheet.flatten([styles.textStyle, this.props.textStyle])}> {this.state.date.hour} 时</Text>
                        <Text style={StyleSheet.flatten([styles.textStyle, this.props.textStyle])}> {this.state.date.minute} 分</Text>
                        <Text style={StyleSheet.flatten([styles.textStyle, this.props.textStyle])}> {this.state.date.sec} 秒</Text>
                    </View>
                }
            </View>
        )
    }
    
}
const styles = StyleSheet.create({
    containerStyle:{
        // height: 60,
        flexDirection: 'row',
    },
    labelStyle:{
        fontSize: 14,
    },
    textStyle:{
        fontSize: 14,
        color: '#FF0020',
        marginRight: 4,
        letterSpacing: -1
    },
})