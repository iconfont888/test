import React, { Component } from 'react';
import {
    View,
    StyleSheet,
    Dimensions,
} from 'react-native';
import { FormLabel, FormInput, FormValidationMessage,Button,Image  } from 'react-native-elements';
import Spinner from 'react-native-spinkit';
import {onChangeLoaing} from "../action";
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
class AGLoading extends Component{
    constructor(props) {
        super(props)
        this.state = {
          isClose: this.props.isClose || false,

        }
    }
    componentWillMount() {
       this.setState({
           isClose: this.props.isClose || true
       })
    }

    componentDidMount(){ // 页面加载完成

        
    }
    render(){
        return(
            <View style={!this.state.isClose && styles.containerStyle}>
            {
                !this.state.isClose && (


                            <View style={styles.bgStyle}>
                                <Spinner
                                    isVisible={!this.state.isClose}
                                    type={'ThreeBounce'}
                                    size={100}
                                    color={'#fff'}
                                />
                                {/*<Text style={styles.TextStyle}>页面正在加载中...</Text>*/}
                            </View>



                )
            }
            </View>
            
        )
    }
    
}
const styles = StyleSheet.create({
    indicator:{
        // height: 2,
        borderRadius: 8,
        backgroundColor: 'white'
    },
    containerStyle:{
        position:'absolute',
        backgroundColor: '#00000050',
        flex: 1,
        top:0,
        left:0,
        width: '100%',
        height:'100%',
        // zIndex: 9999,
       
    },
    bgStyle:{

        // width:400,
        // height: 40,
        justifyContent: 'center',
        alignItems: 'center',
        flex:1,
        // flexDirection: 'row'
    },
    TextStyle:{
        color:'#fff',
        textAlign: 'center',
        marginTop: 80,
        fontSize: 20,

    },
    divStyle:{
        backgroundColor: '#fff',
        width:40,
        height:40,
        borderWidth: 2,
        borderRadius: 40,
        borderColor: '#fff',
    },
    
})
export default AGLoading