import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
import REGRULE from "../../util/reg_rule";
// import AGInput from "./input"
import Icon from 'react-native-vector-icons/Entypo';
import { FormLabel, FormInput, FormValidationMessage,Button } from 'react-native-elements'
// import common from "../util/common";
import {AGInput, AGIphoneInput, AGInputPassword} from "./index";
/**
  * @author candice
  * @title demo 使用二层封装input插件 模拟一个表单编写
  * @dec 如果使用过程中有任何问题可咨询candice ,如有bug也可以快速的反馈于我，这是二次封装无法避免无bug。
  * 
 **/
export default class AGForm extends Component{
    constructor(props) {
      super(props)
      this.state = {
            form:{ // 表单提交字段 
                userName: '',
                password: '',
                address: ''
            },
            passwordIconName: 'eye-with-line',
            secureTextEntry: true,
            value: '',
            autoVerification: { // 点击按钮时 值为错误时 自动触发错误事件提醒 若没有则为不必填
                userName: false,
                password: false
            },
        }
        this.updateValue = this.updateValue.bind(this);
        this.submits = this.submits.bind(this);
        this.eyesStatus = this.eyesStatus.bind(this);

    };
    submits(){
        for(let key in this.state.autoVerification){
            let item = this.state.autoVerification[key];
            if(this.state.form.hasOwnProperty(key) && this.state.form[key] == ''){
                this.state.autoVerification[key] = true;
                this.setState({
                    autoVerification: this.state.autoVerification
                })
                return;
            }

        }
        console.log('提交成功表单')
    }
    updateValue({name, value}){
        this.state.form[name] = value;
    }
    eyesStatus(){
        this.setState({
            secureTextEntry: !this.state.secureTextEntry,
            passwordIconName: this.state.passwordIconName == 'eye' ? 'eye-with-line' : 'eye'
        })
    }
    render(){
        return(
            <View>
                <AGInput
                    label = '用户名'
                    placeholder = "请输入用户名"
                    rules={[{reg: REGRULE.REGISTER_LOGIN_NAME_REGEX, regErrorMessage: "请输入6-10位"}]}
                    iconRightBorder = {true}
                    blank={true}
                    updateValue = {this.updateValue}
                    autoVerification ={this.state.autoVerification.userName}
                    ref = "userName"
                    InputProps={{
                        ref: "userName1"
                    }
                        
                    }
                    updateName = "userName"
                    rightIcon={{type:'antdesign',name:"user",color:'#5f4e4b',size:24}}
                /> 
                <AGInputPassword
                    label = '密码'
                    rules={[{reg: REGRULE.REGISTER_LOGIN_NAME_REGEX, regErrorMessage: "请输入6-10位"}]}
                    iconLeftBorder = {true}
                    placeholder = "请输入密码"
                    ref="password"
                    blank={true}
                    updateValue = {this.updateValue}
                    autoVerification ={this.state.autoVerification.password}
                    updateName = "password"
                    
                /> 
                <AGInput
                    label = '地址'
                    iconLeftBorder = {true}
                    ref="address"
                    placeholder = "请输入地址"
                    updateValue = {this.updateValue}
                    updateName = "address"
                    leftIcon={{type:'antdesign',name:"home",color:'#5f4e4b',size:24}}
                />
                <Button onPress={this.submits} title={'提交'} />
            </View> 
        )
    }
    
}