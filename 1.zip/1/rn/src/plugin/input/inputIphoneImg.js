import React, { Component } from 'react';
import { View, Text, TextInput, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import REGRULE from "../../util/reg_rule";
import AGInput from "./input"
import Icon from 'react-native-vector-icons/Entypo';
import { FormLabel, FormInput, FormValidationMessage, Button, Image } from 'react-native-elements';
import { baseUrl } from '../../service/env'
// import common from "../util/common";
// import {AGInput, AGIphoneInput} from "../plugin/input";
/**
  * @author candice
  * @title demo 使用二层封装input插件 模拟一个表单编写
  * @dec 如果使用过程中有任何问题可咨询candice ,如有bug也可以快速的反馈于我，这是二次封装无法避免无bug。
  * 
 **/
export default class AGInputIphoneImg extends Component {
    constructor(props) {
        super(props)
        this.state = {
            imgUrl: "",
            imgLoadingContent: (<ActivityIndicator />)
        }
        this.updateUrl = this.updateUrl.bind(this);
        this.imgLoad = this.imgLoad.bind(this);
    };
    componentDidMount() {
        this.updateUrl();
    }
    updateUrl() {
        this.setState({
            imgUrl: this.getImgUrl()
        })
    }
    getImgUrl() {
        return baseUrl() + "/api/captcha?site=11&type=" + this.props.type + "&_d" + (1 - new Date());
    }
    imgLoad() {
        this.setState({
            imgLoadingContent: ''
        })
    }
    render() {
        let InputProps = {
            maxLength: 4
        }
        return (
            <View>
                <AGInput
                    leftIcon={{ type: 'material', name: "verified-user", color: '#5f4e4b', size: 24 }}
                    iconLeftBorder={true}
                    rules={[{ reg: REGRULE.VERIFICATION_CODE_REGEX, regErrorMessage: '验证码不正确' }]}
                    blank={true}
                    keyboardType="numeric"
                    blankErrorMessage="验证码不能为空"
                    placeholder="请输入验证码"
                    InputProps={InputProps}
                    {...this.props}
                    ref={"codeImage"}
                    rightIcon={(<TouchableOpacity onPress={this.updateUrl} ><Image
                        style={{ width: 90, height: 40 }}
                        source={{ uri: this.state.imgUrl }}
                        PlaceholderContent={this.state.imgLoadingContent != '' && this.state.imgLoadingContent}
                        onLoadEnd={this.imgLoad}
                    /></TouchableOpacity>)}
                />
            </View>

        )
    }

}
const styles = StyleSheet.create({
    containerStyle: {
        height: 40,
    },
    sendBtnStyle: {
        height: 40,
        marginTop: -6,
        marginRight: -2,
        position: 'relative',
        backgroundColor: '#fe5d37'
    }
})