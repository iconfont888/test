/**
  * 手机号码input
  * @author candice
* */
import React, { Component } from 'react';
import AGInput from './input';
import { View, Text, StyleSheet } from 'react-native';
import {Icon} from 'react-native-elements';
import REGRULE from "../../util/reg_rule";
import AGInputIphoneCode from "./inputIphoneCode";
export default class AGIphoneInput extends Component{
    constructor(props){
        props && super(props);
        this.state = {
            leftIcon: this.props.leftIcon || true
        }
    }
    otherVerification(value){
        let res = true;
        let errorMessage = '';
        if(REGRULE.INTERNET_PHONE_REGEX.test(Number(value))){
            res = false
            errorMessage = '无效号码，属于网络运营商!'
        }
        if(!REGRULE.PHONE_REGEX.test(Number(value))){
            res = false
            errorMessage = '请输入正确手机号码!'
        }
        return new Promise((reslove,reject) => {
            reslove(errorMessage)
        })
    }
    render(){
        let InputProps = Object.assign({
            keyboardType: 'numeric'
        },this.props.InputProps)
        return(
            <View>
                <AGInput 
                    leftIcon={this.state.leftIcon ? {type:'material',name:"phone-iphone",color:'#5f4e4b',size:24}:null}
                    blank = {true}
                    blankErrorMessage='手机号码不能为空!'
                    otherVerification = {this.otherVerification}
                    InputProps = {InputProps}
                    ref={"iphone"}
                    errorStyle={{
                        marginTop: -10
                    }}
                    {...this.props}
                    iconLeftBorder = {true}
                />
            </View>
        )
        
    }
}