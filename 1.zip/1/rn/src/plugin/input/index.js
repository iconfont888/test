import AGInput from './input';
import AGIphoneInput from './iphoneInput';
import AGForm from './form';
import AGInputPassword from './inputPassword';
import AGInputIphoneImg from './inputIphoneImg';
import AGInputIphoneCode from './inputIphoneCode';
import AGInputMobile from './inputMobile'

export{ 
    AGInput,
    AGIphoneInput,
    AGForm,
    AGInputMobile,
    AGInputPassword,
    AGInputIphoneImg,
    AGInputIphoneCode
};