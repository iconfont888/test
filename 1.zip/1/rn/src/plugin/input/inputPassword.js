import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
import REGRULE from "../../util/reg_rule";
import AGInput from "./input"
import Icon from 'react-native-vector-icons/Entypo';
import { FormLabel, FormInput, FormValidationMessage,Button } from 'react-native-elements'
// import common from "../util/common";
// import {AGInput, AGIphoneInput} from "../plugin/input";
/**
  * @author candice
  * @title demo 使用二层封装input插件 模拟一个表单编写
  * @dec 如果使用过程中有任何问题可咨询candice ,如有bug也可以快速的反馈于我，这是二次封装无法避免无bug。
  *  leftIconName
  *  leftIconType
 **/
export default class AGInputPassword extends Component{
    constructor(props) {
      super(props)
      this.state = {
            passwordIconName: 'eye-with-line',
            secureTextEntry: true,
      }
      this.eyesStatus = this.eyesStatus.bind(this);
    };
    eyesStatus(){
        this.setState({
            secureTextEntry: !this.state.secureTextEntry,
            passwordIconName: this.state.passwordIconName == 'eye' ? 'eye-with-line' : 'eye'
        })
    }
    render(){
        return(
            <AGInput
                leftIcon={{type:this.props.leftIconType || 'antdesign',name:  this.props.leftIconName || "lock",color:'#5f4e4b',size: this.props.leftIconSize || 24}}
                {...this.props}
                ref={this.props.refName || 'password'}
                updateName={"password"}
                secureTextEntry = {this.state.secureTextEntry}
                rightIcon={(<Icon name={this.state.passwordIconName} size={20} onPress={this.eyesStatus} style={{lineHeight: 40,paddingRight: 10}} />)}
            />  
        )
    }
}