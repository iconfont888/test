/**
 * @author candice
 * @update 2019/4/2
* */
import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Input } from 'react-native-elements';
import {DIMENS_BORDER_COLOR} from '../../common/colors';
import {DIMENS_LINE_DEFAULT} from '../../common/dimens';
export default class AGInput extends Component{
    constructor(props){
        super(props);
        this.state ={
            errorText: this.props.errorText 
        }
    }
    render(){
        return(
            <View>
                <Input 
                    inputStyle = {styles.inputStaticStyle}
                    placeholder='INPUT WITH ICON'
                    errorStyle={{ color: 'red' }}
                    errorMessage={this.state.errorText}
                />    
            </View>
              
        )
    }
}
const styles = StyleSheet.create({
    inputStaticStyle:{
        borderWidth: DIMENS_LINE_DEFAULT,
        borderBottomWidth: DIMENS_LINE_DEFAULT,
        borderColor: DIMENS_BORDER_COLOR
    }
})