/*
 * @Author: Kobe 
 * @Date: 2019-04-12 10:18:56 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-07-17 16:28:03
 */

import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableWithoutFeedback } from 'react-native';
import { connect } from "react-redux";
import NavigationUtil from '../router/NavigationUtil'
import AppStorage from "../util/AppStorage";
import Constant from '../common/Constant'
import colors from '../common/colors'
import dimens from '../common/dimens'
import LoadingUtil from '../util/loadingUtil'
import { GET_AD_INFO } from '../service/getData'
import common from '../util/common'
import WebViewPage from './WebViewPage';
import ImgURL from '../common/ImgURL';

type Props = {};
//倒计时

class AdPage extends Component<Props>{


    constructor(props) {
        super(props)
        this.state = {
            imageUrl: '',
            countDownText: '',
            timeLeft: 5,
            jumpOverFlag: false,
            showAd: false,
            jumpUrl: ''
        }
        this.onPressJumpButton = this.onPressJumpButton.bind(this)
        this.onPressImage = this.onPressImage.bind(this)

        this.loadCache()
        this.fetchAd()


    }
    componentWillUnmount(){
        //清除未完成的倒计时
        clearInterval(this.interval)
    }


    /**
     * 获取广告配置
     */

    async fetchAd() {
        await GET_AD_INFO().then((res) => {
            if (res.successful) {
                AppStorage.save(Constant.KEY_AD_DATA, res.data)
                //预下载图片
                Image.prefetch(res.data[0].imageHttpUrl)
            }
        }).catch((e) => {
            //console.log(e.message)
        })

    }

    /**
     * 加载本地广告缓存
     */
    async loadCache() {
        // this.goToMain()
        // return;
        AppStorage.get(Constant.KEY_AD_DATA).then((data) => {

            if (data && data[0].switchFlag == '1') {
                this.setState({
                    imageUrl: data[0].imageHttpUrl,
                    showAd: true,
                    jumpUrl: data[0].jumpUrl
                })
                this.countDown(data[0].jumpOverFlag && data[0].jumpOverFlag == '1', data[0].time)
            } else {
                this.goToMain()
            }

        }).catch((e) => {
            console.log(e.message)
            this.goToMain()
        })
    }

    /**
     * 倒计时
     * @param {*} jumpOverFlag 
     * @param {*} time 
     */
    countDown(jumpOverFlag, time) {
        if (time > 0) {
            //设置初始数据
            this.setState({
                timeLeft: time,
                jumpOverFlag: jumpOverFlag,
                countDownText: jumpOverFlag ? '跳过(' + time + 's)' : time + 's',
            })
            this.interval = setInterval(() => {
                try {
                    if (this.state.timeLeft < 1) {
                        //倒计时完成
                        this.goToMain()
                    } else {
                        let newTime = this.state.timeLeft - 1
                        this.setState({
                            timeLeft: newTime,
                            countDownText: jumpOverFlag ? '跳过(' + newTime + 's)' : newTime + 's'
                        })
                    }
                } catch (e) {
                    console.log(e.message)
                }
            }, 1000)
        } else {
            this.goToMain()
        }


    }

    /**
     * 跳转到首页
     */
    goToMain() {
        if (this.interval) {
            //清除未完成的倒计时
            clearInterval(this.interval)
        }
        NavigationUtil.resetToMainPage({
            navigation: this.props.navigation
        })
    }

    /**
     * 跳过按钮点击事件
     */
    onPressJumpButton() {
        if (this.state.jumpOverFlag) {
            this.goToMain()
        }
    }

    /**
     * 图片点击事件
     */
    onPressImage() {
        if (this.state.jumpUrl) {
            this.props.navigation.navigate(
                'WebViewPage',
                {
                    url: this.state.jumpUrl,
                    isRelativePath: true
                }
            )
        }
    }




    render() {
        let view
        if (this.state.showAd) {
            view = <View style={styles.bg}>
                <TouchableWithoutFeedback onPress={this.onPressImage}>
                    <Image resizeMode={'stretch'} style={styles.adImage} source={{ uri: this.state.imageUrl }} />
                </TouchableWithoutFeedback>

                {this.state.countDownText ?
                    <TouchableWithoutFeedback onPress={this.onPressJumpButton}>
                    <View style={styles.countDown}>
                        <Text style={styles.countDownText} onPress={this.onPressJumpButton}>{this.state.countDownText}</Text>
                    </View>
                    </TouchableWithoutFeedback>
                    : null}
            </View>
        } else {
            view = <Image style={{ flex: 1, height: null, width: null, backgroundColor: colors.COLOR_BLACK }} source={ImgURL.launch_screen} resizeMode={'stretch'} />
        }
        return (
            view
        )
    }
}

const styles = StyleSheet.create({
    bg: {
        flex: 1,
    },
    adImage: {
        flex: 1,
    },
    countDown: {
        position: 'absolute',
        right: dimens.DIMENS_SPACING_DEFAULT,
        top: dimens.DIMENS_SPACING_DEFAULT,
        justifyContent: 'center',
        padding: dimens.DIMENS_SPACING_DEFAULT,
        borderRadius: 18,
        backgroundColor: colors.COLOR_BLACK,
        opacity: 0.4,
        marginTop: 40,
        marginRight: dimens.DIMENS_SPACING_DEFAULT
    },
    countDownText:{
        color: colors.COLOR_WHITE,
        fontSize: dimens.DIMENS_TEXT_DEFAULT,
    }
})


export default connect(null)(AdPage)