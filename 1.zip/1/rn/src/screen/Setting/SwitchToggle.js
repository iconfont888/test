import React from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity ,Platform } from 'react-native';
import dimens from '../../common/dimens';
import colors from '../../common/colors';


const SwitchToggle = ({ name, desc, isOpen, onPress, testID, _ref }) => {
    if (!name) {
        throw Error('Name is empty!')
    }
    const iosProps = {
        disabled: false,
        ios_backgroundColor: colors.COLOR_BLACK_99,
        pointerEvents: 'none'
    }
    const androidProps ={
        disabled : true
    }
    let p
    if(Platform.OS == 'android'){
        p = androidProps
    }else{
        p= iosProps
    }
    return (
        <TouchableOpacity activeOpacity={1} style={styles.container} onPress={onPress}>
            <Text style={styles.name}>{name}</Text>
            {desc ? <Text style={styles.desc}>{desc}</Text> : null}
            <Switch
                {...p}
                testID={testID}
                style={styles.toggle}
                value={isOpen}
                onTintColor={colors.COLOR_ORANGE_RED}
                tintColor={colors.COLOR_BLACK_99}
                thumbColor={colors.COLOR_WHITE}
                thumbTintColor={colors.COLOR_WHITE}
                ref={_ref}
                
            />
        </TouchableOpacity>)
}

const styles = StyleSheet.create({
    name: {
        fontSize: dimens.DIMENS_TEXT_DEFAULT,
        color: colors.COLOR_BLACK_33,
        lineHeight: 20,
        left: 0,
    },
    container: {
        height: 56,
        flexDirection: 'row',
        width: '100%',
        alignItems: 'center',
        //justifyContent:'flex-start',
        paddingLeft: dimens.DIMENS_SPACING_DEFAULT,
        paddingRight: dimens.DIMENS_SPACING_DEFAULT,
        backgroundColor: colors.COLOR_WHITE,

    },
    desc: {
        fontSize: dimens.DIMENS_TEXT_SMALL,
        color: colors.COLOR_BLACK_99,
        lineHeight: 20,
        position: 'absolute',
        right: 68
    },
    toggle: {
        //width: 44,
        //  height: 20,
        position: 'absolute',
        right: 0,
        marginRight: dimens.DIMENS_SPACING_DEFAULT
        // transform:[{
        //     scaleX:1.2
        // },{
        //     scaleY:1.2
        // }]
    }
})
module.exports = { SwitchToggle }