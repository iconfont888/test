/*
 * @Author: Kobe 
 * @Date: 2019-04-29 14:49:56 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-06-27 08:14:47
 */
import React, { Component } from 'react'
import AgHeaderSecondary from '../../common/UI/AgHeaderSecondary';
import { View, StyleSheet, Text, Platform, Alert } from 'react-native'
import dimens from '../../common/dimens';
import colors from '../../common/colors';
import { AgBtn } from "../../common/UI";
import { LOCK_ACCOUNT } from '../../service/getData'
import DeviceInfo from 'react-native-device-info'
import { AgDialog } from '../../common/UI'
import BackPressComponent from '../../common/BackPressComponent';
import NavigationUtil from '../../router/NavigationUtil'
import SafeAreaViewPlus from '../../common/SafeAreaViewPlus';
import Strings from '../../common/Strings'
import actions from "../../action";
import Types from "../../action/types";
import { connect } from "react-redux";

type Props = {}
const TAG = 'AccountLockPage'
class AccountLockPage extends Component<Props>{
    constructor(props) {
        super(props)
        this.state = {
            showDialog: false
        }
        this.showDialog = this.showDialog.bind(this)
        this.cancelPress = this.cancelPress.bind(this)
        this.enterPress = this.enterPress.bind(this)
        this.backPress = new BackPressComponent({ backPress: () => this.onBackPress() })
    }

    componentDidMount() {
        this.backPress.componentDidMount()

    }

    componentWillUnmount() {
        this.backPress.componentWillUnmount()
        this.cancelPress()
    }

    showDialog() {
        //    this.setState({
        //        showDialog:true
        //    })
        Alert.alert(
            Strings.DIALOG_TITLE_TIPS,
            '您确定要冻结账号吗?',
            [
                { text: Strings.DIALOG_CANLEL },
                {
                    text: Strings.DIALOG_ENTER, onPress: () => {
                        this.enterPress()
                    }
                },
            ],
            // { cancelable: true }
        )
    }

    hideDialog() {
        this.setState({
            showDialog: false
        })
    }

    onBackPress() {
        NavigationUtil.goBack(this.props.navigation)
        return true
    }

    enterPress() {
        //this.hideDialog()
        LOCK_ACCOUNT().then((res) => {
            if (res.successful) {
                global.toast(Strings.MSG_SUCCESS)
                this.props.onFetchList([Types.SYNC_LOGOUT])
            } else {
                global.toast(Strings.MSG_FAILED)
            }
        }).catch((e) => {
            global.toast(Strings.MSG_FAILED)
            console.log(TAG, 'enterPress', e)
        })
    }




    cancelPress() {
        this.hideDialog()
    }
    render() {
        return (<SafeAreaViewPlus>
            <AgHeaderSecondary navigation={this.props.navigation} title='紧急冻结账号' />
            <View style={{padding:5}}>
                <Text style={styles.content}>紧急冻结将无法在网站、app中登录账号，您确定要紧急冻结账号吗？</Text>
            </View>
            <AgBtn title={'冻结账号'}
                titleStyle={{ fontSize: dimens.DIMENS_TEXT_BIG_14, fontWeight: 'bold' }}
                buttonStyle={styles.button}
                onPress={this.showDialog}
            />
            <AgDialog
                title={Strings.DIALOG_TITLE_TIPS}
                desc={'您确定要冻结账号吗?'}
                visible={this.state.showDialog}
                onBackdropPress={this.cancelPress}
                leftBtnTitle={Strings.DIALOG_CANLEL}
                rightBtnTitle={Strings.DIALOG_ENTER}
                leftBtnPress={this.cancelPress}
                rightBtnPress={this.enterPress}
            />
        </SafeAreaViewPlus>
        )
    }
}

const mapDispatchToProps = dispatch => ({
    onFetchList: (arr) => dispatch(actions.onFetchList(arr)),

});
const mapStateToProps = state => ({
    nav: state.nav,
});
export default connect(mapStateToProps, mapDispatchToProps)(AccountLockPage)

const styles = StyleSheet.create({
    content: {
        color: colors.COLOR_BLACK_66,
        marginTop: 20,
        marginBottom: 20,
        marginLeft: dimens.DIMENS_SPACING_DEFAULT,
        marginRight: dimens.DIMENS_SPACING_DEFAULT,
        lineHeight: 20,
        width: '100%',
        fontSize: 12
    },
    button: {
        height: 46,
        marginLeft: dimens.DIMENS_SPACING_DEFAULT,
        marginRight: dimens.DIMENS_SPACING_DEFAULT,
    }
})
