/*
 * @Author: Kobe 
 * @Date: 2019-05-01 13:14:16 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-07-01 10:43:43
 */
import React, { Component } from 'react'
import SafeAreaViewPlus from '../../common/SafeAreaViewPlus';
import AgHeaderSecondary from '../../common/UI/AgHeaderSecondary';
import { Text, StyleSheet, View, Alert } from 'react-native'
import dimens from '../../common/dimens';
import colors from '../../common/colors';
import { SwitchToggle } from './SwitchToggle'
import { GET_LOGIN_SET, SET_LOGIN_SET } from '../../service/getData'
import AppModule from '../../common/AppModule'
import loadingUtil from '../../util/loadingUtil'
import BackPressComponent from '../../common/BackPressComponent';
import NavigationUtil from '../../router/NavigationUtil'

type Props = {}
export default class LoginSettingPage extends Component<Props>{
    constructor(props) {
        super(props)
        this.state = {
            togglePwdLogin: false,
            toggleSmsLogin: false,
            toggleFingerLogin: false,
            toggleFaceLogin: false,
            isSupportFinger: false,
            isSupportFace: false,
            isFetching: false
        }
        //   this.onTogglePress = this.onTogglePress.bind(this)
        this.backPress = new BackPressComponent({backPress:()=>this.onBackPress()})

    }

    componentDidMount() {
        this.backPress.componentDidMount()

    }

    componentWillUnmount() {
        this.backPress.componentWillUnmount()
        this.hideLoaing()
    }


    onBackPress(){
        NavigationUtil.goBack(this.props.navigation)
        return true
    }
    componentWillMount() {
        this.getSetting()
        AppModule.deviceSupportTouchID().then((res) => {
            //状态码请看APPModule描述文档
            if (res.code && res.code === 200) {
                this.setState({
                    isSupportFinger: true,
                })
            }
        }).catch((e) => {
            console.log(e)
        })

        AppModule.deviceSupportFaceID().then((res) => {
            if (res.code && res.code === 200) {
                this.setState({
                    isSupportFace: true,
                })
            }
        }).catch((e) => {
            console.log(e)
        })
    }

    showLoaing() {
        this.setState({
            isFetching: true
        })
        loadingUtil.showLoaing()
    }

    hideLoaing() {
        loadingUtil.hideLoaing()
        this.setState({
            isFetching: false
        })
    }

    async getSetting() {
        this.showLoaing()

        GET_LOGIN_SET().then((res) => {
            if (res.successful) {
                this.setState({
                    togglePwdLogin: res.data.password,
                    toggleSmsLogin: res.data.sms,
                    toggleFingerLogin: res.data.fingerprintLogin,
                    toggleFaceLogin: res.data.faceLogin,
                })
            } else{

            }
            this.hideLoaing()
        }).catch((e) => {
            // global.toast(e)
            this.hideLoaing()
        })
    }

    onTogglePress(name) {
        if (this.state.isFetching) {
            return
        }
        let togglePwdLogin = this.state.togglePwdLogin
        let toggleSmsLogin = this.state.toggleSmsLogin
        let toggleFingerLogin = this.state.toggleFingerLogin
        let toggleFaceLogin = this.state.toggleFaceLogin
        switch (name) {
            case 'pwd':
                togglePwdLogin = !this.state.togglePwdLogin
                break;
            case 'sms':
                toggleSmsLogin = !this.state.toggleSmsLogin
                break;
            case 'finger':
                toggleFingerLogin = !this.state.toggleFingerLogin
                break;
            case 'face':
                toggleFaceLogin = !this.state.toggleFaceLogin
                break;
            default:
                break;
        }
        if (!togglePwdLogin && !toggleSmsLogin) {
            Alert.alert(
                '提示',
                '必须至少开启一个普通登录选项!',
                [
                    { text: '确定' },
                ],
                { cancelable: false }
            )
            return
        }

        this.showLoaing()
        

        SET_LOGIN_SET(togglePwdLogin, toggleSmsLogin, toggleFingerLogin, toggleFaceLogin).then((res) => {
            if(res.successful){
                this.setState({
                    togglePwdLogin: togglePwdLogin,
                    toggleSmsLogin: toggleSmsLogin,
                    toggleFingerLogin: toggleFingerLogin,
                    toggleFaceLogin: toggleFaceLogin,
                })
            }
            this.hideLoaing()
        }).catch((e) => {
            this.hideLoaing()
        })


    }

    render() {
        let quickLoginViewContent = null
        if (this.state.isSupportFace || this.state.isSupportFinger) {

            quickLoginViewContent = <View style={{ flex: 1 }}>
                <Text style={styles.title}>快捷登录</Text>
                {this.state.isSupportFinger ? <SwitchToggle
                    name={'指纹登录'}
                    desc={'使用手机绑定的指纹登录'}
                    isOpen={this.state.toggleFingerLogin}
                    onPress={() => {
                        this.onTogglePress('finger')
                    }}
                /> : null}
                <View style={styles.line} />
                {this.state.isSupportFace ? <SwitchToggle
                    name={'刷脸登录'}
                    desc={'通过面部识别进行登录'}
                    isOpen={this.state.toggleFaceLogin}
                    onPress={() => {
                        this.onTogglePress('face')
                    }}
                /> : null}
            </View>
        }

        return (<SafeAreaViewPlus>
            <AgHeaderSecondary navigation={this.props.navigation} title='登录设定' />
            <Text style={styles.title}>普通登录</Text>
            <SwitchToggle
                testID={'1'}
                name={'密码登录'}
                desc={'账号密码登录'}
                isOpen={this.state.togglePwdLogin}
                onPress={() => {
                    this.onTogglePress('pwd')
                }}
            />
            <View style={styles.line} />
            <SwitchToggle
                testID={'2'}
                name={'动态码登录'}
                desc={'绑定手机接收动态码短信'}
                isOpen={this.state.toggleSmsLogin}
                onPress={() => {
                    this.onTogglePress('sms')
                }}
            />
            {quickLoginViewContent}
        </SafeAreaViewPlus>)
    }
}

const styles = StyleSheet.create({
    title: {
        fontSize: dimens.DIMENS_TEXT_DEFAULT,
        color: colors.COLOR_BROWN_DEEP,
        marginTop: 20,
        marginLeft: dimens.DIMENS_SPACING_DEFAULT,
        marginBottom: dimens.DIMENS_SPACING_DEFAULT
    },
    line: {
        height: dimens.DIMENS_LINE_DEFAULT,
    }
})