import React, { Component } from 'react';
import { View, Text ,StyleSheet, } from 'react-native';
import { connect } from "react-redux";
import { Button } from 'react-native-elements';
import NavigationUtil from '../router/NavigationUtil'
import WebViewPage from './WebViewPage';



type Props = {};
class BbsPage extends Component<Props>{
    
    render() {
   // AccountLockPage
        
        
        return null
    }
}


const mapStateToProps = state => ({
    nav: state.nav,
    // customThemeViewVisible: state.theme.customThemeViewVisible,
    // theme: state.theme.theme,
});
export default connect(mapStateToProps)(BbsPage)