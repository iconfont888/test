/**
 *Created by Lili 2019/4/11
 * 首页 登录按钮模块
 **/
import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View, Image,ActivityIndicator
} from 'react-native';
import {AgBtn, AgCard, AgUserLevel} from "../../common/UI";
import Svg, {Ellipse} from "react-native-svg";
import dimens from "../../common/dimens";
import Color from "../../common/colors";
import actions from "../../action";
import {connect} from "react-redux";
import NavigationUtil from "../../router/NavigationUtil";
import ImgURL from '../../common/ImgURL'
import Types from '../../action/types'
import {AgCardBox} from "../../common/UI/AgCard";
import colors from '../../common/colors';

class LoginBtnCard extends Component {
    constructor(props) {
        super(props)
        // console.log(this.props,"==LoginBtnCard ==,==")
        this.loginArr = [
            {name: '登录', path: "LoginPage", eColor: '#FC9224', sColor: '#FFC24E'},
            {name: '注册', path: "RegisterPage",}
        ]
    }

    goLogin = (path) => {
        console.log(NavigationUtil.getNavigation(),"NavigationUtil.getNavigation()")
        NavigationUtil.goPage(path)
        // this.props.navigation.replace(path)
        // alert(e.target + " ==" + name)
        // this.props.onLoginStatus(true)
    }

    render() {
        return (
            <AgCardBox>
                {
                    this.props.badge != '' && (
                        <View
                            style={{
                                height: 20,
                                borderColor:'#fff',
                                width: 66,
                                position: "absolute",
                                right: 5,
                                top: 6,
                                zIndex: 2,
                                borderWidth:1,
                                borderRadius: 4,

                                justifyContent:'center',
                                alignItems:'center',
                                backgroundColor:'#ffcd1d'}}
                        >
                            <Text style={{color:"#c21919",fontSize:12}}>{
                                this.props.badge
                            }</Text>
                        </View>
                    )
                }
                <View style={styles.loginCard}>
                    {
                        this.loginArr.map((u, i) => {
                            return (
                                <View style={styles.btnBox} key={i}>
                                    <AgBtn title={u.name} sColor={u.sColor} eColor={u.eColor}
                                           titleStyle={{fontSize: H2, fontWeight: 'bold', lineHeight: 30}}
                                           buttonStyle={{height: 30}}
                                           onPress={() => this.goLogin(u.path)}
                                    />
                                </View>
                            )
                        })
                    }
                </View>
            </AgCardBox>
        )
    }
}

class UserInfo extends Component {
    constructor(props) {
        super(props)
        // console.log(this.props,"==LoginBtnCard ==,==")
        this.loginArr = [
            {name: '登录', path: "LoginPage", eColor: '#FC9224', sColor: '#FFC24E'},
            {name: '注册', path: "RegisterPage",}
        ]
    }
    componentDidMount() {
        this.props.onFetchList(Types.GET_BALANCE)
    }
    render() {
        const isRefreshing=this.props.fetchType==Types.GET_BALANCE
        console.log('isRefreshing',isRefreshing,this.props.fetchType)
        return (
            <AgCardBox>
                <View style={styles.box}>
                    <View style={styles.header}>
                        <Text style={styles.txt}>您好！{this.props.loginName} </Text>
                        <View style={{marginLeft: 10}}>
                            <AgUserLevel/>
                        </View>
                    </View>
                    <View style={styles.body}>

                        <Text style={styles.txt}>总余额：</Text>
                        {
                            isRefreshing ? <ActivityIndicator size="small" color="#333" style={{margin:4}} />:
                                <Text style={styles.txtBold}>￥{this.props.totalBalance}</Text>
                        }
                    </View>

                </View>

            </AgCardBox>
        )
    }
}

/**
 *cx prop定义椭圆中心的x坐标
 *cy prop定义椭圆中心的y坐标
 * rx prop定义水平半径
 *ry prop定义垂直半径
 * @returns {*}
 * @constructor
 */
const ArchSvg = () => (
    <Svg height='50' width='100%'>
        <Ellipse
            cx="50%"
            cy='100%'
            rx="50%"
            ry="50%"
            fill='#F3F3F3'
        />
    </Svg>

)

class UserInfoCard extends Component {
    constructor(props) {
        super(props)
        // this.props.onLoginStatus(true)
    }
    render() {
        return (
            <View style={styles.container}>
                <ArchSvg/>
                <View style={{
                    height: this.props.isLogin ? 40 : 10,
                    width: '110%',
                    padding: 0,
                    backgroundColor: "#F3F3F3"
                }}></View>
                <View style={styles.absolute}>
                    {this.props.isLogin ? <UserInfo/>: <LoginBtnCard badge={this.props.rBadge}/>}

                </View>
            </View>
        );
    }
}

const SPACING = dimens.DIMENS_SPACING_DEFAULT
const BORDER_LINE = Color.COLOR_DEFAULT_LINE
const H1=dimens.DIMENS_TEXT_BIG_18
const H2=dimens.DIMENS_TEXT_BIG_16
const styles = StyleSheet.create({

    container: {
        flex: 1,
        // position: 'absolute',
        // bottom: -100,
        // left:0,
        // right:0,
        width: '100%',

        zIndex: 1000,
    },
    btnBox: {
        padding: 10, flex: 1
    },
    loginCard: {
        // flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: "center",
        backgroundColor: '#fff',

    },
    absolute: {
        position: 'absolute',
        top: 0, width: '100%'
    },

    box: {padding: SPACING},
    header: {
        flex: 1, flexDirection: 'row', alignItems: 'center',
        borderBottomWidth: 1, borderBottomColor: BORDER_LINE, paddingBottom: 10
    },
    body: {marginTop: 10,flexDirection:"row",alignItems:'center'},
    txt: {color:'#666',fontSize:H2},
    txtBold: {fontWeight: 'bold',color:colors.COLOR_BLACK_33,fontSize:dimens.DIMENS_TEXT_BIG_18}
});
const mapDispatchToProps = dispatch => ({
    // onLoginStatus: (is) => dispatch(actions.onLoginStatus(is)),
    onFetchList: (arr) => dispatch(actions.onFetchList(arr)),
    // onfetchTest: () => dispatch(actions.onfetchTest()),
    // onHeaderColor: (c) => dispatch(actions.onHeaderColor(c)),
    // onSpCurrentUri:(idx)=>dispatch(actions.onSpCurrentUri(idx))
});
const mapStateToProps = (state) => ({
    nav: state.nav,
    isLogin: state.UserInfoReducer.isLogin,
    isRefreshing: state.fetchReducer.isRefreshing,
    fetchType: state.fetchReducer.fetchType,

    rBadge: state.fetchReducer.CMS_REGISTERED_BADGE_D,

    totalBalance: state.UserInfoReducer.GET_BALANCE_D.totalBalance,
    loginName: state.UserInfoReducer.loginName,
    // headerColor:state.HomeReducer.headerColor,
    // payload: JSON.stringify(state.fetchReducer.payload),
});
UserInfo = connect(mapStateToProps,mapDispatchToProps)(UserInfo)
// LoginBtnCard=connect(mapStateToProps, mapDispatchToProps)(LoginBtnCard)
export default connect(mapStateToProps, mapDispatchToProps)(UserInfoCard)
