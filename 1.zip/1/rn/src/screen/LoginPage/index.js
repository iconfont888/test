import React, { Component } from 'react';
import { View, Text, Dimensions, StyleSheet, TouchableOpacity } from 'react-native';
import { connect } from "react-redux";
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import SafeAreaViewPlus from "../../common/SafeAreaViewPlus";
import colors from "../../common/colors";
import FastLogin from './FastLogin';
import DynamicLogin from './DynamicLogin';
import OtherLogin from './OtherLogin';
import { AgHeaderSecondary } from "../../common/UI";
import { LOGIN_METHOD } from '../../service/getData';
import AppModule from '../../common/AppModule'
import AppStorage from '../../util/AppStorage'
import Constant from '../../common/Constant'
import AGTab from '../../plugin/tab';


class LoginPage extends Component {
  constructor(props) {
    super(props)
    this.state = {
      routes: [
        { key: 'first', title: '快速登录' },
        { key: 'second', title: '动态码登录' },
      ],
      redirect: "",
      otherLogin: false
    };
  };
  tabData() {
    return (
      [
        {

          key: 'FastLogin',
          type: 1,
          screen: () => <FastLogin navigation={this.props.navigation} redirect={this.state.redirect} />,
          navigationOptions: {
            title: '快速登录',
          }
        },
        {

          key: 'DynamicLogin',
          type: 2,
          screen: () => <DynamicLogin navigation={this.props.navigation} redirect={this.state.redirect} />,
          navigationOptions: {
            title: '动态码登录',
          }
        },
      ]
    )
  }
  componentWillMount(): void {
    try {
      if (this.props.navigation.state.params && this.props.navigation.state.params.redirect) {
        let redirect = this.props.navigation.state.params.redirect;
        this.setState({
          redirect: redirect,
        })
      }
    } catch (error) {
    }
  }
  render() {
    let { otherLogin } = this.state;
    return (
      <SafeAreaViewPlus style={styles.loginBox}>
        <AgHeaderSecondary navigation={this.props.navigation} title={otherLogin ? (otherLogin === 1 ? '指纹登录' : '面部登录') : '登录'} />
        {
          !this.state.otherLogin ?
            <AGTab tabData={this.tabData()} tabStyle={{ width: Dimensions.get('window').width / 2, height: 40 }}></AGTab>
            : <OtherLogin otherLogin={otherLogin} redirect={this.state.redirect} changeLogin={() => { this.setState({ otherLogin: false }) }} />

        }
      </SafeAreaViewPlus>
    )
  }

  async getOtherLogin() {
    let haveTouch, haveFace;
    const LastLoginName = await AppStorage.get(Constant.KEY_LAST_LOGIN_NAME);
    if (LastLoginName) {
      AppModule.deviceSupportTouchID().then((res) => {
        if (res.code && res.code === 200) {
          haveTouch = true;
        }
      })
      AppModule.deviceSupportFaceID().then((res) => {
        if (res.code && res.code === 200) {
          haveFace = true;
        }
      })
      await LOGIN_METHOD(LastLoginName).then((res) => {
        if (res.successful) {
          if (res.data.faceLogin && haveFace) {
            this.setState({ otherLogin: 2 });
            return
          }
          if (res.data.fingerprintLogin && haveTouch) {
            this.setState({ otherLogin: 1 })
          }
        }
      })
    }
  }
  componentDidMount() {
    this.getOtherLogin();
  }
}

const styles = StyleSheet.create({
  loginBox: {
    flex: 1,
    backgroundColor: colors.COLOR_WHITE
  },
});

//监听状态
const mapStateToProps = state => ({
  nav: state.nav,
  isLogin: state.UserInfoReducer.isLogin,
});
export default connect(mapStateToProps)(LoginPage)
