/*
 * @Author: Kobe 
 * @Date: 2019-06-07 15:15:52 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-06-10 10:54:27
 * 这个类存储一些全局变量,不能删除
 */

export default class MyGlobal{

}