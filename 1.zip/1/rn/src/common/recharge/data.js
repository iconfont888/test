// 充值页面 本地数据js
import VirtualComponent from './virtualComponent'
import RechargePagecomponent from './rechargePagecomponent'
import React, { Component } from 'react';
const IMG_DATA = {
    // 充值页面 icon
    "pay_bankcard_icon": require('../../assets/recharge/bankcard.png'),
    "pay_virtual_icon": require('../../assets/recharge/bitcorn.png'),
    "pay_bitebi_icon": require('../../assets/recharge/bitebi.png'),
    "pay_china_icon": require('../../assets/recharge/china.png'),
    "pay_ONLINE_JD_QR_icon": require('../../assets/recharge/jdPay.png'),
    "pay_online_icon": require('../../assets/recharge/online.png'),
    "pay_app_icon": require('../../assets/recharge/phone.png'),
    "pay_QQ_APP_icon": require('../../assets/recharge/qq.png'),
    "pay_QQ_QR_icon": require('../../assets/recharge/qq.png'),
    "pay_qrpay_icon": require('../../assets/recharge/scan.png'),
    "pay_phone_bank_icon": require('../../assets/recharge/shouji.png'),
    "pay_ONLINE_BANK_icon": require('../../assets/recharge/upan.png'),
    "pay_WECHAT_APP_icon": require('../../assets/recharge/wechat.png'),
    "pay_WECHAT_QR_icon": require('../../assets/recharge/weixin.png'),
    "pay_scan_wechat_icon": require('../../assets/recharge/weixin.png'),
    "pay_online_bank1_icon": require('../../assets/recharge/yinhangka.png'),
    "pay_ONLINE_UNIONPAY_QR_icon": require('../../assets/recharge/yinlian.png'),
    "pay_ONLINE_PLATFORM_icon": require('../../assets/recharge/yinlian.png'),
    "pay_yitaibi_icon": require('../../assets/recharge/bitebi.png'),
    "pay_alipay_icon": require('../../assets/recharge/zhifubao.png'),
    "pay_ALIPAY_QR_icon": require('../../assets/recharge/zhifubao1.png'),
    "pay_app_alipay_icon": require('../../assets/recharge/zhifubao1.png'),
    "pay_ALIPAY_APP_icon": require('../../assets/recharge/zhifubao1.png'),
    "pay_QUICK_PAY_icon": require('../../assets/recharge/quick_pass.png'),
    "pay_alipay_icon2": require('../../assets/recharge/zhifubao2.png'),
    'bank_card_bg': require('../../assets/recharge/bank_card.png'),
    'important': require('../../assets/recharge/important.png'),
    'pay_kcPay_icon': require('../../assets/recharge/pay_kcPay_icon.png'),
    'corner': require('../../assets/recharge/corner.png'),
}

const RECHARGE_DATA = {
        qrpay:{ // 扫码支付
            id: "qrpay",
            name: "扫码支付",
            active: true,
            tip: '支持微信/银联/QQ/京东，实时到账',
            payTitle: '扫码类型：',
            imgUri:IMG_DATA.pay_qrpay_icon,
            API:'/api/pay/scan-qr',
            sendPayType:'scan-qr',
            pattern: "scan_jd|scan_qq|scan_unionpay|scan_wechat|scan_big_wechat",
        },
        app:{ // app支付
            id: "app",
            name: "APP支付",
            pattern: "app_",
            active: false,
            sendPayType:'wap-app',
            API:'/api/pay/scan-qr',
            imgUri:IMG_DATA.pay_app_icon,
            tip: "通过 APP 钱包支付，实时到账，快速便捷",
            payTitle: "APP类型：",
        },
        alipay:{ // 支付宝支付
            id: 'alipay',
            name: '支付宝',
            active: false,
            API:'/api/pay/scan-qr',
            imgUri:IMG_DATA.pay_alipay_icon,
            sendPayType:'scan-qr',
            pattern: 'scan_alipay|scan_big_alipay',
            tip:'扫码转账，实时到账',
            payTitle: "充值类型："
        },
        online:{
            id: "online",
            name: "在线支付",
            active: false,
            pattern: "online_",
            API:'/api/pay/online',
            sendPayType:'online',
            imgUri:IMG_DATA.pay_online_icon,
            tip:"在线充值，实时到账",
            payTitle: "充值类型：",
        },
        transfer:{
            id: "bankcard",
            name: "银行卡转账",
            pattern: "transfer",
            sendPayType:'',
            active: false,
            API:'/api/pay/bq',
            imgUri:IMG_DATA.pay_bankcard_icon,
            tip:"转账到银行卡，3分钟内到账",
            payTitle: "充值方式：",
        },
        virtual_btc:{
            id: "virtual",
            name: "比特币支付",
            pattern: "virtual_",
            sendPayType:'virtual',
            active: false,
            API:'/api/pay/virtual',
            imgUri:IMG_DATA.pay_bitcorn_icon,
            tip:"不记名充值，安全又快捷",
            payTitle: "扫码类型：",
        },
        kcPay:{
            id: "kcPay",
            name: "快充",
            pattern: "kcPay",
            sendPayType:'kcPay',
            active: false,
            API:'/api/pay/kaier/orderNo',
            imgUri:IMG_DATA.pay_kcPay_icon,
            tip:"微信、支付宝、银行APP",
            payTitle: "扫码类型：",
        }
    }
// 充值金额提示
const RECHARGE_REG_RULE_TIP ={
    blankMessage: '充值金额不能为空',
    apilyVaildMessage: '请输入有效的充值金额',
    apilyIntMessage:'充值金额仅支持整数',
    apilyPiontMessage: '充值金额必须带有两位小数',
    appMessage: '你已选择微信充值',
    'pay_online_bank': '登录网银',
    'pay_online_platform': '登录银联',
    'pay_qrpay': '扫描二维码',
    'pay_app': '登录APP',
    'pay_alipay': '扫描二维码',
    'pay_virtual': '打开比特币钱包',
    'pay_bank_tip': '【温馨提示】建议存入特殊金额，以便款项能更快速匹配到账。',
    'bank_large_money_tip': '每周五17：00～周日24：00进行跨行/支付宝/微信转账50000元及以上金额，受人民银行系统开发时间影响，一般会在下周一9：00延时到账。因银行卡有时效性，请尽量避免于该时间段使用大额跨行转账。',
    pay_bank_tip_example: '（例： 7659、12349、50000.33...）',
    placeHolderMessage: '单笔充值金额',
    minMessageAndMaxMessage: '',
}
const RECOMMEND_DATA = [
    {
        text: '扫码支付',
        tips:  ["实时到账 无手续费 安全快速"],
        idRecom: true,
        imgUri:IMG_DATA.pay_qrpay_icon,
        id: "qrpay",
    },
    {
        text: '比特币支付',
        id: "virtual",
        imgUri:IMG_DATA.pay_virtual_icon,
        tips: ["不记名充值 安全又快捷"],
        idRecom: true,
    },
    {
        text: '在线支付',
        id: "online",
        imgUri:IMG_DATA.pay_online_icon,
        tips: ["实时到账 无手续费 安全快速"],
        idRecom: true,
    },
    {
        text: 'APP支付',
        tips: ["APP钱包支付 无手续费 安全快捷"],
        id: "app",
        imgUri:IMG_DATA.pay_app_icon,
        idRecom: true,
    },
    {
        text: '支付宝',
        id: 'alipay',
        imgUri:IMG_DATA.pay_alipay_icon,
        tips: ["扫码转账，实时到账", "方便快捷 使用人数多"],
        idRecom: false,
    },
    {
        text: '银行卡转账',
        id: "bankcard",
        imgUri:IMG_DATA.pay_bankcard_icon,
        tips: ["简单 方便 1-3分钟内到账", "支持所有银行 网银/手机银行转账"],
        idRecom: false,
    },
   {
        id: "kcPay",
        text: "快充",
        idRecom: false,
        imgUri:IMG_DATA.pay_kcPay_icon,
        tips:["微信、支付宝、银行APP"],
    }]
// 充值 正则 验证
const RECHARGE_REG_RULE ={
   'apily': [
       {
           reg: /[0-9]{1,22}(.[0-9]{1,2})?/
       }
   ],
   numberReg: /^\d+(.[0-9]{1,2})$/,
    noNumberReg:/^([a-z])|([A-Z])$/,
    REAL_NAME_REGEX: /(^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5]$)|(^[a-zA-Z][a-zA-Z\s.]{0,18}[a-zA-Z]$)/,
}
const SEND_LETTER_DATA = {
    checkBankCardNumberChange:{ // 充值成功
        text: '旧卡已更换，转账时请勿转入旧卡，以免造成您的资金损失！',
        url: '/api/pay/remind/bank',
        type: 'POST',
        letterType:'BANK_CARD_NUMBER_CHANGE'
    },
    checkFirstTimeBQ:{ // tab切换
        text: '每次使用银行卡转账前，须先到网站获取/确认卡号信息，以免造成您的资金损失！',
        url: '/api/pay/remind/first',
        type: 'POST',
        letterType:'FIRST_TIME_BQ'
    },
    checkHaveCard:{ // 初始化时调用
        text: '旧卡已停用，转账时请勿转入旧卡，以免造成您的资金损失！',
        url: '/api/pay/remind/card',
        type: 'POST',
    },
    clearBankCardHistory:{ // 充值成功后第二步再次调用
        text: '亲，记得定期清理网银收款银行列表中的旧卡信息，以免误转入旧卡造成您的资金损失！',// 弹窗信息
        url: '/api/pay/remind/history',//url
        type: 'POST', // 请求方式
        letterType:'CLEAR_BANK_CARD_HISTORY' // 短信类型
    },
}
export {
    RECHARGE_DATA,
    RECHARGE_REG_RULE,
    RECHARGE_REG_RULE_TIP,
    IMG_DATA,
    SEND_LETTER_DATA,
    RECOMMEND_DATA

}
