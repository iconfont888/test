import React, { Component } from 'react';
import { View, Text, TextInput } from 'react-native';
export default class VirtualComponent extends Component{
    constructor(props){
        super(props)
    }

    render() {
        return (
            <View>
                <Text>比特币充值页面</Text>
            </View>
        );
    }
}