/*
 * @Author: Kobe 
 * @Date: 2019-04-15 17:50:26 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-07-23 15:42:43
 * 域名环境
 */
import AppModule from './AppModule'
import Constant from './Constant';
import AppStorage from '../util/AppStorage'
import { GET_DOMAIN_LOOP_INFO } from '../service/getData'
import { defaultLoopPath } from '../service/env'
import MyGlobal from './MyGlobal';
import { baseUrl } from '../service/env'
import {DeviceEventEmitter} from 'react-native'



const PID = 'b79'

const _TEST = 0
const _JSON = 1
const TAG = 'Domain'
export default class Domain {

    static async initDomain() {
        //换取app中DomainApiPath的值
        const domain = AppModule.getInstance().DOMAIN_API_PATH
        if (domain) {
            //Jenkins中设置了DomainApiPath,强制使用该值作为环境url,优先级比DomainLoopJsonPath高  
            //在该值存在时,屏蔽域名轮询功能
            MyGlobal.currentDomain = domain
            console.log(TAG, 'initDomain', 'Jenkins设置了DomainApiPath,应用指定域名,屏蔽域名轮询功能')
        } else {
            //Jenkins中没有设置DomainApiPath
            //开始检查Jenkins是否设置了DomainLoopJsonPath
            const paths = AppModule.getInstance().DOMAIN_LOOP_JSON_PATH
            //baseUrl使用默认全局环境值,一般配置为运营环境,其他环境在需要分包测试时直接使用Jenkins打包,用DomainApiPath或DomainLoopJsonPath控制
            //开启域名轮询
            this.initLoop(paths)
        }

    }

    /**
     * Jenkins中设置了DomainLoopJsonPath,true则强制使用该值进行域名轮询
     * @param {*} isUseJenkinsPath 
     */
    static initLoop(domainLoopJsonPath) {
        const urls = new Map()


        //获取上次缓存域名
        AppStorage.get(Constant.KEY_CACHE_DOMAIN).then((cacheDomain) => {
            if (cacheDomain) {
                //加入缓存域名到检查列表
                urls.set(cacheDomain, _TEST)
            }

            //加入本地默认域名到检查列表(此时默认变量未被改变)
            urls.set(baseUrl(), _TEST)

            //加入json列表
            if (domainLoopJsonPath && domainLoopJsonPath.length > 0) {
                console.log(TAG, 'initLoop', 'Jenkins设置了DomainLoopJsonPath,使用指定json列表进行域名轮询')
                domainLoopJsonPath.forEach((url) => {
                    urls.set(url, _JSON)
                })
            } else {
                console.log(TAG, 'initLoop', '使用默认Json列表进行域名轮询')
                defaultLoopPath().forEach((url) => {
                    urls.set(url, _JSON)
                })
            }



            //设置当前全局域名
            if (cacheDomain) {
                MyGlobal.currentDomain = cacheDomain
                console.log(TAG, 'initLoop', '获取上次缓存域名并设置', cacheDomain)
            }

            //轮询检查
            this.loop(urls)
        })



    }

    static loop(urls: Map) {
        if (!urls || urls.size < 1) {
            console.log(TAG, 'loop', '轮询结束,所有连接失败')
            AppModule.setBaiduEvent("EVENT_LOOP_FAILED_ALL","轮询结束,所有连接失败")
            return
        }
        console.log(TAG, 'loop', '开始轮询检测')

        let url = urls.keys().next().value
        let mode = urls.get(url)
        console.log(TAG, 'loop', 'url = ' + url, 'mode = ' + (mode === _TEST ? '检测模式' : '获取json模式'))

        //删除这条url
        urls.delete(url)

        //检查url是否可用
        Promise.race([
            GET_DOMAIN_LOOP_INFO(url),
            new Promise((resolve, reject) => {
                setTimeout(() => {
                    reject(new Error('request timeout'))
                }, 2000);
            })
        ])
            .then((response) => {


                if (mode === _TEST) {
                    const code = response.status
                    if (code === 200 || code === 301 || code === 302 || code === 403) {
                        let isNeedToRefresh = false
                        let oldDomain = ''
                        if(MyGlobal.currentDomain && MyGlobal.currentDomain != url){
                            isNeedToRefresh = true
                            oldDomain = MyGlobal.currentDomain
                        }
                        //设置全局域名

                        MyGlobal.currentDomain = url
                        //设置缓存域名
                        AppStorage.save(Constant.KEY_CACHE_DOMAIN, url)

                        console.log(TAG, 'loop', '检测成功,终止轮询')
                        if(isNeedToRefresh){
                            DeviceEventEmitter.emit('DOMAIN_LOOP_SUCCESS_REFRESH')
                            AppModule.setBaiduEvent("EVENT_LOOP_SUCCESS_AND_REPLACE",`OLD:${oldDomain}   NEW:${url}`)
                        }else{
                            AppModule.setBaiduEvent("EVENT_LOOP_SUCCESS_NO_REPLACE",url)
                        }
                        //检测成功,终止轮询
                        return
                    } else {
                        this.loop(urls)
                        AppModule.setBaiduEvent("EVENT_LOOP_FAILED",url)
                    }
                }

                if (mode === _JSON) {
                    if (response.ok) {
                        response.json().then((res) => {
                            console.log(TAG, 'loop', res)
                            if (res && res.list.length > 0) {
                                const data = res
                                const pid = data.list[0].pid
                                const resUrl = data.list[0].url
                                if (pid == PID && resUrl) {
                                    urls.set(resUrl, _TEST)
                                    console.log(TAG, 'loop', '获取Json内容成功,加入轮询队列', 'resUrl = ' + resUrl)
                                }
                            }
                            this.loop(urls)
                        }).catch((e) => {
                            this.loop(urls)
                        })
                    } else {
                        this.loop(urls)
                    }
                }
            }).catch((e) => {
                console.log(TAG, 'loop', e.message)
                this.loop(urls)
            })
    }


}