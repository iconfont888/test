/*
 * @Author: Kobe 
 * @Date: 2019-04-17 13:59:40 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-04-19 10:20:47
 */


import { DeviceEventEmitter, NativeEventEmitter, Platform, NativeModules } from 'react-native';

const DataTransferModule = NativeModules.DataTransferModule
const map = new Map()
class NativeEvent {

    //全局消息通知
    static NATIVE_EVENT_MESSAGE = 'NATIVE_EVENT_MESSAGE'
    //友盟推送消息点击通知
    static NATIVE_EVENT_UMENG_NOTIFICATION_CLICK = 'NATIVE_EVENT_UMENG_NOTIFICATION_CLICK'

    /**
     * 添加原生事件监听,ios的监听对象以promise作为key存储在map中
     * 返回的promise要在componentWillUnmount中移除
     * @param {*} eventName 
     */
    static addLisenter(eventName) {
        const promise = new Promise((resolve, reject) => {
            try {
                if (Platform.OS === 'ios') {
                    let eventEmitter = new NativeEventEmitter(DataTransferModule)
                    eventEmitter.addListener(eventName, (result) => {
                        resolve(result)
                    })
                    map.set(promise, eventEmitter)
                } else {
                    DeviceEventEmitter.addListener(eventName, (result) => {
                        resolve(result)
                    })
                }
            } catch (e) {
                reject(e)
            }


        })
        return promise

    }

    /**
     * 移除监听
     * @param {*} listener 
     */
    static removeLisenter(listener) {
        try {
            map.get(listener).remove()
            map.delete(listener)
        } catch (e) {
            console.log(e)
        }
    }

}
export default NativeEvent