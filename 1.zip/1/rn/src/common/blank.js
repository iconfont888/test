import { Text, View, ScrollView, Image, Dimensions, StyleSheet, RefreshControl } from 'react-native';
import React, { Component } from 'react';
import { connect } from "react-redux";
import imgUrl from '../common/ImgURL';
import colors from '../common/colors'
import { PropTypes } from "prop-types";
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
const blank_icon = require('../assets/blank/nogamerecord.png')
class AGBlank extends Component<Props>{
    static propTypes = {
        tipText: PropTypes.string, // 没有数据的提示信息 默认为暂无数据
        childComponent: PropTypes.func, // 子组件
        handleRefresh: PropTypes.func, // 上拉刷新函数需要 返回一个promise 对象
    }
    constructor(props) {
        super(props)
        this.state = {
            loading: false
        }
        this.handleRefresh = this.handleRefresh.bind(this)
    }
    handleRefresh() {
        this.setState({ loading: true })
        this.props.handleRefresh && this.props.handleRefresh().then((isData) => {
            if (!isData) {
                this.setState({
                    loading: false
                })
            }
        })
    }
    render(): * {
        let scrollStyle = !this.props.childComponent ? {
            flex: 1,
            width: screenWidth,
            paddingHorizontal: 20,
            justifyContent: 'center',
            // height:screenHeight - 124,
            alignItems: 'center'
        } : {
                flex: 1,
                // height:screenHeight - 60,
                width: screenWidth,
                paddingHorizontal: 20,

            }
        return (

            <ScrollView
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={scrollStyle}
                horizontal={false}
                refreshControl={
                    <RefreshControl
                        colors={[colors.COLOR_PROGRESS_BAR]}
                        refreshing={this.state.loading}
                        onRefresh={() => this.handleRefresh()}
                    // tintColor={colors.COLOR_ORANGE_RED}
                    />
                }

            >

                <View style={{ flex: 1, width: '100%', marginTop: -110, justifyContent: 'center', alignItems: 'center', height: this.props.childComponent ? '50%' : null }}>
                    <Image
                        source={blank_icon}
                        style={{ width: 110, height: 110 }}
                    />
                    {
                        this.props.tipComponent ? this.props.tipComponent : <Text style={{ marginTop: 10 }}>{this.props.tipText || '暂无数据'}</Text>
                    }
                </View>
                {this.props.childComponent &&
                    (
                        <View style={{ justifyContent: 'center', alignItems: 'center', borderTopWidth: 1, height: '50%', borderColor: colors.DIMENS_BORDER_COLOR }}>
                            {this.props.childComponent()}
                        </View>)
                }
            </ScrollView>
        )
    }
}
const styles = StyleSheet.create({
    containerStyle: {
        justifyContent: 'center',
        alignItems: 'center',
    }
})
const mapStateToProps = state => ({
    // favorite: state.favorite,
});

const mapDispatchToProps = dispatch => ({
    //将 dispatch(onRefreshPopular(storeName, url))绑定到props
    // onLoadFavoriteData: (storeName, isShowLoading) => dispatch(actions.onLoadFavoriteData(storeName, isShowLoading)),
});
export default connect(mapStateToProps)(AGBlank);
