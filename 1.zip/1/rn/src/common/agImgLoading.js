import {Text, View, StyleSheet, FlatList,RefreshControl,ActivityIndicator} from 'react-native';
import React, { Component } from 'react';
import colors from  '../common/colors';
import {PropTypes} from 'prop-types';
import imgUrls from '../common/ImgURL'
import AGBlank from '../common/blank'
import common from '../util/common'
import {Image} from "react-native-elements";
/**
 *  @author candice
 *  @params 如下propTypes
 *  @ 为何使用回调函数更新数据而不是使用钩子函数更新数据 -》 滚动时两次调用onEndReached
 *  @question 遗留问题，初始化数据为空时，无任何展示
 * **/
export default class AGImgLoading extends Component<Props>{
    static propTypes = {
        data: PropTypes.array, // 初始化时的list数据
        handleLoadData: PropTypes.func, // 数据加载回调函数需要 返回一个promise 对象
        handleRefresh: PropTypes.func, // 上拉刷新函数需要 返回一个promise 对象
        handleFishing: PropTypes.func, // 数据加载完之后的回调
        renderItem: PropTypes.func, // 渲染item
    }
    canLoadMore = true
    constructor(props){
        super(props)
        this.state = {
            uri: this.props.uri,
            imgLoadingContent: this.props.imgLoadingContent || (
                <Image
                    source = {imgUrls["yayoulogo_icon"]}
                    style={{width: 80,height:86}}
                />
            )
        }
        this.imgLoad = this.imgLoad.bind(this)
    }
    imgLoad() {
        this.setState({
            imgLoadingContent: ''
        })
    }
    componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {
        this.setState({
            uri: nextProps.uri
        })
    }
    render(): * {
        return(
            <View style={styles.containerStyle}>
                {
                    this.state.uri == '' ? (
                        <Image
                            source = {imgUrls["yayoulogo_icon"]}
                            style={{width: 80,height:86}}
                            resizeMode={'stretch'}
                        />
                    ) : (
                        <Image
                            source={this.state.uri}
                            style={StyleSheet.flatten([this.props.imgStyle, styles.imgStyle])}
                            resizeMode={'stretch'}
                            PlaceholderContent={this.state.imgLoadingContent !='' && this.state.imgLoadingContent}
                            onLoadEnd={this.imgLoad}
                        />
                    )
                }
            </View>
        )
    }
    componentDidMount(): void {
    }
    componentWillUnmount(){
    }
}
const styles = StyleSheet.create({
    imgStyle: {
        width: '100%',
        height: '100%'
    },
    containerStyle:{
        flex: 1,
    },

})