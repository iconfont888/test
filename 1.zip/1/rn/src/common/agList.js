import {Text, View, StyleSheet, FlatList,RefreshControl,ActivityIndicator} from 'react-native';
import React, { Component } from 'react';
import colors from  '../common/colors';
import {PropTypes} from 'prop-types';
import AGBlank from '../common/blank'
import common from '../util/common'
/**
 *  @author candice
 *  @params 如下propTypes
 *  @ 为何使用回调函数更新数据而不是使用钩子函数更新数据 -》 滚动时两次调用onEndReached
 *  @question 遗留问题，初始化数据为空时，无任何展示
 * **/
export default class AGList extends Component<Props>{
    static propTypes = {
        data: PropTypes.array, // 初始化时的list数据
        handleLoadData: PropTypes.func, // 数据加载回调函数需要 返回一个promise 对象
        handleRefresh: PropTypes.func, // 上拉刷新函数需要 返回一个promise 对象
        handleFishing: PropTypes.func, // 数据加载完之后的回调
        renderItem: PropTypes.func, // 渲染item
    }
    canLoadMore = true
    constructor(props){
        super(props)
        this.state = {
            isMoreData: true, // 是否还有很多数据
            loading:false,
            data: null,
            optimization:true
        }
        this._onEndReached = this._onEndReached.bind(this);
        this._onViewableItemsChanged = this._onViewableItemsChanged.bind(this)
    }
    componentWillMount(): void {
        this.handleRefresh()
    }
    componentWillReceiveProps(nextProps: Readonly<P>, nextContext: any): void {
        if(nextProps.data){

        }
    }

    async handleRefresh(){
        //  上拉刷新
        let self = this;
        await this.props.handleRefresh && this.props.handleRefresh().then(({data = [],total}) => {
            let isMoreData = true;
            if(data.length == total){
                isMoreData = false
            }
            self.setState({
                data:[]
            },() => {
                self.setState({
                    data: [...data],
                    isMoreData
                })
            })

        })
        self.canLoadMore = false;
    }
    genIndicator(){
        return(
            <View style={styles.indicatorContainer}>
                {
                    !this.state.isMoreData ? <Text>我是有底线的</Text> : <View>
                        <ActivityIndicator
                            style={styles.indicator}
                            // color={colors.COLOR_ORANGE_RED}
                        />
                        <Text>正在加载更多</Text>
                    </View>
                }
            </View>
        )
    }
    resetData(){
       // 重置数据
        let self = this
       if(!this.props.resetData){
           return false;
       }
        this.props.resetData().then(({data,total}) => {
            if(data.length === Number(total) || !data ){
                self.setState({
                    isMoreData: false,
                    data:[...data],
                })
            } else {
                self.setState({
                    data:[...data],
                })
            }
        })
    }
    async _onEndReached(){
        let self = this;
        if (this.canLoadMore) {//fix 滚动时两次调用onEndReached https://github.com/facebook/react-native/issues/14015
            await this.props.handleLoadData && this.props.handleLoadData().then(({data,total}) => {
                let res = [...this.state.data, ...data]
                if(res.length === Number(total) || !data ){
                    self.setState({
                        isMoreData: false,
                        data: res,
                    })
                } else {
                    self.setState({
                        data: res,
                    })
                }
                self.canLoadMore = false;
            })
        }
    }
    _onViewableItemsChanged(info){
        // 优化Item
        // console.log(info, 11111111111)
        // if(this.state.optimization){
        //
        // }
        // this.props.onViewableItemsChanged && this.props.onViewableItemsChanged();

    }
    goTop(){
        this.refs.flatList.scrollToOffset({animated:true, offset:0})
    }
    // this.count =
    render(): * {
        return(
            <View style={styles.containerStyle}>

                {
                    !common.isNull(this.state.data) && ( this.state.data.length > 0 ? (
                        <FlatList
                            {...this.props}
                            ref={'flatList'}
                            data={this.state.data}
                            showsVerticalScrollIndicator = {false}
                            style={styles.listStyle}
                            keyExtractor={(item,index) => '' + index}
                            refreshControl={
                                <RefreshControl
                                    colors={[colors.COLOR_PROGRESS_BAR]}
                                    refreshing={this.props.loading}
                                    onRefresh={() => this.handleRefresh()}
                                    // tintColor={colors.COLOR_ORANGE_RED}
                                />
                            }
                            onEndReached={this._onEndReached}
                            onViewableItemsChanged={this._onViewableItemsChanged}
                            viewabilityConfig={{
                                itemVisiblePercentThreshold:0,
                                waitForInteraction: true
                            }}
                            onMomentumScrollBegin={() => {
                                this.canLoadMore = true; //fix 初始化时页调用onEndReached的问题
                            }}
                            onEndReachedThreshold={1}
                            ListFooterComponent ={() => this.genIndicator()}
                            renderItem={this.props.renderItem}
                        />
                    ) : (

                        <View style={{flex:1}}>
                            <AGBlank
                                handleRefresh={() => this.handleRefresh()}
                            />
                        </View>
                    ))
                }

            </View>
        )
    }
    firstView = true
    componentDidMount(): void {
                            this.firstView = false
    }

    componentWillUnmount(){
        this.setState({
            loading: false
        })
    }
}
const styles = StyleSheet.create({
    indicatorStyle: {
        height: 2,
        backgroundColor: 'white'
    },
    containerStyle:{
        flex: 1,
        backgroundColor: colors.COLOR_DEFAULT_BG,
        justifyContent:'center',
        alignItems: 'center',
    },
    indicatorContainer:{
        alignItems: 'center',
        paddingBottom: 10,
        paddingTop:10
    },
})