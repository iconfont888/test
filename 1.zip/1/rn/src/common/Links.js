/*
 * @Author: Kobe
 * @Date: 2019-05-20 10:23:39
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-06-07 14:21:22
 *
 */
import {baseUrl} from '../service/env'
export default{
    BBS:'/bbs/index.html',
    GGC:'/game/game_loading.html?%2Fapi%2Fgame%2Fscg%2Fload',
    BBS2:'/bbs/index.html',
    NB_QUICK_BET:baseUrl()+'/nbfast.html',
    // AgCopyright.js
    ABOUT:"/aboutus/index.html#about",//关于AG亚游
    PRIVACY:"/aboutus/index.html#privacy",//隐私说明
    CONTRACT:"/aboutus/index.html#contract",//合约条款
    CONTACT:"/aboutus/index.html#contact",//联络我们

    U_SUBSCRIBE:'/ucenter/personal/u_subscribe.html',//短信订阅
    U_FRIEND:'/ucenter/recommend/u_friend.html',//推荐好友送礼金
    //我的特权
    ANNIVERSARY:"/ucenter/vip/anniversary.html",//周年礼金
    GIFT:"/ucenter/vip/gift.html",//佳节礼品
    BUSINESS:"/ucenter/vip/business.html",//商务秘书
    TRAVEL:"/ucenter/vip/travel.html",//海外旅游
    VIP_CLUB:'/activity/20160620/vipclub/',//VIP偷看
    VIP_CLUB_DETAIL:'/activity/20160620/vipclub/?link=menu3',//星级升级详情
//首页弹窗
    MISSION: '/ucenter/mission',//我的任务

    MASERATI1788:"/activity/maserati1788",//查看彩卷
    PREFERENTIAL_PRE:"http://ag6bbs.com/forum.php?mod=viewthread&tid=11087&highlight=%E9%80%9A%E5%85%B3",//红包 通关夺重金
    SCG_TIP_MODE:'/game/game_loading.html?%2Fapi%2Fgame%2Fscg%2Fload'//刮刮彩弹框首页弹窗 领取 链接
}
