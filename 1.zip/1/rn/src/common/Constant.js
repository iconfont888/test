/*
 * @Author: Kobe 
 * @Date: 2019-04-12 13:57:48 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-06-07 15:03:06
 */
export default {
    KEY_AD_DATA: 'KEY_AD_DATA',
    KEY_CACHE_DOMAIN: 'KEY_CACHE_DOMAIN',
    KEY_INIT_APP: 'KEY_INIT_APP',//初始化加密KEY
    KEY_LAST_LOGIN_NAME:'KEY_LAST_LOGIN_NAME',//用户最后一次登录用户名，用于快捷登录
    KEY_USER_INFO: 'KEY_AUTHORIZATION_TOKEN',//用户信息，包含token
    KEY_REGISTER_FLAG: 'KEY_REGISTER_FLAG',//注册弹窗标识
    KEY_PASS_FORGOT_STEP: 'KEY_PASS_FORGOT_STEP',//忘记密码步骤记录
    KEY_REDIRECT_FROM_H5: 'KEY_REDIRECT_FROM_H5',//H5携带的重定向地址
    //IS_LOGIN:'IS_LOGIN',// 设置登录状态 包含session 失效
    KEY_TOKEN: 'KEY_TOKEN',//token
    KEY_DOWNLOAD_TIME: 'KEY_DOWNLOAD_TIME',//首次下载时间
    kEY_FIRST_SHOW_BIOMETRICS_GUIDE : 'kEY_FIRST_FINGER_DIALOG',//首次显示生物识别引导
    KEY_CURRENT_DOMAIN:'KEY_CURRENT_DOMAIN',//当前轮询到的域名
    'CHANGE_IPHONE_NAME_USER': 'CHANGE_IPHONE_NAME_USER'
}