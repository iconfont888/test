/*
 * @Author: Kobe 
 * @Date: 2019-04-02 13:29:25 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-04-02 13:37:28
 * 
 * 全局样式
 */

import colors from './colors'
import Dimens from './dimens'

export default {
    //test: {
    //    height: Dimens.DIMENS_LINE_DEFAULT,
    //    backgroundColor: Color.COLOR_BLACK_99,
    //}
    disabledButtonBgStyle:{
        backgroundColor:'#D6D6D6',
    },
    disabledButtonStyle:{
        backgroundColor:'#D6D6D6',
        color:'#fff'
    },
    unDisabledButtonBgStyle:{
        backgroundColor:colors.COLOR_ORANGE_RED
    },
    unDisabledButtonStyle:{
        backgroundColor:colors.COLOR_ORANGE_RED,
        color:'#fff'
    }
}