/*
 * @Author: Kobe 
 * @Date: 2019-04-02 13:28:46 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-06-20 08:43:26
 * 
 * 全局颜色
 * 
 * 所有颜色在这里定义后再从其他地方import引用,禁止直接在页面代码中使用颜色值,方便以后统一换色
 * 公用颜色命名 COLOR_XXX
 * 如有某些控件希望单独使用该控件独有的颜色以控件名+颜色名命名,如  进度条  PROGRESS_BLUE : '#1FB8F3'
 */

 

export default {


    //------------------------------常用默认值-----------------------start
    //主题颜色
    COLOR_PRIMARY : '#EFE5DC',
    //默认背景颜色
    COLOR_DEFAULT_BG : '#F3F3F3',
    //默认灰线
    COLOR_DEFAULT_LINE : '#E5E5E5',
    // border边框颜色
    DIMENS_BORDER_COLOR : '#ccc',
    //标签未选中颜色
    COLOR_TAB_ACTIVE : '#FF5D37',
    //标签选中颜色
    COLOR_TAB_INACTIVE : '#5F4E4B',
    //返回按钮颜色调整
    COLOR_BACK_BTN : '#B4A7A0',
    //下拉刷新颜色
    COLOR_PROGRESS_BAR: '#554031',
    //------------------------------常用默认值-----------------------end







    //------------------------------颜色值-----------------------start
    //透明
    COLOR_TRANSPARENT : '#00000000',
    //纯白
    COLOR_WHITE : '#FFFFFFFF',
    //黑色(灰)
    COLOR_BLACK : '#000000',
    COLOR_BLACK_33 : '#333333',
    COLOR_BLACK_66 : '#666666',
    COLOR_BLACK_99 : '#999999',
    COLOR_BLACK_C0 : '#C0C0C0',
    //橙色(设计图中橙色列表过多,主要以这几种颜色为主找相近的使用,如出现差异较大的情况时可新增一个颜色)
    COLOR_ORANGE : '#FC9224',
    COLOR_ORANGE_RED : '#FF5F37',
    COLOR_ORANGE_YELLOW : '#FFC24E',
    COLOR_ORANGE_PINK : '#FFA06D',
    //棕色
    COLOR_BROWN : '#B39481',
    COLOR_BROWN_LIGHT : '#D0B9AB',
    COLOR_BROWN_YELLOW : '#D4A667',
    COLOR_BROWN_DEEP : '#553F30',
    //红色
    COLOR_RED_DARK : '#DE5050',
    COLOR_RED : '#FF4747',
    //蓝色
    COLOR_BLUE_DEEP : '#1F2028',
    COLOR_BLUE_GREY : '#363741',
    COLOR_BLUE_LINK : '#3a8fef',
    //绿色
    COLOR_GREEN : '#50A44C',
    //黄色
    COLOR_YELLOW_WHITE : '#FEFFE7',

    //------------------------------颜色值-----------------------end




    //------------------------------我的页面 星级背景-----------------------start
    //默认 0-3星级
    MY_LEVEL_DEFAULT_START : '#414355',
    MY_LEVEL_DEFAULT_END : '#727382',
    //等级4
    MY_LEVEL_4_START : '#7C4E4C',
    MY_LEVEL_4_END : '#A57B77',
    //等级5
    MY_LEVEL_5_START : '#8B6843',
    MY_LEVEL_5_END : '#D4A671',
    //等级6
    MY_LEVEL_6_START : '#4C5E7A',
    MY_LEVEL_6_END : '#869EC2',
    //等级7
    MY_LEVEL_7_START : '#4D406C',
    MY_LEVEL_7_END : '#A085C0',
    //------------------------------我的页面 星级背景-----------------------end


}



