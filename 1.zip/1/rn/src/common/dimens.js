/*
 * @Author: Kobe
 * @Date: 2019-04-02 13:29:34
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-04-02 13:33:01
 * 全局尺寸
 */

export default {

    //线的高度
    DIMENS_LINE_DEFAULT : 1,

    //默认间距
    DIMENS_SPACING_DEFAULT : 10,
    //默认cardview间距
    DIMENS_CARD_SPACING_DEFAULT : 8,
    //圆角
    DIMENS_CORNER_DEFAULT : 4,
    DIMENS_CORNER_6 : 6,
    DIMENS_CORNER_8 : 8,


    //默认字体
    DIMENS_TEXT_DEFAULT : 14,//P
    //小字体
    DIMENS_TEXT_SMALL : 12,//H5
    DIMENS_TEXT_SMALL_13 : 13,//H4
    DIMENS_TEXT_SMALL_10 : 10,
    //大字体
    DIMENS_TEXT_BIG_16 : 16,//H2
    DIMENS_TEXT_BIG_18 : 18,//H1
    DIMENS_TEXT_BIG_20 : 20,//H0
    DIMENS_TEXT_BIG_34 : 34,
    DIMENS_TEXT_BIG_46 : 46,
    DIMENS_TEXT_BIG_56 : 56,

    //标题
    DIMENS_TEXT_TITLE_SMALL : 16,
    DIMENS_TEXT_TITLE_BIG : 24,

    //appbar
    DIMENS_TEXT_TITLE_APPBAR : 20,


}
