/**
 *
 *Created by Lili 2019/4/3
 **/
import React, {Component} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, ActivityIndicator} from 'react-native';
import {Button} from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import dimens from "../dimens";

/**
 * 默认纯橙色btn样式
 * @param title
 * @param onPress
 * @returns {*}
 * @constructor
 */
const AgButton=(props)=>{
    const {buttonStyle}=props
    return (
        <Button {...props}
                titleStyle={{fontSize: H1,fontWeight: 'bold'}}   buttonStyle={[{backgroundColor: '#ff5d37'},buttonStyle]}/>
    )
}



/**
 * 渐变色Button
 * @param title
 * @param onPress
 * @param titleStyle
 * @param sColor 渐变开始颜色
 * @param eColor 渐变结束颜色
 * start 就是渐变开始的位置，x、y 范围是 0 - 1 ，
 end 同上，就是渐变结束的位置
 * @param buttonStyle  设置按钮 w,h,border ,padding...
 * @returns {*}
 * @constructor
 *
 */
const  AgBtn= ({title,onPress,sColor,eColor,buttonStyle,titleStyle}) => {
    let titleStyle2=[styles.title,titleStyle]
    if(buttonStyle&&buttonStyle.height){
        let h=buttonStyle.height;
        titleStyle2.push({height:h,lineHeight:h-5})
    }
    return (
        <Button
            onPress={onPress}
            title={title}
            titleStyle={titleStyle2}
            buttonStyle={[styles.buttonStyle,buttonStyle]}
            containerStyle={styles.container}
            ViewComponent={LinearGradient} // Don't forget this!
            linearGradientProps={{
                colors: [sColor, eColor],
                start: {x: 0, y: 0.5},
                end: {x: 1, y: 0.5},
            }}
        />
    )
}

AgBtn.defaultProps  = {
    title:'quddd',
    sColor: '#FFA06D',
    eColor: '#FF5831',
    fontSize:H4,
}
/**
 * 空心Button
 * @param title
 * @param onPress
 * @param fontSize
 * @param buttonStyle  设置按钮 w,h,border ,padding...
 * @returns {*}
 * @constructor
 */
const  AgOutlineBtn= ({title,onPress,buttonStyle,titleStyle}) => {
    let titleStyle2=[styles.title2,titleStyle]
    if(buttonStyle&&buttonStyle.height){
        let h=buttonStyle.height;
        titleStyle2.push({height:h,lineHeight:h-5})
    }
    return (
        <Button
            title={title}
            type="outline"
            onPress={onPress}
            titleStyle={titleStyle2}
            buttonStyle={[styles.buttonStyle2,buttonStyle]}
            containerStyle={styles.container}
        />

    )}

const H4=dimens.DIMENS_TEXT_SMALL_13
const H1=dimens.DIMENS_TEXT_BIG_18


const styles = StyleSheet.create({
    container: {
        // width:80
        // justifyContent:'center',
        // alignItems:'center'
    },
    buttonStyle2: {
        borderRadius: 50,
        borderColor: "#FF5F37",
        borderStyle: 'solid',
        borderWidth: 1,
        height:25,
    },
    title2: {
        color: '#FF5F37',
        fontSize: H4,
        height:20,
        lineHeight:20,
        letterSpacing: 1,
    },
    buttonStyle: {borderRadius: 50, borderColor: "#FF5F37"},
    title: {
        color: '#fff',
        fontSize: H4,
        height:20,
        lineHeight:20,
        letterSpacing: 1,
    },

})
module.exports = {AgButton,AgBtn,AgOutlineBtn}
