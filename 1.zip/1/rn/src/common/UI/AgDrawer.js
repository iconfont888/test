/**
 *Created by Lili 2019/6/14
 * 侧边栏
 **/
import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image, Dimensions, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import Drawer from 'react-native-drawer'
import UserDrawer from '../../router/UserDrawer'
import {connect} from "react-redux";
import actions from "../../action";
import dimens from "../dimens";

import {AgUserLevel} from './AgUserLevel'

/**
 * side
 * type（字符串：displace：overlay：static）displace- 抽屉的类型。
 * 2.content是显示的内容，也就是抽屉界面中显示的视图

 3.tapToClose是在抽屉显示的时候，点击右边的底层视图，抽屉会自动关闭

 4.open：true表示抽屉打开，false表示抽屉关闭

 5.openDrawerOffset 抽屉打开时，占频幕宽度的百分比

 6.closedDrawerOffset 抽屉关闭之后留在频幕中的百分比

 7.disabled 是否开启开关

 8.tweenHandler 这个函数的值是（0-1），主要用于控制随着拉动想要伴随的动画效果

 9.acceptDoubleTag响应区域双击可以打开抽屉

 10.acceptTap响应区域单击可以打开抽屉

 11.panOpenMask拉开抽屉的响应区域

 12.panCloseMask最右边的频幕宽度比例范围内为关闭响应区域

 13.initializeOpen 默认是否是开着
 ---------------------

 */
const drawerStyles = {
    drawer: { shadowColor: '#000000', shadowOpacity: 0.8, shadowRadius: 3},
    main: {paddingLeft: 0},
}
 class AgDrawer extends Component {
    constructor(props) {
        super(props);
    }
    closeControlPanel = () => {
        this._drawer.close()
    };
    openControlPanel = () => {
        this._drawer.open()
    };
    componentDidMount() {

    }
    componentWillReceiveProps(nextProps, nextContext) {
        if(nextProps.isShow!=this.props.isShow){
            console.log(nextProps.isShow)
            if(nextProps.isShow){
                this._drawer.open()
            }else{
                this._drawer.close();
            }
        }
    }
    render() {
        return (
                <Drawer
                    open={false}
                    type='overlay'
                    tapToClose={true}
                    // panOpenMask={0}
                    openDrawerOffset={0} // 20% gap on the right side of drawer
                    // panCloseMask={0.4}
                    // closedDrawerOffset={-3}
                    styles={drawerStyles}
                    side={'right'}
                    acceptPan={false}
                    acceptTap={true}
                    negotiatePan={true}
                    ref={(ref) => this._drawer = ref}
                    onClose={()=> this.props.onUserDrawerShow(false)}
                    content={
                      <UserDrawer />
                    }
                >
                    {this.props.children}


                </Drawer>
        );
    }
}
const window = Dimensions.get('window');

const styles = StyleSheet.create({


});

const mapDispatchToProps = dispatch => ({
    onUserDrawerShow: (is) => dispatch(actions.onUserDrawerShow(is)),

});
const mapStateToProps = (state) => ({
    nav: state.nav,
    isShow: state.HomeReducer.ON_USER_DRAWER_D,

});
export default connect(mapStateToProps, mapDispatchToProps)(AgDrawer)
