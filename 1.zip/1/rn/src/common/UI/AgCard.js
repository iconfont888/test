/**
 *Created by Lili 2019/4/3
 **/
import React, {Component} from 'react';
import {StyleSheet, View, TouchableOpacity} from "react-native";
import dimens from "../dimens";

// class AgCard extends Component {
//     render() {
//         return (
//             <View style={[styles.card]} >
//                 <View style={[styles.box, this.props.style]}>
//                     {
//                         this.props.children.map(function (child,i) {
//                             return <View key={i}>{child}</View>
//                         })
//                     }
//                 </View>
//             </View>
//         )
//     }
// }
/**
 * card 可点击
 * 作用：规范内容的间距，圆角
 * @param props
 * @returns {*}
 * @constructor
 */
const AgCard = (props) => (
    <TouchableOpacity style={[{margin: SPACING,marginTop:0},props.containerStyle]} onPress={props.onPress}>
        <View style={[styles.card,props.style]}>
            {props.children}
        </View>
    </TouchableOpacity>
)
/**
 * card
 * 作用：规范内容的间距，圆角
 * @param props
 * @returns {*}
 * @constructor
 */
const AgCardBox = (props) => (
    <View style={[{margin: SPACING,marginTop:0},props.containerStyle]} >
        <View style={[styles.card,props.style]}>
            {props.children}
        </View>
    </View>
)
const SPACING = dimens.DIMENS_SPACING_DEFAULT
const BORDER_RADIUS = dimens.DIMENS_CORNER_8

const styles = StyleSheet.create({
    card: {
        width: "100%",
        height:"100%",
        borderRadius: BORDER_RADIUS,
        backgroundColor: '#fff',
        // marginRight:10,
        // marginLeft:10,
        // marginBottom:20,
        // overflow: 'hidden',
        padding: 5,

    },

})

module.exports =  {AgCard,AgCardBox}
