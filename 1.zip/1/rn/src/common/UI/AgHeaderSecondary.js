/**
 *Created by Lili 2019/4/17
 * 二级导航
 **/
import React, {Component} from 'react';
import Color from '../colors'
import {
    StyleSheet,
    Text,
    View,Platform
} from 'react-native';
import {Image, Icon, Header} from "react-native-elements";
import {connect} from "react-redux";
import NavigationUtil from "../../router/NavigationUtil";
import dimens from "../dimens";

/**
 * title：string必填
 * leftComponent:選填
 * rightComponent:選填
 */
class AgHeaderSecondary extends Component {
    constructor(props) {
        super(props);
        this.goBack = this.goBack.bind(this)

    }

    goBack() {

        this.props.navigation.goBack()
    }

    leftComponent() {
        if (Boolean(this.props.leftComponent)) return this.props.leftComponent

        return {
            icon: 'chevron-left', size: 40, color: ICON_COLOR,
            containerStyle: styles.leftComponentSty,
            onPress: this.props.onLeftPress||this.goBack
        }
    }
    rightComponent(){
        if (Boolean(this.props.rightComponent)) return this.props.rightComponent
    }

    render() {
        return (
            <View>
                <Header
                    containerStyle={Platform.OS !== 'ios'?styles.containerStyle:styles.containerStyleIos}
                    backgroundColor={'#EFE5DC'}
                    placement="center"
                    leftComponent={this.leftComponent()}
                    rightComponent={this.rightComponent()}
                    centerComponent={{text: this.props.title, style: styles.centerComponentSty}}
                />
                {
                    Platform.OS !== 'ios' && <View style={{height: 70}}></View>
                }
            </View>
        );
    }
}

//icon 标题颜色
const ICON_COLOR = Color.COLOR_BROWN_DEEP
const H0=dimens.DIMENS_TEXT_BIG_20

const styles = StyleSheet.create({
    container: {
        // flex: 1
    },
    leftComponentSty: {

        // borderWidth:2
    },
    centerComponentSty: {
        color: ICON_COLOR, fontSize: H0, fontWeight: "bold"
    },
    containerStyleIos:{
        shadowOffset: {width: 0, height: 5},
        shadowOpacity: 0.5,
        shadowRadius: 5,
        shadowColor: "#eee",

    },
    containerStyle: {
        flex: 1,
        position: "absolute",
        top: 0,
        width: '100%',
        height: 70,
        flexDirection: 'row',
        alignItems: 'center',
        shadowOffset: {width: 0, height: 5},
        shadowOpacity: 0.5,
        shadowRadius: 5,
        shadowColor: "#eee",
        //注意：这一句是可以让安卓拥有灰色阴影
        elevation: 8,
        zIndex: 1
    },

    flex: {
        flex: 1,
        borderWidth: 2,
        // flexDirection: 'row',
        // justifyContent: 'space-around',
        // alignItems: 'center'
    },
});
const mapDispatchToProps = dispatch => ({
    // onfetchTest: () => dispatch(actions.onfetchTest()),
    // onHeaderColor: (c) => dispatch(actions.onHeaderColor(c)),
    // onSpCurrentUri:(idx)=>dispatch(actions.onSpCurrentUri(idx))
});
const mapStateToProps = (state) => ({
    nav: state.nav,
    // color: state.HomeReducer.headerColor,

});
export default connect(mapStateToProps, mapDispatchToProps)(AgHeaderSecondary)
