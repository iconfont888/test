/**
 *Created by Lili 2019/4/18
 * 版权 footnote
 **/
import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View, TouchableOpacity,
    Image, ScrollView,
} from 'react-native';
import Links from '../Links'
import NavigationUtil from "../../router/NavigationUtil";
import dimens from "../dimens";
export default class AgCopyright extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <View style={[{flex:1},this.props.style || {}]}>
                {
                    this.props.type=='col'?<ColAbout/>:<RowAbout/>
                }
            </View>
        );
    }
}
const onPress=(u)=>{
    NavigationUtil.goPage('WebViewPage', {
        url: u.link,
        isRelativePath: true,
    })
}
const list=[
    {label:'关于AG亚游',link:Links.ABOUT},
    {label:'隐私说明',link:Links.PRIVACY},
    {label:'合约条款',link:Links.CONTRACT},
    {label:'联络我们',link:Links.CONTACT},
]
const RowAbout = () => {
    return(
        <View style={styles.row}>
            {
               list.map((u,i)=>(
                    <View key={i} style={styles.row}>
                        <Text style={styles.label} onPress={()=>onPress(u)}>{u.label}</Text>
                        { i!=3&&<Text style={styles.gang} >|</Text>}
                    </View>

                ))
            }
        </View>
    )
}
/**
 * 首页 关于亚游
 * @returns {*}
 * @constructor
 */
const ColAbout = () => {
    let styles = {
        padding: 15,
        paddingLeft: SPACING,
        borderBottomWidth: 1,
        borderBottomColor: "#E0E0E0",

    }
    return (<View >
        {
           list.map((u, i) => (
                <TouchableOpacity onPress={()=>onPress(u)} key={i} style={styles}><Text style={styles.label}>{u.label}</Text></TouchableOpacity>
            ))
        }
    </View>)
}
const SPACING = dimens.DIMENS_SPACING_DEFAULT
const H5 = dimens.DIMENS_TEXT_SMALL
const styles = StyleSheet.create({
    container: {
        color: "#999",
        flex: 1,
        textAlign: "center",
        flexDirection: 'row',
        alignItems: "center",
        justifyContent: 'center',
    },
    row:{

        alignItems: "center",
        justifyContent: 'center',
        flexDirection: 'row',
    },
    gang: {margin: 10,color:'#999'},
    label:{fontSize:H5,color:'#999'}

});
