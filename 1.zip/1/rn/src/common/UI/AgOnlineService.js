/**
 *Created by Lili 2019/5/20
 * 在线客服
 **/
import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image, Alert, TouchableOpacity
} from 'react-native';
import {ONLINE_CUSTOMER_SERVICE} from "../../service/getData";
import NavigationUtil from "../../router/NavigationUtil";
import common from '../../util/common';

/**
 * example 1  <AgOnlineService text='在线客服'/>
 * example 2  <AgOnlineService type='auto'> <AgOutlineBtn title={"立即联系"} />  <Image ....>    <AgOnlineService/>
 * @param type
 * @param text
 * @param children
 * @returns {*}
 * @constructor
 */
const AgOnlineService = (props) => {
    const {type, text} = props
    // console.log(props.children)
    const onPress = () => {
        common.goCustomerServerUrl()
    }
    if (type == 'auto') {
        return (<TouchableOpacity onPress={() => onPress()}>
            <View pointerEvents={'none'}>
                {
                    Boolean(props.children) != false && props.children
                }
            </View>
        </TouchableOpacity>)
    }
    return <Text style={styles.a} onPress={() => onPress()}>{text}</Text>
}


// export default class AgOnlineService extends Component {
//     constructor(props) {
//         super(props);
//     }
//
//     render() {
//         return (
//             <View style={styles.container}>
//
//             </View>
//         );
//     }
// }

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    a: {
        color: '#0054ff'
    }
});

export default AgOnlineService
