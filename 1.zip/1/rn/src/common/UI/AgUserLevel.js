import React, {Component} from 'react';
import {
    StyleSheet,
    Text,
    View,
    Image,
    Platform
} from 'react-native';
import {connect} from "react-redux";


/**
 *Created by Lili 2019/4/17
 * 用户星级
 * 【已做全局，不需要传递level】
 * level:number
 * privateLevel:局部level，当传此属性，显示privateLevel的等级。level无效；
 * style：
 **/
class AgUserLevel extends Component {
    constructor(props) {
        super(props)
        // this.state={level:0}
    }

// componentDidMount() {
//       this.setState({level:this.props.privateLevel||this.props.level})
// }

    render() {
        const isPrivate = Boolean(this.props.privateLevel)
        return (
            <View style={[styles.container, this.props.style]}>
                <DoLevel level={!isPrivate ? this.props.level : this.props.privateLevel}/>

            </View>
        );
    }
}

const DoLevel = ({level}) => {
    const levelNames = ["新会员", "一星级", "二星级", "三星级"];
    let name = levelNames[0]
    level = level || 0
    if (level < 4) {
        name = levelNames[level]
    } else {
        name = 'VIP' + level
    }
    // console.log(name,"用户星级")
    return (
        <Text style={styles.label}>{name}</Text>
    );
}


const styles = StyleSheet.create({
    container: {borderWidth: 1, borderColor: "#D4A667", borderRadius: 5, paddingHorizontal: 5, margin: 0},
    label: {color: '#D4A667', textAlign: "center",textAlignVertical: "center",...Platform.select({
        ios: { lineHeight: 21},
        android: {}
      })}
});
const mapStateToProps = (state) => ({
    nav: state.nav,
    isLogin: state.UserInfoReducer.isLogin,
    level: state.fetchReducer.GET_PERSON_INFO_D.level
});
export default connect(mapStateToProps)(AgUserLevel)
