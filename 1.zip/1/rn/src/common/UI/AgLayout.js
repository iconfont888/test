/**
 *Created by Lili 2019/4/11
 *
 * 功能：获取组件的宽度和高度,位置信息
 *
 * ref :这个参数表示组件的实例
 *
 * x，y表示组件的相对位置，
 * width，height表示组件的宽度和高度，
 * pageX，pageY表示组件相对于屏幕的绝对位置
 *
 **/
import React, {Component} from 'react';
import {
    findNodeHandle,
    UIManager
} from 'react-native';

 const AgLayout= (ref)=> {
    const handle = findNodeHandle(ref);

     return new Promise((resolve) => {
         UIManager.measure(handle, (x, y, width, height, pageX, pageY) => {
             resolve({
                 x,
                 y,
                 width,
                 height,
                 pageX,
                 pageY
             });
         });
     });
}


export default AgLayout