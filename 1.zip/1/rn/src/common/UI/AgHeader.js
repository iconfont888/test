/**
 *Created by Lili 2019/4/8
 * 顶部导航栏
 **/
import React, {Component} from 'react';
import {Image, Icon, Header} from "react-native-elements";
import {StyleSheet, Text, View, TouchableOpacity, Platform} from "react-native";
import ImgURL from "../../common/ImgURL"

import Color from '../../common/colors'
import {connect} from "react-redux";
import actions from "../../action";
import NavigationUtil from "../../router/NavigationUtil";
import dimens from "../dimens";
import colors from "../colors";

const goLogin = (name, e) => {

    alert(e.target + " ==" + name)
}

/**
 * 顶级 一级导航栏
 * 服务大厅入口+侧边栏入口
 */
class AgHeader extends Component<Props> {
    constructor(props) {
        super(props)
        this.onPressLeft = this.onPressLeft.bind(this)
        this.onPressRight = this.onPressRight.bind(this)
        this.getNavigation = this.getNavigation.bind(this)
            // this.state={isShow:false}
    }

    componentDidMount() {

    }

    getNavigation() {
        if (NavigationUtil.getNavigation()) {
            return NavigationUtil.getNavigation()
        } else {
            return this.props.navigation
        }
    }

    /**
     * 使用侧边栏方法
     *  navigation.openDrawer();
     * navigation.closeDrawer();
     * navigation.toggleDrawer();
     */
    onPressLeft() {
        // console.log(this.getNavigation(),"this.getNavigation()")
        // this.getNavigation().openDrawer()
        // this.setState({isShow:true})

        this.props.onUserDrawerShow(true)

    }

//    服务大厅
    onPressRight() {
        // console.log("AgHeader====:",this.props.navigation,NavigationUtil.getNavigation(),"NavigationUtil.getNavigation()")

        this.getNavigation().navigate('ServiceHall')
    }

    render() {
        return (
            <View style={{backgroundColor:colors.COLOR_TRANSPARENT}}>

                <Header
                    statusBarProps={{ barStyle: 'light-content', translucent: true, backgroundColor: colors.COLOR_TRANSPARENT }}
                    containerStyle={[styles.containerStyle,this.props.containerStyle? this.props.containerStyle:{}]}
                    backgroundColor={this.props.bgColor || 'rgba(255, 0, 0, 0)'}
                    rightComponent={{
                        icon: 'menu', size: 26, color: this.props.color, containerStyle: styles.leftComponentSty,
                        onPress: this.onPressLeft
                    }}
                    centerComponent={{
                        text: this.props.title,
                        style: {fontSize: H1, fontWeight: "bold", color: this.props.color}
                    }}
                    leftComponent={<HeadsetMic color={this.props.color} onPress={this.onPressRight}/>}
                >

                    {/*<CenterComponent title={this.props.title} color={this.props.color}/>*/}
                    {/*<LeftComponent color={this.props.color} onPress={this.onPressLeft}/>*/}
                </Header>

                {
                    // Platform.OS !== 'ios' && <View style={{height: 50}}></View>
                }
            </View>

        )
    }

}

const HeadsetMic = (props) => {
    let uri = props.color == Color.COLOR_WHITE ? ImgURL.kefu_icon : ImgURL.kefuB_icon
    return (
        <View style={styles.flex}>
            <TouchableOpacity onPress={props.onPress}>
                <Image source={uri} style={styles.img}/>
            </TouchableOpacity>
        </View>
    )
}
const CenterComponent = (props) => {
    return (
        <View style={styles.flex}><Text style={{color: props.color}}>{props.title}</Text></View>
    )
}

const LeftComponent = (props) => {

    return (
        <View style={styles.flex}>
            <Icon
                name='menu'
                color={props.color}
                size={26}
                onPress={props.onPress}
            />
        </View>

    )
}
// AgHeader.defaultProps  = {
//     // color:Color.COLOR_BROWN_DEEP
//     color:Color.COLOR_WHITE
// }
const H0=dimens.DIMENS_TEXT_BIG_20
const H1=dimens.DIMENS_TEXT_BIG_18

const styles = StyleSheet.create({
    pos: {
        flex: 1, position: "absolute", top: -15,
        width: '100%', height: '100%',
    },
    centerComponentSty: {
        fontSize: H0, fontWeight: "bold"
    },
    containerStyleIos: {
        borderBottomColor: 'rgba(255, 0, 0, 0)',

    },
    containerStyle: {
        borderBottomColor: colors.COLOR_TRANSPARENT,
        // position: "absolute",
        // top: 0,
        // width: '100%',
        // height: 70,
        // zIndex: 1000
    },
    leftComponentSty: {

        // borderWidth:2
    },

    flex: {
        flex: 1,
        // borderWidth: 2,
        // flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center'
    },
    img: {
        width: 20,
        height: 20,
    },
})
const mapDispatchToProps = dispatch => ({
    onUserDrawerShow: (is) => dispatch(actions.onUserDrawerShow(is)),

    // onfetchTest: () => dispatch(actions.onfetchTest()),
    // onHeaderColor: (c) => dispatch(actions.onHeaderColor(c)),
    // onSpCurrentUri:(idx)=>dispatch(actions.onSpCurrentUri(idx))
});
const mapStateToProps = (state) => ({
    nav: state.nav,
    // color: state.HomeReducer.headerColor,

});
export default connect(mapStateToProps, mapDispatchToProps)(AgHeader)
