/*
 * @Author: Kobe 
 * @Date: 2019-04-17 13:59:22 
 * @Last Modified by: Kobe
 * @Last Modified time: 2019-04-17 14:43:10
 */

export default{
    SUCCESS : 200,
    ERROR : 500,
    FAILED : -1
}