/**
 *Created by candice
 **/
import Types from '../action/types';
const initialData = {
    msgSnackBar:{
        isShow:false,
        title:'您有0条新消息',
        showType:0//2 跳转站内信
    },
    socketMessage: {

    },
}
const socketReducer = (state = initialData, action) => {
    switch (action.type) {
        case Types.INIT_STORE:
            return {
                ...state,
                socketMessage:{}
            }
        case Types.SOCKET_MESSAGE:
            return {
                ...state,
                socketMessage: {...action.socketMessage}
            }
        case Types.ON_SOCKET_SNACKBAR_SHOW:
            //onSnackBarShow
            let msgSnackBar={}
            if(action.isShow==true){
                msgSnackBar={
                    isShow:true,
                    title:action.title,
                    showType: action.showType
                }
            }else{
                msgSnackBar={
                    isShow:false,
                    title:'',
                    showType: 0
                }
            }
            return {
                ...state,
                msgSnackBar: msgSnackBar
            }
        default:
            return state
    }
}
export default socketReducer
