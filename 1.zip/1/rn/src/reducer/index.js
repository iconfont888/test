import {rootCom, RootNavigator} from '../router/AppNavigators';
import {combineReducers} from 'redux'
import fetchReducer from './fetchReducer'
import HomeReducer from './HomeReducer'
import UserInfoReducer from './UserInfoReducer'
import socketReducer from './socket'
//1.指定默认state
const navState = RootNavigator.router.getStateForAction(RootNavigator.router.getActionForPathAndParams(rootCom));

/**
 * 2.创建自己的 navigation reducer，
 */
const navReducer = (state = navState, action) => {
    const nextState = RootNavigator.router.getStateForAction(action, state);
    // 如果`nextState`为null或未定义，只需返回原始`state`
    return nextState || state;
};


/**
 * 3.合并reducer
 * @type {Reducer<any> | Reducer<any, AnyAction>}
 */
const index = combineReducers({
    nav: navReducer,
    fetchReducer:fetchReducer,
    HomeReducer:HomeReducer,
    UserInfoReducer:UserInfoReducer,
    socketReducer,
    // theme: theme,
    // popular: popular,
    // trending: trending,
    // favorite: favorite,
    // language: language,
    // search: search,
});

export default index;
