/**
 *Created by Lili 2019/4/11
 **/
import Types from '../action/types';
import Color from '../common/colors'

const initASheetData = {
    showData: {isShow: false, type: '', selIdx: 0},
    EditBankInfo: {
        BankName: {value: '', index: 0},
        BankType: {'value': '借记卡', index: 0},
        Provinces: {'value': '北京市', index: 0},
        City: {"value": "北京市", index: 0},
    },
}

const initialData = {
    SHOW_HOME_OVERLAY_TD: {actType: '', isShow: false},//显示首页活动弹框类型；
    SHOW_HOME_OVERLAY_ARR:[],
    imgUri: '',
    headerColor: Color.COLOR_WHITE,
    ASheetData: JSON.parse(JSON.stringify(initASheetData)),
    ON_USER_DRAWER_D:false,
    appRouter:{
        index:0,
        prev:'HomePage',
        current:'HomePage',
        routerList: ['HomePage'],
        routeName:'HomePage'
    },
}
const onAction = (state = initialData, action) => {
    switch (action.type) {
        case Types.INIT_STORE:
            return {
                ...initialData,
                imgUri:state.imgUri,
                appRouter:state.appRouter,
            }
        case Types.GET_APP_ROUTER :
            return{
                ...state,
                appRouter:action.appRouter,
            }
        case Types.NAVIGATE:
            return {
                ...state,
                routeName:action.routeName,
            }
        case Types.SP_CURRENT_URI:
            return {
                ...state,
                imgUri: action.imgUri
            }
        case Types.HEADER_COLOR:
            return {
                ...state,
                headerColor: action.headerColor
            }

        case Types.GET_ACTION_SHEET_DATA:
            var ASheetData = {...state.ASheetData}
            ASheetData['EditBankInfo'][action.key] = action.data;
            if (ASheetData === state.ASheetData) return
            // console.log(ASheetData,"ASheetData GET_ACTION_SHEET_DATA")
            return {
                ...state,
                ASheetData: ASheetData
            }
        //show or hide ActionSheet; listType,isShow,selIdx
        case Types.ON_SHOW_ACTION_SHEET:
            console.log(action.listType, "action.listTypeaction.listType")
            if (action.listType == 'init') {
                console.log('action.listType', initASheetData.EditBankInfo);
                return {
                    ...state,
                    ASheetData: JSON.parse(JSON.stringify(initASheetData))
                }
            }
            var ASheetData = {...state.ASheetData}
            ASheetData.showData = {isShow: action.isShow, type: action.listType, selIdx: action.selIdx}
            if (ASheetData === state.ASheetData) return
            // console.log(ASheetData,"ASheetData ON_SHOW_ACTION_SHEET")
            return {
                ...state,
                ASheetData: ASheetData
            }
        case Types.SHOW_HOME_OVERLAY:
            let arr=state.SHOW_HOME_OVERLAY_ARR
            const {actType,isShow}=action.SHOW_HOME_OVERLAY_TD
            if(actType!='all'){
                let idx=arr.indexOf(actType)
                if(isShow){
                    if(idx==-1){
                        arr.push(actType)
                    }
                }else {
                    if(idx!=-1){
                        arr.splice(idx,1)
                    }
                }
            }
            return {
                ...state,
                SHOW_HOME_OVERLAY_ARR:arr,
                SHOW_HOME_OVERLAY_TD: action.SHOW_HOME_OVERLAY_TD
            }
    }
    if (action.type == Types[action.type]) {
        let key = action.type + '_D'
        if (initialData.hasOwnProperty(key)) {
            return {
                ...state,
                [key]: action[key]
            }
        }
    }
    return state

}
export default onAction
