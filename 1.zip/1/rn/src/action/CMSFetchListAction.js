import Types from "./types";
import {CMS_TEMPLATES, DETONATION_AWARD, CMS_PROMOTIONS} from "../service/getData";
import CMS from "../service/CMSCode";
import AppStorage from "../util/AppStorage";

import { Platform } from 'react-native';
import MyGlobal from "../common/MyGlobal";
/**
 *Created by Lili 2019/5/2
 **/
async function on_CMS_TOP_MENU(dispatch) {
    const fun = arr => ({
        type: Types.CMS_TOP_MENU,
        CMS_TOP_MENU_D: arr,
    })
    await CMS_TEMPLATES(CMS.CMS_TOP_MENU).then((res) => {
        console.log(res.data, "--------onTopMenu----------")
        if(res.data.length<1)return dispatch(fun([]));
        let arr = res.data.map((u, i) => {
            return {uri: u.maxImageHttpUrl, name: u.tip, badgeUri: u.hotIconHttpUrl, path: u.defaultAction || '',minPath: u.minImageAction || ''}
        })
        AppStorage.save('CMS_TOP_MENU_D', arr);
        return dispatch(fun(arr))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}
async function on_CMS_REGISTERED_BADGE(dispatch) {
    const fun = obj => ({
        type: Types.CMS_REGISTERED_BADGE,
        CMS_REGISTERED_BADGE_D: obj,
    })
    await CMS_TEMPLATES(CMS.CMS_REGISTERED_BADGE).then((res) => {
        console.log(res.data, "--------CMS_REGISTERED_BADGE------首页注册badge----")
        // let obj = res.data.map((u, i) => {
        //     return {badgeUri: u.hotIconHttpUrl, adesc:'首页注册badge' }
        // })
        let badgeUri
        if(res.data.length<1){
            badgeUri=''
        }else{
            badgeUri=res.data[0].tip||''
        }

        return dispatch(fun(badgeUri))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}
async function on_CMS_HOME_SWIPER(dispatch) {
    const getSpCurrentIdx = uri => ({
        type: Types.SP_CURRENT_URI,
        imgUri: uri,
    })
    const fun = arr => ({
        type: Types.CMS_HOME_SWIPER,
        CMS_HOME_SWIPER_D: arr,
    })
    await CMS_TEMPLATES(CMS.CMS_HOME_SWIPER).then((res) => {
        console.log(res.data, "------onHomeSwiper---------")
        if(res.data.length<1)return dispatch(fun([]));
        let arr = res.data.map((u, i) => {
            return {
                adesc:'首页轮播',
                uri: u.minImageHttpUrl,
                 bgUri: u.maxImageHttpUrl,
                title: u.tip|| '',
                label: u.textDescription|| '',
                path: u.defaultAction || ''
            }
        })
        // if(!MyGlobal.IS_FIRST_INIT_BANNER){
        //     MyGlobal.IS_FIRST_INIT_BANNER = true
            dispatch(getSpCurrentIdx(arr[0].bgUri))
        // }
        
        return dispatch(fun(arr))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}

async function on_CMS_TOP_NEWS(dispatch) {
    const fun = arr => ({
        type: Types.CMS_TOP_NEWS,
        CMS_TOP_NEWS_D: arr,
    })
    await CMS_TEMPLATES(CMS.CMS_TOP_NEWS).then((res) => {
        console.log(res.data, "-------onTopNews-----------")
        if(res.data.length<1)return dispatch(fun([]));
        let arr = res.data.map((u, i) => {
            return {label: i, value: u.textDescription, path: u.defaultAction || ''}
        })
        return dispatch(fun(arr))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}

// beginTime: "2019-05-06 12:00:00"
// countTime: 0
// createTime: "2019-05-06 11:19:52"
// creator: "lili"
// defaultAction: ""
// detailAction: ""
// endTime: "2020-05-30 12:00:00"
// id: "f17eeed3233d44a7ae710da7e757f01e"
// maxImage: "/group1/M00/00/0A/CgsQZ1zPpmCAaG97AAAYGAynv70311.png"
// maxImageAction: ""
// maxImageHttpUrl: "http://10.11.16.103:8001/group1/M00/00/0A/CgsQZ1zPpmCAaG97AAAYGAynv70311.png"
// moduleCode: "070109"
// moduleName: "站内信-专属"
// ossType: "FAST_DFS"
// pageModuleId: "56b42c81bf754257955315272664f51d"
// pageNullType: 0
// productCode: "B79"
// promotionDescription: "真人厅 三天内投注额满1000元！↵立刻送88元 奖金 ！"
// promotionTop: 1
// promotionType: "NEW_MEMBER"
// rank: 0
// status: 1
// sysTime: 1557121098532
// targetType: ""
// terminalType: "MOBILE_MAIN_APP"
// title: "领8000京东卡备战双12"
// type: "1"
// updateTime: "2019-05-06 13:24:12"
// updator: "lili"
// userLevelStr: ",2"
async function on_CMS_EXCLUSIVE_OFFER(dispatch) {
    const fun = data => ({
        type: Types.CMS_EXCLUSIVE_OFFER,
        CMS_EXCLUSIVE_OFFER_D: data,
    })
    let fdata = {
        moduleCode: CMS.CMS_EXCLUSIVE_OFFER,
        pageNumber: 1,
        pageSize: 1
    }
    await CMS_TEMPLATES(CMS.CMS_EXCLUSIVE_OFFER).then((res) => {
        console.log(res.data, "-------CMS_EXCLUSIVE_OFFER--------//站内信-专属优惠---")
        let item

        if(res.data.length<1){
            item={endTime:0}
        }else{
            item = res.data[0];
        }

        let data = {
            adesc: '站内信-专属优惠',
            title: item.tip,
            sub: item.textDescription|| '',
            // img:item.maxImageHttpUrl,
            endTime: item.endTime,
            path:item.defaultAction || ''
        }
        return dispatch(fun(data))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}

/**
 * GameCard
 * 不想一个一个的写。封装起来。
 *
 * // CMS_PLAYER_LOVE:'CMS_PLAYER_LOVE',//玩家最爱
 //     CMS_NEW_GAME:'CMS_NEW_GAME',//最新游戏
 //     CMS_GAME_DOWNLOAD:'CMS_GAME_DOWNLOAD',//客户端下载

 * @param type
 * @param dispatch
 * @returns {Promise<void>}
 *
 */
async function on_CMS_GAMECARD(type, dispatch) {
    // console.log(CMS.HOME_SWIPER,"CMS.HOME_SWIPER")
    const fun = arr => ({
        type: Types[type],
        [type + '_D']: arr,
    })
    await CMS_TEMPLATES(CMS[type]).then((res) => {
        console.log(res.data, "onGameCard", type)
        if(res.data.length<1)return;
        let arr = res.data.map((u, i) => {
            return {
                title: u.tip,
                uri: u.maxImageHttpUrl,
                hot: i == 0 ? 1 : 0,
                badgeUri: u.hotIconHttpUrl,
                label: u.textDescription, path: u.defaultAction || '',
                minPath: u.minImageAction || ''
            }
        })
        let result = []
        for (let i = 0, len = arr.length; i < len; i += 3) {
            result.push(arr.slice(i, i + 3));
        }
        return dispatch(fun(result))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}
//客户端下载
async function on_CMS_GAMECARD_DOWNLOAD(type, dispatch) {
    const fun = arr => ({
        type: Types[type],
        [type + '_D']: arr,
    })
    await CMS_TEMPLATES(CMS[type]).then((res) => {
        if(res.data.length<1)return;
        let _temp_arr = [];
        let _ios_ignore_games = ["捕鱼王经典版","AG赌场厅","AG国际厅"];
        try {
            res.data.map((u, i) => {
                let _path = "";
                if(u.tip.indexOf("手机亚游") != -1){
                    return;
                }
                if(Platform.OS === 'ios' && u.tip && _ios_ignore_games.indexOf(u.tip) !=-1){
                    return;
                }
                if(u.jsonObj){
                    jsonObj = JSON.parse(u.jsonObj);
                    if (Platform.OS === 'ios') {
                        _path = jsonObj.ios;
                    }else{
                        _path = jsonObj.android;
                    }
                }else if(u.defaultAction){
                    _path = u.defaultAction;
                }
                _temp_arr.push({
                    title: u.tip,
                    uri: u.maxImageHttpUrl,
                    hot: i == 0 ? 1 : 0,
                    badgeUri: u.hotIconHttpUrl,
                    label: u.textDescription,
                    path: _path || ""
                })
            })
            let result = []
            for (let i = 0, len = _temp_arr.length; i < len; i += 3) {
                result.push(_temp_arr.slice(i, i + 3));
            }
            return dispatch(fun(result))
        } catch (error) {
        }
        
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}
async function on_CMS_USER_DRAWER(dispatch) {
    // console.log(CMS.HOME_SWIPER,"CMS.HOME_SWIPER")

    const fun = arr => ({
        type: Types.CMS_USER_DRAWER,
        CMS_USER_DRAWER_D: arr,
    })
    await CMS_TEMPLATES(CMS.CMS_USER_DRAWER).then((res) => {
        console.log(res.data, "---------on_CMS_USER_DRAWER---侧边栏-----")
        if(res.data.length<1)return;
        let arr = res.data.map((u, i) => {
            return {uri: u.maxImageHttpUrl, name: u.tip, path: u.defaultAction || '' , minPath: u.minImageAction || ''}
        })
        return dispatch(fun(arr))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}

async function on_CMS_NB_QUICK_BET(dispatch) {

    const fun = is => ({
        type: Types.CMS_NB_QUICK_BET,
        CMS_NB_QUICK_BET_D: is,
    })
    await CMS_TEMPLATES(CMS.CMS_NB_QUICK_BET).then((res) => {
        console.log(res.data, "---------onNbQuickBet---nb快捷投注-----")
        const isNbQuickBetShow = res.data.length > 0
        console.log(isNbQuickBetShow, "---------onNbQuickBet---nb快捷投注-----")
        return dispatch(fun(isNbQuickBetShow))
    }).catch(error => (dispatch({type: Types.FETCH_FAILED})))

}

export default (dispatch) => {
    const obj = {
        CMS_REGISTERED_BADGE: async () => await on_CMS_REGISTERED_BADGE(dispatch),//首页注册badge
        CMS_HOME_SWIPER: async () => await on_CMS_HOME_SWIPER(dispatch),//轮播图
        CMS_TOP_MENU: async () => await on_CMS_TOP_MENU(dispatch),//首页menu
        CMS_TOP_NEWS: async () => await on_CMS_TOP_NEWS(dispatch), //头条

        CMS_PLAYER_LOVE: async () => await on_CMS_GAMECARD(Types.CMS_PLAYER_LOVE, dispatch),//玩家最爱
        CMS_NEW_GAME: async () => await on_CMS_GAMECARD(Types.CMS_NEW_GAME, dispatch),//最新游戏
        CMS_GAME_DOWNLOAD: async () => await on_CMS_GAMECARD_DOWNLOAD(Types.CMS_GAME_DOWNLOAD, dispatch),//客户端下载
        CMS_USER_DRAWER: async () => await on_CMS_USER_DRAWER(dispatch),//侧边栏
        CMS_EXCLUSIVE_OFFER: async () => await on_CMS_EXCLUSIVE_OFFER(dispatch),////站内信-专属优惠
        CMS_NB_QUICK_BET: async () => await on_CMS_NB_QUICK_BET(dispatch)
    }
    return obj
}

