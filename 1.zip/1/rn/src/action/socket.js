/**
 *  socket.js
 *  @author candice
 * **/
import Types from './types'
export function onSocketMsg(msg) {
    const getMsg = msg => ({
        type: Types.SOCKET_MESSAGE,
        socketMessage : msg,
    })
    return dispatch => {
        dispatch(getMsg(msg))
    }
}

export function onSnackBarShow(isShow,title,showType) {
    const fun = () => ({
        type: Types.ON_SOCKET_SNACKBAR_SHOW,
        isShow ,
        showType,
        title
    })
    console.log('websocket ON_SOCKET_SNACKBAR_SHOW')
    return dispatch => {
        dispatch(fun())
    }
}
