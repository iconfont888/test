import Types from "./types";


/**
 * dispatch登录状态
 * status:true 登录，false:登出 or this.props.onFetchList([Types.SYNC_LOGOUT])
 * info:用户等级&用户名称；
 * @returns {function(*): *}
 */
export function onLoginStatus(status, info) {
    const getIsLogin = (status, info) => {
      if(status&&info) {
          //【注意】清空所有数据重新载入；
          window.resetState();
          return {
              type: Types.LOGIN_STATUS,
              isLogin: status,
              userLevel:info.userLevel,
              loginName:info.loginName,
              userType:info.userType,
          }
      }
        return {
            type: Types.LOGIN_STATUS,
            isLogin: status
        }

    }
    return dispatch => {
        dispatch(getIsLogin(status, info))
    }
}
/**
 * dispatch注册方式
 * type:
 * @returns {function(*): *}
 */
export function onRegType(registerVerificationType) {
    return dispatch => {
        dispatch({
            type: Types.REGISTER_TYPE,
            registerVerificationType
        })
    }
}
/**
 * dispatch注册成功
 * type:
 * @returns {function(*): *}
 */
export function onRegSucc(flag) {
    return dispatch => {
        dispatch({
            type: Types.REGISTER_FLAG,
            flag
        })
    }
}
/**
 * 验证银行需要的电话号码；
 * @param phone
 * @returns {Function}
 */
export function  onInitBankPhone(phone) {
    const getfun = () => ({
        type: Types.INIT_BANK_PHONE,
        phone: phone
    })
    console.log(phone,"INIT_BANK_PHONE")
    return dispatch => {
        dispatch(getfun())
    }
}

