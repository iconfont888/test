import {onSpCurrentUri, onHeaderColor, onShowHomeOverlay, onActionSheetData, onShowActionSheet,onUserDrawerShow} from "./HomeAction";
import {onLoginStatus,onInitBankPhone,onRegType,onRegSucc} from "./UserInfoAction"
import {onFetchList} from "./fetchListAction"
import {onSocketMsg,onSnackBarShow} from './socket'

export default {
    onSpCurrentUri, onHeaderColor, onLoginStatus,onRegType,onRegSucc, onShowHomeOverlay, onActionSheetData, onShowActionSheet, onSocketMsg,
    onFetchList,onSnackBarShow,onUserDrawerShow,onInitBankPhone

}
