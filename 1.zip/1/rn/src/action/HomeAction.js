/**
 *Created by Lili 2019/4/11
 **/
import Types from './types'



const getSpCurrentIdx = uri => ({
    type: Types.SP_CURRENT_URI,
    imgUri: uri,

})

/**
 * dispatch轮播图当前uri
 * @returns {function(*): *}
 */
export function onSpCurrentUri(uri) {

    return dispatch => {
        dispatch(getSpCurrentIdx(uri))
    }
}


/**
 * header 字体和icon颜色
 * @param color
 * @returns {Function}
 */
export function onHeaderColor(color) {
    const getColor = color => ({
        type: Types.HEADER_COLOR,
        headerColor: color,
    })
    return dispatch => {
        dispatch(getColor(color))
    }
}


/**
 * dispatch actionsheet 值
 *
 * key: 'bankName'
 * data:{'id': '10001', 'value': '上海浦东发展银行',selIdx:0},
 * @returns {function(*): *}
 */
export function onActionSheetData(key,data) {
    const getfun = () => ({
        type: Types.GET_ACTION_SHEET_DATA,
        key,data
    })
    return dispatch => {
        dispatch(getfun())
    }
}
/**
 * show or hide ActionSheet;
 * example create by lili  \src\screen\BankPage\EditBankInfo.js
 * isShow:true: show false: hide
 * listType, ActionSheet data type
 * selIdx:0  open ActionSheet default select item idx
 * dispatch actionsheet 值
 * @returns {function(*): *}
 */
export function onShowActionSheet(listType,isShow,selIdx) {
    const getfun = () => ({
        type: Types.ON_SHOW_ACTION_SHEET,
        isShow,listType,selIdx
    })
    return dispatch => {
        dispatch(getfun())
    }
}

/**
 * 首页弹框打开关闭方式：
 * @param actType 弹框类型
 * @param isShow true：打开/false：关闭  默认flase
 * @returns {Function}
 */

export function onShowHomeOverlay(isShow,actType) {
    const getfun = () => ({
        type: Types.SHOW_HOME_OVERLAY,
        SHOW_HOME_OVERLAY_TD: {actType,isShow}
    })
    return dispatch => {
        dispatch(getfun())
    }
}

export function onUserDrawerShow(isShow) {
    const getfun = () => ({
        type: Types.ON_USER_DRAWER,
        ON_USER_DRAWER_D: isShow
    })
    console.log(isShow,"onUserDrawerShow")
    return dispatch => {
        dispatch(getfun())
    }
}


