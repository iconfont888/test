/**
 *Created by Lili 2019/4/16
 * 侧边栏
 **/
import React ,{Component}from 'react';
import {StyleSheet, Button, Image, ScrollView, Text} from 'react-native';
import {createDrawerNavigator, createAppContainer,createStackNavigator,DrawerItems, SafeAreaView} from 'react-navigation';


import MainPage from "../screen/MainPage";

import UserDrawer from "./UserDrawer";
import {MuenData} from "../screen/HomePage/data";
import ServiceHall from "../screen/ServiceHall";
import {connect} from "react-redux";
export const DrawerNav = createDrawerNavigator({

        MainPage: {
            screen: MainPage,
            navigationOptions: {
                header: null,// 可以通过将header设为null 来禁用StackNavigator的Navigation Bar
            }
        },
    },
    {
        // initialRouteName: 'MainPage',
        contentOptions: {
            items:[]
        },
        drawerWidth:180,
        drawerPosition:'right',
        drawerLockMode:'unlocked',
        contentComponent: (props) => (<UserDrawer config={props} />)}
);

