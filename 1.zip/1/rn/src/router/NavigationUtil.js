/**
 * 全局导航跳转工具类
 *
 */

import {NavigationActions, StackActions} from "react-navigation";

export default class NavigationUtil {
    /**
     * 跳转到指定页面
     * @param page 要跳转的页面名
     * @param params 要传递的参数
     **/
    currentPage = ''; // 当前页面
    static goPage(page = '', params = {}) {
        const navigation = NavigationUtil.navigation;
        if (!navigation) {
            console.log('NavigationUtil.navigation can not be null')
            return;
        }

        this.currentPage = page;
        // console.log( NavigationUtil.navigation, 9999999999999999999)
        navigation.navigate(
            page,
            {
                ...params
            }
        )
        if (params && params.replace) {
            this.replaceTime = setTimeout(() => {
                clearTimeout(this.replaceTime)
                this.getNavigation().replace(page)
            }, 10)
        }
        // console.log(navigation,"NavigationUtil.navigation")
    }

    static pushPage(page = '', params = {}) {
        const navigation = NavigationUtil.navigation;
        if (!navigation) {
            console.log('NavigationUtil.navigation can not be null')
            return;
        }

        this.currentPage = page;
        navigation.push(
            page,
            {
                ...params
            }
        )
        if (params && params.replace) {
            this.replaceTime = setTimeout(() => {
                clearTimeout(this.replaceTime)
                this.getNavigation().replace(page)
            }, 100)
        }
    }


    /**
     * 获得navigation
     * @returns {*}
     * @date: 2019/4/17 8:40
     * @author: Lili
     */
    static getNavigation() {
        const navigation = NavigationUtil.navigation;
        if (!navigation) {
            console.log('NavigationUtil.navigation can not be null')
            return null;
        }
        return navigation
    }

    /**
     * 返回上一页
     * @param navigation
     */
    static goBack(navigation) {
        console.log(navigation, 'navigation ============candice')
        navigation.goBack();
    }

    /**
     * 返回上一页
     * @param navigatio 且有刷新的动作
     *
     * **/
    static goRefBack(navigation) {
        // console.log(navigation, 999999999999999)
        return false;
        // navigation.goBack();
    }

    /**
     * 重置到首页
     * @param navigation
     */
    static resetToMainPage(params = {}) {
        const {navigation} = params;
        this.currentPage = "Main";
        navigation.navigate("Main");
    }
    /**
     *  重置到某个整个路由
     *
     * **/
    static resstNavigator(page) {
        const resetAction = StackActions.reset({
            index: 0,
            actions: [
                NavigationActions.navigate({routeName: page || 'HomePage'})
            ]
        })
        const navigation = NavigationUtil.navigation;
        navigation.dispatch(resetAction)
    }
}
