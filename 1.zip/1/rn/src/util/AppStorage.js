/*
 * @Description: AsyncStorage简易封装
 * @Author: ian
 * @LastEditors: Please set LastEditors
 * @Date: 2019-04-05 16:40:33
 * @LastEditTime: 2019-06-16 15:58:23
 */

import { AsyncStorage } from 'react-native';
export default class AppStorage {
     static async get(key) {
        const jsonValue = await AsyncStorage.getItem(key).then((value) => {
            const jsonValue = JSON.parse(value);
            return jsonValue;
        });
        return jsonValue;
    }
    static save(key, value) {
        return AsyncStorage.setItem(key, JSON.stringify(value));
    }
    static update(key, value) {
        return AsyncStorage.getItem(key).then((item) => {
            value = typeof value === 'string' ? value : Object.assign({}, item, value);
            return AsyncStorage.setItem(key, JSON.stringify(value));
        });
    }
    static delete(key) {
        return AsyncStorage.removeItem(key);
    }
    static clearAll(){
        return AsyncStorage.clear();
    }
}
