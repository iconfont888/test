/***
 *  loading 工具类
 *  @author candice
 *  @date 2019/4/19
 * */
const LoadingUtil = {
    showLoaing(){
        global.globalAGLoading.setState({
            isClose:false
        })
    },
    hideLoaing(){
        global.globalAGLoading.setState({
            isClose:true
        })
    },
    ruleLoaing(time = 0){
        /**
         *  可展示几秒后消失loading
         * **/
        this.showLoaing();
        setTimeout(() => {
            this.hideLoaing()
        },time)
    }
}
export default  LoadingUtil;