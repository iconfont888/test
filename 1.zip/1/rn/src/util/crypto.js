/*
 * @Description: DES加密解密
 * @Author: ian
 * @LastEditors: Please set LastEditors
 * @Date: 2019-04-04 17:00:51
 * @LastEditTime: 2019-04-18 14:44:13
 */

import CryptoJS from "crypto-js";
import AppStorage from "./AppStorage";
import Constant from '../common/Constant'
let AuthTokenKey = "";


async function getAuthTokenKey(){
     if(AuthTokenKey){
         return AuthTokenKey
     }
    //AES密钥，服务端获取并存放asyncStorage
    const initInfo = await AppStorage.get(Constant.KEY_INIT_APP)
    if(initInfo && initInfo.cryptoKey){
        AuthTokenKey = initInfo.cryptoKey
        return AuthTokenKey
    }else{
        throw new Error('服务器异常,请稍后再试!')
    }
}

/**
* @description DES 加密
* @param value
* @param key
* @returns {string}
*/
export async function Encrypt(value, key) {
    if(!key){
        key = await getAuthTokenKey()
        
    }
    
   // 
    let keyHex = CryptoJS.enc.Utf8.parse(key);
    let encrypted = CryptoJS.DES.encrypt(value, keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    return encodeURIComponent(encrypted.toString());

};
/**
* @description DES 解密
* @param value
* @param key
* @returns {string}
*/

export async function Decrypt(value, key) {
    if(!key){
        key = await getAuthTokenKey()
    }
    let plaintext = CryptoJS.DES.decrypt(value, (key), {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    return plaintext.toString(CryptoJS.enc.Utf8);
};