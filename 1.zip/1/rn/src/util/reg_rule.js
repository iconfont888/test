/**
 * @dec 正则表达集中存放
 * @author candice
  
* */
export default  {
    "environment": 'production',
    //===================Begin  正则表达式===========================================//
    //  登录用户名
    "LOGIN_NAME_REGEX": /(^[a|A|Z|z][s|S|g|G|Y|y][a-zA-Z0-9]{4,20}$)|(^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$)/,
    // 网络电话
    "INTERNET_PHONE_REGEX": /^(17[01]|16[257])\d{8}$/,
    //  登录时用户密码
    "LOGIN_PASSWORD_REGEX": /^[a-zA-Z0-9]{6,12}$/,
    //  手机号码
    "PHONE_REGEX": /^(1[3458]\d{9}|17[2-9]\d{8}|19[189]\d{8}|166\d{8})$/,
    // 手机动态验证码
    "IPHONE_SEND_CODE": /^[0-9]{6}$/,
    //  推荐码code
    "recommendcode": "recommendcode",
    //  注册用户名
    "REGISTER_LOGIN_NAME_REGEX": /^[a-z0-9]{6,10}$/,
    //  注册密码
    "OLD_PASSWORD_REGEX": /^.{3,}$/,
    "REGISTER_PASSWORD_REGEX": /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,10}$/,
    "zy_REGISTER_PASSWORD_REGEX": /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,12}$/,
    //  银行卡号
    "BANK_CARD_NO_REGEX": /^\d{16,19}$/,
    //  比特币钱包地址
    "BITCOIN_ACCOUNT_URL_REGEX": /^\w{26,34}$/,
    //  中英文 长度: 2~20; 省/市/银行名称/开户网点
    "CN_AND_EN_REGEX": /^[\u4e00-\u9fa5_a-zA-Z]{2,20}$/,
    //  中文姓名 长度: 2~20
    "CN_NAME_REGEX": /^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5]$/,
    //  英文姓名 长度: 2~20
    "EN_NAME_REGEX": /^[a-zA-Z][a-zA-Z\s.]{0,18}[a-zA-Z]$/,
    //  真实姓名 (中文: 安瓦尔江·阿不都塞买提; 英文: Nick.ST.OB), 长度: 2~20
    "REAL_NAME_REGEX": /(^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5]$)|(^[a-zA-Z][a-zA-Z\s.]{0,18}[a-zA-Z]$)/,
    //  普通验证码
    "VERIFICATION_CODE_REGEX": /^\d{4}$/,
    //  短信/语音验证码 长度: 6位数字
    "SMS_AND_VOICE_CAPTCHA_REGEX": /^\d{6}$/,
    //  普通验证码 长度: 4位数字
    "generalCaptchaReguler": /^\d{4}$/,
    //  推荐码 长度:5~8位数字
    "recommendCodeRegular": /^\d{5,8}$/,
    //  忘记密码计时key
    "forgetPwdKey": "forgetPwdKey",
    //  动态码登录计时key
    "smsLoginKey": "smsLoginKey",
    //  VIP 站URL前缀
    "vipPrefix": "",
    //市
    "CITY_NAME_REGEX": /^[\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。]{0,18}[\u4e00-\u9fa5] | [\u4e00-\u9fa5][\u4e00-\u9fa5\\.·•。（]{0,18}[\u4e00-\u9fa5][）]?$/

}
