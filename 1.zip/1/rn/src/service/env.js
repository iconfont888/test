import AppStorage from "../util/AppStorage";
import MyGlobal from "../common/MyGlobal";
import AppModule from "../common/AppModule";

/*
 * @Description: 接口根地址配置
 * @Author: ian
 * @LastEditors: Please set LastEditors
 * @Date: 2019-04-05 09:38:51
 * @LastEditTime: 2019-07-31 08:33:49
 */

//全局默认环境url, 注意global需要先声明才能使用
// global.baseUrl = 'http://10.11.16.204:6201'  //dev
// global.baseUrl = 'http://10.11.36.132:8002'  //ian

//global.baseUrl = 'http://10.11.36.52:8888'  //james
// global.baseUrl = 'http://10.11.36.48:9993'  //yancy
// global.baseUrl = 'http://10.11.36.48:6010'  //yancy
// global.baseUrl = 'http://10.11.36.49:7777'; //niki
// niki2
// global.baseUrl = 'http://10.11.36.49:8888/'
//
//   global.baseUrl ='http://10.11.16.116:9955'//test
// const PE = 'https://testm.ag9.com'
const PE = 'https://m.ag13842.com'
const UAT = 'http://uatm.ag288.com'
const SIT = 'http://10.11.16.116:9911'
const DEV = 'http://10.11.16.209:8019'
// const PE = SIT

// best
// global.baseUrl = 'http://10.11.36.41:8109'

console.log('global.baseUrl', global.baseUrl)
export const baseUrl = () => {

  const env = AppModule.getInstance().CODE_PUSH_TYPE
  let baseUrl
  switch (env) {
    case "PE":
      baseUrl = PE
      break;
    case "UAT":
      baseUrl = UAT
      break;
    case "SIT":
      baseUrl = SIT
      break;
    default://DEV
      baseUrl = DEV
      break;
  }

  // return global.baseUrl
  let currentDomain = MyGlobal.currentDomain
  let customPath = AppModule.getInstance().DOMAIN_API_PATH
  if(customPath){
    currentDomain = customPath
  }
  return currentDomain ? currentDomain : baseUrl
}

export const defaultLoopPath = () => {
  return [
    'https://b79-01.cdnp1.com/mobile/B79/mobileweb.json',
    'https://b79-01.cdnp2.com/mobile/B79/mobileweb.json',
    'https://b79-01.cdnp3.com/mobile/B79/mobileweb.json'
  ]
}

