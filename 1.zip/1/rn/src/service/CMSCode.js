/**
 *Created by Lili 2019/4/25
 * CMS moduleCodes
 **/
export default {
    CMS_HOME_SWIPER: '070101',//首页轮播图
    CMS_USER_DRAWER:'070102',//首页侧边栏
    CMS_TOP_MENU:'070103',//首页top menu
    CMS_PLAYER_LOVE:'070104',//玩家最爱
    CMS_TOP_NEWS: '070105',//亚洲头条，跑马灯
    CMS_NEW_GAME:'070106',//最新游戏
    CMS_GAME_DOWNLOAD:'070108',//客户端下载
    CMS_EXCLUSIVE_OFFER:'070109',//站内信-专属优惠
    CMS_NEW_PROMOTIONS:'070110',//新人优惠
    CMS_HOME_MODEL:'070111',//首页弹框,
    CMS_REGISTERED_BADGE:'070112',//首页注册角标badge,
    CMS_NB_QUICK_BET:'070000',//nb快捷投注
    CMS_SAVE_URL_MODEL: '030901',// 保存网址功能
}
