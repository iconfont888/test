

# 常见命令行运行失败处理方式
## 1.Android Gradle编译时文件被占用(android\app\build\xxx\xxx\xxx\r\xxx\xxx)
>
>   * What went wrong:
>   Failed to capture fingerprint of output files for task ':app:processDebugResources' property 'sourceOutputDir' during up-to-date check.
>   Could not read path 'D:\project\project_rn\tcbs-app-rn\android\app\build\generated\not_namespaced_r_class_sources\debug\processDebugResources\r\android'.

>处理方式:删除目录android\app\build下build这整个文件夹,或直接使用react-native start命令启动服
>务即可,一般没有新的link或app代码没有改动的情况下app是不需要重新编译的

 ---

## 2.Android使用cmd或powershell运行
> 由于Android项目使用了渠道分包,在运行时需要增加对应的渠道参数才能正常安装apk到手机或模拟器上,否则会出现Activity class {xxxx/xxxx.MainActivity} does not exist.

> react-native.cmd run-android --appId com.pn.androidgame.app

>如使用vscode则可以直接用vscode自带的Debug Android运行,对应参数已经添加进去

## 3.在link之后提示gradle失败
> link之后要检查android\settings.gradle文件,查看刚刚添加的组件的路径的斜杠 '/' 是否写反了, '\'是错误的
> 将其修正后即可正常

## 4. 非debug模式 千万不要 console.log(this) 和 console.log(react组件) 容易引起卡顿
