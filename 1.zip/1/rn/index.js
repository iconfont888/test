/**
 * @format
 */

import {AppRegistry,Text,TextInput} from 'react-native';
import App from './App';
import {name as appName} from './app.json';
import { Input } from 'react-native-elements';


Text.defaultProps = Object.assign({},Text.defaultProps,{allowFontScaling:false})
TextInput.getDefaultProps = Object.assign({},TextInput.defaultProps,{allowFontScaling:false})
Input.defaultProps = Object.assign({},Input.defaultProps,{allowFontScaling:false})

AppRegistry.registerComponent(appName, () => App);

if (!__DEV__) {
    global.console = {
      info: () => {},
      log: () => {},
      warn: () => {},
      debug: () => {},
      error: () => {}
    };
  }
