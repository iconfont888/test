package com.pn.androidgame.app;

import android.app.Application;

import com.BV.LinearGradient.LinearGradientPackage;
import com.beefe.picker.PickerViewPackage;
import com.cmcewen.blurview.BlurViewPackage;
import com.facebook.react.ReactApplication;
import com.RNFetchBlob.RNFetchBlobPackage;
import com.rnfs.RNFSPackage;
import com.psykar.cookiemanager.CookieManagerPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;
import com.github.yamill.orientation.OrientationPackage;
import com.horcrux.svg.SvgPackage;
import com.learnium.RNDeviceInfo.RNDeviceInfo;
import com.microsoft.codepush.react.CodePush;
import com.oblador.vectoricons.VectorIconsPackage;
import com.pn.androidgame.app.baidu.BaiduCountHelper;
import com.pn.androidgame.app.umeng.PushModule;
import com.pn.androidgame.app.util.ProcessUtils;
import com.react.rnspinkit.RNSpinkitPackage;
import com.reactnativecommunity.webview.RNCWebViewPackage;
import com.swmansion.gesturehandler.react.RNGestureHandlerPackage;
import com.swmansion.reanimated.ReanimatedPackage;
import com.tcbs_app_rn.AndroidReactPackage;

import org.devio.rn.splashscreen.SplashScreenReactPackage;

import java.util.Arrays;
import java.util.List;

public class MainApplication extends Application implements ReactApplication {

    private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {

        @Override
        protected String getJSBundleFile() {
            return CodePush.getJSBundleFile();
        }

        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            return Arrays.<ReactPackage>asList(
                    new MainReactPackage(),
            new RNFetchBlobPackage(),
            new RNFSPackage(),
            new CookieManagerPackage(),
            new PickerViewPackage(),
            new RNDeviceInfo(),
            new OrientationPackage(),
            new RNSpinkitPackage(),
                    new BlurViewPackage(),
                    new SvgPackage(),
                    new ReanimatedPackage(),
                    new LinearGradientPackage(),
                    new RNGestureHandlerPackage(),
                    new RNCWebViewPackage(),
                    new VectorIconsPackage(),
                    new CodePush(getCodePushKey(), getApplicationContext(), BuildConfig.DEBUG),
                    new SplashScreenReactPackage(),
                    new AndroidReactPackage()

            );
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }

        private String getCodePushKey(){
            String codePushKey;
            if (BuildConfig.CODE_PUSH_TYPE.equals("PE")){
                codePushKey=BuildConfig.CODE_PUSH_PE;
            }else if(BuildConfig.CODE_PUSH_TYPE.equals("UAT")) {
                codePushKey=BuildConfig.CODE_PUSH_UAT;
            }else if(BuildConfig.CODE_PUSH_TYPE.equals("SIT")) {
                codePushKey=BuildConfig.CODE_PUSH_SIT;
            }else {
                codePushKey=BuildConfig.CODE_PUSH_DEV;
            }
            return codePushKey;
        }
    };

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        SoLoader.init(this, /* native exopackage */ false);
        //友盟注册,必须在这个时候才能注册成功,不能在PushModule对象初始化的时候注册!!!而且不能放在下面主线程中调用
        PushModule.Companion.register(this);
        if (ProcessUtils.INSTANCE.isMainProcess(this)) {
            //百度埋点,为防止启动次数记录过多导致异常,需要在主线程启动
            BaiduCountHelper.INSTANCE.init(this);
        }

    }
}
