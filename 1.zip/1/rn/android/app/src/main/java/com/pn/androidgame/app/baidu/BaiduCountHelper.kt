package com.pn.androidgame.app.baidu

import android.content.Context
import com.baidu.mobstat.StatService
import com.pn.androidgame.app.BuildConfig
import com.pn.androidgame.app.util.LogUtils
import com.pn.androidgame.app.util.ProcessUtils
import com.pn.androidgame.app.util.UAHelper
import com.pn.androidgame.app.util.WDevice

/**
 * Created by Kobe on 2019/2/26
 */
object BaiduCountHelper {
    private const val TAG = "BaiduDSHelper";
    fun init(context: Context) {
        if (ProcessUtils.isMainProcess(context)) {
            StatService.setAppKey(BuildConfig.BaiduMobAd_STAT_ID)
            StatService.setAppChannel(context, UAHelper.extra(context), true)
            StatService.setOn(context, StatService.EXCEPTION_LOG)
            StatService.setLogSenderDelayed(15000)
            StatService.setDebugOn(BuildConfig.DEBUG)
            //StatService.enableDeviceMac(this,false);
            //StatService.setForTv(this,true);
            StatService.setAppVersionName(context, WDevice.getVersionName(context))
            StatService.start(context)
            LogUtils.i(TAG, "init","baidu init start")
        }
    }
}