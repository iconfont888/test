package com.pn.androidgame.app;

import android.os.Bundle;
import android.webkit.WebView;

import com.facebook.react.ReactActivity;
import com.pn.androidgame.app.baidu.LocationListener;
import com.pn.androidgame.app.baidu.LocationService;
import com.umeng.message.PushAgent;

public class MainActivity extends ReactActivity {
    private LocationService locationService=null;
    private LocationListener mListener=null;
    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "tcbs_app_rn";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //开启浏览器调试
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        locationService=new LocationService(this);
        //SplashScreen.show(this);
        super.onCreate(savedInstanceState);
        PushAgent.getInstance(this).onAppStart();
    }

    @Override
    protected void onStart() {
        super.onStart();
        mListener = new LocationListener(this);
        if (locationService!=null){
            locationService.registerListener(mListener);
            locationService.setLocationOption(locationService.getDefaultLocationClientOption());
            locationService.start();
        }
    }

    @Override
    protected void onStop() {
        if (locationService!=null){
            locationService.unregisterListener(mListener);
            locationService.stop();
        }
        super.onStop();
    }
}
