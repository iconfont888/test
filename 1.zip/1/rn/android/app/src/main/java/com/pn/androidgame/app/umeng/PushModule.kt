package com.pn.androidgame.app.umeng

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import com.facebook.react.bridge.*
import com.pn.androidgame.app.AppModule
import com.pn.androidgame.app.BuildConfig
import com.pn.androidgame.app.Constant
import com.pn.androidgame.app.util.LogUtils
import com.pn.androidgame.app.util.SendEventHelper
import com.pn.androidgame.app.util.UAHelper
import com.umeng.commonsdk.UMConfigure
import com.umeng.message.*
import com.umeng.message.common.UmengMessageDeviceConfig
import com.umeng.message.entity.UMessage
import com.umeng.message.inapp.InAppMessageManager
import com.umeng.message.tag.TagManager

class PushModule : ReactContextBaseJavaModule {



    private var mPushAgent: PushAgent
    var aliasType = BuildConfig.UMENG_ALIASTYPE

    private val reactContext: ReactApplicationContext?

    constructor(reactContext: ReactApplicationContext?) : super(reactContext) {
        this.reactContext = reactContext
        this.mSDKHandler = Handler(Looper.getMainLooper())
        mPushAgent= PushAgent.getInstance(reactContext)
        UMConfigure.setLogEnabled(BuildConfig.DEBUG)
        init()
        LogUtils.i(TAG,"init","友盟初始化完成")
    }

    companion object {
        private val TAG = "PushModule";
        private val appkey = BuildConfig.UMENG_APPKEY
        private var channel= BuildConfig.CHANNEL    //设置默认渠道，防止获取为空
        private val messageSecret = BuildConfig.UMENG_MESSAGE_SECRET
        private val deviceType = 0


        fun register(context: Context){
            //开启测试模式
            InAppMessageManager.getInstance(context).setInAppMsgDebugMode(BuildConfig.DEBUG)
            //友盟初始化
            var channel = UAHelper.extra(context)
            if(!TextUtils.isEmpty(BuildConfig.CHANNEL)){
                channel =BuildConfig.CHANNEL
            }
            UMConfigure.init(context, appkey, channel, deviceType, messageSecret)
            //通知栏信息显示条数
            PushAgent.getInstance(context).displayNotificationNumber=3
            //注册
            PushAgent.getInstance(context).register(object : IUmengRegisterCallback {
                override fun onSuccess(deviceToken: String) {
                    //注册成功会返回device token
                    LogUtils.i(TAG,"register","注册成功","deviceToken=$deviceToken")
                    //SendEventHelper.sendEvent(reactContext,Constant.NATIVE_EVENT_MESSAGE,SendEventHelper.createParams("友盟注册成功 deviceToken=$deviceToken",SUCCESS))
                }

                override fun onFailure(s: String, s1: String) {
                    LogUtils.i(TAG,"register","注册失败",s," && ",s1)
                    //SendEventHelper.sendEvent(reactContext,Constant.NATIVE_EVENT_MESSAGE,SendEventHelper.createParams("友盟注册失败 $s&&$s1",ERROR))
                }
            })
        }

    }


    private val mSDKHandler: Handler

    override fun getName(): String {
        return "UMPushModule"
    }

    private fun runOnMainThread(runnable: Runnable) {
        mSDKHandler.postDelayed(runnable, 0)
    }

    fun init() {

        //点击通知栏监听
        val notificationClickHandler = object : UmengNotificationClickHandler() {
            /**
             * 自定义消息回调
             * @param context
             * @param msg
             */
           /* override fun dealWithCustomAction(context: Context?, msg: UMessage) {
                Toast.makeText(context, msg.custom, Toast.LENGTH_LONG).show()
            }*/

            /**
             * 正常打开app消息回调
             * @param context
             * @param uMessage
             */
            override fun launchApp(context: Context, uMessage: UMessage?) {
                super.launchApp(context, uMessage)
                LogUtils.i(TAG,"launchApp","点击推送",uMessage?:0)

                SendEventHelper.sendEvent(reactContext, Constant.NATIVE_EVENT_UMENG_NOTIFICATION_CLICK, SendEventHelper.createParams("推送通知被点击 $uMessage", AppModule.SUCCESS,uMessage))
                /*Handler().post {
                    if (uMessage?.extra!=null){
                        val eventMessage = EventMessage()
                        eventMessage.code=RxCode.U_PUSH_URL
                        eventMessage.message=uMessage.extra["url"]
                        RxBus.getRxInstance().post(eventMessage)
                        LogUtils.i(TAG,"launchApp","跳转链接","url=${eventMessage.message}")
                    }
                }*/
            }

            /**
             * 打开url的回调
             * @param context
             * @param uMessage
             */
            /*override fun openUrl(context: Context, uMessage: UMessage) {
                super.openUrl(context, uMessage)
            }*/
        }
        mPushAgent.notificationClickHandler = notificationClickHandler


        //收到信息回调
        val messageHandler = object : UmengMessageHandler() {
            /**
             * 通知的回调方法
             * @param context
             * @param msg
             */
            override fun dealWithNotificationMessage(context: Context, msg: UMessage) {
                LogUtils.i(TAG, "dealWithNotificationMessage","收到消息","title=${msg.title}","text=${msg.text}")
                SendEventHelper.sendEvent(reactContext, Constant.NATIVE_EVENT_MESSAGE, SendEventHelper.createParams("友盟收到消息 title=${msg.title}\",\"text=${msg.text}",200,msg))
                //调用super则会走通知展示流程，不调用super则不展示通知
                super.dealWithNotificationMessage(context, msg)

            }

        }
        mPushAgent.messageHandler = messageHandler

    }

    @ReactMethod
    fun addTag(tag: String, successCallback: Promise) {
        mPushAgent.tagManager.addTags(TagManager.TCallBack { isSuccess, result ->
            if (isSuccess) {
                successCallback.resolve(SendEventHelper.createSuccess(result))
            } else {
                successCallback.reject(AppModule.FAILED.toString(),"添加标签失败")
            }
        }, tag)
    }

    @ReactMethod
    fun deleteTag(tag: String, successCallback: Promise) {
        mPushAgent.tagManager.deleteTags(TagManager.TCallBack { isSuccess, result ->
            LogUtils.i(TAG, "deleteTag","isSuccess:$isSuccess")
            if (isSuccess) {
                successCallback.resolve(SendEventHelper.createSuccess(result))
            } else {
                successCallback.reject(AppModule.FAILED.toString(),"删除标签失败")
            }
        }, tag)

    }


    @ReactMethod
    fun listTag(successCallback: Promise) {
        mPushAgent.tagManager.getTags { isSuccess, result ->
            mSDKHandler.post(Runnable {
                if (isSuccess) {
                    if (result != null) {
                        successCallback.resolve(SendEventHelper.createSuccess(resultToList(result)))
                    } else {
                        successCallback.reject(AppModule.FAILED.toString(), resultToList(result).toString())
                    }
                } else {
                    successCallback.reject(AppModule.FAILED.toString(), resultToList(result).toString())
                }
            })
        }
    }

    @ReactMethod
    fun addAlias(alias: String, aliasType: String, successCallback: Promise) {
        mPushAgent.addAlias(alias, aliasType) { isSuccess, message ->
            LogUtils.i(TAG, "addAlias","isSuccess:$isSuccess,$message")


            if (isSuccess) {
                successCallback.resolve(SendEventHelper.createSuccess())
            } else {
                successCallback.reject(AppModule.FAILED.toString(),message?:"")
            }
        }
    }

   /* @ReactMethod
    fun addAliasType() {

        //Toast.makeText(ma, "function will come soon", Toast.LENGTH_LONG)
    }*/


    @ReactMethod
    fun addExclusiveAlias(exclusiveAlias: String, aliasType: String, successCallback: Promise) {
        mPushAgent.setAlias(exclusiveAlias, aliasType) { isSuccess, message ->
            LogUtils.i(TAG, "addExclusiveAlias","isSuccess:$isSuccess,$message")
            if (java.lang.Boolean.TRUE == isSuccess) {
                successCallback.resolve(SendEventHelper.createSuccess(message))
            } else {
                successCallback.reject(AppModule.FAILED.toString(),message?:"")
            }
        }
    }

    @ReactMethod
    fun deleteAlias(alias: String, aliasType: String, successCallback: Promise) {
        mPushAgent.deleteAlias(alias, aliasType) { isSuccess, s ->
            if (java.lang.Boolean.TRUE == isSuccess) {
                successCallback.resolve(SendEventHelper.createSuccess())
            } else {
                successCallback.reject(AppModule.FAILED.toString(),s?:"")
            }
        }
    }

    @ReactMethod
    fun appInfo(successCallback: Promise) {
        val pkgName = reactContext!!.getPackageName()
        val info = String.format("DeviceToken:%s\n" + "SdkVersion:%s\nAppVersionCode:%s\nAppVersionName:%s",
                mPushAgent.registrationId, MsgConstant.SDK_VERSION,
                UmengMessageDeviceConfig.getAppVersionCode(reactContext), UmengMessageDeviceConfig.getAppVersionName(reactContext))
        successCallback.resolve(SendEventHelper.createSuccess("应用包名:$pkgName\n$info"))
    }

    private fun resultToList(result: List<String>?): WritableArray {
        val list = Arguments.createArray()
        if (result != null) {
            for (key in result) {
                list.pushString(key)
            }
        }
        LogUtils.i(TAG,"resultToList", "list=$list")
        return list
    }
}