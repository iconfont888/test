package com.pn.androidgame.app.util

import android.content.Context
import android.text.TextUtils
import android.util.Log
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/**
 * Created by Nereus on 2018/4/20.
 */

object UAHelper {


    fun getNewUAString(originUA: String, context: Context): String {
        val versinName = WDevice.getVersionName(context)
        var newUserAgent = "$originUA/app/b79/android/hybrid/$versinName"
        val extra = extra(context)
        if (!TextUtils.isEmpty(extra)) {
            newUserAgent += "/$extra"
        }
        Log.i("UAHelper getNewUAString", "newUA:$newUserAgent")
        return newUserAgent
    }

    fun extra(context: Context): String {
        var reader: BufferedReader? = null
        try {
            val inputStream = context.assets.open("domain.txt")
            reader = BufferedReader(InputStreamReader(inputStream))
            val channel = reader.readLine()
            Log.i("UAHelper extra", "channel:$channel")
            return channel
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            try {
                reader?.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }

        }
        return ""
    }


}
