package com.pn.androidgame.app.util

import android.app.ActivityManager
import android.content.Context

/**
 * Created by Kobe on 2019/2/25
 */
object ProcessUtils {
    /**
     * 获取当前进程名
     */
    private fun getCurrentProcessName(applicationContext: Context): String {
        val pid = android.os.Process.myPid()
        var processName = ""
        try {
            val manager = applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (process in manager.getRunningAppProcesses()) {
                if (process.pid === pid) {
                    processName = process.processName
                }
            }
        }catch (e:Exception){

        }
        return processName
    }

    /**
     * 包名判断是否为主进程
     *
     * @param
     * @return
     */
    fun isMainProcess(applicationContext: Context): Boolean {
        return applicationContext.packageName == getCurrentProcessName(applicationContext)
    }

}