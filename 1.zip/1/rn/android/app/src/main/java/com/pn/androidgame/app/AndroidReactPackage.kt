package com.tcbs_app_rn

import android.view.View
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ReactShadowNode
import com.facebook.react.uimanager.ViewManager
import com.pn.androidgame.app.AppModule
import com.pn.androidgame.app.umeng.PushModule

/**
 * Created by Kobe on 2019/4/4
 *
 * Android模块统一管理类
 */
class AndroidReactPackage:ReactPackage {
    override fun createNativeModules(reactContext: ReactApplicationContext?): MutableList<NativeModule> {
        //有新的模块就直接在这里加
        return arrayListOf(
                AppModule(reactContext),
                PushModule(reactContext)
                )
    }

    override fun createViewManagers(reactContext: ReactApplicationContext?): MutableList<ViewManager<View, ReactShadowNode<*>>> {
        return arrayListOf()
    }
}