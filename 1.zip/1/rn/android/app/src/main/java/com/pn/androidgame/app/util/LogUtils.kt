//
// Source code recreated from isSupport .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.pn.androidgame.app.util

import android.text.TextUtils
import android.util.Log

object LogUtils {
    private val tagPrefix=""
    private var isFullLog = true
    private var level: Level? = null

    fun setEnableFullLog(flag: Boolean) {
        isFullLog = flag
    }

    fun setLogLevel(level: Level?) {
        if (level != null) {
            LogUtils.level = level
            if (isFullLog) {
                i("LogLevel", "set", "value", level)
            }
        }

    }

    fun v(tag: String, method: String, vararg objects: Any): Int {
        return if (isFullLog && isLevelConditionMatch(LogUtils.Level.Verbose)) Log.v(getTag(tag), getContent(method, *objects)) else 0
    }

    fun d(tag: String, method: String, vararg objects: Any): Int {
        return if (isFullLog && isLevelConditionMatch(LogUtils.Level.Debug)) Log.d(getTag(tag), getContent(method, *objects)) else 0
    }

    fun i(tag: String, method: String, vararg objects: Any): Int {
        return if (isFullLog && isLevelConditionMatch(LogUtils.Level.INFO)) Log.i(getTag(tag), getContent(method, *objects)) else 0
    }

    fun w(tag: String, method: String, vararg objects: Any): Int {
        return wt(tag, method, null, *objects)
    }

    fun wt(tag: String, method: String, throwable: Throwable?, vararg objects: Any): Int {
        return if (isFullLog && isLevelConditionMatch(LogUtils.Level.Warn)) Log.w(getTag(tag), getContent(method, *objects), throwable) else 0
    }

    fun e(tag: String, method: String, vararg objects: Any): Int {
        return et(tag, method, null, *objects)
    }

    fun et(tag: String, method: String, throwable: Throwable?, vararg objects: Any): Int {
        return if (isFullLog && isLevelConditionMatch(LogUtils.Level.Error)) Log.e(getTag(tag), getContent(method, *objects), throwable) else 0
    }

    private fun isLevelConditionMatch(level: Level): Boolean {
        return level.ordinal >= LogUtils.level!!.ordinal
    }

    private fun getTag(tag: String): String? {
        return if (!TextUtils.isEmpty(tag)) "$tagPrefix.$tag" else tag
    }

    private fun getContent(method: String?, vararg objects: Any): String {
        if (method == null && objects.isEmpty()) {
            return ""
        } else {
            val stringBuilder = StringBuilder()
            if (method != null) {
                stringBuilder.append(" ").append(method)
            }

            if (objects.isNotEmpty()) {
                var index: Int
                index = 0
                while (index + 1 < objects.size) {
                    stringBuilder.append(" ")
                    val `object` = objects[index]
                    ++index
                    stringBuilder.append(getObjectContent(`object`, objects[index]))
                    ++index
                }

                if (index == objects.size - 1) {
                    stringBuilder.append(" ")
                    stringBuilder.append(objects[index])
                }
            }

            return stringBuilder.toString()
        }
    }

    private fun getObjectContent(o1: Any?, o2: Any?): String {
        return (o1 ?: "").toString() + ": " + (o2 ?: "")
    }

    init {
        level = LogUtils.Level.INFO
    }

    enum class Level private constructor() {
        Verbose,
        Debug,
        INFO,
        Warn,
        Error
    }
}
