package com.pn.androidgame.app.finger

import android.hardware.fingerprint.FingerprintManager

interface FingerListener {
    /**
     * 开始识别
     */
    fun onStartListening()
    /**
     * 停止识别
     */
    fun onStopListening()
    /**
     * 识别成功
     */
    fun onSuccess(result:FingerprintManager.AuthenticationResult?)
    /**
     * 识别失败
     */
    fun onFail(isNormal:Boolean,code:Int)
    /**
     * 多次识别失败的回调
     */
    fun onAuthenticationError(errorCode:Int,errorString:CharSequence?)
    /**
     * 识别提示
     */
    fun onAuthenticationHelp(helpCode:Int,helpString:CharSequence?)
}