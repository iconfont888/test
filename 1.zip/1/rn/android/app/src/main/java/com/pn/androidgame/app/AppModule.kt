package com.pn.androidgame.app

import android.app.AlertDialog
import android.hardware.fingerprint.FingerprintManager
import android.text.TextUtils
import com.baidu.mobstat.StatService
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.pn.androidgame.app.finger.FingerListener
import com.pn.androidgame.app.finger.FingerUtil
import com.pn.androidgame.app.util.*
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader

/**
 * Created by Kobe on 2019/4/4
 */
class AppModule(private val reactContext: ReactApplicationContext?) : ReactContextBaseJavaModule(reactContext) {
    companion object {
        val SUCCESS = 200
        val ERROR = 500
        val FAILED = -1
    }

    override fun getName(): String {
        return "AppModule"
    }

    /**
     * 常量
     */
    override fun getConstants(): MutableMap<String, Any> {
        val map = HashMap<String, Any>()
        map["APPLICATION_ID"]=BuildConfig.APPLICATION_ID
        map["DEBUG"]=BuildConfig.DEBUG
        map["VERSION_CODE"]=BuildConfig.VERSION_CODE
        map["VERSION_NAME"]=BuildConfig.VERSION_NAME
        map["CODE_PUSH_TYPE"]=BuildConfig.CODE_PUSH_TYPE
        map["DOMAIN_API_PATH"]=BuildConfig.DOMAIN_API_PATH
        map["DOMAIN_LOOP_JSON_PATH"]=BuildConfig.DOMAIN_LOOP_JSON_PATH
        map["IS_JENKINS"]=BuildConfig.IS_JENKINS
        map["UMENG_ALIASTYPE"]=BuildConfig.UMENG_ALIASTYPE
        map["APP_PRODUCT_ID"]=BuildConfig.APP_PRODUCT_ID
        map["EXTRA_PARAMS"]=BuildConfig.EXTRA_PARAMS
        return map
    }

    /**
     * 获取DOMAIN_API_PATH
     */
    @ReactMethod
    fun getDomainApiPath(promise: Promise) {
        promise.resolve(SendEventHelper.createSuccess(
                hashMapOf("domain" to BuildConfig.DOMAIN_API_PATH)
        ))
    }

    /**
     * 获取DOMAIN_LOOP_JSON_PATH
     */
    @ReactMethod
    fun getDomainLoopJsonPath(promise: Promise) {
        promise.resolve(SendEventHelper.createSuccess(
                hashMapOf("paths" to BuildConfig.DOMAIN_LOOP_JSON_PATH)
        ))
    }

    /**
     * 获取定位文本
     */
    @ReactMethod
    fun getAddress(promise: Promise) {
        try {
            val address = PrefUtils(reactContext!!.applicationContext).getString(Constant.APP_ADDRESS, "")
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf("address" to address)
            ))
        } catch (e: Exception) {
            promise.reject(e)
        }
    }

    /**
     * 设置百度统计的用户(登陆后调用)
     */
    @ReactMethod
    fun setBaiduUserId(username: String,promise: Promise) {
        try {
            StatService.setUserId(reactContext, username)
            promise.resolve(SendEventHelper.createSuccess())
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }

    }

    /**
     * 检查是否支持指纹识别
     */
    @ReactMethod
    fun deviceSupportTouchID(promise: Promise) {
        try {
            val code = FingerUtil.checkFinger(reactContext!!)
            val msg = when (code) {
                FingerUtil.ERROR_NO_PERMISSION -> "没有指纹识别权限"
                FingerUtil.ERROR_NO_SUPPORT -> "该设备不支持指纹识别"
                FingerUtil.ERROR_NO_RECORD_FINGER -> "没有录入指纹"
                else -> "支持指纹识别"
            }
            promise.resolve(SendEventHelper.createParams(msg, code))
        } catch (e: Exception) {
            promise.reject(ERROR.toString(), "调用异常")
        }
    }


    /**
     * 开启指纹验证
     */
    @ReactMethod
    fun useTouchID(promise: Promise) {
        try {
            var dialog: AlertDialog? = null
            val fingerUtil = FingerUtil(reactContext!!)
            fingerUtil.startListening(object : FingerListener {
                override fun onStartListening() {
                    dialog = AlertDialog.Builder(reactContext.currentActivity)
                            .setTitle("指纹识别")
                            .setMessage("请录入您的指纹")
                            .setPositiveButton("取消") { dialog, which ->
                                dialog.dismiss()
                            }
                            .setCancelable(false)
                            .setOnDismissListener { fingerUtil.cancelListening() }
                            .show()
                }

                override fun onStopListening() {
                    promise.resolve(SendEventHelper.createParams("指纹验证取消", FingerUtil.CANCEL))
                }

                override fun onSuccess(result: FingerprintManager.AuthenticationResult?) {
                    if (dialog != null) {
                        dialog!!.dismiss()
                    }

                    promise.resolve(SendEventHelper.createParams("指纹验证成功", SUCCESS))
                }

                override fun onFail(isNormal: Boolean, code: Int) {
                    if (dialog != null) {
                        dialog!!.dismiss()
                    }
                    promise.resolve(SendEventHelper.createParams("指纹验证失败", code))
                }

                override fun onAuthenticationError(errorCode: Int, errorString: CharSequence?) {
                }

                override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                }

            })
        } catch (e: Exception) {
            promise.reject(ERROR.toString(), e.message)
        }
    }

    /**
     * 检查是否支持脸部识别
     */
    @ReactMethod
    fun deviceSupportFaceID(promise: Promise) {
        promise.resolve(SendEventHelper.createParams("该设备不支持脸部识别", 1))
    }


    /**
     * 开启脸部识别
     */
    @ReactMethod
    fun useFaceID(promise: Promise) {
        //空实现
        promise.reject(ERROR.toString(), "该设备不支持脸部识别")
    }

    /**
     * 获取App内置渠道域名
     */
    @ReactMethod
    fun getAppChannel(promise: Promise){
        var reader: BufferedReader? = null
        try {
            val inputStream = reactContext!!.getAssets().open("domain.txt")
            reader = BufferedReader(InputStreamReader(inputStream))
            var channel = reader.readLine()
            if(!TextUtils.isEmpty(BuildConfig.CHANNEL)){
               channel =BuildConfig.CHANNEL
            }
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf("channel" to channel)
            ))
            return
        } catch (e: IOException) {
            e.printStackTrace()
            promise.reject(ERROR.toString(),e.message)
        } finally {
            try {
                reader?.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }

        }
    }

    /**
     * 获取缓存大小
     */
    @ReactMethod
    fun getCacheSize(promise: Promise){
        try {
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf("cacheSize" to DataCleanManager.getCacheSize(File("/data/data/" + reactContext!!.packageName)))
            ))
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }
    }

    /**
     * 清除缓存
     */
    @ReactMethod
    fun clearAppData(promise: Promise){
        try {
            DataCleanManager.cleanApplicationData(reactContext!!)
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf("cacheSize" to DataCleanManager.getCacheSize(File("/data/data/" + reactContext!!.packageName)))
            ))
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }
    }


    /**
     * 获取设备码
     */
    @ReactMethod
    fun getDeviceId(promise: Promise){
        try {
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf("deviceId" to WDevice.getDeviceID(reactContext!!))
            ))
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }
    }

    /**
     * 获取网络信息
     */
    @ReactMethod
    fun getNetworkInfo(promise: Promise){
        try {
            promise.resolve(SendEventHelper.createSuccess(
                    hashMapOf(
                            "networkType" to NetUtils.getNetworkStateString(reactContext!!),
                            "networkOperators" to NetUtils.getOperatorName(reactContext!!)
                            )
            ))
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }
    }

    /**
     * 获取是否由Jenkins打包
     */
    @ReactMethod
    fun getIsJenkins(promise: Promise){
        try {
            promise.resolve(SendEventHelper.createSuccess(
                hashMapOf("isJenkins" to (BuildConfig.IS_JENKINS == "true"))
            ))
        }catch (e:Exception){
            promise.reject(ERROR.toString(),e.message)
        }
    }

    /**
     * 设置百度自定义埋点
     */
    @ReactMethod
    fun setBaiduEvent(key:String?,value:String?, promise: Promise){
        try {
            StatService.onEvent(reactContext,key,value)
        }catch (e:Exception){

        }
    }
}