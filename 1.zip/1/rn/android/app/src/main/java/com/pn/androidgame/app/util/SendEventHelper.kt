package com.pn.androidgame.app.util

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.google.gson.Gson
import com.pn.androidgame.app.AppModule
import com.pn.androidgame.app.Constant

/**
 * Created by Kobe on 2019/4/4
 */
object SendEventHelper {
    fun sendEvent(reactContext: ReactContext?, eventName: String, params: WritableMap? = null) {
        try {
            reactContext!!
                    .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                    .emit(eventName, params)
        } catch (e: Exception) {
            LogUtils.et("SendEventHelper", "sendEvent", e)
        }

    }

    fun createParams(msg: String = "", code: Int = 0, data: Any? = null): WritableMap {
        val writableMap = Arguments.createMap()
        //预留添加统一的参数
        writableMap.putInt(Constant.CODE, code)
        writableMap.putString(Constant.MSG, msg)
        try {
            writableMap.putString(Constant.DATA, Gson().toJson(data))
        } catch (e: Exception) {
        }

        return writableMap
    }

    fun createSuccess(data: Any? = null): WritableMap {
        return createParams("success", AppModule.SUCCESS, data)
    }
}